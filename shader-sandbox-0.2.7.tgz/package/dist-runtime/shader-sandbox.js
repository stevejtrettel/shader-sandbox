(function(){"use strict";try{if(typeof document<"u"){var r=document.createElement("style");r.appendChild(document.createTextNode(`[data-theme=auto]{--font-mono: monospace;--font-ui: inherit;--bg-primary: transparent;--bg-secondary: transparent;--bg-tertiary: transparent;--bg-canvas: #000000;--text-primary: currentColor;--text-secondary: color-mix(in srgb, currentColor 80%, transparent);--text-muted: color-mix(in srgb, currentColor 60%, transparent);--text-disabled: color-mix(in srgb, currentColor 40%, transparent);--border-primary: color-mix(in srgb, currentColor 15%, transparent);--border-secondary: color-mix(in srgb, currentColor 25%, transparent);--accent-primary: #4a9eff;--accent-primary-hover: #3a8eef;--accent-primary-active: #2a7edf;--accent-secondary: #7c4dff;--error-bg: rgba(204, 0, 0, .08);--error-text: #cc0000;--error-border: rgba(204, 0, 0, .2);--success-bg: rgba(76, 175, 80, .08);--success-text: #4caf50;--success-border: rgba(76, 175, 80, .2);--overlay-bg: rgba(0, 0, 0, .75);--overlay-backdrop: rgba(0, 0, 0, .95);--shadow-sm: none;--shadow-md: none;--shadow-lg: none;--code-bg: #fafafa;--code-text: #1e1e1e;--code-line-number: #999999;--code-line-border: #e0e0e0;--code-selection: rgba(173, 214, 255, .4);--syntax-comment: #6a9955;--syntax-keyword: #0000ff;--syntax-string: #a31515;--syntax-number: #098658;--syntax-operator: #1e1e1e;--syntax-function: #795e26;--syntax-class: #267f99;--syntax-punctuation: #1e1e1e;--tab-bg: transparent;--tab-text: color-mix(in srgb, currentColor 60%, transparent);--tab-text-hover: color-mix(in srgb, currentColor 80%, transparent);--tab-text-active: currentColor;--tab-border-active: currentColor;--button-bg: transparent;--button-border: color-mix(in srgb, currentColor 25%, transparent);--button-text: currentColor;--button-bg-hover: color-mix(in srgb, currentColor 10%, transparent);--button-border-hover: color-mix(in srgb, currentColor 40%, transparent);--button-text-hover: currentColor;--recompile-bg: color-mix(in srgb, currentColor 10%, transparent);--recompile-text: currentColor;--recompile-bg-hover: color-mix(in srgb, currentColor 15%, transparent);--recompile-bg-active: color-mix(in srgb, currentColor 20%, transparent);--image-viewer-bg: transparent;--pane-radius: 0;--pane-shadow: none}@media (prefers-color-scheme: dark){[data-theme=auto]{--error-bg: rgba(255, 107, 107, .1);--error-text: #ff6b6b;--error-border: rgba(255, 107, 107, .25);--success-bg: rgba(107, 207, 107, .1);--success-text: #6bcf6b;--success-border: rgba(107, 207, 107, .25);--code-bg: #1e1e1e;--code-text: #d4d4d4;--code-line-number: #858585;--code-line-border: #3a3a3a;--code-selection: rgba(38, 79, 120, .6);--syntax-comment: #6a9955;--syntax-keyword: #569cd6;--syntax-string: #ce9178;--syntax-number: #b5cea8;--syntax-operator: #d4d4d4;--syntax-function: #dcdcaa;--syntax-class: #4ec9b0;--syntax-punctuation: #d4d4d4}}[data-theme=light]{--font-mono: "Monaco", "Menlo", "Courier New", monospace;--font-ui: system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;--bg-primary: #f5f5f5;--bg-secondary: #ffffff;--bg-tertiary: #f8f8f8;--bg-canvas: #000000;--text-primary: #000000;--text-secondary: #333333;--text-muted: #666666;--text-disabled: #999999;--border-primary: #e0e0e0;--border-secondary: #cccccc;--accent-primary: #4a9eff;--accent-primary-hover: #3a8eef;--accent-primary-active: #2a7edf;--accent-secondary: #7c4dff;--error-bg: #fff0f0;--error-text: #cc0000;--error-border: #ffcccc;--success-bg: #e8f5e9;--success-text: #4caf50;--success-border: #4caf50;--overlay-bg: rgba(0, 0, 0, .75);--overlay-backdrop: rgba(0, 0, 0, .95);--shadow-sm: 0 2px 8px rgba(0, 0, 0, .1);--shadow-md: 0 10px 30px rgba(0, 0, 0, .2);--shadow-lg: 0 20px 60px rgba(0, 0, 0, .25);--code-bg: #ffffff;--code-text: #000000;--code-line-number: #999999;--code-line-border: #e0e0e0;--code-selection: rgba(173, 214, 255, .4);--syntax-comment: #6a9955;--syntax-keyword: #0000ff;--syntax-string: #a31515;--syntax-number: #098658;--syntax-operator: #000000;--syntax-function: #795e26;--syntax-class: #267f99;--syntax-punctuation: #000000;--tab-bg: #f8f8f8;--tab-text: #666666;--tab-text-hover: #333333;--tab-text-active: #000000;--tab-border-active: #4a9eff;--button-bg: transparent;--button-border: #cccccc;--button-text: #666666;--button-bg-hover: #f0f0f0;--button-border-hover: #999999;--button-text-hover: #333333;--recompile-bg: #e8e8e8;--recompile-text: #333333;--recompile-bg-hover: #d8d8d8;--recompile-bg-active: #c8c8c8;--image-viewer-bg: #f5f5f5;--pane-radius: 8px;--pane-shadow: var(--shadow-lg), var(--shadow-sm)}[data-theme=dark]{--font-mono: "Monaco", "Menlo", "Courier New", monospace;--font-ui: system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;--bg-primary: #1a1a1a;--bg-secondary: #252525;--bg-tertiary: #2a2a2a;--bg-canvas: #000000;--text-primary: #ffffff;--text-secondary: #e0e0e0;--text-muted: #a0a0a0;--text-disabled: #666666;--border-primary: #3a3a3a;--border-secondary: #4a4a4a;--accent-primary: #4a9eff;--accent-primary-hover: #5aadff;--accent-primary-active: #3a8eef;--accent-secondary: #9c7cff;--error-bg: #3a1a1a;--error-text: #ff6b6b;--error-border: #5a2a2a;--success-bg: #1a3a1a;--success-text: #6bcf6b;--success-border: #2a5a2a;--overlay-bg: rgba(0, 0, 0, .85);--overlay-backdrop: rgba(0, 0, 0, .98);--shadow-sm: 0 2px 8px rgba(0, 0, 0, .3);--shadow-md: 0 10px 30px rgba(0, 0, 0, .4);--shadow-lg: 0 20px 60px rgba(0, 0, 0, .5);--code-bg: #1e1e1e;--code-text: #d4d4d4;--code-line-number: #858585;--code-line-border: #3a3a3a;--code-selection: rgba(38, 79, 120, .6);--syntax-comment: #6a9955;--syntax-keyword: #569cd6;--syntax-string: #ce9178;--syntax-number: #b5cea8;--syntax-operator: #d4d4d4;--syntax-function: #dcdcaa;--syntax-class: #4ec9b0;--syntax-punctuation: #d4d4d4;--tab-bg: #2a2a2a;--tab-text: #a0a0a0;--tab-text-hover: #d0d0d0;--tab-text-active: #ffffff;--tab-border-active: #4a9eff;--button-bg: transparent;--button-border: #4a4a4a;--button-text: #a0a0a0;--button-bg-hover: #3a3a3a;--button-border-hover: #5a5a5a;--button-text-hover: #e0e0e0;--recompile-bg: #3a3a3a;--recompile-text: #e0e0e0;--recompile-bg-hover: #4a4a4a;--recompile-bg-active: #5a5a5a;--image-viewer-bg: #2a2a2a;--pane-radius: 8px;--pane-shadow: var(--shadow-lg), var(--shadow-sm)}[data-theme=system]{--font-mono: "Monaco", "Menlo", "Courier New", monospace;--font-ui: system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;--bg-primary: #f5f5f5;--bg-secondary: #ffffff;--bg-tertiary: #f8f8f8;--bg-canvas: #000000;--text-primary: #000000;--text-secondary: #333333;--text-muted: #666666;--text-disabled: #999999;--border-primary: #e0e0e0;--border-secondary: #cccccc;--accent-primary: #4a9eff;--accent-primary-hover: #3a8eef;--accent-primary-active: #2a7edf;--accent-secondary: #7c4dff;--error-bg: #fff0f0;--error-text: #cc0000;--error-border: #ffcccc;--success-bg: #e8f5e9;--success-text: #4caf50;--success-border: #4caf50;--overlay-bg: rgba(0, 0, 0, .75);--overlay-backdrop: rgba(0, 0, 0, .95);--shadow-sm: 0 2px 8px rgba(0, 0, 0, .1);--shadow-md: 0 10px 30px rgba(0, 0, 0, .2);--shadow-lg: 0 20px 60px rgba(0, 0, 0, .25);--code-bg: #ffffff;--code-text: #000000;--code-line-number: #999999;--code-line-border: #e0e0e0;--code-selection: rgba(173, 214, 255, .4);--syntax-comment: #6a9955;--syntax-keyword: #0000ff;--syntax-string: #a31515;--syntax-number: #098658;--syntax-operator: #000000;--syntax-function: #795e26;--syntax-class: #267f99;--syntax-punctuation: #000000;--tab-bg: #f8f8f8;--tab-text: #666666;--tab-text-hover: #333333;--tab-text-active: #000000;--tab-border-active: #4a9eff;--button-bg: transparent;--button-border: #cccccc;--button-text: #666666;--button-bg-hover: #f0f0f0;--button-border-hover: #999999;--button-text-hover: #333333;--recompile-bg: #e8e8e8;--recompile-text: #333333;--recompile-bg-hover: #d8d8d8;--recompile-bg-active: #c8c8c8;--image-viewer-bg: #f5f5f5;--pane-radius: 8px;--pane-shadow: var(--shadow-lg), var(--shadow-sm)}@media (prefers-color-scheme: dark){[data-theme=system]{--bg-primary: #1a1a1a;--bg-secondary: #252525;--bg-tertiary: #2a2a2a;--bg-canvas: #000000;--text-primary: #ffffff;--text-secondary: #e0e0e0;--text-muted: #a0a0a0;--text-disabled: #666666;--border-primary: #3a3a3a;--border-secondary: #4a4a4a;--accent-primary: #4a9eff;--accent-primary-hover: #5aadff;--accent-primary-active: #3a8eef;--accent-secondary: #9c7cff;--error-bg: #3a1a1a;--error-text: #ff6b6b;--error-border: #5a2a2a;--success-bg: #1a3a1a;--success-text: #6bcf6b;--success-border: #2a5a2a;--overlay-bg: rgba(0, 0, 0, .85);--overlay-backdrop: rgba(0, 0, 0, .98);--shadow-sm: 0 2px 8px rgba(0, 0, 0, .3);--shadow-md: 0 10px 30px rgba(0, 0, 0, .4);--shadow-lg: 0 20px 60px rgba(0, 0, 0, .5);--code-bg: #1e1e1e;--code-text: #d4d4d4;--code-line-number: #858585;--code-line-border: #3a3a3a;--code-selection: rgba(38, 79, 120, .6);--syntax-comment: #6a9955;--syntax-keyword: #569cd6;--syntax-string: #ce9178;--syntax-number: #b5cea8;--syntax-operator: #d4d4d4;--syntax-function: #dcdcaa;--syntax-class: #4ec9b0;--syntax-punctuation: #d4d4d4;--tab-bg: #2a2a2a;--tab-text: #a0a0a0;--tab-text-hover: #d0d0d0;--tab-text-active: #ffffff;--tab-border-active: #4a9eff;--button-bg: transparent;--button-border: #4a4a4a;--button-text: #a0a0a0;--button-bg-hover: #3a3a3a;--button-border-hover: #5a5a5a;--button-text-hover: #e0e0e0;--recompile-bg: #3a3a3a;--recompile-text: #e0e0e0;--recompile-bg-hover: #4a4a4a;--recompile-bg-active: #5a5a5a;--image-viewer-bg: #2a2a2a;--pane-radius: 8px;--pane-shadow: var(--shadow-lg), var(--shadow-sm)}}.unstyled{--pane-radius: 0 !important;--pane-shadow: none !important}:root{--glass-bg: rgba(30, 30, 35, .65);--glass-bg-hover: rgba(30, 30, 35, .8);--glass-border: 1px solid rgba(255, 255, 255, .1);--glass-shadow: 0 4px 16px rgba(0, 0, 0, .25), 0 2px 4px rgba(0, 0, 0, .15), inset 0 1px 0 rgba(255, 255, 255, .1);--glass-shadow-sm: 0 2px 8px rgba(0, 0, 0, .25), inset 0 1px 0 rgba(255, 255, 255, .08);--glass-blur: blur(20px);--glass-radius: 6px;--glass-radius-sm: 6px;--glass-text: rgba(255, 255, 255, .9);--glass-text-muted: rgba(255, 255, 255, .6)}.stats-container{position:absolute;bottom:12px;left:12px;z-index:1000;display:flex;flex-direction:column;align-items:flex-start;gap:6px}.fps-counter{padding:6px 10px;background:var(--glass-bg);color:var(--glass-text);font-family:var(--font-mono);font-size:11px;font-weight:500;border-radius:var(--glass-radius-sm);border:var(--glass-border);cursor:pointer;-webkit-user-select:none;user-select:none;backdrop-filter:var(--glass-blur);-webkit-backdrop-filter:var(--glass-blur);box-shadow:var(--glass-shadow-sm);transition:all .2s ease}.fps-counter:hover{background:var(--glass-bg-hover)}.stats-grid{display:flex;flex-direction:row;gap:6px;opacity:0;visibility:hidden;transform:translateY(8px);transition:opacity .2s ease,transform .2s ease,visibility .2s;pointer-events:none}.stats-grid.open{opacity:1;visibility:visible;transform:translateY(0);pointer-events:auto}.stat-item{padding:6px 10px;background:var(--glass-bg);border-radius:var(--glass-radius-sm);border:var(--glass-border);backdrop-filter:var(--glass-blur);-webkit-backdrop-filter:var(--glass-blur);box-shadow:var(--glass-shadow-sm);display:flex;flex-direction:column;align-items:center;gap:2px;min-width:48px}.stat-value{color:var(--glass-text);font-family:var(--font-mono);font-size:11px;font-weight:600;white-space:nowrap}.stat-label{color:var(--glass-text-muted);font-family:var(--font-ui);font-size:9px;font-weight:500;text-transform:uppercase;letter-spacing:.5px}.playback-controls{position:absolute;bottom:12px;right:12px;z-index:1000}.controls-menu-button{padding:6px 8px;background:var(--glass-bg);color:var(--glass-text);border:var(--glass-border);border-radius:var(--glass-radius-sm);cursor:pointer;backdrop-filter:var(--glass-blur);-webkit-backdrop-filter:var(--glass-blur);box-shadow:var(--glass-shadow-sm);transition:all .2s ease;display:flex;align-items:center;justify-content:center;width:44px;height:44px;font-size:20px;font-weight:300;line-height:1}.controls-menu-button:hover{background:var(--glass-bg-hover);transform:scale(1.05)}.controls-menu-button:active{transform:scale(.95)}.controls-grid{position:absolute;bottom:0;right:0;display:grid;grid-template-columns:44px 44px 44px 44px;grid-template-rows:44px 44px;gap:6px;opacity:0;visibility:hidden;transform:scale(.8);transform-origin:bottom right;transition:opacity .2s ease,transform .2s ease,visibility .2s;pointer-events:none}.controls-grid.open{opacity:1;visibility:visible;transform:scale(1);pointer-events:auto}.control-button{padding:6px 8px;background:var(--glass-bg);color:var(--glass-text);border:var(--glass-border);border-radius:var(--glass-radius-sm);cursor:pointer;backdrop-filter:var(--glass-blur);-webkit-backdrop-filter:var(--glass-blur);box-shadow:var(--glass-shadow-sm);transition:all .2s ease;display:flex;align-items:center;justify-content:center;width:44px;height:44px}.control-button:hover{background:var(--glass-bg-hover);transform:scale(1.05)}.control-button:active{transform:scale(.95)}.control-button svg{width:16px;height:16px;fill:currentColor}.playback-controls .controls-menu-button{position:relative;z-index:1}.playback-controls.open>.controls-menu-button{opacity:0;pointer-events:none}.shader-error-overlay{position:absolute;top:0;left:0;right:0;bottom:0;background:#000000f2;-webkit-backdrop-filter:blur(8px);backdrop-filter:blur(8px);display:flex;align-items:center;justify-content:center;z-index:2000;padding:60px;overflow-y:auto}.error-overlay-content{background:#1a1a1a;border-radius:6px;max-width:900px;width:100%;display:flex;flex-direction:column;box-shadow:0 20px 60px #000c,0 0 1px #ffffff1a;border:1px solid #2a2a2a;max-height:calc(100vh - 120px)}.error-header{display:flex;align-items:center;justify-content:space-between;padding:18px 24px;background:linear-gradient(135deg,#c62828,#b71c1c);color:#fff;border-radius:6px 6px 0 0;border-bottom:1px solid rgba(0,0,0,.3);box-shadow:0 2px 8px #0003}.error-title{font-size:15px;font-weight:600;font-family:var(--font-ui);display:flex;align-items:center;gap:8px;letter-spacing:-.01em}.error-close{background:transparent;border:none;color:#ffffffe6;font-size:24px;line-height:1;cursor:pointer;padding:0;width:32px;height:32px;display:flex;align-items:center;justify-content:center;border-radius:4px;transition:all .2s ease;opacity:.8}.error-close:hover{background:#ffffff26;opacity:1;transform:scale(1.05)}.error-body{padding:24px;overflow-y:auto;flex:1}.error-section{margin-bottom:24px}.error-section:last-child{margin-bottom:0}.error-pass-name{font-size:13px;font-weight:600;color:#ffa726;font-family:var(--font-mono);margin-bottom:10px;padding-bottom:6px;border-bottom:1px solid #2a2a2a;letter-spacing:.02em}.error-content{margin:0;padding:14px 16px;background:#0f0f0f;border-radius:4px;color:#ff6b6b;font-size:13px;font-family:var(--font-mono);line-height:1.6;overflow-x:auto;border:1px solid #2a2a2a;white-space:pre-wrap;word-break:break-word}.error-code-context{margin:12px 0 0;padding:14px 16px;background:#0d0d0d;border-radius:4px;color:#b0b0b0;font-size:12px;font-family:var(--font-mono);line-height:1.6;overflow-x:auto;border:1px solid #2a2a2a;white-space:pre}.error-code-context .context-line{color:#666;display:block}.error-code-context .error-line-highlight{color:#fff;background:#c6282840;display:block;font-weight:600;border-left:3px solid #c62828;margin-left:-16px;padding-left:13px}.context-lost-overlay{position:absolute;top:0;left:0;right:0;bottom:0;background:#000000e6;-webkit-backdrop-filter:blur(8px);backdrop-filter:blur(8px);display:flex;align-items:center;justify-content:center;z-index:3000}.context-lost-content{text-align:center;color:#fff;padding:40px}.context-lost-icon{margin-bottom:16px;opacity:.8}.context-lost-spinner{width:48px;height:48px;border:3px solid rgba(255,255,255,.2);border-top-color:#fff;border-radius:50%;margin:0 auto 16px;animation:context-lost-spin 1s linear infinite}@keyframes context-lost-spin{to{transform:rotate(360deg)}}.context-lost-title{font-size:18px;font-weight:600;margin-bottom:8px;font-family:var(--font-ui)}.context-lost-message{font-size:14px;opacity:.7;margin-bottom:20px;font-family:var(--font-ui)}.context-lost-reload{background:#fff;color:#000;border:none;padding:10px 24px;border-radius:6px;font-size:14px;font-weight:500;cursor:pointer;transition:transform .2s,box-shadow .2s;font-family:var(--font-ui)}.context-lost-reload:hover{transform:scale(1.02);box-shadow:0 4px 12px #fff3}.context-lost-reload:active{transform:scale(.98)}.recording-indicator{position:absolute;top:12px;right:12px;z-index:1000;display:flex;align-items:center;gap:6px;padding:6px 10px;background:#dc2626d9;border-radius:var(--glass-radius-sm);border:1px solid rgba(255,100,100,.3);backdrop-filter:var(--glass-blur);-webkit-backdrop-filter:var(--glass-blur);box-shadow:var(--glass-shadow-sm)}.recording-dot{width:8px;height:8px;background:#fff;border-radius:50%;animation:recording-pulse 1s ease-in-out infinite}@keyframes recording-pulse{0%,to{opacity:1}50%{opacity:.4}}.recording-text{color:#fff;font-family:var(--font-mono);font-size:11px;font-weight:600;letter-spacing:.5px}.control-button.recording{background:#dc2626b3;border-color:#ff64644d}.control-button.recording:hover{background:#dc2626d9}.control-button.recording svg{fill:#fff}.media-permission-banner{position:absolute;bottom:48px;left:50%;transform:translate(-50%);background:var(--glass-bg);backdrop-filter:blur(12px);-webkit-backdrop-filter:blur(12px);border:var(--glass-border);box-shadow:var(--glass-shadow);color:#ffffffe6;padding:8px 16px;border-radius:6px;font-size:13px;font-family:var(--font-ui);display:flex;align-items:center;gap:12px;z-index:100;white-space:nowrap}.media-banner-button{background:#4a9effcc;color:#fff;border:none;padding:4px 12px;border-radius:4px;cursor:pointer;font-size:13px;font-family:inherit}.media-banner-button:hover{background:#4a9eff}.script-error-overlay{position:absolute;bottom:48px;left:12px;right:12px;z-index:1500;pointer-events:auto}.script-error-content{background:#1a1a1a;border-radius:6px;box-shadow:0 8px 32px #0009,0 0 1px #ffffff1a;border:1px solid #2a2a2a;overflow:hidden}.script-error-header{display:flex;align-items:center;justify-content:space-between;padding:10px 14px;background:linear-gradient(135deg,#e65100,#bf360c);color:#fff;border-bottom:1px solid rgba(0,0,0,.3)}.script-error-header.disabled{background:linear-gradient(135deg,#6d4c41,#4e342e)}.script-error-header.warning{background:linear-gradient(135deg,#f9a825,#f57f17);color:#1a1a1a}.script-error-header.warning .script-error-close{color:#000000b3}.script-error-header.warning .script-error-close:hover{background:#00000026;color:#000000e6}.script-error-title{font-size:13px;font-weight:600;font-family:var(--font-mono);display:flex;align-items:center;gap:6px}.script-error-close{background:transparent;border:none;color:#ffffffe6;font-size:20px;line-height:1;cursor:pointer;padding:0;width:32px;height:32px;display:flex;align-items:center;justify-content:center;border-radius:4px;opacity:.8;transition:all .2s ease}.script-error-close:hover{background:#ffffff26;opacity:1}.script-error-message{margin:0;padding:10px 14px;color:#ffab91;font-size:12px;font-family:var(--font-mono);line-height:1.5;white-space:pre-wrap;word-break:break-word;max-height:80px;overflow-y:auto}.script-error-stack{margin:0;padding:6px 14px 10px;color:#888;font-size:11px;font-family:var(--font-mono);line-height:1.4;white-space:pre-wrap;word-break:break-word;max-height:60px;overflow-y:auto;border-top:1px solid #2a2a2a}.script-overlay{position:absolute;z-index:500;padding:6px 10px;background:var(--glass-bg);color:var(--glass-text);font-family:var(--font-mono);font-size:11px;border-radius:var(--glass-radius-sm);border:var(--glass-border);backdrop-filter:var(--glass-blur);-webkit-backdrop-filter:var(--glass-blur);box-shadow:var(--glass-shadow-sm);pointer-events:none;white-space:pre;max-width:calc(100% - 24px);overflow:hidden;text-overflow:ellipsis}.script-overlay.hidden{display:none}.script-overlay.top-left{top:12px;left:12px}.script-overlay.top-right{top:12px;right:12px}.script-overlay.bottom-left{bottom:12px;left:12px}.script-overlay.bottom-right{bottom:12px;right:12px}@media (prefers-reduced-motion: reduce){*,*:before,*:after{transition-duration:.01ms!important;animation-duration:.01ms!important;animation-iteration-count:1!important}}@media (max-width: 428px){.stats-container{bottom:8px;left:8px}.playback-controls{bottom:8px;right:8px}.script-error-overlay{left:8px;right:8px;bottom:40px}.script-overlay.top-left{top:8px;left:8px}.script-overlay.top-right{top:8px;right:8px}.script-overlay.bottom-left{bottom:8px;left:8px}.script-overlay.bottom-right{bottom:8px;right:8px}}.uniforms-panel-wrapper{position:absolute;top:16px;right:16px;z-index:100;display:flex;flex-direction:column;align-items:flex-end}.uniforms-toggle-button{width:44px;height:44px;padding:6px;background:var(--glass-bg);border:var(--glass-border);border-radius:var(--glass-radius-sm);color:var(--glass-text);cursor:pointer;backdrop-filter:var(--glass-blur);-webkit-backdrop-filter:var(--glass-blur);box-shadow:var(--glass-shadow-sm);transition:all .2s ease,opacity .15s ease;display:flex;align-items:center;justify-content:center}.uniforms-toggle-button:hover{background:var(--glass-bg-hover);transform:scale(1.05)}.uniforms-toggle-button:active{transform:scale(.95)}.uniforms-toggle-button svg{width:16px;height:16px}.uniforms-toggle-button.hidden{opacity:0;transform:scale(.8);pointer-events:none;position:absolute}.uniforms-panel{width:175px;max-height:calc(100% - 80px);background:var(--glass-bg);backdrop-filter:var(--glass-blur);-webkit-backdrop-filter:var(--glass-blur);border-radius:var(--glass-radius);border:var(--glass-border);box-shadow:var(--glass-shadow);overflow:hidden;display:flex;flex-direction:column;transform-origin:top right;transition:opacity .2s ease,transform .2s ease,max-height .2s ease}.uniforms-panel.closed{opacity:0;transform:scale(.25) translate(0);transform-origin:top right;pointer-events:none;max-height:0;padding:0}.uniforms-panel-wrapper.inline .uniforms-panel{transform:none;opacity:1;width:auto;min-width:200px;background:transparent;border:none;box-shadow:none;backdrop-filter:none;-webkit-backdrop-filter:none}.uniforms-panel-wrapper.inline{top:auto;bottom:16px;max-width:33%}.uniforms-panel-wrapper.inline .uniform-controls{padding:8px 10px;gap:6px;background:transparent}.uniforms-panel-wrapper.inline .uniform-controls-list{gap:8px}.uniforms-panel-wrapper.inline .uniform-control-label,.uniforms-panel-wrapper.inline .uniform-control-value{display:none}.uniforms-panel-wrapper.inline .uniform-control-float,.uniforms-panel-wrapper.inline .uniform-control-int{display:block;padding:0}.uniforms-panel-wrapper.inline .uniform-control-slider{width:100%;margin:0;height:5px;background:transparent;box-shadow:none;filter:drop-shadow(0 1px 2px rgba(0,0,0,.35))}.uniforms-panel-wrapper.inline .uniform-control-slider::-webkit-slider-runnable-track{height:5px;background:#fffffff2;border:1px solid rgba(0,0,0,.45);border-radius:999px;box-sizing:border-box}.uniforms-panel-wrapper.inline .uniform-control-slider::-moz-range-track{height:5px;background:#fffffff2;border:1px solid rgba(0,0,0,.45);border-radius:999px;box-sizing:border-box}.uniforms-panel-wrapper.inline .uniform-control-slider::-webkit-slider-thumb{width:14px;height:14px;margin-top:-5px;background:#fff;border:1.5px solid rgba(0,0,0,.8);box-shadow:none;box-sizing:border-box;border-radius:50%}.uniforms-panel-wrapper.inline .uniform-control-slider::-moz-range-thumb{width:14px;height:14px;background:#fff;border:1.5px solid rgba(0,0,0,.8);box-shadow:none;box-sizing:border-box;border-radius:50%}.uniforms-panel-header{padding:10px 14px;font-family:var(--font-ui);font-size:11px;font-weight:600;text-transform:uppercase;letter-spacing:.5px;color:var(--glass-text-muted);background:#ffffff08;border-bottom:1px solid rgba(255,255,255,.06);flex-shrink:0;display:flex;justify-content:space-between;align-items:center}.uniforms-panel-close{background:transparent;border:none;color:var(--glass-text-muted);font-size:18px;line-height:1;cursor:pointer;padding:0;width:32px;height:32px;display:flex;align-items:center;justify-content:center;border-radius:4px;transition:all .15s ease}.uniforms-panel-close:hover{background:#ffffff1a;color:var(--glass-text)}.uniforms-panel-content{flex:1;overflow-y:auto;overflow-x:hidden}.uniforms-panel .uniform-controls{padding:12px;gap:12px;background:transparent}.uniforms-panel .uniform-controls-header{display:none}.uniforms-panel .uniform-controls-list{gap:14px}.uniforms-panel .uniform-control{gap:6px}.uniforms-panel .uniform-control-label{font-size:11px;color:var(--glass-text)}.uniforms-panel .uniform-control-value{font-size:10px;padding:1px 4px;min-width:40px;color:var(--glass-text-muted);background:#0003;border-radius:3px}.uniforms-panel .uniform-control-slider{height:4px;background:#ffffff26}.uniforms-panel .uniform-control-slider::-webkit-slider-runnable-track{height:4px;background:#ffffff26}.uniforms-panel .uniform-control-slider::-webkit-slider-thumb{width:12px;height:12px;margin-top:-4px;background:#ffffffe6;box-shadow:0 1px 4px #0000004d}.uniforms-panel .uniform-control-slider::-moz-range-track{height:4px;background:#ffffff26}.uniforms-panel .uniform-control-slider::-moz-range-thumb{width:12px;height:12px;background:#ffffffe6;box-shadow:0 1px 4px #0000004d}.uniforms-panel .uniform-control-toggle{width:34px;height:18px}.uniforms-panel .uniform-control-toggle-slider{border-radius:18px}.uniforms-panel .uniform-control-toggle-slider:before{width:12px;height:12px;left:3px;bottom:3px}.uniforms-panel .uniform-control-toggle input:checked+.uniform-control-toggle-slider:before{transform:translate(16px)}.uniforms-panel .uniform-control-xy-pad{height:100px}.uniforms-panel .uniform-control-xy-handle{width:12px;height:12px}.uniforms-panel .uniform-control-color-swatch{height:28px}.uniforms-panel .uniform-control-vec-slider-row{gap:6px}.uniforms-panel .uniform-control-vec-component{font-size:9px;width:12px;color:var(--glass-text-muted)}.uniforms-panel .uniform-control-vec-value{font-size:9px;min-width:32px;color:var(--glass-text-muted);background:#0003;border-radius:3px}.uniforms-panel .uniform-control-xy-pad{background:#00000040;border:1px solid rgba(255,255,255,.1)}.uniforms-panel .uniform-control-xy-handle{background:#ffffffe6;box-shadow:0 1px 4px #0006}.uniforms-panel-content::-webkit-scrollbar{width:6px}.uniforms-panel-content::-webkit-scrollbar-track{background:transparent}.uniforms-panel-content::-webkit-scrollbar-thumb{background:#fff3;border-radius:3px}.uniforms-panel-content::-webkit-scrollbar-thumb:hover{background:#ffffff59}.uniform-controls{display:flex;flex-direction:column;gap:16px;padding:16px;height:100%;overflow-y:auto;background:var(--bg-secondary)}.uniform-controls-empty{color:var(--text-muted);font-size:13px;text-align:center;padding:20px}.uniform-controls-header{display:flex;justify-content:flex-end;padding-bottom:8px;border-bottom:1px solid var(--border-primary);margin-bottom:8px}.uniform-controls-reset{font-family:inherit;font-size:11px;padding:4px 10px;background:var(--bg-tertiary);color:var(--text-secondary);border:1px solid var(--border-primary);border-radius:4px;cursor:pointer;transition:background .15s ease,color .15s ease}.uniform-controls-reset:hover{background:var(--border-primary);color:var(--text-primary)}.uniform-controls-reset:active{transform:translateY(1px)}.uniform-controls-list{display:flex;flex-direction:column;gap:16px}.uniform-control{display:flex;flex-direction:column;gap:8px}.uniform-control-label-row{display:flex;justify-content:space-between;align-items:center}.uniform-control-label{font-family:var(--font-mono);font-size:12px;font-weight:500;color:var(--text-primary)}.uniform-control-value{font-family:var(--font-mono);font-size:11px;color:var(--text-muted);background:var(--bg-tertiary);padding:2px 6px;border-radius:3px;min-width:50px;text-align:right}.uniform-control-slider{-webkit-appearance:none;-moz-appearance:none;appearance:none;width:100%;height:6px;background:var(--border-primary);border-radius:3px;outline:none;cursor:pointer}.uniform-control-slider::-webkit-slider-runnable-track{height:6px;background:var(--border-primary);border-radius:3px}.uniform-control-slider::-webkit-slider-thumb{-webkit-appearance:none;-moz-appearance:none;appearance:none;width:14px;height:14px;background:var(--accent-primary);border-radius:50%;cursor:pointer;margin-top:-4px;transition:transform .15s ease,box-shadow .15s ease}.uniform-control-slider::-webkit-slider-thumb:hover{transform:scale(1.1);box-shadow:0 2px 6px #0003}.uniform-control-slider::-webkit-slider-thumb:active{transform:scale(.95)}.uniform-control-slider::-moz-range-track{height:6px;background:var(--border-primary);border-radius:3px}.uniform-control-slider::-moz-range-thumb{width:14px;height:14px;background:var(--accent-primary);border:none;border-radius:50%;cursor:pointer;transition:transform .15s ease,box-shadow .15s ease}.uniform-control-slider::-moz-range-thumb:hover{transform:scale(1.1);box-shadow:0 2px 6px #0003}.uniform-control-slider::-moz-range-thumb:active{transform:scale(.95)}.uniform-control-slider:focus{outline:none}.uniform-control-slider:focus::-webkit-slider-thumb{box-shadow:0 0 0 3px var(--code-selection)}.uniform-control-slider:focus::-moz-range-thumb{box-shadow:0 0 0 3px var(--code-selection)}.uniform-control-toggle{position:relative;display:inline-block;width:40px;height:22px;cursor:pointer}.uniform-control-toggle input{opacity:0;width:0;height:0}.uniform-control-toggle-slider{position:absolute;top:0;left:0;right:0;bottom:0;background:var(--border-primary);border-radius:22px;transition:background .2s ease}.uniform-control-toggle-slider:before{content:"";position:absolute;width:16px;height:16px;left:3px;bottom:3px;background:var(--text-muted);border-radius:50%;transition:transform .2s ease,background .2s ease}.uniform-control-toggle input:checked+.uniform-control-toggle-slider{background:var(--accent-primary)}.uniform-control-toggle input:checked+.uniform-control-toggle-slider:before{transform:translate(18px);background:#fff}.uniform-control-toggle input:focus+.uniform-control-toggle-slider{box-shadow:0 0 0 2px var(--code-selection)}.uniform-control-xy-pad{position:relative;width:100%;height:120px;background:var(--bg-tertiary);border:1px solid var(--border-primary);border-radius:4px;cursor:crosshair;overflow:hidden}.uniform-control-xy-pad:before,.uniform-control-xy-pad:after{content:"";position:absolute;background:var(--border-primary);opacity:.5}.uniform-control-xy-pad:before{left:50%;top:0;bottom:0;width:1px}.uniform-control-xy-pad:after{top:50%;left:0;right:0;height:1px}.uniform-control-xy-handle{position:absolute;width:14px;height:14px;background:var(--accent-primary);border:2px solid white;border-radius:50%;transform:translate(-50%,-50%);box-shadow:0 2px 4px #0000004d;pointer-events:none;z-index:1}.uniform-control-color-wrapper{display:flex;align-items:center;gap:8px}.uniform-control-color-swatch{width:100%;height:32px;border-radius:4px;border:1px solid var(--border-primary);cursor:pointer;transition:box-shadow .15s ease}.uniform-control-color-swatch:hover{box-shadow:0 0 0 2px var(--accent-primary)}.uniform-control-color-input{position:absolute;width:0;height:0;opacity:0;pointer-events:none}.uniform-control-vec3{gap:6px}.uniform-control-vec-slider-row{display:flex;align-items:center;gap:8px}.uniform-control-vec-component{font-family:var(--font-mono);font-size:10px;font-weight:600;color:var(--text-muted);width:14px;text-align:center}.uniform-control-vec-slider{flex:1}.uniform-control-vec-value{min-width:40px;font-size:10px}.screenshot-panel-backdrop{position:absolute;top:0;left:0;right:0;bottom:0;background:#000000b3;-webkit-backdrop-filter:blur(4px);backdrop-filter:blur(4px);display:flex;align-items:center;justify-content:center;z-index:4000}.screenshot-panel{background:#1a1a1f;border:1px solid rgba(255,255,255,.1);border-radius:10px;box-shadow:0 20px 60px #0009;width:380px;max-width:calc(100% - 32px);max-height:calc(100% - 32px);overflow-y:auto;font-family:var(--font-ui);color:#e0e0e0}.screenshot-panel-header{display:flex;align-items:center;justify-content:space-between;padding:14px 18px;background:linear-gradient(135deg,#2e7d32,#1b5e20);color:#fff;border-bottom:1px solid rgba(0,0,0,.3);border-radius:10px 10px 0 0}.screenshot-panel-title{font-size:14px;font-weight:600;display:flex;align-items:center;gap:8px}.screenshot-panel-close{background:transparent;border:none;color:#fffc;font-size:20px;line-height:1;cursor:pointer;padding:0;width:32px;height:32px;display:flex;align-items:center;justify-content:center;border-radius:4px;transition:all .15s ease}.screenshot-panel-close:hover{background:#ffffff26;color:#fff}.screenshot-panel-body{padding:18px;display:flex;flex-direction:column;gap:16px}.screenshot-section{display:flex;flex-direction:column;gap:6px}.screenshot-section-label{font-size:12px;font-weight:500;color:#fff9;text-transform:uppercase;letter-spacing:.5px}.screenshot-collapsible-header{font-size:12px;font-weight:500;color:#fff9;text-transform:uppercase;letter-spacing:.5px;cursor:pointer;-webkit-user-select:none;user-select:none;display:flex;align-items:center;gap:4px}.screenshot-collapsible-header:hover{color:#fffc}.screenshot-collapsible-arrow{font-size:10px;transition:transform .15s;display:inline-block}.screenshot-collapsible:not(.collapsed) .screenshot-collapsible-arrow{transform:rotate(90deg)}.screenshot-collapsible.collapsed .screenshot-section-content{display:none}.screenshot-section-content{padding-top:6px}.screenshot-input{background:#0f0f14;border:1px solid rgba(255,255,255,.1);border-radius:5px;color:#e0e0e0;font-family:var(--font-mono);font-size:13px;padding:7px 10px;outline:none;transition:border-color .15s}.screenshot-input:focus{border-color:#64c86480}.screenshot-input[type=number]{-moz-appearance:textfield}.screenshot-input[type=number]::-webkit-inner-spin-button,.screenshot-input[type=number]::-webkit-outer-spin-button{-webkit-appearance:none;margin:0}.screenshot-select{width:100%;cursor:pointer;-webkit-appearance:none;-moz-appearance:none;appearance:none;background-image:url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 12 12' fill='rgba(255,255,255,0.4)'%3E%3Cpath d='M3 5l3 3 3-3'/%3E%3C/svg%3E");background-repeat:no-repeat;background-position:right 10px center;padding-right:28px}.screenshot-res-row{display:flex;gap:8px;align-items:center}.screenshot-res-row .screenshot-input{flex:1;min-width:0}.screenshot-dim-separator{color:#fff6;font-size:13px;flex-shrink:0}.screenshot-aspect-lock{background:transparent;border:1px solid rgba(255,255,255,.15);border-radius:4px;color:#ffffff4d;cursor:pointer;padding:4px;display:flex;align-items:center;justify-content:center;transition:all .15s;flex-shrink:0}.screenshot-aspect-lock.active{color:#64c864cc;border-color:#64c8644d}.screenshot-aspect-lock:hover{border-color:#ffffff4d}.screenshot-time-slider{width:100%;height:4px;-webkit-appearance:none;-moz-appearance:none;appearance:none;background:#0f0f14;border-radius:2px;outline:none;margin:4px 0}.screenshot-time-slider::-webkit-slider-thumb{-webkit-appearance:none;width:14px;height:14px;border-radius:50%;background:#4caf50;cursor:pointer;border:2px solid #1a1a1f}.screenshot-time-slider::-moz-range-thumb{width:14px;height:14px;border-radius:50%;background:#4caf50;cursor:pointer;border:2px solid #1a1a1f}.screenshot-range-row{display:flex;gap:6px;align-items:center}.screenshot-range-input{width:70px;flex-shrink:0;font-size:11px!important;padding:5px 6px!important}.screenshot-unit{font-size:12px;color:#fff6;flex-shrink:0}.screenshot-time-row{display:flex;gap:8px;align-items:center}.screenshot-time-row .screenshot-input{flex:1}.screenshot-notice{font-size:11px;color:#ffc864b3;line-height:1.4;padding:6px 8px;background:#ffc8640d;border-radius:4px;border:1px solid rgba(255,200,100,.1)}.screenshot-progress{display:none;flex-direction:column;gap:6px}.screenshot-progress.active{display:flex}.screenshot-progress-bar-bg{height:6px;background:#0f0f14;border-radius:3px;overflow:hidden}.screenshot-progress-bar{height:100%;background:linear-gradient(90deg,#2e7d32,#66bb6a);border-radius:3px;width:0%;transition:width .1s ease}.screenshot-progress-text{font-size:12px;color:#ffffff80;font-family:var(--font-mono);text-align:center}.screenshot-panel-actions{display:flex;gap:8px;padding:0 18px 18px}.screenshot-btn{flex:1;padding:9px 16px;border-radius:6px;font-size:13px;font-weight:500;cursor:pointer;border:none;transition:all .15s;font-family:inherit}.screenshot-btn-primary{background:linear-gradient(135deg,#2e7d32,#1b5e20);color:#fff}.screenshot-btn-primary:hover{filter:brightness(1.1)}.screenshot-btn-primary.disabled{opacity:.5;cursor:not-allowed;filter:none;pointer-events:none}.screenshot-btn-secondary{background:#64c8641a;color:#64c864cc;border:1px solid rgba(100,200,100,.2);flex:0 0 auto}.screenshot-btn-secondary:hover{background:#64c86426}.screenshot-btn-cancel{background:#ffffff14;color:#ffffffb3;border:1px solid rgba(255,255,255,.1)}.screenshot-btn-cancel:hover{background:#ffffff1f}.recording-panel-backdrop{position:absolute;top:0;left:0;right:0;bottom:0;background:#000000b3;-webkit-backdrop-filter:blur(4px);backdrop-filter:blur(4px);display:flex;align-items:center;justify-content:center;z-index:4000}.recording-panel{background:#1a1a1f;border:1px solid rgba(255,255,255,.1);border-radius:10px;box-shadow:0 20px 60px #0009;width:380px;max-width:calc(100% - 32px);max-height:calc(100% - 32px);overflow-y:auto;font-family:var(--font-ui);color:#e0e0e0}.recording-panel-header{display:flex;align-items:center;justify-content:space-between;padding:14px 18px;background:linear-gradient(135deg,#1565c0,#0d47a1);color:#fff;border-bottom:1px solid rgba(0,0,0,.3);border-radius:10px 10px 0 0}.recording-panel-title{font-size:14px;font-weight:600;display:flex;align-items:center;gap:8px}.recording-panel-close{background:transparent;border:none;color:#fffc;font-size:20px;line-height:1;cursor:pointer;padding:0;width:32px;height:32px;display:flex;align-items:center;justify-content:center;border-radius:4px;transition:all .15s ease}.recording-panel-close:hover{background:#ffffff26;color:#fff}.recording-panel-body{padding:18px;display:flex;flex-direction:column;gap:16px}.recording-section{display:flex;flex-direction:column;gap:6px}.recording-section-label{font-size:12px;font-weight:500;color:#fff9;text-transform:uppercase;letter-spacing:.5px}.recording-collapsible-header{font-size:12px;font-weight:500;color:#fff9;text-transform:uppercase;letter-spacing:.5px;cursor:pointer;-webkit-user-select:none;user-select:none;display:flex;align-items:center;gap:4px}.recording-collapsible-header:hover{color:#fffc}.recording-collapsible-arrow{font-size:10px;transition:transform .15s;display:inline-block}.recording-collapsible:not(.collapsed) .recording-collapsible-arrow{transform:rotate(90deg)}.recording-collapsible.collapsed .recording-section-content{display:none}.recording-section-content{padding-top:6px}.recording-input{background:#0f0f14;border:1px solid rgba(255,255,255,.1);border-radius:5px;color:#e0e0e0;font-family:var(--font-mono);font-size:13px;padding:7px 10px;outline:none;transition:border-color .15s}.recording-input:focus{border-color:#648cff80}.recording-input[type=number]{-moz-appearance:textfield}.recording-input[type=number]::-webkit-inner-spin-button,.recording-input[type=number]::-webkit-outer-spin-button{-webkit-appearance:none;margin:0}.recording-select{width:100%;cursor:pointer;-webkit-appearance:none;-moz-appearance:none;appearance:none;background-image:url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 12 12' fill='rgba(255,255,255,0.4)'%3E%3Cpath d='M3 5l3 3 3-3'/%3E%3C/svg%3E");background-repeat:no-repeat;background-position:right 10px center;padding-right:28px}.recording-res-row{display:flex;gap:8px;align-items:center}.recording-res-row .recording-input{flex:1;min-width:0}.recording-dim-separator{color:#fff6;font-size:13px;flex-shrink:0}.recording-aspect-lock{background:transparent;border:1px solid rgba(255,255,255,.15);border-radius:4px;color:#ffffff4d;cursor:pointer;padding:4px;display:flex;align-items:center;justify-content:center;transition:all .15s;flex-shrink:0}.recording-aspect-lock.active{color:#648cffcc;border-color:#648cff4d}.recording-aspect-lock:hover{border-color:#ffffff4d}.recording-field-row{display:flex;gap:8px;align-items:center}.recording-field-row .recording-input{flex:1}.recording-field-label{font-size:12px;color:#ffffff80;width:75px;flex-shrink:0}.recording-unit{font-size:12px;color:#fff6;flex-shrink:0}.recording-format-group{display:flex;gap:8px}.recording-format-option{flex:1;position:relative}.recording-format-option input[type=radio]{position:absolute;opacity:0;pointer-events:none}.recording-format-option label{display:block;text-align:center;padding:8px;background:#0f0f14;border:1px solid rgba(255,255,255,.1);border-radius:5px;font-size:12px;font-weight:500;cursor:pointer;transition:all .15s}.recording-format-option label.disabled{opacity:.4;cursor:not-allowed}.recording-format-option input[type=radio]:checked+label{background:#648cff26;border-color:#648cff80;color:#8ab4ff}.recording-format-option label:hover:not(.disabled){border-color:#fff3}.recording-quality-row{display:flex;gap:8px;align-items:center;margin-top:4px}.recording-quality-row .recording-select{flex:1}.recording-estimate{font-size:11px;color:#fff6;font-family:var(--font-mono);text-align:center;padding:4px 0}.recording-notice{font-size:11px;color:#ffc864b3;line-height:1.4;padding:6px 8px;background:#ffc8640d;border-radius:4px;border:1px solid rgba(255,200,100,.1)}.recording-progress{display:none;flex-direction:column;gap:8px;padding:18px}.recording-progress.active{display:flex}.recording-progress-bar-bg{height:6px;background:#0f0f14;border-radius:3px;overflow:hidden}.recording-progress-bar{height:100%;background:linear-gradient(90deg,#1565c0,#42a5f5);border-radius:3px;width:0%;transition:width .1s ease}.recording-progress-text{font-size:12px;color:#ffffff80;font-family:var(--font-mono);text-align:center}.recording-panel-actions{display:flex;gap:8px;padding:0 18px 18px}.recording-btn{flex:1;padding:9px 16px;border-radius:6px;font-size:13px;font-weight:500;cursor:pointer;border:none;transition:all .15s;font-family:inherit}.recording-btn-primary{background:linear-gradient(135deg,#1565c0,#0d47a1);color:#fff}.recording-btn-primary:hover{filter:brightness(1.1)}.recording-btn-cancel{background:#ffffff14;color:#ffffffb3;border:1px solid rgba(255,255,255,.1)}.recording-btn-cancel:hover{background:#ffffff1f}.multi-view-controls-wrapper{position:absolute;top:16px;right:16px;z-index:100;display:flex;flex-direction:column;align-items:flex-end}.multi-view-controls-toggle{width:44px;height:44px;padding:6px;background:var(--glass-bg);border:var(--glass-border);border-radius:var(--glass-radius-sm);color:var(--glass-text);cursor:pointer;backdrop-filter:var(--glass-blur);-webkit-backdrop-filter:var(--glass-blur);box-shadow:var(--glass-shadow-sm);transition:all .2s ease,opacity .15s ease;display:flex;align-items:center;justify-content:center}.multi-view-controls-toggle:hover{background:var(--glass-bg-hover);transform:scale(1.05)}.multi-view-controls-toggle:active{transform:scale(.95)}.multi-view-controls-toggle svg{width:16px;height:16px}.multi-view-controls-toggle.hidden{opacity:0;transform:scale(.8);pointer-events:none;position:absolute}.multi-view-controls-panel{width:175px;max-height:calc(100vh - 100px);background:var(--glass-bg);backdrop-filter:var(--glass-blur);-webkit-backdrop-filter:var(--glass-blur);border-radius:var(--glass-radius);border:var(--glass-border);box-shadow:var(--glass-shadow);overflow:hidden;display:flex;flex-direction:column;transform-origin:top right;transition:opacity .2s ease,transform .2s ease,max-height .2s ease}.multi-view-controls-panel.closed{opacity:0;transform:scale(.25) translate(0);transform-origin:top right;pointer-events:none;max-height:0;padding:0}.multi-view-controls-header{padding:10px 14px;font-family:var(--font-ui);font-size:11px;font-weight:600;text-transform:uppercase;letter-spacing:.5px;color:var(--glass-text-muted);background:#ffffff08;border-bottom:1px solid rgba(255,255,255,.06);flex-shrink:0;display:flex;justify-content:space-between;align-items:center}.multi-view-controls-close{background:transparent;border:none;color:var(--glass-text-muted);font-size:18px;line-height:1;cursor:pointer;padding:0;width:32px;height:32px;display:flex;align-items:center;justify-content:center;border-radius:4px;transition:all .15s ease}.multi-view-controls-close:hover{background:#ffffff1a;color:var(--glass-text)}.controls-section{display:flex;flex-direction:column;gap:8px;padding:12px}.controls-section+.controls-section{padding-top:0}.section-label{font-size:10px;font-weight:600;text-transform:uppercase;letter-spacing:.5px;color:var(--glass-text-muted);padding-bottom:6px;border-bottom:1px solid rgba(255,255,255,.06);margin-bottom:4px}.playback-controls{flex-direction:row;gap:8px;padding:12px}.control-btn{width:44px;height:44px;border:none;border-radius:var(--glass-radius-sm);background:#ffffff1a;color:var(--glass-text);cursor:pointer;display:flex;align-items:center;justify-content:center;transition:all .15s ease}.control-btn:hover{background:#fff3}.control-btn:active{transform:scale(.95)}.control-btn svg{width:16px;height:16px}.uniforms-section{border-top:1px solid rgba(255,255,255,.06)}.uniforms-container{display:flex;flex-direction:column;gap:8px}.multi-view-controls-panel .uniform-controls{padding:0;gap:12px;background:transparent}.multi-view-controls-panel .uniform-controls-header{display:none}.multi-view-controls-panel .uniform-controls-list{gap:14px}.multi-view-controls-panel .uniform-control{gap:6px}.multi-view-controls-panel .uniform-control-label{font-size:11px;color:var(--glass-text)}.multi-view-controls-panel .uniform-control-value{font-size:10px;padding:1px 4px;min-width:40px;color:var(--glass-text-muted);background:#0003;border-radius:3px}.multi-view-controls-panel .uniform-control-slider{height:4px;background:#ffffff26}.multi-view-controls-panel .uniform-control-slider::-webkit-slider-runnable-track{height:4px;background:#ffffff26}.multi-view-controls-panel .uniform-control-slider::-webkit-slider-thumb{width:12px;height:12px;margin-top:-4px;background:#ffffffe6;box-shadow:0 1px 4px #0000004d}.multi-view-controls-panel .uniform-control-slider::-moz-range-track{height:4px;background:#ffffff26}.multi-view-controls-panel .uniform-control-slider::-moz-range-thumb{width:12px;height:12px;background:#ffffffe6;box-shadow:0 1px 4px #0000004d}.multi-view-controls-panel .uniform-control-toggle{width:34px;height:18px}.multi-view-controls-panel .uniform-control-toggle-slider{border-radius:18px}.multi-view-controls-panel .uniform-control-toggle-slider:before{width:12px;height:12px;left:3px;bottom:3px}.multi-view-controls-panel .uniform-control-toggle input:checked+.uniform-control-toggle-slider:before{transform:translate(16px)}.layout-fullscreen{width:100%;height:100%}.layout-fullscreen .canvas-container{position:relative;width:100%;height:100%;background:#000}.layout-default{width:100%;height:100%}.layout-default .canvas-container{position:relative;width:100%;height:100%;background:var(--bg-canvas);border-radius:var(--pane-radius);box-shadow:var(--pane-shadow);overflow:hidden}.layout-split{width:100%;height:100%;display:flex;gap:24px}.layout-split .canvas-container{position:relative;flex:1;background:var(--bg-canvas);border-radius:var(--pane-radius);box-shadow:var(--pane-shadow);overflow:hidden}.layout-split .code-panel{position:relative;flex:1;display:flex;flex-direction:column;background:var(--bg-secondary);border-radius:var(--pane-radius);box-shadow:var(--pane-shadow);overflow:hidden}.tab-bar{display:flex;background:var(--tab-bg);border-bottom:1px solid var(--border-primary);padding:8px 8px 0;gap:4px}.tab-button{padding:8px 16px;background:transparent;border:none;border-radius:6px 6px 0 0;font-size:13px;font-family:var(--font-mono);cursor:pointer;transition:background .2s,color .2s;color:var(--tab-text)}.tab-button:hover{background:var(--button-bg-hover);color:var(--tab-text-hover)}.tab-button.active{background:var(--bg-secondary);color:var(--tab-text-active);font-weight:500}.copy-button{position:absolute;top:12px;right:12px;padding:6px;background:var(--button-bg);border:none;border-radius:4px;color:var(--button-text);cursor:pointer;transition:all .2s;z-index:10;display:flex;align-items:center;justify-content:center}.copy-button:hover{background:var(--button-bg-hover);color:var(--button-text-hover)}.copy-button:active{transform:scale(.9)}.copy-button.copied{color:var(--success-text)}.code-viewer{flex:1;min-height:0;overflow:auto;position:relative;background:var(--code-bg)}.code-viewer pre{margin:0;padding:16px;font-size:13px;line-height:1.5;font-family:var(--font-mono);background:var(--code-bg);color:var(--code-text)}.code-viewer code{font-family:inherit;font-size:inherit}.token.comment{color:var(--syntax-comment)}.token.keyword{color:var(--syntax-keyword)}.token.string{color:var(--syntax-string)}.token.number{color:var(--syntax-number)}.token.operator{color:var(--syntax-operator)}.token.function{color:var(--syntax-function)}.token.class-name{color:var(--syntax-class)}.token.punctuation{color:var(--syntax-punctuation)}.tab-button.image-tab,.tab-button.image-tab.active{color:var(--accent-secondary)}.image-viewer{display:flex;align-items:center;justify-content:center;height:100%;padding:16px;background:var(--image-viewer-bg)}.image-viewer img{max-width:100%;max-height:100%;object-fit:contain;border-radius:4px;box-shadow:var(--shadow-sm)}.layout-split{container-type:inline-size}@container (max-width: 700px){.layout-split{flex-direction:column}}.layout-tabbed{width:100%;height:100%;display:flex;flex-direction:column;box-sizing:border-box}.tabbed-wrapper{display:flex;flex-direction:column;width:100%;height:100%;border-radius:var(--pane-radius);box-shadow:var(--pane-shadow);overflow:hidden}.tabbed-toolbar{display:flex;align-items:center;flex-shrink:0;background:var(--tab-bg);border-bottom:1px solid var(--border-primary);padding-right:8px}.tabbed-tab-bar{display:flex;flex:1;gap:4px;overflow-x:auto;overflow-y:hidden;scrollbar-width:thin}.tabbed-tab-bar::-webkit-scrollbar{height:4px}.tabbed-tab-bar::-webkit-scrollbar-thumb{background:var(--border-secondary);border-radius:2px}.tabbed-tab-button{padding:10px 16px;background:transparent;border:none;border-bottom:2px solid transparent;font-size:12px;font-family:var(--font-mono);cursor:pointer;transition:color .15s,border-color .15s;color:var(--tab-text);white-space:nowrap;flex-shrink:0}.tabbed-tab-button:hover{color:var(--tab-text-hover)}.tabbed-tab-button.active{color:var(--tab-text-active);border-bottom-color:var(--tab-border-active)}.tabbed-tab-button.shader-tab{font-family:var(--font-ui)}.tabbed-tab-button.image-tab{color:var(--accent-secondary)}.tabbed-tab-button.image-tab.active{color:var(--accent-secondary);border-bottom-color:var(--accent-secondary)}.tabbed-tab-button.uniforms-tab{color:var(--accent-tertiary, var(--accent-primary));padding:8px 12px}.tabbed-tab-button.uniforms-tab.active{color:var(--accent-tertiary, var(--accent-primary));border-bottom-color:var(--accent-tertiary, var(--accent-primary))}.tabbed-tab-button .uniforms-icon{width:18px;height:18px;display:block}.tabbed-content{flex:1;min-height:0;position:relative;background:var(--bg-canvas);overflow:hidden}.tabbed-canvas-container{position:absolute;top:0;left:0;width:100%;height:100%}.tabbed-code-viewer{position:absolute;top:0;left:0;width:100%;height:100%;overflow:auto;background:var(--code-bg)}.tabbed-code-viewer pre{margin:0;padding:16px 16px 16px 0;font-size:13px;line-height:1.6;font-family:var(--font-mono);background:var(--code-bg);color:var(--code-text);display:flex}.tabbed-code-viewer code{font-family:inherit;font-size:inherit}.tabbed-line-numbers{text-align:right;padding-right:16px;margin-right:16px;border-right:1px solid var(--code-line-border);color:var(--code-line-number);-webkit-user-select:none;user-select:none;flex-shrink:0;padding-left:16px}.tabbed-code-content{flex:1;overflow-x:auto}.tabbed-image-viewer{position:absolute;top:0;left:0;width:100%;height:100%;display:flex;align-items:center;justify-content:center;background:var(--image-viewer-bg);padding:20px;box-sizing:border-box}.tabbed-image-viewer img{max-width:100%;max-height:100%;object-fit:contain;border-radius:4px;box-shadow:var(--shadow-sm)}.tabbed-code-viewer .token.comment{color:var(--syntax-comment)}.tabbed-code-viewer .token.keyword{color:var(--syntax-keyword)}.tabbed-code-viewer .token.string{color:var(--syntax-string)}.tabbed-code-viewer .token.number{color:var(--syntax-number)}.tabbed-code-viewer .token.operator{color:var(--syntax-operator)}.tabbed-code-viewer .token.function{color:var(--syntax-function)}.tabbed-code-viewer .token.class-name{color:var(--syntax-class)}.tabbed-code-viewer .token.punctuation{color:var(--syntax-punctuation)}@media (max-width: 600px){.tabbed-tab-button{padding:8px 12px;font-size:12px}}.tabbed-editor-container{position:absolute;top:0;left:0;width:100%;height:100%;overflow:hidden;background:var(--code-bg)}.tabbed-button-container{display:flex;align-items:center;gap:6px;flex-shrink:0}.tabbed-copy-button{display:flex;align-items:center;justify-content:center;background:var(--button-bg);border:1px solid var(--button-border);color:var(--button-text);width:44px;height:44px;border-radius:4px;cursor:pointer;transition:background .15s,border-color .15s,color .15s}.tabbed-copy-button:hover{background:var(--button-bg-hover);border-color:var(--button-border-hover);color:var(--button-text-hover)}.tabbed-copy-button:active{background:var(--button-bg-hover)}.tabbed-copy-button.copied{background:var(--success-bg);border-color:var(--success-border);color:var(--success-text)}.tabbed-recompile-button{display:flex;align-items:center;gap:6px;background:var(--recompile-bg);border:none;color:var(--recompile-text);padding:6px 12px;border-radius:4px;cursor:pointer;font-family:inherit;font-size:12px;font-weight:500;transition:background .15s,color .15s}.tabbed-recompile-button:hover{background:var(--recompile-bg-hover)}.tabbed-recompile-button:active{background:var(--recompile-bg-active)}.tabbed-recompile-button svg{flex-shrink:0}.tabbed-error-display{position:absolute;bottom:0;left:0;right:0;background:var(--error-bg);color:var(--error-text);padding:10px 14px;font-family:var(--font-mono);font-size:12px;white-space:pre-wrap;overflow:auto;max-height:120px;border-top:1px solid var(--error-border);z-index:10}.tabbed-fallback-textarea{width:100%;height:100%;background:var(--code-bg);color:var(--code-text);border:none;padding:12px;font-family:var(--font-mono);font-size:13px;resize:none;outline:none}.tabbed-uniforms-container{position:absolute;top:0;left:0;width:100%;height:100%;overflow-y:auto;background:#00000080;-webkit-backdrop-filter:blur(8px);backdrop-filter:blur(8px);display:flex;justify-content:center;padding:20px;box-sizing:border-box}.tabbed-uniforms-container .uniform-controls{max-width:400px;width:100%;background:#1e1e23f2;border-radius:12px;padding:20px;box-shadow:0 4px 20px #0006;height:fit-content}.tabbed-uniforms-container .uniform-control-label{color:#e0e0e0}.tabbed-uniforms-container .uniform-control-value{color:#a0a0a0;background:#0000004d}.tabbed-uniforms-container .uniform-controls-header{color:#909090;border-bottom-color:#ffffff1a}.tabbed-uniforms-container .uniform-control-slider{background:#ffffff1a}.tabbed-uniforms-container .uniform-control-slider::-webkit-slider-thumb{background:#fff}.tabbed-uniforms-container .uniform-control-slider::-moz-range-thumb{background:#fff}.tabbed-uniforms-container .uniform-control-vec-component{color:#909090}.tabbed-uniforms-container .uniform-control-vec-value{color:#a0a0a0;background:#0000004d}.layout-multi-view{position:relative;width:100%;height:100%;box-sizing:border-box;background:var(--bg-primary)}.multi-view-canvas{position:relative;background:var(--bg-canvas);border-radius:var(--pane-radius);box-shadow:var(--pane-shadow);overflow:hidden}.multi-view-label{position:absolute;top:12px;left:12px;padding:4px 10px;background:#0009;color:#fff;font-family:var(--font-mono);font-size:12px;font-weight:500;border-radius:4px;text-transform:capitalize;z-index:5;pointer-events:none}.multi-view-info{position:absolute;bottom:12px;left:12px;padding:6px 10px;background:#0009;color:#fff;font-family:var(--font-mono);font-size:11px;border-radius:4px;z-index:5;pointer-events:none}.layout-grid-view{display:grid;gap:16px}.layout-grid-view .multi-view-canvas{min-height:0;min-width:0}.layout-grid-view[data-view-count="2"].grid-horizontal{grid-template-columns:1fr 1fr;grid-template-rows:1fr}.layout-grid-view[data-view-count="2"].grid-vertical{grid-template-columns:1fr;grid-template-rows:1fr 1fr}.layout-grid-view[data-view-count="3"].grid-horizontal{grid-template-columns:1fr 1fr;grid-template-rows:1fr 1fr}.layout-grid-view[data-view-count="3"].grid-horizontal .multi-view-canvas:last-child{grid-column:1 / -1}.layout-grid-view[data-view-count="3"].grid-vertical{grid-template-columns:1fr 1fr;grid-template-rows:1fr 1fr}.layout-grid-view[data-view-count="3"].grid-vertical .multi-view-canvas:first-child{grid-column:1 / -1}.layout-grid-view[data-view-count="4"]{grid-template-columns:1fr 1fr;grid-template-rows:1fr 1fr}.layout-inset-view .multi-view-canvas.inset-main{width:100%;height:100%}.layout-inset-view .multi-view-canvas.inset-overlay{position:absolute;bottom:40px;right:40px;width:25%;min-width:200px;aspect-ratio:16 / 9;z-index:10;transition:all .2s ease}.layout-inset-view .multi-view-canvas.inset-overlay.minimized{width:48px;height:48px;min-width:unset;aspect-ratio:unset;cursor:pointer;opacity:.8}.layout-inset-view .multi-view-canvas.inset-overlay.minimized:hover{opacity:1}.inset-minimize-btn{position:absolute;top:8px;right:8px;width:24px;height:24px;border:none;border-radius:4px;background:#00000080;color:#fff;cursor:pointer;display:flex;align-items:center;justify-content:center;font-size:14px;z-index:11;transition:background .2s}.inset-minimize-btn:hover{background:#000000b3}.editor-toolbar{display:flex;align-items:center;background:var(--tab-bg);border-bottom:1px solid var(--border-primary);padding-right:8px}.editor-tab-bar{display:flex;flex:1;overflow-x:auto;scrollbar-width:thin}.editor-tab-button{background:transparent;border:none;color:var(--tab-text);padding:10px 16px;cursor:pointer;font-family:var(--font-mono);font-size:12px;white-space:nowrap;border-bottom:2px solid transparent;transition:color .15s,border-color .15s}.editor-tab-button:hover{color:var(--tab-text-hover)}.editor-tab-button.active{color:var(--tab-text-active);border-bottom-color:var(--tab-border-active)}.editor-tab-button.image-tab{color:var(--accent-secondary)}.editor-tab-button.image-tab.active{color:var(--accent-secondary);border-bottom-color:var(--accent-secondary)}.editor-tab-button.uniforms-tab{color:var(--accent-tertiary, var(--accent-primary));padding:8px 12px}.editor-tab-button.uniforms-tab.active{color:var(--accent-tertiary, var(--accent-primary));border-bottom-color:var(--accent-tertiary, var(--accent-primary))}.editor-tab-button .uniforms-icon{width:18px;height:18px;display:block}.editor-copy-button{display:flex;align-items:center;justify-content:center;background:var(--button-bg);border:1px solid var(--button-border);color:var(--button-text);width:32px;height:32px;border-radius:4px;cursor:pointer;transition:background .15s,border-color .15s,color .15s;flex-shrink:0;margin-right:6px}.editor-copy-button:hover{background:var(--button-bg-hover);border-color:var(--button-border-hover);color:var(--button-text-hover)}.editor-copy-button:active{background:var(--button-bg-hover)}.editor-copy-button.copied{background:var(--success-bg);border-color:var(--success-border);color:var(--success-text)}.editor-copy-button svg{flex-shrink:0}.editor-recompile-button{display:flex;align-items:center;gap:6px;background:var(--recompile-bg);border:none;color:var(--recompile-text);padding:6px 12px;border-radius:4px;cursor:pointer;font-family:inherit;font-size:12px;font-weight:500;transition:background .15s,color .15s;flex-shrink:0}.editor-recompile-button:hover{background:var(--recompile-bg-hover)}.editor-recompile-button:active{background:var(--recompile-bg-active)}.editor-recompile-button svg{flex-shrink:0}.editor-content-area{flex:1;overflow:hidden;position:relative;background:var(--code-bg)}.editor-prism-container{height:100%;width:100%}.editor-fallback-textarea{width:100%;height:100%;background:var(--code-bg);color:var(--code-text);border:none;padding:12px;font-family:var(--font-mono);font-size:13px;resize:none;outline:none}.editor-image-viewer{display:flex;align-items:center;justify-content:center;height:100%;background:var(--image-viewer-bg);padding:20px}.editor-uniforms-container{height:100%;overflow-y:auto;background:var(--bg-secondary)}.editor-image-viewer img{max-width:100%;max-height:100%;object-fit:contain;border-radius:4px;box-shadow:var(--shadow-sm)}.editor-error-display{background:var(--error-bg);color:var(--error-text);padding:10px 14px;font-family:var(--font-mono);font-size:12px;white-space:pre-wrap;overflow:auto;max-height:120px;border-top:1px solid var(--error-border)}.prism-editor-wrapper{display:flex;height:100%;background:var(--code-bg);font-family:var(--font-mono);font-size:13px;line-height:1.6}.prism-editor-line-numbers{flex-shrink:0;padding:16px 12px 16px 16px;text-align:right;color:var(--code-line-number);border-right:1px solid var(--code-line-border);-webkit-user-select:none;user-select:none;overflow:hidden}.prism-editor-line-numbers span{display:block}.prism-editor-area{flex:1;position:relative;overflow:hidden}.prism-editor-textarea,.prism-editor-highlight{position:absolute;top:0;left:0;width:100%;height:100%;padding:16px;margin:0;border:none;outline:none;font-family:inherit;font-size:inherit;line-height:inherit;white-space:pre-wrap;word-wrap:break-word;overflow:auto;box-sizing:border-box;tab-size:2;-moz-tab-size:2;letter-spacing:normal;word-spacing:normal}.prism-editor-textarea{background:transparent;color:transparent;caret-color:var(--code-text);resize:none;z-index:1;-webkit-text-fill-color:transparent}.prism-editor-textarea::selection{background:var(--code-selection)}.prism-editor-textarea::-moz-selection{background:var(--code-selection)}.prism-editor-highlight{background:var(--code-bg);color:var(--code-text);pointer-events:none;z-index:0}.prism-editor-highlight code{font-family:inherit;font-size:inherit;line-height:inherit;background:none;padding:0;margin:0;border:none;display:block;white-space:inherit;word-wrap:inherit;-moz-tab-size:2;tab-size:2}.prism-editor-highlight code[class*=language-],.prism-editor-highlight[class*=language-]{padding:0;margin:0;background:none;border:none;text-shadow:none}.prism-editor-highlight .token.comment{color:var(--syntax-comment)}.prism-editor-highlight .token.keyword{color:var(--syntax-keyword)}.prism-editor-highlight .token.string{color:var(--syntax-string)}.prism-editor-highlight .token.number{color:var(--syntax-number)}.prism-editor-highlight .token.operator{color:var(--syntax-operator)}.prism-editor-highlight .token.function{color:var(--syntax-function)}.prism-editor-highlight .token.class-name{color:var(--syntax-class)}.prism-editor-highlight .token.punctuation{color:var(--syntax-punctuation)}`)),document.head.appendChild(r)}}catch(e){console.error("vite-plugin-css-injected-by-js",e)}})();
var Vs = Object.defineProperty;
var zs = (s, e, t) => e in s ? Vs(s, e, { enumerable: !0, configurable: !0, writable: !0, value: t }) : s[e] = t;
var h = (s, e, t) => zs(s, typeof e != "symbol" ? e + "" : e, t);
function q(s) {
  return "count" in s && typeof s.count == "number" && !("struct" in s);
}
function Q(s) {
  return "struct" in s && typeof s.struct == "object" && "count" in s;
}
function G(s) {
  return q(s) || Q(s);
}
function Se(s) {
  return !G(s) && !s.hidden;
}
function ns(s) {
  return "views" in s && Array.isArray(s.views);
}
function St(s, e, t) {
  const i = s.createShader(e);
  if (!i)
    throw new Error("Failed to create shader object");
  if (s.shaderSource(i, t), s.compileShader(i), !s.getShaderParameter(i, s.COMPILE_STATUS)) {
    const r = s.getShaderInfoLog(i);
    throw s.deleteShader(i), new Error(`Shader compilation failed:
${r}`);
  }
  return i;
}
function Rt(s, e, t) {
  const i = St(s, s.VERTEX_SHADER, e), n = St(s, s.FRAGMENT_SHADER, t), r = s.createProgram();
  if (!r)
    throw new Error("Failed to create program object");
  if (s.attachShader(r, i), s.attachShader(r, n), s.linkProgram(r), !s.getProgramParameter(r, s.LINK_STATUS)) {
    const a = s.getProgramInfoLog(r);
    throw s.deleteProgram(r), s.deleteShader(i), s.deleteShader(n), new Error(`Program linking failed:
${a}`);
  }
  return s.detachShader(r, i), s.detachShader(r, n), s.deleteShader(i), s.deleteShader(n), r;
}
function js(s) {
  const e = s.createVertexArray();
  if (!e)
    throw new Error("Failed to create VAO");
  s.bindVertexArray(e);
  const t = new Float32Array([
    -1,
    -1,
    // Bottom-left
    3,
    -1,
    // Bottom-right (extends beyond viewport)
    -1,
    3
    // Top-left (extends beyond viewport)
  ]), i = s.createBuffer();
  if (!i)
    throw new Error("Failed to create VBO");
  return s.bindBuffer(s.ARRAY_BUFFER, i), s.bufferData(s.ARRAY_BUFFER, t, s.STATIC_DRAW), s.enableVertexAttribArray(0), s.vertexAttribPointer(
    0,
    // attribute location
    2,
    // size (vec2)
    s.FLOAT,
    // type
    !1,
    // normalized
    0,
    // stride
    0
    // offset
  ), s.bindVertexArray(null), s.bindBuffer(s.ARRAY_BUFFER, null), e;
}
function Ie(s, e, t) {
  const i = s.createTexture();
  if (!i)
    throw new Error("Failed to create texture");
  return s.bindTexture(s.TEXTURE_2D, i), s.texImage2D(
    s.TEXTURE_2D,
    0,
    // mip level
    s.RGBA32F,
    // internal format (32-bit float per channel)
    e,
    t,
    0,
    // border (must be 0)
    s.RGBA,
    // format
    s.FLOAT,
    // type
    null
    // no data (allocate only)
  ), s.texParameteri(s.TEXTURE_2D, s.TEXTURE_MIN_FILTER, s.NEAREST), s.texParameteri(s.TEXTURE_2D, s.TEXTURE_MAG_FILTER, s.NEAREST), s.texParameteri(s.TEXTURE_2D, s.TEXTURE_WRAP_S, s.CLAMP_TO_EDGE), s.texParameteri(s.TEXTURE_2D, s.TEXTURE_WRAP_T, s.CLAMP_TO_EDGE), s.bindTexture(s.TEXTURE_2D, null), i;
}
function kt(s, e) {
  const t = s.createFramebuffer();
  if (!t)
    throw new Error("Failed to create framebuffer");
  s.bindFramebuffer(s.FRAMEBUFFER, t), s.framebufferTexture2D(
    s.FRAMEBUFFER,
    s.COLOR_ATTACHMENT0,
    s.TEXTURE_2D,
    e,
    0
    // mip level
  );
  const i = s.checkFramebufferStatus(s.FRAMEBUFFER);
  if (i !== s.FRAMEBUFFER_COMPLETE)
    throw s.deleteFramebuffer(t), new Error(`Framebuffer incomplete: ${Qs(s, i)}`);
  return s.bindFramebuffer(s.FRAMEBUFFER, null), t;
}
function Hs(s) {
  const e = s.createTexture();
  if (!e)
    throw new Error("Failed to create black texture");
  s.bindTexture(s.TEXTURE_2D, e);
  const t = new Float32Array([0, 0, 0, 1]);
  return s.texImage2D(
    s.TEXTURE_2D,
    0,
    s.RGBA32F,
    1,
    1,
    0,
    s.RGBA,
    s.FLOAT,
    t
  ), s.texParameteri(s.TEXTURE_2D, s.TEXTURE_MIN_FILTER, s.NEAREST), s.texParameteri(s.TEXTURE_2D, s.TEXTURE_MAG_FILTER, s.NEAREST), s.texParameteri(s.TEXTURE_2D, s.TEXTURE_WRAP_S, s.CLAMP_TO_EDGE), s.texParameteri(s.TEXTURE_2D, s.TEXTURE_WRAP_T, s.CLAMP_TO_EDGE), s.bindTexture(s.TEXTURE_2D, null), e;
}
function Ws(s) {
  const e = s.createTexture();
  if (!e)
    throw new Error("Failed to create keyboard texture");
  s.bindTexture(s.TEXTURE_2D, e);
  const t = 256, i = 3, n = new Float32Array(t * i * 4);
  return s.texImage2D(
    s.TEXTURE_2D,
    0,
    s.RGBA32F,
    t,
    i,
    0,
    s.RGBA,
    s.FLOAT,
    n
  ), s.texParameteri(s.TEXTURE_2D, s.TEXTURE_MIN_FILTER, s.NEAREST), s.texParameteri(s.TEXTURE_2D, s.TEXTURE_MAG_FILTER, s.NEAREST), s.texParameteri(s.TEXTURE_2D, s.TEXTURE_WRAP_S, s.CLAMP_TO_EDGE), s.texParameteri(s.TEXTURE_2D, s.TEXTURE_WRAP_T, s.CLAMP_TO_EDGE), s.bindTexture(s.TEXTURE_2D, null), e;
}
function Xs(s, e, t, i) {
  const o = new Float32Array(3072);
  for (let a = 0; a < 256; a++) {
    const c = t.get(a) || !1, u = i.get(a) || 0, l = (0 * 256 + a) * 4;
    o[l + 0] = c ? 1 : 0, o[l + 1] = c ? 1 : 0, o[l + 2] = c ? 1 : 0, o[l + 3] = 1;
    const d = (2 * 256 + a) * 4;
    o[d + 0] = u, o[d + 1] = u, o[d + 2] = u, o[d + 3] = 1;
  }
  s.bindTexture(s.TEXTURE_2D, e), s.texSubImage2D(
    s.TEXTURE_2D,
    0,
    0,
    0,
    // x, y offset
    256,
    3,
    s.RGBA,
    s.FLOAT,
    o
  ), s.bindTexture(s.TEXTURE_2D, null);
}
function Gs(s) {
  const e = s.createTexture();
  if (!e) throw new Error("Failed to create audio texture");
  s.bindTexture(s.TEXTURE_2D, e);
  const t = 512, i = 2, n = new Uint8Array(t * i);
  return s.texImage2D(s.TEXTURE_2D, 0, s.R8, t, i, 0, s.RED, s.UNSIGNED_BYTE, n), s.texParameteri(s.TEXTURE_2D, s.TEXTURE_MIN_FILTER, s.LINEAR), s.texParameteri(s.TEXTURE_2D, s.TEXTURE_MAG_FILTER, s.LINEAR), s.texParameteri(s.TEXTURE_2D, s.TEXTURE_WRAP_S, s.CLAMP_TO_EDGE), s.texParameteri(s.TEXTURE_2D, s.TEXTURE_WRAP_T, s.CLAMP_TO_EDGE), s.bindTexture(s.TEXTURE_2D, null), e;
}
function Ks(s, e, t, i) {
  s.bindTexture(s.TEXTURE_2D, e), s.texSubImage2D(s.TEXTURE_2D, 0, 0, 0, 512, 1, s.RED, s.UNSIGNED_BYTE, t), s.texSubImage2D(s.TEXTURE_2D, 0, 0, 1, 512, 1, s.RED, s.UNSIGNED_BYTE, i), s.bindTexture(s.TEXTURE_2D, null);
}
function At(s) {
  const e = s.createTexture();
  if (!e) throw new Error("Failed to create video texture");
  return s.bindTexture(s.TEXTURE_2D, e), s.texImage2D(s.TEXTURE_2D, 0, s.RGBA, 1, 1, 0, s.RGBA, s.UNSIGNED_BYTE, new Uint8Array([0, 0, 0, 255])), s.texParameteri(s.TEXTURE_2D, s.TEXTURE_MIN_FILTER, s.LINEAR), s.texParameteri(s.TEXTURE_2D, s.TEXTURE_MAG_FILTER, s.LINEAR), s.texParameteri(s.TEXTURE_2D, s.TEXTURE_WRAP_S, s.CLAMP_TO_EDGE), s.texParameteri(s.TEXTURE_2D, s.TEXTURE_WRAP_T, s.CLAMP_TO_EDGE), s.bindTexture(s.TEXTURE_2D, null), e;
}
function Ys(s, e, t) {
  s.bindTexture(s.TEXTURE_2D, e), s.pixelStorei(s.UNPACK_FLIP_Y_WEBGL, !0), s.texImage2D(s.TEXTURE_2D, 0, s.RGBA, s.RGBA, s.UNSIGNED_BYTE, t), s.pixelStorei(s.UNPACK_FLIP_Y_WEBGL, !1), s.bindTexture(s.TEXTURE_2D, null);
}
function qs(s, e, t, i, n) {
  const r = e ?? s.createTexture();
  if (!r) throw new Error("Failed to create script texture");
  return s.bindTexture(s.TEXTURE_2D, r), n instanceof Float32Array ? s.texImage2D(s.TEXTURE_2D, 0, s.RGBA32F, t, i, 0, s.RGBA, s.FLOAT, n) : s.texImage2D(s.TEXTURE_2D, 0, s.RGBA, t, i, 0, s.RGBA, s.UNSIGNED_BYTE, n), s.texParameteri(s.TEXTURE_2D, s.TEXTURE_MIN_FILTER, s.NEAREST), s.texParameteri(s.TEXTURE_2D, s.TEXTURE_MAG_FILTER, s.NEAREST), s.texParameteri(s.TEXTURE_2D, s.TEXTURE_WRAP_S, s.CLAMP_TO_EDGE), s.texParameteri(s.TEXTURE_2D, s.TEXTURE_WRAP_T, s.CLAMP_TO_EDGE), s.bindTexture(s.TEXTURE_2D, null), r;
}
function Qs(s, e) {
  switch (e) {
    case s.FRAMEBUFFER_INCOMPLETE_ATTACHMENT:
      return "FRAMEBUFFER_INCOMPLETE_ATTACHMENT";
    case s.FRAMEBUFFER_INCOMPLETE_MISSING_ATTACHMENT:
      return "FRAMEBUFFER_INCOMPLETE_MISSING_ATTACHMENT";
    case s.FRAMEBUFFER_INCOMPLETE_DIMENSIONS:
      return "FRAMEBUFFER_INCOMPLETE_DIMENSIONS";
    case s.FRAMEBUFFER_UNSUPPORTED:
      return "FRAMEBUFFER_UNSUPPORTED";
    case s.FRAMEBUFFER_INCOMPLETE_MULTISAMPLE:
      return "FRAMEBUFFER_INCOMPLETE_MULTISAMPLE";
    default:
      return `Unknown status: ${e}`;
  }
}
const at = {
  float: 1,
  vec2: 2,
  vec3: 3,
  vec4: 4,
  mat3: 9,
  mat4: 16
}, ct = {
  float: 4,
  // 1 float + 3 padding
  vec2: 4,
  // 2 floats + 2 padding
  vec3: 4,
  // 3 floats + 1 padding
  vec4: 4,
  // 4 floats, naturally aligned
  mat3: 12,
  // 3 columns × 4 floats (vec3 padded to vec4)
  mat4: 16
  // 4 columns × 4 floats, no padding
};
function ue(s, e) {
  return at[s] * e;
}
function Zs(s, e) {
  return ct[s] * e * 4;
}
function Ft(s, e) {
  return ct[s] * e;
}
function Bt(s, e, t, i) {
  const n = at[s], r = ct[s];
  if (n === r)
    return t;
  const o = r * e, a = i && i.length >= o ? i : new Float32Array(o);
  if (s === "mat3")
    for (let c = 0; c < e; c++) {
      const u = c * 9, l = c * 12;
      a[l + 0] = t[u + 0], a[l + 1] = t[u + 1], a[l + 2] = t[u + 2], a[l + 3] = 0, a[l + 4] = t[u + 3], a[l + 5] = t[u + 4], a[l + 6] = t[u + 5], a[l + 7] = 0, a[l + 8] = t[u + 6], a[l + 9] = t[u + 7], a[l + 10] = t[u + 8], a[l + 11] = 0;
    }
  else
    for (let c = 0; c < e; c++) {
      const u = c * n, l = c * 4;
      for (let d = 0; d < n; d++)
        a[l + d] = t[u + d];
      for (let d = n; d < 4; d++)
        a[l + d] = 0;
    }
  return a;
}
const Js = {
  float: 4,
  vec2: 8,
  vec3: 16,
  vec4: 16,
  mat3: 16,
  mat4: 16
}, ei = {
  float: 4,
  vec2: 8,
  vec3: 12,
  vec4: 16,
  mat3: 48,
  mat4: 64
};
function Ke(s, e) {
  return Math.ceil(s / e) * e;
}
function Ve(s) {
  const e = [];
  let t = 0, i = 0, n = 0;
  for (const [a, c] of Object.entries(s)) {
    const u = Js[c], l = ei[c], d = at[c];
    t = Ke(t, u), e.push({ name: a, type: c, offsetBytes: t, sizeBytes: l, tightFloats: d }), t += l, i = Math.max(i, u), n += d;
  }
  const r = Ke(Math.max(i, 16), 16), o = Ke(t, r);
  return {
    fields: e,
    strideBytes: o,
    strideFloats: o / 4,
    tightFloatsPerElement: n
  };
}
function ti(s, e) {
  return s.strideBytes * e;
}
function si(s, e, t, i) {
  const n = s.strideFloats * e, r = i && i.length >= n ? i : new Float32Array(n);
  for (let o = 0; o < e; o++) {
    const a = o * s.strideFloats;
    for (const c of s.fields) {
      const u = a + c.offsetBytes / 4, l = o * c.tightFloats, d = t[c.name];
      if (d)
        if (c.type === "mat3")
          for (let m = 0; m < 3; m++)
            r[u + m * 4 + 0] = d[l + m * 3 + 0] ?? 0, r[u + m * 4 + 1] = d[l + m * 3 + 1] ?? 0, r[u + m * 4 + 2] = d[l + m * 3 + 2] ?? 0, r[u + m * 4 + 3] = 0;
        else
          for (let m = 0; m < c.tightFloats; m++)
            r[u + m] = d[l + m] ?? 0;
    }
  }
  return r;
}
function ii(s, e, t, i) {
  const n = e * s.strideFloats;
  for (const r of s.fields) {
    const o = t[r.name];
    if (!o) continue;
    const a = n + r.offsetBytes / 4;
    if (r.type === "mat3")
      for (let c = 0; c < 3; c++)
        i[a + c * 4 + 0] = o[c * 3 + 0] ?? 0, i[a + c * 4 + 1] = o[c * 3 + 1] ?? 0, i[a + c * 4 + 2] = o[c * 3 + 2] ?? 0, i[a + c * 4 + 3] = 0;
    else
      for (let c = 0; c < r.tightFloats; c++)
        i[a + c] = o[c] ?? 0;
  }
}
const Pt = `#version 300 es
precision highp float;

layout(location = 0) in vec2 position;

void main() {
  gl_Position = vec4(position, 0.0, 1.0);
}
`, ni = `#version 300 es
precision highp float;

// Shadertoy compatibility: equirectangular texture sampling
const float ST_PI = 3.14159265359;
const float ST_TWOPI = 6.28318530718;
vec2 _st_dirToEquirect(vec3 dir) {
  float phi = atan(dir.z, dir.x);
  float theta = asin(dir.y);
  return vec2(phi / ST_TWOPI + 0.5, theta / ST_PI + 0.5);
}
`, ri = `// --- Keyboard helpers (auto-injected) ---
// Letter keys
const int KEY_A = 65; const int KEY_B = 66; const int KEY_C = 67; const int KEY_D = 68;
const int KEY_E = 69; const int KEY_F = 70; const int KEY_G = 71; const int KEY_H = 72;
const int KEY_I = 73; const int KEY_J = 74; const int KEY_K = 75; const int KEY_L = 76;
const int KEY_M = 77; const int KEY_N = 78; const int KEY_O = 79; const int KEY_P = 80;
const int KEY_Q = 81; const int KEY_R = 82; const int KEY_S = 83; const int KEY_T = 84;
const int KEY_U = 85; const int KEY_V = 86; const int KEY_W = 87; const int KEY_X = 88;
const int KEY_Y = 89; const int KEY_Z = 90;

// Digit keys
const int KEY_0 = 48; const int KEY_1 = 49; const int KEY_2 = 50; const int KEY_3 = 51;
const int KEY_4 = 52; const int KEY_5 = 53; const int KEY_6 = 54; const int KEY_7 = 55;
const int KEY_8 = 56; const int KEY_9 = 57;

// Arrow keys
const int KEY_LEFT = 37; const int KEY_UP = 38; const int KEY_RIGHT = 39; const int KEY_DOWN = 40;

// Special keys
const int KEY_SPACE = 32;
const int KEY_ENTER = 13;
const int KEY_TAB = 9;
const int KEY_ESC = 27;
const int KEY_BACKSPACE = 8;
const int KEY_DELETE = 46;
const int KEY_SHIFT = 16;
const int KEY_CTRL = 17;
const int KEY_ALT = 18;

// Function keys
const int KEY_F1 = 112; const int KEY_F2 = 113; const int KEY_F3 = 114; const int KEY_F4 = 115;
const int KEY_F5 = 116; const int KEY_F6 = 117; const int KEY_F7 = 118; const int KEY_F8 = 119;
const int KEY_F9 = 120; const int KEY_F10 = 121; const int KEY_F11 = 122; const int KEY_F12 = 123;

// Returns 1.0 if key is held down, 0.0 otherwise
float keyDown(int key) {
  return textureLod(keyboard, vec2((float(key) + 0.5) / 256.0, 0.25), 0.0).x;
}

// Returns 1.0/0.0, toggling each time the key is pressed
float keyToggle(int key) {
  return textureLod(keyboard, vec2((float(key) + 0.5) / 256.0, 0.75), 0.0).x;
}

// Boolean convenience helpers
bool isKeyDown(int key) { return keyDown(key) > 0.5; }
bool isKeyToggled(int key) { return keyToggle(key) > 0.5; }
`;
function oi(s, e, t) {
  const i = [ni];
  if (t.commonSource && (i.push("// Common code"), i.push(t.commonSource), i.push("")), t.namedSamplers && t.namedSamplers.size > 0) {
    if (i.push(`// Core uniforms
uniform vec3  iResolution;
uniform float iTime;
uniform float iTimeDelta;
uniform int   iFrame;
uniform vec4  iMouse;
uniform bool  iMousePressed;
uniform vec4  iDate;
uniform float iFrameRate;

// Shader Sandbox touch extensions
uniform int   iTouchCount;
uniform vec4  iTouch0;
uniform vec4  iTouch1;
uniform vec4  iTouch2;
uniform float iPinch;
uniform float iPinchDelta;
uniform vec2  iPinchCenter;
`), t.viewNames && t.viewNames.length > 1) {
      i.push("// Cross-view uniforms (multi-view project)");
      for (const d of t.viewNames)
        i.push(`uniform vec4  iMouse_${d};`), i.push(`uniform vec3  iResolution_${d};`), i.push(`uniform bool  iMousePressed_${d};`);
      i.push("");
    }
    i.push("// Named samplers");
    for (const [d] of t.namedSamplers)
      i.push(`uniform sampler2D ${d};`), i.push(`uniform vec3 ${d}_resolution;`);
    i.push(""), t.namedSamplers.has("keyboard") && (i.push(ri), i.push(""));
  } else if (i.push(`// Shadertoy built-in uniforms
uniform vec3  iResolution;
uniform float iTime;
uniform float iTimeDelta;
uniform int   iFrame;
uniform vec4  iMouse;
uniform bool  iMousePressed;
uniform vec4  iDate;
uniform float iFrameRate;
uniform vec3  iChannelResolution[4];
uniform sampler2D iChannel0;
uniform sampler2D iChannel1;
uniform sampler2D iChannel2;
uniform sampler2D iChannel3;

// Shader Sandbox touch extensions (not in Shadertoy)
uniform int   iTouchCount;          // Number of active touches (0-10)
uniform vec4  iTouch0;              // Primary touch: (x, y, startX, startY)
uniform vec4  iTouch1;              // Second touch
uniform vec4  iTouch2;              // Third touch
uniform float iPinch;               // Pinch scale factor (1.0 = no pinch)
uniform float iPinchDelta;          // Pinch change since last frame
uniform vec2  iPinchCenter;         // Center point of pinch gesture
`), t.viewNames && t.viewNames.length > 1) {
    i.push("// Cross-view uniforms (multi-view project)");
    for (const d of t.viewNames)
      i.push(`uniform vec4  iMouse_${d};`), i.push(`uniform vec3  iResolution_${d};`), i.push(`uniform bool  iMousePressed_${d};`);
    i.push("");
  }
  for (const d of t.ubos) {
    if (d.structLayout) {
      i.push(`// Struct array uniform: ${d.name} (max ${d.count})`), i.push(`struct _st_${d.name} {`);
      for (const m of d.structLayout.fields)
        i.push(`  ${m.type} ${m.name};`);
      i.push("};"), i.push(`layout(std140) uniform _ub_${d.name} {`), i.push(`  _st_${d.name} ${d.name}[${d.count}];`), i.push("};");
    } else
      i.push(`// Array uniform: ${d.name} (max ${d.count})`), i.push(`layout(std140) uniform _ub_${d.name} {`), i.push(`  ${d.def.type} ${d.name}[${d.count}];`), i.push("};");
    i.push(`uniform int ${d.name}_count;`), i.push("");
  }
  const n = Object.entries(t.uniforms).filter(([, d]) => !G(d));
  if (n.length > 0) {
    i.push("// Custom uniforms");
    for (const [d, m] of n) {
      const g = m.type === "bool" ? "bool" : m.type;
      i.push(`uniform ${g} ${d};`);
    }
    i.push("");
  }
  const r = ai(s, e);
  i.push("// User shader code"), i.push(r), i.push(""), i.push(`// Main wrapper
out vec4 fragColor;

void main() {
  mainImage(fragColor, gl_FragCoord.xy);
}`);
  const o = i.join(`
`), a = o.split(`
`);
  let c = 0, u = 0, l = 0;
  for (let d = 0; d < a.length; d++)
    a[d] === "// Common code" && (c = d + 2, u = t.commonSource ? t.commonSource.split(`
`).length : 0), a[d] === "// User shader code" && (l = d + 2);
  return {
    source: o,
    lineMapping: { commonStartLine: c, commonLines: u, userCodeStartLine: l }
  };
}
function ai(s, e) {
  const t = /* @__PURE__ */ new Set();
  if (e.forEach((n, r) => {
    n.kind === "texture" && n.cubemap && t.add(`iChannel${r}`);
  }), t.size === 0)
    return s;
  const i = /texture\s*\(\s*(iChannel[0-3])\s*,\s*([^)]+)\)/g;
  return s.replace(i, (n, r, o) => t.has(r) ? `texture(${r}, _st_dirToEquirect(${o}))` : n);
}
class ci {
  constructor(e, t) {
    h(this, "_audioTexture", null);
    h(this, "_needsAudio", !1);
    h(this, "_videoTextures", []);
    const i = this.getAllChannelSources(t);
    i.some((n) => n.kind === "audio") && (this._needsAudio = !0, this._audioTexture = {
      texture: Gs(e),
      audioContext: null,
      analyser: null,
      stream: null,
      frequencyData: new Uint8Array(512),
      waveformData: new Uint8Array(512),
      width: 512,
      height: 2,
      initialized: !1
    });
    for (const n of i)
      n.kind === "webcam" ? this._videoTextures.find((o) => o.kind === "webcam") || this._videoTextures.push({
        texture: At(e),
        video: null,
        stream: null,
        width: 1,
        height: 1,
        ready: !1,
        kind: "webcam"
      }) : n.kind === "video" && (this._videoTextures.find((o) => o.kind === "video" && o.src === n.src) || this._videoTextures.push({
        texture: At(e),
        video: null,
        stream: null,
        width: 1,
        height: 1,
        ready: !1,
        kind: "video",
        src: n.src
      }));
  }
  // ===========================================================================
  // Accessors
  // ===========================================================================
  get needsAudio() {
    return this._needsAudio;
  }
  get needsWebcam() {
    return this._videoTextures.some((e) => e.kind === "webcam");
  }
  get videoSources() {
    return this._videoTextures.filter((e) => e.kind === "video" && !e.ready && e.src).map((e) => e.src);
  }
  get audioTexture() {
    return this._audioTexture;
  }
  get videoTextures() {
    return this._videoTextures;
  }
  // ===========================================================================
  // Initialization (require user gesture for audio/webcam)
  // ===========================================================================
  async initAudio() {
    if (!(!this._audioTexture || this._audioTexture.initialized))
      try {
        const e = await navigator.mediaDevices.getUserMedia({ audio: !0 }), t = new AudioContext(), i = t.createMediaStreamSource(e), n = t.createAnalyser();
        n.fftSize = 1024, n.smoothingTimeConstant = 0.8, i.connect(n), this._audioTexture.audioContext = t, this._audioTexture.analyser = n, this._audioTexture.stream = e, this._audioTexture.initialized = !0;
      } catch (e) {
        console.warn("Failed to initialize audio input:", e);
      }
  }
  async initWebcam() {
    const e = this._videoTextures.find((t) => t.kind === "webcam" && !t.ready);
    if (e)
      try {
        const t = await navigator.mediaDevices.getUserMedia({ video: !0 }), i = document.createElement("video");
        i.srcObject = t, i.muted = !0, i.playsInline = !0, await i.play(), e.video = i, e.stream = t, e.width = i.videoWidth, e.height = i.videoHeight, i.addEventListener("loadedmetadata", () => {
          e.width = i.videoWidth, e.height = i.videoHeight;
        }), e.ready = !0;
      } catch (t) {
        console.warn("Failed to initialize webcam:", t);
      }
  }
  async initVideo(e) {
    const t = this._videoTextures.find((n) => n.kind === "video" && n.src === e && !n.ready);
    if (!t) return;
    const i = document.createElement("video");
    i.src = e, i.muted = !0, i.loop = !0, i.playsInline = !0, i.crossOrigin = "anonymous", i.addEventListener("loadedmetadata", () => {
      t.width = i.videoWidth, t.height = i.videoHeight;
    });
    try {
      await i.play(), t.video = i, t.ready = !0;
    } catch (n) {
      console.warn(`Failed to play video '${e}':`, n);
    }
  }
  // ===========================================================================
  // Per-frame updates
  // ===========================================================================
  updateAudioTexture(e) {
    var t;
    (t = this._audioTexture) != null && t.analyser && (this._audioTexture.analyser.getByteFrequencyData(this._audioTexture.frequencyData), this._audioTexture.analyser.getByteTimeDomainData(this._audioTexture.waveformData), Ks(
      e,
      this._audioTexture.texture,
      this._audioTexture.frequencyData,
      this._audioTexture.waveformData
    ));
  }
  updateVideoTextures(e) {
    for (const t of this._videoTextures)
      !t.ready || !t.video || t.video.readyState < HTMLMediaElement.HAVE_CURRENT_DATA || (Ys(e, t.texture, t.video), t.video.videoWidth > 0 && (t.width = t.video.videoWidth, t.height = t.video.videoHeight));
  }
  // ===========================================================================
  // Cleanup
  // ===========================================================================
  dispose(e) {
    var t, i, n, r;
    this._audioTexture && ((t = this._audioTexture.stream) == null || t.getTracks().forEach((o) => o.stop()), (i = this._audioTexture.audioContext) == null || i.close(), e.deleteTexture(this._audioTexture.texture));
    for (const o of this._videoTextures)
      (n = o.stream) == null || n.getTracks().forEach((a) => a.stop()), (r = o.video) == null || r.pause(), e.deleteTexture(o.texture);
    this._audioTexture = null, this._videoTextures = [];
  }
  // ===========================================================================
  // Helpers
  // ===========================================================================
  getAllChannelSources(e) {
    const t = [], i = e.passes;
    for (const n of [i.Image, i.BufferA, i.BufferB, i.BufferC, i.BufferD])
      n && (t.push(...n.channels), n.namedSamplers && t.push(...n.namedSamplers.values()));
    return t;
  }
}
class li {
  constructor(e) {
    h(this, "definitions");
    h(this, "values", {});
    this.definitions = e, this.initializeDefaults();
  }
  /**
   * Initialize all values to their definition defaults.
   */
  initializeDefaults() {
    for (const [e, t] of Object.entries(this.definitions))
      if (Q(t)) {
        const i = Ve(t.struct);
        this.values[e] = new Float32Array(i.tightFloatsPerElement * t.count);
      } else q(t) ? this.values[e] = new Float32Array(ue(t.type, t.count)) : this.values[e] = this.cloneValue(t.value);
  }
  /**
   * Clone a value to avoid mutation of arrays.
   */
  cloneValue(e) {
    return e instanceof Float32Array ? e.slice() : Array.isArray(e) ? [...e] : e;
  }
  /**
   * Get the definition for a uniform.
   */
  getDefinition(e) {
    return this.definitions[e];
  }
  /**
   * Get all definitions.
   */
  getDefinitions() {
    return this.definitions;
  }
  /**
   * Check if a uniform exists.
   */
  has(e) {
    return e in this.definitions;
  }
  /**
   * Get the current value of a uniform.
   */
  get(e) {
    const t = this.values[e];
    return t !== void 0 ? this.cloneValue(t) : void 0;
  }
  /**
   * Get all current values (returns a shallow copy).
   */
  getAll() {
    const e = {};
    for (const [t, i] of Object.entries(this.values))
      e[t] = this.cloneValue(i);
    return e;
  }
  /**
   * Set the value of a uniform.
   * Returns true if the value was set, false if the uniform doesn't exist.
   */
  set(e, t) {
    return this.has(e) ? (this.values[e] = this.cloneValue(t), !0) : !1;
  }
  /**
   * Set without cloning — caller is responsible for not mutating the value afterward.
   * For engine-internal use (e.g., array uniforms where data is immediately packed into UBO).
   */
  setRaw(e, t) {
    return this.has(e) ? (this.values[e] = t, !0) : !1;
  }
  /**
   * Get the internal reference without cloning. For engine-internal use only.
   */
  getRaw(e) {
    return this.values[e];
  }
  /**
   * Set multiple values at once.
   */
  setAll(e) {
    for (const [t, i] of Object.entries(e))
      i !== void 0 && this.set(t, i);
  }
  /**
   * Reset a single uniform to its default value.
   */
  reset(e) {
    const t = this.definitions[e];
    if (!t)
      return !1;
    if (Q(t)) {
      const i = Ve(t.struct);
      this.values[e] = new Float32Array(i.tightFloatsPerElement * t.count);
    } else q(t) ? this.values[e] = new Float32Array(ue(t.type, t.count)) : this.values[e] = this.cloneValue(t.value);
    return !0;
  }
  /**
   * Reset all uniforms to their default values.
   */
  resetAll() {
    this.initializeDefaults();
  }
  /**
   * Get the default value for a uniform.
   */
  getDefault(e) {
    const t = this.definitions[e];
    if (t) {
      if (Q(t)) {
        const i = Ve(t.struct);
        return new Float32Array(i.tightFloatsPerElement * t.count);
      }
      return q(t) ? new Float32Array(ue(t.type, t.count)) : this.cloneValue(t.value);
    }
  }
  /**
   * Iterate over all uniforms (name, definition, current value).
   */
  *entries() {
    for (const [e, t] of Object.entries(this.definitions))
      yield [e, t, this.values[e]];
  }
  /**
   * Get the number of uniforms.
   */
  get size() {
    return Object.keys(this.definitions).length;
  }
  /**
   * Check if there are any uniforms.
   */
  get isEmpty() {
    return this.size === 0;
  }
}
class ui {
  constructor(e, t, i) {
    h(this, "_store");
    h(this, "_ubos", []);
    h(this, "_uboMap", /* @__PURE__ */ new Map());
    h(this, "_dirtyScalars", /* @__PURE__ */ new Set());
    h(this, "_uniforms");
    this._uniforms = t, this._store = new li(t), this.initUBOs(e), i && this.applyInitialData(i);
    for (const [n, r] of Object.entries(t))
      G(r) || this._dirtyScalars.add(n);
  }
  // ===========================================================================
  // Accessors
  // ===========================================================================
  get ubos() {
    return this._ubos;
  }
  get store() {
    return this._store;
  }
  // ===========================================================================
  // Get / Set
  // ===========================================================================
  get(e) {
    return this._store.get(e);
  }
  getAll() {
    return this._store.getAll();
  }
  /**
   * Set the value of a custom uniform.
   * Dispatches to the appropriate handler based on uniform type.
   */
  set(e, t) {
    const i = this._uniforms[e];
    if (!i) {
      console.warn(`setUniformValue('${e}'): uniform not defined in config`);
      return;
    }
    q(i) ? this.setPlainArrayRaw(e, i, t) : Q(i) ? this.setStructArrayRaw(e, i, t) : this.setScalar(e, i, t);
  }
  setScalar(e, t, i) {
    const n = t.type;
    if ((n === "float" || n === "int") && typeof i != "number") {
      console.warn(`setUniformValue('${e}'): expected number for ${n}, got ${typeof i}`);
      return;
    }
    if (n === "bool" && typeof i != "boolean") {
      console.warn(`setUniformValue('${e}'): expected boolean, got ${typeof i}`);
      return;
    }
    if (n === "vec2" || n === "vec3" || n === "vec4") {
      if (!Array.isArray(i)) {
        console.warn(`setUniformValue('${e}'): expected array for ${n}, got ${typeof i}`);
        return;
      }
      const r = n === "vec2" ? 2 : n === "vec3" ? 3 : 4;
      if (i.length !== r) {
        console.warn(`setUniformValue('${e}'): expected array of length ${r} for ${n}, got ${i.length}`);
        return;
      }
    }
    this._store.set(e, i), this._dirtyScalars.add(e);
  }
  setPlainArrayRaw(e, t, i) {
    this._store.setRaw(e, i);
    const n = this._uboMap.get(e);
    if (!n) return;
    const r = ue(t.type, t.count), o = ue(t.type, 1);
    if (i.length > r) {
      console.warn(`setUniformValue('${e}'): data length ${i.length} exceeds max ${r}`);
      return;
    }
    if (i.length % o !== 0) {
      console.warn(`setUniformValue('${e}'): data length ${i.length} is not a multiple of ${o}`);
      return;
    }
    const a = i.length / o, c = Bt(t.type, a, i, n.paddedData);
    c !== n.paddedData && n.paddedData.set(c);
    const u = Ft(t.type, a);
    u < n.paddedData.length && n.paddedData.fill(0, u), n.activeCount = a, n.dirty = !0;
  }
  setStructArrayRaw(e, t, i) {
    this._store.setRaw(e, i);
    const n = this._uboMap.get(e);
    if (!n) return;
    const r = n.layout.strideFloats * t.count;
    if (i.length > r) {
      console.warn(`setUniformValue('${e}'): data length ${i.length} exceeds max ${r}`);
      return;
    }
    n.paddedData.set(i), i.length < n.paddedData.length && n.paddedData.fill(0, i.length), n.activeCount = Math.ceil(i.length / n.layout.strideFloats), n.dirty = !0;
  }
  setMultiple(e) {
    for (const [t, i] of Object.entries(e))
      i !== void 0 && this.set(t, i);
  }
  // ===========================================================================
  // Plain Array Helpers
  // ===========================================================================
  /**
   * Set an array uniform from structured JS arrays.
   * Flattens and packs automatically based on the uniform's declared type.
   */
  setArrayUniform(e, t) {
    const i = this._uniforms[e];
    if (!i || !q(i)) {
      console.warn(`setArrayUniform('${e}'): not an array uniform`);
      return;
    }
    const n = ue(i.type, 1);
    if (t.length === 0) {
      this.set(e, new Float32Array(0));
      return;
    }
    const r = this._uboMap.get(e), o = r == null ? void 0 : r.scratch;
    if (typeof t[0] == "number") {
      const l = t;
      if (o) {
        for (let d = 0; d < l.length && d < o.length; d++) o[d] = l[d];
        this.set(e, o.subarray(0, l.length));
      } else
        this.set(e, new Float32Array(l));
      return;
    }
    const a = t;
    if (a.length > i.count) {
      console.warn(`setArrayUniform('${e}'): ${a.length} elements exceeds max ${i.count}`);
      return;
    }
    const c = a.length * n, u = o ?? new Float32Array(c);
    for (let l = 0; l < a.length; l++) {
      const d = a[l], m = l * n;
      for (let g = 0; g < n; g++)
        u[m + g] = d[g] ?? 0;
    }
    this.set(e, u.subarray(0, c));
  }
  /**
   * Set a single element of an array uniform by index.
   * Only repacks that element's std140 slot.
   */
  setArrayElement(e, t, i) {
    const n = this._uniforms[e];
    if (!n || !q(n)) {
      console.warn(`setArrayElement('${e}'): not an array uniform`);
      return;
    }
    const r = this._uboMap.get(e);
    if (!r) return;
    if (t < 0 || t >= n.count) {
      console.warn(`setArrayElement('${e}'): index ${t} out of range [0, ${n.count})`);
      return;
    }
    const o = ue(n.type, 1), a = typeof i == "number" ? [i] : i, c = this._store.getRaw(e), u = t * o;
    for (let g = 0; g < o; g++)
      c[u + g] = a[g] ?? 0;
    const l = Ft(n.type, 1), d = t * l, m = new Float32Array(o);
    for (let g = 0; g < o; g++)
      m[g] = a[g] ?? 0;
    Bt(n.type, 1, m, r.paddedData.subarray(d, d + l)), t >= r.activeCount && (r.activeCount = t + 1), r.dirty = !0;
  }
  // ===========================================================================
  // Struct Array Helpers
  // ===========================================================================
  /**
   * Set a struct array uniform from per-field data.
   * Omitted fields preserve their existing values in the buffer.
   */
  setStructArrayUniform(e, t) {
    const i = this._uniforms[e];
    if (!i || !Q(i)) {
      console.warn(`setStructArrayUniform('${e}'): not a struct array uniform`);
      return;
    }
    const n = this._uboMap.get(e);
    if (!n) return;
    let r = 0;
    const o = {};
    for (const c of n.layout.fields) {
      const u = t[c.name];
      if (!u || u.length === 0) continue;
      const l = n.fieldScratch[c.name];
      if (typeof u[0] == "number") {
        const d = u;
        for (let m = 0; m < d.length && m < l.length; m++) l[m] = d[m];
        o[c.name] = l.subarray(0, d.length), r = Math.max(r, Math.floor(d.length / c.tightFloats));
      } else {
        const d = u;
        r = Math.max(r, d.length);
        const m = d.length * c.tightFloats;
        for (let g = 0; g < d.length; g++) {
          const E = d[g], v = g * c.tightFloats;
          for (let _ = 0; _ < c.tightFloats; _++)
            l[v + _] = E[_] ?? 0;
        }
        o[c.name] = l.subarray(0, m);
      }
    }
    if (r > i.count) {
      console.warn(`setStructArrayUniform('${e}'): ${r} elements exceeds max ${i.count}`);
      return;
    }
    si(n.layout, r, o, n.paddedData);
    const a = n.layout.strideFloats * r;
    a < n.paddedData.length && n.paddedData.fill(0, a), n.activeCount = r, n.dirty = !0;
  }
  /**
   * Set a single element of a struct array uniform by index.
   * Omitted fields preserve their existing values.
   */
  setStructArrayElement(e, t, i) {
    const n = this._uniforms[e];
    if (!n || !Q(n)) {
      console.warn(`setStructArrayElement('${e}'): not a struct array uniform`);
      return;
    }
    const r = this._uboMap.get(e);
    if (!r) return;
    if (t < 0 || t >= n.count) {
      console.warn(`setStructArrayElement('${e}'): index ${t} out of range [0, ${n.count})`);
      return;
    }
    const o = {};
    for (const a of r.layout.fields) {
      const c = i[a.name];
      c !== void 0 && (o[a.name] = typeof c == "number" ? [c] : c);
    }
    ii(r.layout, t, o, r.paddedData), t >= r.activeCount && (r.activeCount = t + 1), r.dirty = !0;
  }
  // ===========================================================================
  // Shared Helpers
  // ===========================================================================
  /**
   * Set how many elements of a UBO uniform the shader should use.
   * Works for both plain array and struct array uniforms.
   */
  setActiveCount(e, t) {
    const i = this._uboMap.get(e);
    if (!i) {
      console.warn(`setActiveCount('${e}'): not a UBO uniform`);
      return;
    }
    if (t < 0 || t > i.def.count) {
      console.warn(`setActiveCount('${e}'): count ${t} out of range [0, ${i.def.count}]`);
      return;
    }
    i.activeCount = t;
  }
  // ===========================================================================
  // GL Binding
  // ===========================================================================
  /**
   * Bind custom uniform values to the current program.
   * Uploads dirty UBOs and re-binds changed scalar uniforms.
   */
  bindToProgram(e, t) {
    for (const i of this._ubos) {
      i.dirty && (e.bindBuffer(e.UNIFORM_BUFFER, i.buffer), e.bufferSubData(e.UNIFORM_BUFFER, 0, i.paddedData), i.dirty = !1);
      const n = t.custom.get(`${i.name}_count`);
      n && e.uniform1i(n, i.activeCount);
    }
    for (const i of this._dirtyScalars) {
      const n = this._uniforms[i];
      if (!n || G(n)) continue;
      const r = this._store.get(i);
      if (r === void 0) continue;
      const o = t.custom.get(i);
      if (o)
        switch (n.type) {
          case "float":
            e.uniform1f(o, r);
            break;
          case "int":
            e.uniform1i(o, r);
            break;
          case "bool":
            e.uniform1i(o, r ? 1 : 0);
            break;
          case "vec2": {
            const a = r;
            e.uniform2f(o, a[0], a[1]);
            break;
          }
          case "vec3": {
            const a = r;
            e.uniform3f(o, a[0], a[1], a[2]);
            break;
          }
          case "vec4": {
            const a = r;
            e.uniform4f(o, a[0], a[1], a[2], a[3]);
            break;
          }
        }
    }
  }
  clearDirty() {
    this._dirtyScalars.clear();
  }
  markAllScalarsDirty() {
    for (const [e, t] of Object.entries(this._uniforms))
      G(t) || this._dirtyScalars.add(e);
  }
  bindUBOsToProgram(e, t, i) {
    for (const n of this._ubos) {
      const r = e.getUniformBlockIndex(t, `_ub_${n.name}`);
      r !== e.INVALID_INDEX && e.uniformBlockBinding(t, r, n.bindingPoint), i.set(`${n.name}_count`, e.getUniformLocation(t, `${n.name}_count`));
    }
  }
  // ===========================================================================
  // Cleanup
  // ===========================================================================
  dispose(e) {
    for (const t of this._ubos)
      e.deleteBuffer(t.buffer);
    this._ubos = [], this._uboMap.clear();
  }
  // ===========================================================================
  // Initial Data
  // ===========================================================================
  applyInitialData(e) {
    for (const [t, i] of Object.entries(e)) {
      const n = this._uniforms[t];
      n && (q(n) ? this.setArrayUniform(t, i) : Q(n) && this.setStructArrayUniform(t, i));
    }
  }
  // ===========================================================================
  // Initialization
  // ===========================================================================
  initUBOs(e) {
    const t = e.getParameter(e.MAX_UNIFORM_BLOCK_SIZE), i = e.getParameter(e.MAX_UNIFORM_BUFFER_BINDINGS);
    let n = 0;
    for (const [r, o] of Object.entries(this._uniforms))
      if (q(o)) {
        const a = this.createPlainArrayUBO(e, r, o, n, t, i);
        this._ubos.push(a), this._uboMap.set(r, a), n++;
      } else if (Q(o)) {
        const a = this.createStructArrayUBO(e, r, o, n, t, i);
        this._ubos.push(a), this._uboMap.set(r, a), n++;
      }
  }
  createPlainArrayUBO(e, t, i, n, r, o) {
    const a = Zs(i.type, i.count);
    this.validateUBOSize(t, a, n, r, o);
    const c = this.allocateBuffer(e, t, a, n);
    return {
      kind: "array",
      name: t,
      def: i,
      buffer: c,
      bindingPoint: n,
      byteSize: a,
      dirty: !1,
      paddedData: new Float32Array(a / 4),
      activeCount: 0,
      scratch: new Float32Array(ue(i.type, i.count))
    };
  }
  createStructArrayUBO(e, t, i, n, r, o) {
    const a = Ve(i.struct), c = ti(a, i.count);
    this.validateUBOSize(t, c, n, r, o);
    const u = this.allocateBuffer(e, t, c, n), l = {};
    for (const d of a.fields)
      l[d.name] = new Float32Array(d.tightFloats * i.count);
    return {
      kind: "struct",
      name: t,
      def: i,
      buffer: u,
      bindingPoint: n,
      byteSize: c,
      dirty: !1,
      paddedData: new Float32Array(c / 4),
      activeCount: 0,
      layout: a,
      fieldScratch: l
    };
  }
  validateUBOSize(e, t, i, n, r) {
    if (t > n)
      throw new Error(`UBO '${e}' requires ${t} bytes but GL MAX_UNIFORM_BLOCK_SIZE is ${n}`);
    if (i >= r)
      throw new Error(`Too many UBO uniforms: binding point ${i} exceeds GL MAX_UNIFORM_BUFFER_BINDINGS (${r})`);
  }
  allocateBuffer(e, t, i, n) {
    const r = e.createBuffer();
    if (!r) throw new Error(`Failed to create UBO buffer for '${t}'`);
    return e.bindBuffer(e.UNIFORM_BUFFER, r), e.bufferData(e.UNIFORM_BUFFER, i, e.DYNAMIC_DRAW), e.bindBuffer(e.UNIFORM_BUFFER, null), e.bindBufferBase(e.UNIFORM_BUFFER, n, r), r;
  }
}
class Mt {
  constructor(e) {
    h(this, "project");
    h(this, "gl");
    h(this, "_width");
    h(this, "_height");
    h(this, "_frame", 0);
    h(this, "_time", 0);
    h(this, "_lastStepTime", null);
    h(this, "_passes", []);
    h(this, "_textures", []);
    h(this, "_keyboardTexture", null);
    h(this, "_blackTexture", null);
    // Keyboard state tracking (Maps keycodes to state)
    h(this, "_keyStates", /* @__PURE__ */ new Map());
    // true = down, false = up
    h(this, "_toggleStates", /* @__PURE__ */ new Map());
    // 0.0 or 1.0
    // Compilation errors (if any occurred during initialization)
    h(this, "_compilationErrors", []);
    // Custom uniforms (scalars + UBO-backed arrays)
    h(this, "_uniformMgr");
    // Media (audio, video, webcam)
    h(this, "_media");
    // Script-uploaded textures
    h(this, "_scriptTextures", /* @__PURE__ */ new Map());
    // Shared VAO for fullscreen triangle (all passes reference this)
    h(this, "_sharedVAO", null);
    // Disposal flag — guards async callbacks (e.g. image loads) after engine is destroyed
    h(this, "_disposed", !1);
    // View names for multi-view projects (enables cross-view uniforms)
    h(this, "_viewNames", []);
    // Asset error callback
    h(this, "_onAssetError");
    this.gl = e.gl, this.project = e.project, this._onAssetError = e.onAssetError, this._width = this.gl.drawingBufferWidth, this._height = this.gl.drawingBufferHeight, this.initExtensions(), this._blackTexture = Hs(this.gl);
    const t = Ws(this.gl);
    this._keyboardTexture = {
      texture: t,
      width: 256,
      height: 3
    }, this.initProjectTextures(), this._media = new ci(this.gl, e.project), this._uniformMgr = new ui(this.gl, e.project.uniforms, e.project.uniformData), e.viewNames && e.viewNames.length > 1 && (this._viewNames = e.viewNames), this.initRuntimePasses();
  }
  // ===========================================================================
  // Media Delegates (forwarded to MediaManager)
  // ===========================================================================
  async initAudio() {
    return this._media.initAudio();
  }
  updateAudioTexture() {
    this._media.updateAudioTexture(this.gl);
  }
  async initWebcam() {
    return this._media.initWebcam();
  }
  async initVideo(e) {
    return this._media.initVideo(e);
  }
  updateVideoTextures() {
    this._media.updateVideoTextures(this.gl);
  }
  /** Whether this project uses audio channels. */
  get needsAudio() {
    return this._media.needsAudio;
  }
  /** Whether this project uses webcam channels. */
  get needsWebcam() {
    return this._media.needsWebcam;
  }
  /** Get video sources that need initialization. */
  get videoSources() {
    return this._media.videoSources;
  }
  /**
   * Upload or update a named texture from JavaScript (for script channel).
   */
  updateTexture(e, t, i, n) {
    const r = this._scriptTextures.get(e), o = n instanceof Float32Array;
    if (r && r.width === t && r.height === i && r.isFloat === o) {
      const a = this.gl;
      a.bindTexture(a.TEXTURE_2D, r.texture), o ? a.texSubImage2D(a.TEXTURE_2D, 0, 0, 0, t, i, a.RGBA, a.FLOAT, n) : a.texSubImage2D(a.TEXTURE_2D, 0, 0, 0, t, i, a.RGBA, a.UNSIGNED_BYTE, n), a.bindTexture(a.TEXTURE_2D, null);
    } else {
      const a = qs(
        this.gl,
        (r == null ? void 0 : r.texture) ?? null,
        t,
        i,
        n
      );
      this._scriptTextures.set(e, { texture: a, width: t, height: i, isFloat: o });
    }
  }
  /**
   * Read pixels from a buffer pass (reads previous frame's data).
   */
  readPixels(e, t, i, n, r) {
    const o = this._passes.find((u) => u.name === e);
    if (!o)
      return console.warn(`readPixels: pass '${e}' not found`), new Uint8Array(n * r * 4);
    const a = this.gl;
    a.bindFramebuffer(a.FRAMEBUFFER, o.framebuffer), a.framebufferTexture2D(a.FRAMEBUFFER, a.COLOR_ATTACHMENT0, a.TEXTURE_2D, o.previousTexture, 0);
    const c = new Uint8Array(n * r * 4);
    return a.readPixels(t, i, n, r, a.RGBA, a.UNSIGNED_BYTE, c), a.framebufferTexture2D(a.FRAMEBUFFER, a.COLOR_ATTACHMENT0, a.TEXTURE_2D, o.currentTexture, 0), a.bindFramebuffer(a.FRAMEBUFFER, null), c;
  }
  // ===========================================================================
  // Public API
  // ===========================================================================
  get width() {
    return this._width;
  }
  get height() {
    return this._height;
  }
  get stats() {
    const e = this._lastStepTime === null ? 0 : this._time - this._lastStepTime;
    return {
      frame: this._frame,
      time: this._time,
      deltaTime: e,
      width: this._width,
      height: this._height
    };
  }
  /**
   * Get shader compilation errors (if any occurred during initialization).
   * Returns empty array if all shaders compiled successfully.
   */
  getCompilationErrors() {
    return this._compilationErrors;
  }
  /**
   * Check if there were any compilation errors.
   */
  hasErrors() {
    return this._compilationErrors.length > 0;
  }
  getUniformStore() {
    return this._uniformMgr.store;
  }
  getUniformValue(e) {
    return this._uniformMgr.get(e);
  }
  getUniformValues() {
    return this._uniformMgr.getAll();
  }
  setUniformValue(e, t) {
    this._uniformMgr.set(e, t);
  }
  setUniformValues(e) {
    this._uniformMgr.setMultiple(e);
  }
  setArrayUniform(e, t) {
    this._uniformMgr.setArrayUniform(e, t);
  }
  setArrayElement(e, t, i) {
    this._uniformMgr.setArrayElement(e, t, i);
  }
  setActiveCount(e, t) {
    this._uniformMgr.setActiveCount(e, t);
  }
  setStructArrayUniform(e, t) {
    this._uniformMgr.setStructArrayUniform(e, t);
  }
  setStructArrayElement(e, t, i) {
    this._uniformMgr.setStructArrayElement(e, t, i);
  }
  /** Export UBO data for HTML export (copies current padded data). */
  getUBOExportData() {
    return this._uniformMgr.ubos.map((e) => ({
      name: e.name,
      type: e.kind === "struct" ? "struct" : e.def.type,
      count: e.def.count,
      bindingPoint: e.bindingPoint,
      paddedData: new Float32Array(e.paddedData),
      struct: e.kind === "struct" ? e.def.struct : void 0
    }));
  }
  /**
   * Get the framebuffer for the Image pass (for presenting to screen).
   */
  getImageFramebuffer() {
    const e = this._passes.find((t) => t.name === "Image");
    return (e == null ? void 0 : e.framebuffer) ?? null;
  }
  /**
   * Bind the Image pass output as the READ_FRAMEBUFFER for blitting to screen.
   *
   * After the ping-pong swap, the rendered output is in previousTexture,
   * but the framebuffer is attached to currentTexture. This method temporarily
   * attaches previousTexture so blitFramebuffer reads the correct data.
   */
  bindImageForRead() {
    const e = this.gl, t = this._passes.find((i) => i.name === "Image");
    return t ? (e.bindFramebuffer(e.READ_FRAMEBUFFER, t.framebuffer), e.framebufferTexture2D(
      e.READ_FRAMEBUFFER,
      e.COLOR_ATTACHMENT0,
      e.TEXTURE_2D,
      t.previousTexture,
      0
    ), !0) : !1;
  }
  /**
   * Restore the Image pass framebuffer to its normal state (attached to currentTexture).
   * Call after blitting to screen.
   */
  unbindImageForRead() {
    const e = this.gl, t = this._passes.find((i) => i.name === "Image");
    t && (e.framebufferTexture2D(
      e.READ_FRAMEBUFFER,
      e.COLOR_ATTACHMENT0,
      e.TEXTURE_2D,
      t.currentTexture,
      0
    ), e.bindFramebuffer(e.READ_FRAMEBUFFER, null));
  }
  /**
   * Run one full frame of all passes.
   *
   * @param timeSeconds - global time in seconds (monotone, from App)
   * @param mouse - iMouse as [x, y, clickX, clickY]
   * @param touch - optional touch state for touch uniforms
   */
  step(e, t, i, n, r) {
    const o = this.gl, a = this._lastStepTime === null ? 0 : e - this._lastStepTime;
    this._lastStepTime = e, this._time = e;
    const c = /* @__PURE__ */ new Date(), u = n ?? {
      count: 0,
      touches: [[0, 0, 0, 0], [0, 0, 0, 0], [0, 0, 0, 0]],
      pinch: 1,
      pinchDelta: 0,
      pinchCenter: [0, 0]
    }, l = {
      iResolution: [this._width, this._height, 1],
      iTime: this._time,
      iTimeDelta: a,
      iFrame: this._frame,
      iMouse: t,
      iMousePressed: i,
      iDate: [
        c.getFullYear(),
        c.getMonth(),
        // 0-11 (matches Shadertoy)
        c.getDate(),
        // 1-31
        c.getHours() * 3600 + c.getMinutes() * 60 + c.getSeconds() + c.getMilliseconds() / 1e3
      ],
      iFrameRate: a > 0 ? 1 / a : 60,
      iTouchCount: u.count,
      iTouch: u.touches,
      iPinch: u.pinch,
      iPinchDelta: u.pinchDelta,
      iPinchCenter: u.pinchCenter,
      crossViewStates: r
    };
    o.viewport(0, 0, this._width, this._height);
    const d = ["BufferA", "BufferB", "BufferC", "BufferD", "Image"];
    for (const m of d) {
      const g = this._passes.find((E) => E.name === m);
      g && (this.executePass(g, l), this.swapPassTextures(g));
    }
    this._uniformMgr.clearDirty(), this._frame += 1;
  }
  /**
   * Resize all internal render targets to new width/height.
   * Does not reset time or frame count.
   */
  resize(e, t) {
    this._width = e, this._height = t;
    const i = this.gl;
    for (const n of this._passes)
      i.deleteTexture(n.currentTexture), i.deleteTexture(n.previousTexture), i.deleteFramebuffer(n.framebuffer), n.currentTexture = Ie(i, e, t), n.previousTexture = Ie(i, e, t), n.framebuffer = kt(i, n.currentTexture);
  }
  /**
   * Reset frame counter and clear all render targets.
   * Used for playback controls to restart shader from frame 0.
   */
  reset() {
    this._frame = 0;
    const e = this.gl;
    for (const t of this._passes)
      e.bindFramebuffer(e.FRAMEBUFFER, t.framebuffer), e.clearColor(0, 0, 0, 0), e.clear(e.COLOR_BUFFER_BIT), e.framebufferTexture2D(
        e.FRAMEBUFFER,
        e.COLOR_ATTACHMENT0,
        e.TEXTURE_2D,
        t.previousTexture,
        0
      ), e.clear(e.COLOR_BUFFER_BIT), e.framebufferTexture2D(
        e.FRAMEBUFFER,
        e.COLOR_ATTACHMENT0,
        e.TEXTURE_2D,
        t.currentTexture,
        0
      );
    e.bindFramebuffer(e.FRAMEBUFFER, null);
  }
  /**
   * Update keyboard key state (called from App on keydown/keyup events).
   *
   * @param keycode ASCII keycode (e.g., 65 for 'A')
   * @param isDown true if key pressed, false if released
   */
  updateKeyState(e, t) {
    const i = this._keyStates.get(e) || !1;
    if (this._keyStates.set(e, t), t && !i) {
      const n = this._toggleStates.get(e) || 0;
      this._toggleStates.set(e, n === 0 ? 1 : 0);
    }
  }
  /**
   * Update keyboard texture with current key states.
   * Should be called once per frame before rendering.
   */
  updateKeyboardTexture() {
    this._keyboardTexture && Xs(
      this.gl,
      this._keyboardTexture.texture,
      this._keyStates,
      this._toggleStates
    );
  }
  /**
   * Recompile a single pass with new GLSL source code.
   * Used for live editing - keeps the old shader running if compilation fails.
   *
   * @param passName - Name of the pass to recompile ('Image', 'BufferA', etc.)
   * @param newSource - New GLSL source code for the pass
   * @returns Object with success status and error message if failed
   */
  recompilePass(e, t) {
    const i = this.gl, n = this._passes.find((a) => a.name === e);
    if (!n)
      return { success: !1, error: `Pass '${e}' not found` };
    const r = this.project.passes[e];
    if (!r)
      return { success: !1, error: `Project pass '${e}' not found` };
    const { source: o } = this.buildFragmentShader(t, r.channels, r.namedSamplers);
    try {
      const a = Rt(i, Pt, o);
      return i.deleteProgram(n.uniforms.program), n.uniforms = this.cacheUniformLocations(a, r.namedSamplers), r.glslSource = t, this._compilationErrors = this._compilationErrors.filter((c) => c.passName !== e), this._uniformMgr.markAllScalarsDirty(), { success: !0 };
    } catch (a) {
      return { success: !1, error: a instanceof Error ? a.message : String(a) };
    }
  }
  /**
   * Recompile common.glsl and all passes that use it.
   * Used for live editing of common code.
   *
   * @param newCommonSource - New GLSL source code for common.glsl
   * @returns Object with success status and errors for each failed pass
   */
  recompileCommon(e) {
    const t = this.project.commonSource;
    this.project.commonSource = e;
    const i = [], n = ["BufferA", "BufferB", "BufferC", "BufferD", "Image"];
    for (const r of n) {
      const o = this.project.passes[r];
      if (!o) continue;
      const a = this.recompilePass(r, o.glslSource);
      a.success || i.push({ passName: r, error: a.error || "Unknown error" });
    }
    if (i.length > 0) {
      this.project.commonSource = t;
      for (const r of n) {
        const o = this.project.passes[r];
        if (!o || i.some((c) => c.passName === r)) continue;
        const a = this.recompilePass(r, o.glslSource);
        a.success || (console.error(`Failed to revert ${r} to old common source:`, a.error), i.push({ passName: r, error: `Revert failed: ${a.error}` }));
      }
      return { success: !1, errors: i };
    }
    return { success: !0, errors: [] };
  }
  /**
   * Delete all GL resources.
   */
  dispose() {
    this._disposed = !0;
    const e = this.gl;
    for (const t of this._passes)
      e.deleteProgram(t.uniforms.program), e.deleteFramebuffer(t.framebuffer), e.deleteTexture(t.currentTexture), e.deleteTexture(t.previousTexture);
    this._sharedVAO && (e.deleteVertexArray(this._sharedVAO), this._sharedVAO = null);
    for (const t of this._textures)
      e.deleteTexture(t.texture);
    this._keyboardTexture && e.deleteTexture(this._keyboardTexture.texture), this._blackTexture && e.deleteTexture(this._blackTexture);
    for (const [, t] of this._scriptTextures)
      e.deleteTexture(t.texture);
    this._scriptTextures.clear(), this._uniformMgr.dispose(e), this._media.dispose(e), this._passes = [], this._textures = [], this._keyboardTexture = null, this._blackTexture = null;
  }
  // ===========================================================================
  // Initialization Helpers
  // ===========================================================================
  initExtensions() {
    const e = this.gl;
    if (!e.getExtension("EXT_color_buffer_float"))
      throw new Error(
        "EXT_color_buffer_float not supported. WebGL2 with float rendering is required."
      );
    e.getExtension("OES_texture_float_linear");
  }
  /**
   * Cache uniform locations for a compiled program.
   * Returns a PassUniformLocations object with all standard and custom uniform locations.
   */
  cacheUniformLocations(e, t) {
    const i = this.gl, n = /* @__PURE__ */ new Map();
    for (const [r, o] of Object.entries(this.project.uniforms))
      G(o) || n.set(r, i.getUniformLocation(e, r));
    return this._uniformMgr.bindUBOsToProgram(i, e, n), {
      program: e,
      iResolution: i.getUniformLocation(e, "iResolution"),
      iTime: i.getUniformLocation(e, "iTime"),
      iTimeDelta: i.getUniformLocation(e, "iTimeDelta"),
      iFrame: i.getUniformLocation(e, "iFrame"),
      iMouse: i.getUniformLocation(e, "iMouse"),
      iMousePressed: i.getUniformLocation(e, "iMousePressed"),
      iDate: i.getUniformLocation(e, "iDate"),
      iFrameRate: i.getUniformLocation(e, "iFrameRate"),
      iChannel: [
        i.getUniformLocation(e, "iChannel0"),
        i.getUniformLocation(e, "iChannel1"),
        i.getUniformLocation(e, "iChannel2"),
        i.getUniformLocation(e, "iChannel3")
      ],
      iChannelResolution: [
        i.getUniformLocation(e, "iChannelResolution[0]"),
        i.getUniformLocation(e, "iChannelResolution[1]"),
        i.getUniformLocation(e, "iChannelResolution[2]"),
        i.getUniformLocation(e, "iChannelResolution[3]")
      ],
      // Touch uniforms
      iTouchCount: i.getUniformLocation(e, "iTouchCount"),
      iTouch: [
        i.getUniformLocation(e, "iTouch0"),
        i.getUniformLocation(e, "iTouch1"),
        i.getUniformLocation(e, "iTouch2")
      ],
      iPinch: i.getUniformLocation(e, "iPinch"),
      iPinchDelta: i.getUniformLocation(e, "iPinchDelta"),
      iPinchCenter: i.getUniformLocation(e, "iPinchCenter"),
      custom: n,
      namedSamplers: (() => {
        const r = /* @__PURE__ */ new Map();
        if (t)
          for (const [o] of t)
            r.set(o, i.getUniformLocation(e, o));
        return r;
      })(),
      namedSamplerResolutions: (() => {
        const r = /* @__PURE__ */ new Map();
        if (t)
          for (const [o] of t)
            r.set(o, i.getUniformLocation(e, `${o}_resolution`));
        return r;
      })(),
      // Cross-view uniforms for multi-view projects
      crossViewMouse: (() => {
        const r = /* @__PURE__ */ new Map();
        if (this._viewNames.length > 1)
          for (const o of this._viewNames)
            r.set(o, i.getUniformLocation(e, `iMouse_${o}`));
        return r;
      })(),
      crossViewResolution: (() => {
        const r = /* @__PURE__ */ new Map();
        if (this._viewNames.length > 1)
          for (const o of this._viewNames)
            r.set(o, i.getUniformLocation(e, `iResolution_${o}`));
        return r;
      })(),
      crossViewMousePressed: (() => {
        const r = /* @__PURE__ */ new Map();
        if (this._viewNames.length > 1)
          for (const o of this._viewNames)
            r.set(o, i.getUniformLocation(e, `iMousePressed_${o}`));
        return r;
      })()
    };
  }
  /**
   * Initialize external textures based on project.textures.
   *
   * NOTE: This function as written assumes that actual image loading
   * is handled elsewhere. For now we just construct an empty array.
   * In a real implementation, you would load images here.
   */
  initProjectTextures() {
    const e = this.gl;
    this._textures = [];
    for (const t of this.project.textures) {
      const i = e.createTexture();
      if (!i)
        throw new Error("Failed to create texture");
      e.bindTexture(e.TEXTURE_2D, i), e.texImage2D(e.TEXTURE_2D, 0, e.RGBA, 1, 1, 0, e.RGBA, e.UNSIGNED_BYTE, new Uint8Array([0, 0, 0, 255]));
      const n = {
        name: t.name,
        texture: i,
        width: 1,
        height: 1
      };
      this._textures.push(n);
      const r = new Image();
      r.crossOrigin = "anonymous", r.onload = () => {
        if (this._disposed || e.isContextLost()) return;
        e.bindTexture(e.TEXTURE_2D, i), e.pixelStorei(e.UNPACK_FLIP_Y_WEBGL, !0), e.texImage2D(e.TEXTURE_2D, 0, e.RGBA, e.RGBA, e.UNSIGNED_BYTE, r), e.pixelStorei(e.UNPACK_FLIP_Y_WEBGL, !1);
        const o = t.filter !== "nearest";
        e.texParameteri(e.TEXTURE_2D, e.TEXTURE_MAG_FILTER, o ? e.LINEAR : e.NEAREST), e.texParameteri(e.TEXTURE_2D, e.TEXTURE_MIN_FILTER, o ? e.LINEAR_MIPMAP_LINEAR : e.NEAREST);
        const a = t.wrap === "clamp" ? e.CLAMP_TO_EDGE : e.REPEAT;
        e.texParameteri(e.TEXTURE_2D, e.TEXTURE_WRAP_S, a), e.texParameteri(e.TEXTURE_2D, e.TEXTURE_WRAP_T, a), o && e.generateMipmap(e.TEXTURE_2D), n.width = r.width, n.height = r.height, console.log(`Loaded texture '${t.name}': ${r.width}x${r.height}`);
      }, r.onerror = () => {
        var o;
        console.error(`Failed to load texture '${t.name}' from ${t.source}`), (o = this._onAssetError) == null || o.call(this, { type: "texture", name: t.name, detail: t.source });
      }, r.src = t.source;
    }
  }
  /**
   * Compile shaders, create VAOs/FBOs/textures, and build RuntimePass array.
   */
  initRuntimePasses() {
    const e = this.gl, t = this.project, i = js(e);
    this._sharedVAO = i;
    const n = ["BufferA", "BufferB", "BufferC", "BufferD", "Image"];
    for (const r of n) {
      const o = t.passes[r];
      if (!o) continue;
      const { source: a, lineMapping: c } = this.buildFragmentShader(o.glslSource, o.channels, o.namedSamplers);
      try {
        const u = Rt(e, Pt, a), l = this.cacheUniformLocations(u, o.namedSamplers), d = Ie(e, this._width, this._height), m = Ie(e, this._width, this._height), g = kt(e, d), E = {
          name: r,
          projectChannels: o.channels,
          vao: i,
          uniforms: l,
          framebuffer: g,
          currentTexture: d,
          previousTexture: m,
          namedSamplers: o.namedSamplers
        };
        this._passes.push(E);
      } catch (u) {
        const l = u instanceof Error ? u.message : String(u), d = l.match(/ERROR:\s*\d+:(\d+):/);
        let m = !1, g = null;
        if (d) {
          const E = parseInt(d[1], 10);
          if (c.commonStartLine > 0 && c.commonLines > 0) {
            const v = c.commonStartLine + c.commonLines - 1;
            E >= c.commonStartLine && E <= v && (m = !0, g = E - c.commonStartLine + 1);
          }
          !m && c.userCodeStartLine > 0 && E >= c.userCodeStartLine && (g = E - c.userCodeStartLine + 1);
        }
        this._compilationErrors.push({
          passName: r,
          error: l,
          source: a,
          isFromCommon: m,
          originalLine: g,
          lineMapping: c
        }), console.error(`Failed to compile ${r}:`, l);
      }
    }
  }
  /**
   * Build complete fragment shader source with Shadertoy boilerplate.
   */
  buildFragmentShader(e, t, i) {
    return oi(e, t, {
      commonSource: this.project.commonSource ?? "",
      ubos: this._uniformMgr.ubos.map((n) => ({
        name: n.name,
        def: n.def,
        count: n.def.count,
        structLayout: n.kind === "struct" ? n.layout : void 0
      })),
      uniforms: this.project.uniforms,
      namedSamplers: i,
      viewNames: this._viewNames.length > 1 ? this._viewNames : void 0
    });
  }
  /**
   * Set view names for multi-view projects.
   * This enables cross-view uniforms (iMouse_viewName, iResolution_viewName, etc.)
   * Must be called before shader compilation.
   */
  setViewNames(e) {
    this._viewNames = e;
  }
  // ===========================================================================
  // Pass Execution
  // ===========================================================================
  executePass(e, t) {
    const i = this.gl;
    i.bindFramebuffer(i.FRAMEBUFFER, e.framebuffer), i.useProgram(e.uniforms.program), i.bindVertexArray(e.vao), this.bindBuiltinUniforms(e.uniforms, t), this._uniformMgr.bindToProgram(i, e.uniforms), e.namedSamplers && e.namedSamplers.size > 0 ? this.bindNamedSamplers(e) : this.bindChannelTextures(e), i.drawArrays(i.TRIANGLES, 0, 3), i.bindVertexArray(null), i.useProgram(null), i.bindFramebuffer(i.FRAMEBUFFER, null);
  }
  bindBuiltinUniforms(e, t) {
    const i = this.gl;
    e.iResolution && i.uniform3f(e.iResolution, t.iResolution[0], t.iResolution[1], t.iResolution[2]), e.iTime && i.uniform1f(e.iTime, t.iTime), e.iTimeDelta && i.uniform1f(e.iTimeDelta, t.iTimeDelta), e.iFrame && i.uniform1i(e.iFrame, t.iFrame), e.iMouse && i.uniform4f(e.iMouse, t.iMouse[0], t.iMouse[1], t.iMouse[2], t.iMouse[3]), e.iMousePressed && i.uniform1i(e.iMousePressed, t.iMousePressed ? 1 : 0), e.iDate && i.uniform4f(e.iDate, t.iDate[0], t.iDate[1], t.iDate[2], t.iDate[3]), e.iFrameRate && i.uniform1f(e.iFrameRate, t.iFrameRate), e.iTouchCount && i.uniform1i(e.iTouchCount, t.iTouchCount);
    for (let n = 0; n < 3; n++) {
      const r = e.iTouch[n];
      if (r) {
        const o = t.iTouch[n];
        i.uniform4f(r, o[0], o[1], o[2], o[3]);
      }
    }
    if (e.iPinch && i.uniform1f(e.iPinch, t.iPinch), e.iPinchDelta && i.uniform1f(e.iPinchDelta, t.iPinchDelta), e.iPinchCenter && i.uniform2f(e.iPinchCenter, t.iPinchCenter[0], t.iPinchCenter[1]), t.crossViewStates)
      for (const [n, r] of t.crossViewStates) {
        const o = e.crossViewMouse.get(n);
        o && i.uniform4f(o, r.mouse[0], r.mouse[1], r.mouse[2], r.mouse[3]);
        const a = e.crossViewResolution.get(n);
        a && i.uniform3f(a, r.resolution[0], r.resolution[1], r.resolution[2]);
        const c = e.crossViewMousePressed.get(n);
        c && i.uniform1i(c, r.mousePressed ? 1 : 0);
      }
  }
  bindChannelTextures(e) {
    const t = this.gl;
    for (let i = 0; i < 4; i++) {
      const n = e.projectChannels[i], r = this.resolveChannelTexture(n), o = this.resolveChannelResolution(n);
      t.activeTexture(t.TEXTURE0 + i), t.bindTexture(t.TEXTURE_2D, r);
      const a = e.uniforms.iChannel[i];
      a && t.uniform1i(a, i);
      const c = e.uniforms.iChannelResolution[i];
      c && t.uniform3f(c, o[0], o[1], 1);
    }
  }
  /**
   * Bind named samplers (standard mode).
   * Each named sampler gets its own texture unit.
   */
  bindNamedSamplers(e) {
    const t = this.gl;
    let i = 0;
    for (const [n, r] of e.namedSamplers) {
      const o = this.resolveChannelTexture(r), a = this.resolveChannelResolution(r);
      t.activeTexture(t.TEXTURE0 + i), t.bindTexture(t.TEXTURE_2D, o);
      const c = e.uniforms.namedSamplers.get(n);
      c && t.uniform1i(c, i);
      const u = e.uniforms.namedSamplerResolutions.get(n);
      u && t.uniform3f(u, a[0], a[1], 1), i++;
    }
  }
  /**
   * Resolve a ChannelSource to an actual WebGLTexture to bind.
   */
  resolveChannelTexture(e) {
    switch (e.kind) {
      case "none":
        if (!this._blackTexture)
          throw new Error("Black texture not initialized");
        return this._blackTexture;
      case "buffer": {
        const t = this._passes.find((i) => i.name === e.buffer);
        return t ? e.current ? t.currentTexture : t.previousTexture : (console.warn(`resolveChannelTexture: buffer '${e.buffer}' not found, using black`), this._blackTexture);
      }
      case "texture": {
        const t = this._textures.find((i) => i.name === e.name);
        return t ? t.texture : (console.warn(`resolveChannelTexture: texture '${e.name}' not found, using black`), this._blackTexture);
      }
      case "keyboard":
        if (!this._keyboardTexture)
          throw new Error("Internal error: keyboard texture not initialized");
        return this._keyboardTexture.texture;
      case "audio":
        return this._media.audioTexture ? this._media.audioTexture.texture : this._blackTexture;
      case "webcam": {
        const t = this._media.videoTextures.find((i) => i.kind === "webcam");
        return (t == null ? void 0 : t.texture) ?? this._blackTexture;
      }
      case "video": {
        const t = this._media.videoTextures.find((i) => i.kind === "video" && i.src === e.src);
        return (t == null ? void 0 : t.texture) ?? this._blackTexture;
      }
      case "script": {
        const t = this._scriptTextures.get(e.name);
        return (t == null ? void 0 : t.texture) ?? this._blackTexture;
      }
    }
  }
  /**
   * Resolve a ChannelSource to its resolution [width, height].
   * Returns [0, 0] for unused channels.
   */
  resolveChannelResolution(e) {
    switch (e.kind) {
      case "none":
        return [0, 0];
      case "buffer":
        return [this._width, this._height];
      case "texture": {
        const t = this._textures.find((i) => i.name === e.name);
        return t ? [t.width, t.height] : [0, 0];
      }
      case "keyboard":
        return [256, 3];
      case "audio":
        return this._media.audioTexture ? [this._media.audioTexture.width, this._media.audioTexture.height] : [0, 0];
      case "webcam": {
        const t = this._media.videoTextures.find((i) => i.kind === "webcam");
        return t ? [t.width, t.height] : [0, 0];
      }
      case "video": {
        const t = this._media.videoTextures.find((i) => i.kind === "video" && i.src === e.src);
        return t ? [t.width, t.height] : [0, 0];
      }
      case "script": {
        const t = this._scriptTextures.get(e.name);
        return t ? [t.width, t.height] : [0, 0];
      }
    }
  }
  /**
   * Swap current and previous textures for a pass (ping-pong).
   * Also reattach framebuffer to new current texture.
   */
  swapPassTextures(e) {
    const t = this.gl, i = e.currentTexture;
    e.currentTexture = e.previousTexture, e.previousTexture = i, t.bindFramebuffer(t.FRAMEBUFFER, e.framebuffer), t.framebufferTexture2D(
      t.FRAMEBUFFER,
      t.COLOR_ATTACHMENT0,
      t.TEXTURE_2D,
      e.currentTexture,
      0
    ), t.bindFramebuffer(t.FRAMEBUFFER, null);
  }
}
class di {
  constructor(e) {
    h(this, "container");
    h(this, "overlay", null);
    this.container = e;
  }
  /**
   * Display shader compilation errors in an overlay.
   */
  show(e, t) {
    this.overlay || (this.overlay = document.createElement("div"), this.overlay.className = "shader-error-overlay", this.container.appendChild(this.overlay));
    const i = e.filter((l) => l.isFromCommon), n = e.filter((l) => !l.isFromCommon), c = [...i.length > 0 ? [i[0]] : [], ...n].map(({ passName: l, error: d, isFromCommon: m, originalLine: g, lineMapping: E }) => {
      const v = d.replace(`Shader compilation failed:
`, ""), _ = g;
      let R = v;
      _ !== null && (R = v.replace(/ERROR:\s*\d+:(\d+):/g, `ERROR: 0:${_}:`));
      let p = null;
      if (m)
        p = t.commonSource;
      else {
        const f = t.passes[l];
        p = (f == null ? void 0 : f.glslSource) ?? null;
      }
      return {
        passName: m ? "common.glsl" : l,
        error: hi(R, E, m),
        codeContext: _ !== null && p ? pi(p, _) : null
      };
    }).map(({ passName: l, error: d, codeContext: m }) => `
      <div class="error-section">
        <div class="error-pass-name">${l}</div>
        <pre class="error-content">${rs(d)}</pre>
        ${m ? `<pre class="error-code-context">${m}</pre>` : ""}
      </div>
    `).join("");
    this.overlay.innerHTML = `
      <div class="error-overlay-content">
        <div class="error-header">
          <span class="error-title">
            <svg width="16" height="16" viewBox="0 0 16 16" fill="currentColor" style="vertical-align: text-bottom;">
              <path d="M8 0a8 8 0 1 1 0 16A8 8 0 0 1 8 0zM3.5 7.5a.75.75 0 0 0 0 1.5h9a.75.75 0 0 0 0-1.5h-9z"/>
            </svg>
            Shader Compilation Failed
          </span>
          <button class="error-close" title="Dismiss">×</button>
        </div>
        <div class="error-body">
          ${c}
        </div>
      </div>
    `;
    const u = this.overlay.querySelector(".error-close");
    u && u.addEventListener("click", () => this.hide());
  }
  /**
   * Hide the error overlay.
   */
  hide() {
    this.overlay && (this.overlay.remove(), this.overlay = null);
  }
  /**
   * Clean up resources.
   */
  dispose() {
    this.hide();
  }
}
function hi(s, e, t) {
  return s.split(`
`).map((i) => {
    const n = i.match(/^ERROR:\s*(\d+):(\d+):\s*(.+)$/);
    if (n) {
      const [, , r, o] = n, a = parseInt(r, 10);
      let c = a;
      return t && e.commonStartLine > 0 ? c = a - e.commonStartLine + 1 : e.userCodeStartLine > 0 && a >= e.userCodeStartLine && (c = a - e.userCodeStartLine + 1), `Line ${c}: ${mi(o)}`;
    }
    return i;
  }).join(`
`);
}
function mi(s) {
  return s.includes("no matching overloaded function found") ? s + " (check function name spelling and argument types)" : s.includes("undeclared identifier") ? s + " (variable not declared — check spelling)" : s.includes("syntax error") ? s + " (check for missing semicolons, brackets, or commas)" : s.includes("is not a function") ? s + " (identifier exists but is not callable)" : s.includes("wrong operand types") ? s + " (type mismatch — check vec/float/int types)" : s;
}
function pi(s, e) {
  const t = s.split(`
`);
  if (e < 1 || e > t.length) return null;
  const i = 3, n = Math.max(0, e - i - 1), r = Math.min(t.length, e + i);
  return t.slice(n, r).map((a, c) => {
    const u = n + c + 1, l = u === e, d = String(u).padStart(4, " "), m = rs(a);
    return l ? `<span class="error-line-highlight">${d} │ ${m}</span>` : `<span class="context-line">${d} │ ${m}</span>`;
  }).join("");
}
function rs(s) {
  const e = document.createElement("div");
  return e.textContent = s, e.innerHTML;
}
const ve = class ve {
  constructor(e) {
    h(this, "container");
    h(this, "overlay", null);
    h(this, "autoHideTimer", null);
    this.container = e;
  }
  /**
   * Show an error from setup() or onFrame().
   */
  showError(e, t) {
    this.clearAutoHide(), this.ensureOverlay();
    const i = t instanceof Error ? t.message : String(t), n = t instanceof Error && t.stack ? t.stack.split(`
`).slice(1, 4).join(`
`) : "";
    this.overlay.innerHTML = `
      <div class="script-error-content">
        <div class="script-error-header">
          <span class="script-error-title">
            <svg width="14" height="14" viewBox="0 0 16 16" fill="currentColor" style="vertical-align: text-bottom;">
              <path d="M8 1.5a6.5 6.5 0 1 0 0 13 6.5 6.5 0 0 0 0-13zM0 8a8 8 0 1 1 16 0A8 8 0 0 1 0 8zm9 3a1 1 0 1 1-2 0 1 1 0 0 1 2 0zm-.25-6.25a.75.75 0 0 0-1.5 0v3.5a.75.75 0 0 0 1.5 0v-3.5z"/>
            </svg>
            script.js ${e}() error
          </span>
          <button class="script-error-close" title="Dismiss">×</button>
        </div>
        <pre class="script-error-message">${Ue(i)}</pre>
        ${n ? `<pre class="script-error-stack">${Ue(n)}</pre>` : ""}
      </div>
    `, this.wireClose(), this.autoHideTimer = setTimeout(() => this.hide(), ve.AUTO_HIDE_MS);
  }
  /**
   * Show a persistent warning when onFrame() has been disabled.
   */
  showDisabled() {
    this.clearAutoHide(), this.ensureOverlay(), this.overlay.innerHTML = `
      <div class="script-error-content">
        <div class="script-error-header disabled">
          <span class="script-error-title">
            <svg width="14" height="14" viewBox="0 0 16 16" fill="currentColor" style="vertical-align: text-bottom;">
              <path d="M8 1.5a6.5 6.5 0 1 0 0 13 6.5 6.5 0 0 0 0-13zM0 8a8 8 0 1 1 16 0A8 8 0 0 1 0 8zm9 3a1 1 0 1 1-2 0 1 1 0 0 1 2 0zm-.25-6.25a.75.75 0 0 0-1.5 0v3.5a.75.75 0 0 0 1.5 0v-3.5z"/>
            </svg>
            script.js onFrame() disabled
          </span>
          <button class="script-error-close" title="Dismiss">×</button>
        </div>
        <pre class="script-error-message">Too many consecutive errors. Reload to retry.</pre>
      </div>
    `, this.wireClose();
  }
  /**
   * Show a warning banner for asset load errors (textures, framebuffers).
   */
  showWarning(e, t) {
    this.clearAutoHide(), this.ensureOverlay(), this.overlay.innerHTML = `
      <div class="script-error-content">
        <div class="script-error-header warning">
          <span class="script-error-title">
            <svg width="14" height="14" viewBox="0 0 16 16" fill="currentColor" style="vertical-align: text-bottom;">
              <path d="M8.982 1.566a1.13 1.13 0 0 0-1.96 0L.165 13.233c-.457.778.091 1.767.98 1.767h13.713c.889 0 1.438-.99.98-1.767L8.982 1.566zM8 5c.535 0 .954.462.9.995l-.35 3.507a.552.552 0 0 1-1.1 0L7.1 5.995A.905.905 0 0 1 8 5zm.002 6a1 1 0 1 1 0 2 1 1 0 0 1 0-2z"/>
            </svg>
            ${Ue(e)}
          </span>
          <button class="script-error-close" title="Dismiss">×</button>
        </div>
        <pre class="script-error-message">${Ue(t)}</pre>
      </div>
    `, this.wireClose(), this.autoHideTimer = setTimeout(() => this.hide(), ve.AUTO_HIDE_MS);
  }
  /**
   * Hide the overlay.
   */
  hide() {
    this.clearAutoHide(), this.overlay && (this.overlay.remove(), this.overlay = null);
  }
  /**
   * Clean up resources.
   */
  dispose() {
    this.hide();
  }
  ensureOverlay() {
    this.overlay || (this.overlay = document.createElement("div"), this.overlay.className = "script-error-overlay", this.container.appendChild(this.overlay));
  }
  wireClose() {
    var t;
    const e = (t = this.overlay) == null ? void 0 : t.querySelector(".script-error-close");
    e && e.addEventListener("click", () => this.hide());
  }
  clearAutoHide() {
    this.autoHideTimer !== null && (clearTimeout(this.autoHideTimer), this.autoHideTimer = null);
  }
};
h(ve, "AUTO_HIDE_MS", 5e3);
let it = ve;
function Ue(s) {
  const e = document.createElement("div");
  return e.textContent = s, e.innerHTML;
}
const Re = {};
for (let s = 0; s < 26; s++)
  Re[`Key${String.fromCharCode(65 + s)}`] = 65 + s;
for (let s = 0; s < 10; s++)
  Re[`Digit${s}`] = 48 + s;
for (let s = 1; s <= 12; s++)
  Re[`F${s}`] = 111 + s;
Object.assign(Re, {
  Backspace: 8,
  Tab: 9,
  Enter: 13,
  ShiftLeft: 16,
  ShiftRight: 16,
  ControlLeft: 17,
  ControlRight: 17,
  AltLeft: 18,
  AltRight: 18,
  Pause: 19,
  CapsLock: 20,
  Escape: 27,
  Space: 32,
  PageUp: 33,
  PageDown: 34,
  End: 35,
  Home: 36,
  ArrowLeft: 37,
  ArrowUp: 38,
  ArrowRight: 39,
  ArrowDown: 40,
  Insert: 45,
  Delete: 46,
  NumLock: 144,
  ScrollLock: 145,
  Semicolon: 186,
  Equal: 187,
  Comma: 188,
  Minus: 189,
  Period: 190,
  Slash: 191,
  Backquote: 192,
  BracketLeft: 219,
  Backslash: 220,
  BracketRight: 221,
  Quote: 222
});
function Lt(s) {
  const e = Re[s.code];
  return e !== void 0 && e >= 0 && e < 256 ? e : null;
}
class fi {
  constructor(e, t, i) {
    h(this, "mouse", [0, 0, 0, 0]);
    h(this, "isMouseDown", !1);
    h(this, "stickyMouse", !1);
    h(this, "touchState", {
      count: 0,
      touches: [[0, 0, 0, 0], [0, 0, 0, 0], [0, 0, 0, 0]],
      pinch: 1,
      pinchDelta: 0,
      pinchCenter: [0, 0]
    });
    /** Callback fired on first user gesture (for media init). */
    h(this, "onFirstGesture", null);
    h(this, "canvas");
    h(this, "pixelRatio");
    h(this, "activePointers", /* @__PURE__ */ new Map());
    h(this, "gestureTriggered", !1);
    h(this, "keyEvents", []);
    // Store bound handlers for cleanup
    h(this, "keydownHandler");
    h(this, "keyupHandler");
    h(this, "keyboardTarget");
    h(this, "canvasListeners", []);
    this.canvas = e, this.pixelRatio = t, this.keyboardTarget = i ?? document, this.setupMouseTracking(), this.setupTouchTracking(), this.keydownHandler = (n) => {
      const r = Lt(n);
      r !== null && this.keyEvents.push({ keycode: r, down: !0 });
    }, this.keyupHandler = (n) => {
      const r = Lt(n);
      r !== null && this.keyEvents.push({ keycode: r, down: !1 });
    }, this.keyboardTarget.addEventListener("keydown", this.keydownHandler), this.keyboardTarget.addEventListener("keyup", this.keyupHandler);
  }
  /**
   * Drain and return accumulated key events since last call.
   */
  getAndClearKeyEvents() {
    const e = this.keyEvents;
    return this.keyEvents = [], e;
  }
  /**
   * Clean up all event listeners.
   */
  dispose() {
    this.keyboardTarget.removeEventListener("keydown", this.keydownHandler), this.keyboardTarget.removeEventListener("keyup", this.keyupHandler);
    for (const { event: e, handler: t } of this.canvasListeners)
      this.canvas.removeEventListener(e, t);
    this.canvasListeners = [];
  }
  triggerGesture() {
    var e;
    this.gestureTriggered || (this.gestureTriggered = !0, (e = this.onFirstGesture) == null || e.call(this));
  }
  setupMouseTracking() {
    const e = (r) => {
      const o = this.canvas.getBoundingClientRect(), a = (r.clientX - o.left) * this.pixelRatio, c = (o.height - (r.clientY - o.top)) * this.pixelRatio;
      return [a, c];
    }, t = (r) => {
      const [o, a] = e(r);
      this.isMouseDown = !0, this.mouse[0] = o, this.mouse[1] = a, this.mouse[2] = o, this.mouse[3] = a, this.triggerGesture();
    }, i = (r) => {
      if (!this.isMouseDown) return;
      const [o, a] = e(r);
      this.mouse[0] = o, this.mouse[1] = a;
    }, n = () => {
      this.isMouseDown = !1, this.stickyMouse || (this.mouse[2] = -Math.abs(this.mouse[2]), this.mouse[3] = -Math.abs(this.mouse[3]));
    };
    this.canvas.addEventListener("mousedown", t), this.canvas.addEventListener("mousemove", i), this.canvas.addEventListener("mouseup", n), this.canvasListeners.push(
      { event: "mousedown", handler: t },
      { event: "mousemove", handler: i },
      { event: "mouseup", handler: n }
    );
  }
  setupTouchTracking() {
    this.canvas.style.touchAction = "pan-y";
    const e = (o, a) => {
      const c = this.canvas.getBoundingClientRect(), u = (o - c.left) * this.pixelRatio, l = (c.height - (a - c.top)) * this.pixelRatio;
      return [u, l];
    }, t = (o) => {
      if (o.pointerType === "mouse") return;
      const [a, c] = e(o.clientX, o.clientY);
      this.activePointers.set(o.pointerId, {
        id: o.pointerId,
        x: a,
        y: c,
        startX: a,
        startY: c
      }), this.canvas.setPointerCapture(o.pointerId), this.updateTouchState(), this.activePointers.size === 1 && (this.isMouseDown = !0, this.mouse[0] = a, this.mouse[1] = c, this.mouse[2] = a, this.mouse[3] = c);
    }, i = (o) => {
      if (o.pointerType === "mouse") return;
      const a = this.activePointers.get(o.pointerId);
      if (!a) return;
      const [c, u] = e(o.clientX, o.clientY);
      a.x = c, a.y = u, this.updateTouchState(), this.activePointers.size === 1 && (this.mouse[0] = c, this.mouse[1] = u), o.preventDefault();
    }, n = (o) => {
      o.pointerType !== "mouse" && (this.activePointers.delete(o.pointerId), this.canvas.releasePointerCapture(o.pointerId), this.activePointers.size === 0 && (this.isMouseDown = !1, this.stickyMouse || (this.mouse[2] = -Math.abs(this.mouse[2]), this.mouse[3] = -Math.abs(this.mouse[3]))), this.updateTouchState());
    }, r = (o) => {
      n(o);
    };
    this.canvas.addEventListener("pointerdown", t), this.canvas.addEventListener("pointermove", i), this.canvas.addEventListener("pointerup", n), this.canvas.addEventListener("pointercancel", r), this.canvasListeners.push(
      { event: "pointerdown", handler: t },
      { event: "pointermove", handler: i },
      { event: "pointerup", handler: n },
      { event: "pointercancel", handler: r }
    );
  }
  updateTouchState() {
    const e = Array.from(this.activePointers.values()), t = e.length;
    this.touchState.count = t;
    for (let i = 0; i < 3; i++)
      if (i < e.length) {
        const n = e[i];
        this.touchState.touches[i] = [n.x, n.y, n.startX, n.startY];
      } else
        this.touchState.touches[i] = [0, 0, 0, 0];
    if (t >= 2) {
      const i = e[0], n = e[1], r = n.x - i.x, o = n.y - i.y, a = Math.sqrt(r * r + o * o), c = n.startX - i.startX, u = n.startY - i.startY, l = Math.sqrt(c * c + u * u);
      if (l > 0) {
        const d = a / l;
        this.touchState.pinchDelta = d - this.touchState.pinch, this.touchState.pinch = d;
      }
      this.touchState.pinchCenter = [
        (i.x + n.x) / 2,
        (i.y + n.y) / 2
      ];
    } else
      this.touchState.pinchDelta = 0, t === 0 && (this.touchState.pinch = 1, this.touchState.pinchCenter = [0, 0]);
  }
}
class It {
  constructor(e) {
    h(this, "container");
    h(this, "canvas");
    h(this, "gl");
    h(this, "errorOverlay");
    h(this, "runtimeErrorOverlay");
    h(this, "input");
    h(this, "_engine");
    h(this, "_project");
    h(this, "_pixelRatio");
    h(this, "_viewNames");
    h(this, "_resizeObserver");
    h(this, "_resizeDebounceTimer", null);
    // Context loss
    h(this, "_contextLostOverlay", null);
    h(this, "_isContextLost", !1);
    // Media
    h(this, "_mediaBanner", null);
    h(this, "_mediaInitialized", !1);
    // Script info overlays (one per corner position)
    h(this, "_overlays", /* @__PURE__ */ new Map());
    // Callbacks for App to hook into
    h(this, "onResize", null);
    h(this, "onContextRestored", null);
    this.container = e.container, this._project = e.project, this._pixelRatio = e.pixelRatio, this._viewNames = e.viewNames, this.canvas = document.createElement("canvas"), this.canvas.style.width = "100%", this.canvas.style.height = "100%", this.canvas.style.display = "block", this.container.appendChild(this.canvas), this.errorOverlay = new di(this.container), this.runtimeErrorOverlay = new it(this.container);
    const t = this.canvas.getContext("webgl2", {
      alpha: !1,
      antialias: !1,
      depth: !1,
      stencil: !1,
      preserveDrawingBuffer: !0,
      powerPreference: "high-performance"
    });
    if (!t)
      throw new Error("WebGL2 not supported");
    this.gl = t, this.setupContextLossHandling(), this.updateCanvasSize(), this._engine = new Mt({
      gl: this.gl,
      project: e.project,
      viewNames: e.viewNames,
      onAssetError: (i) => {
        const n = i.type === "texture" ? `Texture '${i.name}' failed to load` : `Framebuffer '${i.name}' error`;
        this.runtimeErrorOverlay.showWarning(n, i.detail);
      }
    }), this._engine.hasErrors() && this.errorOverlay.show(this._engine.getCompilationErrors(), this._project), (this._engine.needsAudio || this._engine.needsWebcam) && this.showMediaBanner(), this._resizeObserver = new ResizeObserver(() => {
      this.updateCanvasSize(), this._resizeDebounceTimer !== null && clearTimeout(this._resizeDebounceTimer), this._resizeDebounceTimer = setTimeout(() => {
        var i;
        this._resizeDebounceTimer = null, this._engine.resize(this.canvas.width, this.canvas.height), this._engine.reset(), (i = this.onResize) == null || i.call(this, this.canvas.width, this.canvas.height);
      }, 150);
    }), this._resizeObserver.observe(this.container), this.input = new fi(this.canvas, this._pixelRatio, e.keyboardTarget), this.input.stickyMouse = this._project.stickyMouse, this.input.onFirstGesture = () => this.initMediaOnGesture(), this.initVideoFiles();
  }
  get engine() {
    return this._engine;
  }
  get isContextLost() {
    return this._isContextLost;
  }
  // ===========================================================================
  // Per-Frame Rendering
  // ===========================================================================
  /**
   * Step this view for one frame: forward input, run engine, blit to screen.
   */
  step(e, t) {
    if (!this._isContextLost) {
      for (const i of this.input.getAndClearKeyEvents())
        this._engine.updateKeyState(i.keycode, i.down);
      this._engine.updateKeyboardTexture(), this._engine.updateAudioTexture(), this._engine.updateVideoTextures(), this._engine.step(e, this.input.mouse, this.input.isMouseDown, {
        count: this.input.touchState.count,
        touches: this.input.touchState.touches,
        pinch: this.input.touchState.pinch,
        pinchDelta: this.input.touchState.pinchDelta,
        pinchCenter: this.input.touchState.pinchCenter
      }, t), this.input.touchState.pinchDelta = 0, this.presentToScreen();
    }
  }
  /**
   * Blit engine Image pass output to the canvas.
   */
  presentToScreen() {
    const e = this.gl;
    this._engine.bindImageForRead() && (e.bindFramebuffer(e.DRAW_FRAMEBUFFER, null), e.blitFramebuffer(
      0,
      0,
      this.canvas.width,
      this.canvas.height,
      0,
      0,
      this.canvas.width,
      this.canvas.height,
      e.COLOR_BUFFER_BIT,
      e.NEAREST
    ), this._engine.unbindImageForRead());
  }
  // ===========================================================================
  // Cross-View State Getters
  // ===========================================================================
  getMouseState() {
    return [...this.input.mouse];
  }
  getResolution() {
    return [this.canvas.width, this.canvas.height, 1];
  }
  getMousePressed() {
    return this.input.isMouseDown;
  }
  hasErrors() {
    return this._engine.hasErrors();
  }
  // ===========================================================================
  // Script Info Overlays
  // ===========================================================================
  setOverlay(e, t) {
    let i = this._overlays.get(e);
    if (t === null) {
      i && i.classList.add("hidden");
      return;
    }
    i || (i = document.createElement("div"), i.className = `script-overlay ${e}`, this.container.appendChild(i), this._overlays.set(e, i)), i.textContent = t, i.classList.remove("hidden");
  }
  // ===========================================================================
  // Lifecycle
  // ===========================================================================
  dispose() {
    this.input.dispose(), this._resizeObserver.disconnect(), this._resizeDebounceTimer !== null && clearTimeout(this._resizeDebounceTimer), this._engine.dispose(), this.errorOverlay.hide(), this.runtimeErrorOverlay.dispose(), this.hideMediaBanner(), this.hideContextLostOverlay();
    for (const t of this._overlays.values())
      t.remove();
    this._overlays.clear();
    const e = this.gl.getExtension("WEBGL_lose_context");
    e && e.loseContext(), this.container.removeChild(this.canvas);
  }
  // ===========================================================================
  // Canvas Sizing
  // ===========================================================================
  updateCanvasSize() {
    const e = this.container.getBoundingClientRect(), t = Math.floor(e.width * this._pixelRatio), i = Math.floor(e.height * this._pixelRatio);
    (this.canvas.width !== t || this.canvas.height !== i) && (this.canvas.width = t, this.canvas.height = i);
  }
  // ===========================================================================
  // Context Loss Handling
  // ===========================================================================
  setupContextLossHandling() {
    this.canvas.addEventListener("webglcontextlost", (e) => {
      e.preventDefault(), this.handleContextLost();
    }), this.canvas.addEventListener("webglcontextrestored", () => {
      this.handleContextRestored();
    });
  }
  handleContextLost() {
    this._isContextLost = !0, this.showContextLostOverlay(), console.warn("WebGL context lost. Waiting for restoration...");
  }
  handleContextRestored() {
    var e;
    console.log("WebGL context restored. Reinitializing...");
    try {
      this._engine.dispose(), this._engine = new Mt({
        gl: this.gl,
        project: this._project,
        viewNames: this._viewNames,
        onAssetError: (t) => {
          const i = t.type === "texture" ? `Texture '${t.name}' failed to load` : `Framebuffer '${t.name}' error`;
          this.runtimeErrorOverlay.showWarning(i, t.detail);
        }
      }), this._engine.hasErrors() && this.errorOverlay.show(this._engine.getCompilationErrors(), this._project), this._engine.resize(this.canvas.width, this.canvas.height), this.hideContextLostOverlay(), this._isContextLost = !1, (e = this.onContextRestored) == null || e.call(this), console.log("WebGL context successfully restored");
    } catch (t) {
      console.error("Failed to restore WebGL context:", t), this.showContextLostOverlay(!0);
    }
  }
  showContextLostOverlay(e = !1) {
    this._contextLostOverlay || (this._contextLostOverlay = document.createElement("div"), this._contextLostOverlay.className = "context-lost-overlay", this.container.appendChild(this._contextLostOverlay)), e ? this._contextLostOverlay.innerHTML = `
        <div class="context-lost-content">
          <div class="context-lost-icon">
            <svg width="48" height="48" viewBox="0 0 24 24" fill="currentColor">
              <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"/>
            </svg>
          </div>
          <div class="context-lost-title">WebGL Context Lost</div>
          <div class="context-lost-message">Unable to restore automatically.</div>
          <button class="context-lost-reload" onclick="location.reload()">Reload Page</button>
        </div>
      ` : this._contextLostOverlay.innerHTML = `
        <div class="context-lost-content">
          <div class="context-lost-spinner"></div>
          <div class="context-lost-title">WebGL Context Lost</div>
          <div class="context-lost-message">Attempting to restore...</div>
        </div>
      `;
  }
  hideContextLostOverlay() {
    this._contextLostOverlay && (this._contextLostOverlay.remove(), this._contextLostOverlay = null);
  }
  // ===========================================================================
  // Media Initialization
  // ===========================================================================
  initMediaOnGesture() {
    this._mediaInitialized || (this._mediaInitialized = !0, this.hideMediaBanner(), this._engine.needsAudio && this._engine.initAudio(), this._engine.needsWebcam && this._engine.initWebcam());
  }
  initVideoFiles() {
    for (const e of this._engine.videoSources)
      this._engine.initVideo(e);
  }
  showMediaBanner() {
    this._mediaBanner = document.createElement("div"), this._mediaBanner.className = "media-permission-banner";
    const e = [];
    this._engine.needsAudio && e.push("microphone"), this._engine.needsWebcam && e.push("webcam"), this._mediaBanner.innerHTML = `
      <span class="media-banner-text">This shader uses ${e.join(" and ")}</span>
      <button class="media-banner-button">Click to enable</button>
    `, this._mediaBanner.querySelector(".media-banner-button").addEventListener("click", () => {
      this.initMediaOnGesture();
    }), this.container.appendChild(this._mediaBanner);
  }
  hideMediaBanner() {
    this._mediaBanner && (this._mediaBanner.remove(), this._mediaBanner = null);
  }
}
class je {
  constructor(e) {
    h(this, "container");
    h(this, "uniforms");
    h(this, "onChange");
    h(this, "values", {});
    h(this, "updaters", /* @__PURE__ */ new Map());
    // Track document-level event listeners for cleanup
    h(this, "documentListeners", []);
    var t;
    this.container = e.container, this.uniforms = e.uniforms, this.onChange = e.onChange;
    for (const [i, n] of Object.entries(this.uniforms))
      G(n) || n.hidden || (this.values[i] = ((t = e.initialValues) == null ? void 0 : t[i]) ?? n.value);
    this.render();
  }
  /**
   * Render all uniform controls.
   */
  render() {
    this.container.innerHTML = "", this.container.className = "uniform-controls";
    const e = Object.entries(this.uniforms);
    if (e.length === 0) {
      const r = document.createElement("div");
      r.className = "uniform-controls-empty", r.textContent = "No uniforms defined", this.container.appendChild(r);
      return;
    }
    const t = document.createElement("div");
    t.className = "uniform-controls-header";
    const i = document.createElement("button");
    i.className = "uniform-controls-reset", i.textContent = "Reset", i.title = "Reset all uniforms to defaults", i.addEventListener("click", () => this.resetToDefaults()), t.appendChild(i), this.container.appendChild(t);
    const n = document.createElement("div");
    n.className = "uniform-controls-list";
    for (const [r, o] of e) {
      if (G(o) || o.hidden) continue;
      const a = this.createControl(r, o);
      a && (this.updaters.set(r, a.update), n.appendChild(a.element));
    }
    this.container.appendChild(n);
  }
  /**
   * Create a control element for a uniform.
   */
  createControl(e, t) {
    if (G(t) || t.hidden) return null;
    switch (t.type) {
      case "float":
        return this.createFloatSlider(e, t);
      case "int":
        return this.createIntSlider(e, t);
      case "bool":
        return this.createBoolToggle(e, t);
      case "vec2":
        return this.createVec2Pad(e, t);
      case "vec3":
        return t.color ? this.createColorPicker(e, t) : this.createVecSliders(e, t, 3);
      case "vec4":
        return t.color ? this.createColorPicker4(e, t) : this.createVecSliders(e, t, 4);
      default:
        return console.warn(`Uniform '${e}': unknown type '${t.type}'`), null;
    }
  }
  // ===========================================================================
  // Shared Slider Row Helper
  // ===========================================================================
  createSliderRow(e) {
    const t = document.createElement("div");
    t.className = "uniform-control-label-row";
    const i = document.createElement("label");
    i.className = "uniform-control-label", i.textContent = e.label;
    const n = document.createElement("span");
    n.className = "uniform-control-value", n.textContent = e.format(e.value), t.appendChild(i), t.appendChild(n);
    const r = document.createElement("input");
    return r.type = "range", r.className = "uniform-control-slider", r.min = String(e.min), r.max = String(e.max), r.step = String(e.step), r.value = String(e.value), r.addEventListener("input", () => {
      const a = parseFloat(r.value);
      e.onInput(a), n.textContent = e.format(a);
    }), { elements: [t, r], update: (a) => {
      r.value = String(a), n.textContent = e.format(a);
    } };
  }
  // ===========================================================================
  // Float Slider
  // ===========================================================================
  createFloatSlider(e, t) {
    const i = t.step ?? 0.01, { elements: n, update: r } = this.createSliderRow({
      label: t.label ?? e,
      min: t.min ?? 0,
      max: t.max ?? 1,
      step: i,
      value: this.values[e],
      format: (a) => this.formatNumber(a, i),
      onInput: (a) => {
        this.values[e] = a, this.onChange(e, a);
      }
    }), o = document.createElement("div");
    o.className = "uniform-control uniform-control-float";
    for (const a of n) o.appendChild(a);
    return {
      element: o,
      update: (a) => r(a)
    };
  }
  // ===========================================================================
  // Int Slider
  // ===========================================================================
  createIntSlider(e, t) {
    const { elements: i, update: n } = this.createSliderRow({
      label: t.label ?? e,
      min: t.min ?? 0,
      max: t.max ?? 10,
      step: t.step ?? 1,
      value: this.values[e],
      format: (o) => String(Math.round(o)),
      onInput: (o) => {
        const a = Math.round(o);
        this.values[e] = a, this.onChange(e, a);
      }
    }), r = document.createElement("div");
    r.className = "uniform-control uniform-control-int";
    for (const o of i) r.appendChild(o);
    return {
      element: r,
      update: (o) => n(o)
    };
  }
  // ===========================================================================
  // Bool Toggle
  // ===========================================================================
  createBoolToggle(e, t) {
    const i = this.values[e], n = t.label ?? e, r = document.createElement("div");
    r.className = "uniform-control uniform-control-bool";
    const o = document.createElement("div");
    o.className = "uniform-control-label-row";
    const a = document.createElement("label");
    a.className = "uniform-control-label", a.textContent = n;
    const c = document.createElement("label");
    c.className = "uniform-control-toggle";
    const u = document.createElement("input");
    u.type = "checkbox", u.checked = i;
    const l = document.createElement("span");
    return l.className = "uniform-control-toggle-slider", u.addEventListener("change", () => {
      const d = u.checked;
      this.values[e] = d, this.onChange(e, d);
    }), c.appendChild(u), c.appendChild(l), o.appendChild(a), o.appendChild(c), r.appendChild(o), {
      element: r,
      update: (d) => {
        u.checked = d;
      }
    };
  }
  // ===========================================================================
  // Vec2 XY Pad
  // ===========================================================================
  createVec2Pad(e, t) {
    const i = this.values[e], n = t.min ?? [0, 0], r = t.max ?? [1, 1], o = t.label ?? e, a = document.createElement("div");
    a.className = "uniform-control uniform-control-vec2";
    const c = document.createElement("div");
    c.className = "uniform-control-label-row";
    const u = document.createElement("label");
    u.className = "uniform-control-label", u.textContent = o;
    const l = document.createElement("span");
    l.className = "uniform-control-value", l.textContent = this.formatVec2(i), c.appendChild(u), c.appendChild(l);
    const d = document.createElement("div");
    d.className = "uniform-control-xy-pad";
    const m = document.createElement("div");
    m.className = "uniform-control-xy-handle", d.appendChild(m);
    const g = (y) => {
      const T = (y[0] - n[0]) / (r[0] - n[0]) * 100, C = (1 - (y[1] - n[1]) / (r[1] - n[1])) * 100;
      m.style.left = `${T}%`, m.style.top = `${C}%`;
    };
    g(i);
    let E = !1;
    const v = (y) => {
      const T = d.getBoundingClientRect(), C = "touches" in y ? y.touches[0].clientX : y.clientX, A = "touches" in y ? y.touches[0].clientY : y.clientY;
      let w = Math.max(0, Math.min(1, (C - T.left) / T.width)), F = Math.max(0, Math.min(1, (A - T.top) / T.height));
      const L = n[0] + w * (r[0] - n[0]), k = n[1] + (1 - F) * (r[1] - n[1]), V = [L, k];
      this.values[e] = V, m.style.left = `${w * 100}%`, m.style.top = `${F * 100}%`, l.textContent = this.formatVec2(V), this.onChange(e, V);
    }, _ = (y) => {
      E = !0, v(y), y.preventDefault();
    }, R = (y) => {
      E && v(y);
    }, p = () => {
      E = !1;
    };
    d.addEventListener("mousedown", _), document.addEventListener("mousemove", R), document.addEventListener("mouseup", p), this.documentListeners.push({ type: "mousemove", handler: R }), this.documentListeners.push({ type: "mouseup", handler: p });
    const f = (y) => {
      E = !0, v(y), y.preventDefault();
    }, b = (y) => {
      E && v(y);
    };
    return d.addEventListener("touchstart", f), document.addEventListener("touchmove", b), document.addEventListener("touchend", p), this.documentListeners.push({ type: "touchmove", handler: b }), this.documentListeners.push({ type: "touchend", handler: p }), a.appendChild(c), a.appendChild(d), {
      element: a,
      update: (y) => {
        const T = y;
        g(T), l.textContent = this.formatVec2(T);
      }
    };
  }
  // ===========================================================================
  // Vec3 Color Picker
  // ===========================================================================
  createColorPicker(e, t) {
    const i = this.values[e], n = t.label ?? e, r = document.createElement("div");
    r.className = "uniform-control uniform-control-color";
    const o = document.createElement("div");
    o.className = "uniform-control-label-row";
    const a = document.createElement("label");
    a.className = "uniform-control-label", a.textContent = n;
    const c = document.createElement("span");
    c.className = "uniform-control-value", c.textContent = this.rgbToHex(i), o.appendChild(a), o.appendChild(c);
    const u = document.createElement("div");
    u.className = "uniform-control-color-wrapper";
    const l = document.createElement("input");
    l.type = "color", l.className = "uniform-control-color-input", l.value = this.rgbToHex(i);
    const d = document.createElement("div");
    return d.className = "uniform-control-color-swatch", d.style.backgroundColor = this.rgbToHex(i), l.addEventListener("input", () => {
      const m = this.hexToRgb(l.value);
      this.values[e] = m, c.textContent = l.value, d.style.backgroundColor = l.value, this.onChange(e, m);
    }), d.addEventListener("click", () => l.click()), u.appendChild(d), u.appendChild(l), r.appendChild(o), r.appendChild(u), {
      element: r,
      update: (m) => {
        const g = this.rgbToHex(m);
        l.value = g, d.style.backgroundColor = g, c.textContent = g;
      }
    };
  }
  // ===========================================================================
  // Vec4 Color Picker (with alpha)
  // ===========================================================================
  createColorPicker4(e, t) {
    var v, _, R;
    const i = this.values[e], n = t.label ?? e, r = document.createElement("div");
    r.className = "uniform-control uniform-control-color";
    const o = document.createElement("div");
    o.className = "uniform-control-label-row";
    const a = document.createElement("label");
    a.className = "uniform-control-label", a.textContent = n;
    const c = document.createElement("span");
    c.className = "uniform-control-value", c.textContent = this.rgbToHex(i), o.appendChild(a), o.appendChild(c);
    const u = document.createElement("div");
    u.className = "uniform-control-color-wrapper";
    const l = document.createElement("input");
    l.type = "color", l.className = "uniform-control-color-input", l.value = this.rgbToHex(i);
    const d = document.createElement("div");
    d.className = "uniform-control-color-swatch", d.style.backgroundColor = this.rgbToHex(i), l.addEventListener("input", () => {
      const p = this.hexToRgb(l.value), f = this.values[e];
      f[0] = p[0], f[1] = p[1], f[2] = p[2], c.textContent = l.value, d.style.backgroundColor = l.value, this.onChange(e, [...f]);
    }), d.addEventListener("click", () => l.click()), u.appendChild(d), u.appendChild(l);
    const m = ((v = t.step) == null ? void 0 : v[3]) ?? 0.01, { elements: g, update: E } = this.createSliderRow({
      label: "Alpha",
      min: ((_ = t.min) == null ? void 0 : _[3]) ?? 0,
      max: ((R = t.max) == null ? void 0 : R[3]) ?? 1,
      step: m,
      value: i[3],
      format: (p) => this.formatNumber(p, m),
      onInput: (p) => {
        const f = this.values[e];
        f[3] = p, this.onChange(e, [...f]);
      }
    });
    r.appendChild(o), r.appendChild(u);
    for (const p of g) r.appendChild(p);
    return {
      element: r,
      update: (p) => {
        const f = p, b = this.rgbToHex(f);
        l.value = b, d.style.backgroundColor = b, c.textContent = b, E(f[3]);
      }
    };
  }
  // ===========================================================================
  // Vec3/Vec4 Component Sliders
  // ===========================================================================
  createVecSliders(e, t, i) {
    const n = this.values[e], r = t.label ?? e, o = i === 3 ? ["X", "Y", "Z"] : ["X", "Y", "Z", "W"], a = document.createElement("div");
    a.className = `uniform-control uniform-control-vec${i}`;
    const c = document.createElement("div");
    c.className = "uniform-control-label", c.textContent = r, a.appendChild(c);
    const u = [];
    return o.forEach((l, d) => {
      var p, f, b, y, T;
      const m = ((p = t.step) == null ? void 0 : p[d]) ?? 0.01, { elements: g, update: E } = this.createSliderRow({
        label: l,
        min: ((f = t.min) == null ? void 0 : f[d]) ?? 0,
        max: ((b = t.max) == null ? void 0 : b[d]) ?? 1,
        step: m,
        value: n[d],
        format: (C) => this.formatNumber(C, m),
        onInput: (C) => {
          const A = this.values[e];
          A[d] = C, this.onChange(e, [...A]);
        }
      }), [v, _] = g;
      v.classList.add("uniform-control-vec-slider-row"), (y = v.querySelector(".uniform-control-label")) == null || y.classList.add("uniform-control-vec-component"), (T = v.querySelector(".uniform-control-value")) == null || T.classList.add("uniform-control-vec-value"), _.classList.add("uniform-control-vec-slider");
      const R = document.createElement("div");
      R.className = "uniform-control-vec-component-group", R.appendChild(v), R.appendChild(_), u.push(E), a.appendChild(R);
    }), {
      element: a,
      update: (l) => {
        const d = l;
        u.forEach((m, g) => m(d[g]));
      }
    };
  }
  // ===========================================================================
  // Utility Methods
  // ===========================================================================
  formatNumber(e, t) {
    const i = String(t), n = i.indexOf("."), r = n === -1 ? 0 : i.length - n - 1;
    return e.toFixed(r);
  }
  formatVec2(e) {
    return `(${e[0].toFixed(2)}, ${e[1].toFixed(2)})`;
  }
  rgbToHex(e) {
    const t = Math.round(e[0] * 255), i = Math.round(e[1] * 255), n = Math.round(e[2] * 255);
    return `#${t.toString(16).padStart(2, "0")}${i.toString(16).padStart(2, "0")}${n.toString(16).padStart(2, "0")}`;
  }
  hexToRgb(e) {
    const t = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(e);
    return t ? [
      parseInt(t[1], 16) / 255,
      parseInt(t[2], 16) / 255,
      parseInt(t[3], 16) / 255
    ] : [0, 0, 0];
  }
  // ===========================================================================
  // Public Methods
  // ===========================================================================
  /**
   * Update a uniform value externally (e.g., from reset).
   */
  setValue(e, t) {
    var i;
    e in this.uniforms && (this.values[e] = t, (i = this.updaters.get(e)) == null || i(t));
  }
  /**
   * Reset all uniforms to their default values.
   */
  resetToDefaults() {
    for (const [e, t] of Object.entries(this.uniforms))
      G(t) || t.hidden || (this.setValue(e, t.value), this.onChange(e, t.value));
  }
  /**
   * Destroy the controls and clean up.
   */
  destroy() {
    for (const { type: e, handler: t } of this.documentListeners)
      document.removeEventListener(e, t);
    this.documentListeners = [], this.container.innerHTML = "", this.updaters.clear();
  }
}
class gi {
  constructor(e) {
    h(this, "wrapper");
    h(this, "panel");
    h(this, "toggleButton", null);
    h(this, "controls", null);
    h(this, "collapsible");
    h(this, "isOpen");
    if (this.collapsible = e.collapsible ?? !0, this.isOpen = this.collapsible ? e.startOpen ?? !1 : !0, this.wrapper = document.createElement("div"), this.wrapper.className = "uniforms-panel-wrapper", this.collapsible || this.wrapper.classList.add("inline"), this.collapsible && (this.toggleButton = document.createElement("button"), this.toggleButton.className = "uniforms-toggle-button", this.toggleButton.title = "Toggle Uniforms Panel", this.toggleButton.innerHTML = `
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
          <line x1="4" y1="21" x2="4" y2="14"></line>
          <line x1="4" y1="10" x2="4" y2="3"></line>
          <line x1="12" y1="21" x2="12" y2="12"></line>
          <line x1="12" y1="8" x2="12" y2="3"></line>
          <line x1="20" y1="21" x2="20" y2="16"></line>
          <line x1="20" y1="12" x2="20" y2="3"></line>
          <line x1="1" y1="14" x2="7" y2="14"></line>
          <line x1="9" y1="8" x2="15" y2="8"></line>
          <line x1="17" y1="16" x2="23" y2="16"></line>
        </svg>
      `, this.toggleButton.addEventListener("click", () => this.toggle()), this.wrapper.appendChild(this.toggleButton)), this.panel = document.createElement("div"), this.panel.className = "uniforms-panel", !Object.values(e.uniforms).some((n) => Se(n))) {
      this.wrapper.style.display = "none", e.container.appendChild(this.wrapper);
      return;
    }
    if (this.collapsible) {
      const n = document.createElement("div");
      n.className = "uniforms-panel-header";
      const r = document.createElement("span");
      r.textContent = "Uniforms", n.appendChild(r);
      const o = document.createElement("button");
      o.className = "uniforms-panel-close", o.innerHTML = "&times;", o.title = "Close", o.addEventListener("click", () => this.hide()), n.appendChild(o), this.panel.appendChild(n);
    }
    const i = document.createElement("div");
    if (i.className = "uniforms-panel-content", this.panel.appendChild(i), this.controls = new je({
      container: i,
      uniforms: e.uniforms,
      initialValues: e.initialValues,
      onChange: e.onChange
    }), !this.collapsible) {
      const n = i.querySelectorAll(
        ".uniform-control-float > .uniform-control-label-row, .uniform-control-int > .uniform-control-label-row"
      );
      for (const r of n) {
        const o = r.parentElement;
        for (; r.firstChild; )
          o.insertBefore(r.firstChild, r);
        r.remove();
      }
    }
    this.wrapper.appendChild(this.panel), this.collapsible && !this.isOpen && this.panel.classList.add("closed"), e.container.appendChild(this.wrapper);
  }
  /**
   * Update a uniform value from external source.
   */
  setValue(e, t) {
    var i;
    (i = this.controls) == null || i.setValue(e, t);
  }
  /**
   * Show the panel.
   */
  show() {
    var e;
    this.collapsible && (this.isOpen = !0, (e = this.toggleButton) == null || e.classList.add("hidden"), this.panel.classList.remove("closed"));
  }
  /**
   * Hide the panel.
   */
  hide() {
    var e;
    this.collapsible && (this.isOpen = !1, this.panel.classList.add("closed"), (e = this.toggleButton) == null || e.classList.remove("hidden"));
  }
  /**
   * Toggle panel visibility.
   */
  toggle() {
    this.collapsible && (this.isOpen ? this.hide() : this.show());
  }
  /**
   * Check if panel is visible.
   */
  isVisible() {
    return this.isOpen;
  }
  /**
   * Destroy the panel.
   */
  destroy() {
    var e;
    (e = this.controls) == null || e.destroy(), this.wrapper.remove();
  }
}
const Ye = (s) => s.replace(/\\/g, "\\\\").replace(/`/g, "\\`").replace(/\$/g, "\\$");
function bi(s, e) {
  const t = yi(s, e), i = new Blob([t], { type: "text/html" }), r = `${s.root.split("/").pop() || "shader"}.html`, o = URL.createObjectURL(i), a = document.createElement("a");
  a.href = o, a.download = r, a.click(), URL.revokeObjectURL(o), console.log(`Exported: ${r}`);
}
function yi(s, e) {
  var y, T, C, A;
  const t = s.meta.title, i = s.commonSource ?? "", n = e.getUniformValues(), r = e.getUBOExportData(), o = ["BufferA", "BufferB", "BufferC", "BufferD", "Image"], a = [];
  let c = !1, u = !1;
  for (const w of o) {
    const F = s.passes[w];
    if (!F) continue;
    const L = F.channels.map((k) => k.kind === "buffer" ? `buffer:${k.buffer}` : k.kind === "texture" ? "procedural" : k.kind === "keyboard" ? (c = !0, "keyboard") : k.kind === "script" ? (u = !0, `script:${k.name}`) : k.kind === "audio" || k.kind === "webcam" || k.kind === "video" ? "black" : "none");
    a.push({
      name: w,
      source: F.glslSource,
      channels: F.channels,
      channelTypes: L
    });
  }
  const l = !!((y = s.script) != null && y.setup || (T = s.script) != null && T.onFrame), d = Object.entries(s.uniforms).filter(([, w]) => !G(w)), m = [];
  for (const [w, F] of d) {
    if (G(F)) continue;
    const L = n[w] ?? F.value;
    if (F.type === "float" || F.type === "int")
      m.push(`  '${w}': ${L}`);
    else if (F.type === "bool")
      m.push(`  '${w}': ${L ? 1 : 0}`);
    else if (F.type === "vec2") {
      const k = L;
      m.push(`  '${w}': [${k[0]}, ${k[1]}]`);
    } else if (F.type === "vec3") {
      const k = L;
      m.push(`  '${w}': [${k[0]}, ${k[1]}, ${k[2]}]`);
    } else if (F.type === "vec4") {
      const k = L;
      m.push(`  '${w}': [${k[0]}, ${k[1]}, ${k[2]}, ${k[3]}]`);
    }
  }
  const g = d.map(([w, F]) => `uniform ${F.type === "bool" ? "bool" : F.type} ${w};`).join(`
`), E = r.map((w) => {
    if (w.struct) {
      const F = Object.entries(w.struct).map(([L, k]) => `  ${k} ${L};`).join(`
`);
      return `// Struct array uniform: ${w.name} (max ${w.count})
struct _st_${w.name} {
${F}
};
layout(std140) uniform _ub_${w.name} {
  _st_${w.name} ${w.name}[${w.count}];
};
uniform int ${w.name}_count;`;
    }
    return `// Array uniform: ${w.name} (max ${w.count})
layout(std140) uniform _ub_${w.name} {
  ${w.type} ${w.name}[${w.count}];
};
uniform int ${w.name}_count;`;
  }).join(`

`), v = r.map((w) => {
    const F = Array.from(w.paddedData).map((L) => L.toFixed(6)).join(", ");
    return `  { name: '${w.name}', type: '${w.type}', count: ${w.count}, binding: ${w.bindingPoint}, data: new Float32Array([${F}]) }`;
  }).join(`,
`);
  let _ = "", R = "";
  l && ((C = s.script) != null && C.setup && (_ = s.script.setup.toString()), (A = s.script) != null && A.onFrame && (R = s.script.onFrame.toString()));
  const p = c ? `
// --- Keyboard helpers ---
const int KEY_A = 65; const int KEY_B = 66; const int KEY_C = 67; const int KEY_D = 68;
const int KEY_E = 69; const int KEY_F = 70; const int KEY_G = 71; const int KEY_H = 72;
const int KEY_I = 73; const int KEY_J = 74; const int KEY_K = 75; const int KEY_L = 76;
const int KEY_M = 77; const int KEY_N = 78; const int KEY_O = 79; const int KEY_P = 80;
const int KEY_Q = 81; const int KEY_R = 82; const int KEY_S = 83; const int KEY_T = 84;
const int KEY_U = 85; const int KEY_V = 86; const int KEY_W = 87; const int KEY_X = 88;
const int KEY_Y = 89; const int KEY_Z = 90;
const int KEY_0 = 48; const int KEY_1 = 49; const int KEY_2 = 50; const int KEY_3 = 51;
const int KEY_4 = 52; const int KEY_5 = 53; const int KEY_6 = 54; const int KEY_7 = 55;
const int KEY_8 = 56; const int KEY_9 = 57;
const int KEY_LEFT = 37; const int KEY_UP = 38; const int KEY_RIGHT = 39; const int KEY_DOWN = 40;
const int KEY_SPACE = 32; const int KEY_ENTER = 13; const int KEY_TAB = 9; const int KEY_ESC = 27;
const int KEY_BACKSPACE = 8; const int KEY_DELETE = 46; const int KEY_SHIFT = 16;
const int KEY_CTRL = 17; const int KEY_ALT = 18;
const int KEY_F1 = 112; const int KEY_F2 = 113; const int KEY_F3 = 114; const int KEY_F4 = 115;
const int KEY_F5 = 116; const int KEY_F6 = 117; const int KEY_F7 = 118; const int KEY_F8 = 119;
const int KEY_F9 = 120; const int KEY_F10 = 121; const int KEY_F11 = 122; const int KEY_F12 = 123;
float keyDown(int key) { return textureLod(iChannel0, vec2((float(key) + 0.5) / 256.0, 0.25), 0.0).x; }
float keyToggle(int key) { return textureLod(iChannel0, vec2((float(key) + 0.5) / 256.0, 0.75), 0.0).x; }
bool isKeyDown(int key) { return keyDown(key) > 0.5; }
bool isKeyToggled(int key) { return keyToggle(key) > 0.5; }
` : "", f = a.map((w) => `  { name: '${w.name}', source: \`${Ye(w.source)}\`, channels: ${JSON.stringify(w.channelTypes)} }`).join(`,
`), b = `#version 300 es
precision highp float;

const float ST_PI = 3.14159265359;
const float ST_TWOPI = 6.28318530718;
vec2 _st_dirToEquirect(vec3 dir) {
  float phi = atan(dir.z, dir.x);
  float theta = asin(dir.y);
  return vec2(phi / ST_TWOPI + 0.5, theta / ST_PI + 0.5);
}

uniform vec3  iResolution;
uniform float iTime;
uniform float iTimeDelta;
uniform int   iFrame;
uniform vec4  iMouse;
uniform bool  iMousePressed;
uniform vec4  iDate;
uniform float iFrameRate;
uniform vec3  iChannelResolution[4];
uniform sampler2D iChannel0;
uniform sampler2D iChannel1;
uniform sampler2D iChannel2;
uniform sampler2D iChannel3;

${E}
${g}
${p}`;
  return `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${t}</title>
  <style>
    * { margin: 0; padding: 0; box-sizing: border-box; }
    html, body { width: 100%; height: 100%; background: #fff; }
    body { display: flex; align-items: center; justify-content: center; }
    .container {
      width: 90vw;
      max-width: 1200px;
      aspect-ratio: 16 / 9;
      background: #000;
      border-radius: 8px;
      overflow: hidden;
      box-shadow: 0 4px 24px rgba(0,0,0,0.15), 0 2px 8px rgba(0,0,0,0.1);
    }
    canvas { display: block; width: 100%; height: 100%; }
  </style>
</head>
<body>
  <div class="container">
    <canvas id="canvas"></canvas>
  </div>
  <script>
// Shader Sandbox Export - ${t}
// Generated ${(/* @__PURE__ */ new Date()).toISOString()}

// ── Constants ──

const VERTEX_SHADER = \`#version 300 es
precision highp float;
layout(location = 0) in vec2 position;
void main() { gl_Position = vec4(position, 0.0, 1.0); }
\`;

const FRAGMENT_PREAMBLE = \`${Ye(b)}\`;

const FRAGMENT_SUFFIX = \`
out vec4 fragColor;
void main() { mainImage(fragColor, gl_FragCoord.xy); }
\`;

const COMMON_SOURCE = \`${Ye(i)}\`;

const PASSES = [
${f}
];

const UNIFORM_VALUES = {
${m.join(`,
`)}
};

const UBO_DATA = [
${v}
];

// ── WebGL Setup ──

const canvas = document.getElementById('canvas');
const gl = canvas.getContext('webgl2', { alpha: false, antialias: false, preserveDrawingBuffer: true });
if (!gl) { alert('WebGL2 not supported'); throw new Error('WebGL2 not supported'); }

const floatExt = gl.getExtension('EXT_color_buffer_float');
if (!floatExt) console.warn('EXT_color_buffer_float not supported');

// Fullscreen triangle
const vao = gl.createVertexArray();
gl.bindVertexArray(vao);
const vbo = gl.createBuffer();
gl.bindBuffer(gl.ARRAY_BUFFER, vbo);
gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1,-1, 3,-1, -1,3]), gl.STATIC_DRAW);
gl.enableVertexAttribArray(0);
gl.vertexAttribPointer(0, 2, gl.FLOAT, false, 0, 0);

// ── Helper Textures ──

function createProceduralTexture() {
  const tex = gl.createTexture();
  gl.bindTexture(gl.TEXTURE_2D, tex);
  const data = new Uint8Array(8 * 8 * 4);
  for (let y = 0; y < 8; y++) {
    for (let x = 0; x < 8; x++) {
      const i = (y * 8 + x) * 4;
      const c = (x + y) % 2;
      data[i] = c ? 204 : 51; data[i+1] = c ? 26 : 51;
      data[i+2] = c ? 204 : 51; data[i+3] = 255;
    }
  }
  gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, 8, 8, 0, gl.RGBA, gl.UNSIGNED_BYTE, data);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.NEAREST);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.NEAREST);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.REPEAT);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.REPEAT);
  return tex;
}

function createBlackTexture() {
  const tex = gl.createTexture();
  gl.bindTexture(gl.TEXTURE_2D, tex);
  gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, 1, 1, 0, gl.RGBA, gl.UNSIGNED_BYTE, new Uint8Array([0,0,0,255]));
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.NEAREST);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.NEAREST);
  return tex;
}

const proceduralTex = createProceduralTexture();
const blackTex = createBlackTexture();
${c ? `
// ── Keyboard Texture (256x3) ──
// Row 0: current key state, Row 1: key down events, Row 2: toggle state
const keyboardTex = gl.createTexture();
const keyboardData = new Uint8Array(256 * 3);
gl.bindTexture(gl.TEXTURE_2D, keyboardTex);
gl.texImage2D(gl.TEXTURE_2D, 0, gl.R8, 256, 3, 0, gl.RED, gl.UNSIGNED_BYTE, keyboardData);
gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.NEAREST);
gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.NEAREST);
gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);

const keyStates = new Uint8Array(256);     // row 0: held
const keyDown_ev = new Uint8Array(256);    // row 1: down this frame
const keyToggle_st = new Uint8Array(256);  // row 2: toggle

document.addEventListener('keydown', e => {
  const k = e.keyCode;
  if (k < 256) {
    if (!keyStates[k]) {
      keyDown_ev[k] = 255;
      keyToggle_st[k] = keyToggle_st[k] ? 0 : 255;
    }
    keyStates[k] = 255;
  }
});
document.addEventListener('keyup', e => {
  const k = e.keyCode;
  if (k < 256) keyStates[k] = 0;
});

function updateKeyboardTexture() {
  keyboardData.set(keyStates, 0);
  keyboardData.set(keyDown_ev, 256);
  keyboardData.set(keyToggle_st, 512);
  gl.bindTexture(gl.TEXTURE_2D, keyboardTex);
  gl.texSubImage2D(gl.TEXTURE_2D, 0, 0, 0, 256, 3, gl.RED, gl.UNSIGNED_BYTE, keyboardData);
  keyDown_ev.fill(0);
}
` : ""}
${u || l ? `
// ── Script Textures ──
const scriptTextures = new Map();

function updateScriptTexture(name, w, h, data) {
  const existing = scriptTextures.get(name);
  const isFloat = data instanceof Float32Array;
  const internalFormat = isFloat ? gl.RGBA32F : gl.RGBA;
  const type = isFloat ? gl.FLOAT : gl.UNSIGNED_BYTE;
  if (existing && existing.width === w && existing.height === h) {
    gl.bindTexture(gl.TEXTURE_2D, existing.texture);
    gl.texSubImage2D(gl.TEXTURE_2D, 0, 0, 0, w, h, gl.RGBA, type, data);
  } else {
    const tex = existing ? existing.texture : gl.createTexture();
    gl.bindTexture(gl.TEXTURE_2D, tex);
    gl.texImage2D(gl.TEXTURE_2D, 0, internalFormat, w, h, 0, gl.RGBA, type, data);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.NEAREST);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.NEAREST);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
    scriptTextures.set(name, { texture: tex, width: w, height: h });
  }
}
` : ""}
// ── Shader Compilation ──

function compileShader(type, source) {
  const shader = gl.createShader(type);
  gl.shaderSource(shader, source);
  gl.compileShader(shader);
  if (!gl.getShaderParameter(shader, gl.COMPILE_STATUS)) {
    console.error(gl.getShaderInfoLog(shader));
    console.error(source.split('\\n').map((l,i) => (i+1) + ': ' + l).join('\\n'));
    throw new Error('Shader compile failed');
  }
  return shader;
}

function createProgram(fragSource) {
  const vs = compileShader(gl.VERTEX_SHADER, VERTEX_SHADER);
  const fs = compileShader(gl.FRAGMENT_SHADER, fragSource);
  const program = gl.createProgram();
  gl.attachShader(program, vs);
  gl.attachShader(program, fs);
  gl.linkProgram(program);
  if (!gl.getProgramParameter(program, gl.LINK_STATUS)) {
    throw new Error('Program link failed: ' + gl.getProgramInfoLog(program));
  }
  return program;
}

function createRenderTexture(w, h) {
  const tex = gl.createTexture();
  gl.bindTexture(gl.TEXTURE_2D, tex);
  gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA32F, w, h, 0, gl.RGBA, gl.FLOAT, null);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.NEAREST);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.NEAREST);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
  return tex;
}

function createFramebuffer(tex) {
  const fb = gl.createFramebuffer();
  gl.bindFramebuffer(gl.FRAMEBUFFER, fb);
  gl.framebufferTexture2D(gl.FRAMEBUFFER, gl.COLOR_ATTACHMENT0, gl.TEXTURE_2D, tex, 0);
  return fb;
}

// ── Initialize Passes ──

const container = canvas.parentElement;
let width = canvas.width = container.clientWidth * devicePixelRatio;
let height = canvas.height = container.clientHeight * devicePixelRatio;

const runtimePasses = PASSES.map(pass => {
  const fragSource = FRAGMENT_PREAMBLE +
    (COMMON_SOURCE ? '\\n// Common\\n' + COMMON_SOURCE + '\\n' : '') +
    '\\n// User code\\n' + pass.source + FRAGMENT_SUFFIX;
  const program = createProgram(fragSource);
  const currentTexture = createRenderTexture(width, height);
  const previousTexture = createRenderTexture(width, height);
  const framebuffer = createFramebuffer(currentTexture);

  // Cache uniform locations
  const uniforms = {
    iResolution: gl.getUniformLocation(program, 'iResolution'),
    iTime: gl.getUniformLocation(program, 'iTime'),
    iTimeDelta: gl.getUniformLocation(program, 'iTimeDelta'),
    iFrame: gl.getUniformLocation(program, 'iFrame'),
    iMouse: gl.getUniformLocation(program, 'iMouse'),
    iMousePressed: gl.getUniformLocation(program, 'iMousePressed'),
    iDate: gl.getUniformLocation(program, 'iDate'),
    iFrameRate: gl.getUniformLocation(program, 'iFrameRate'),
    iChannel: [0,1,2,3].map(i => gl.getUniformLocation(program, 'iChannel' + i)),
    iChannelResolution: gl.getUniformLocation(program, 'iChannelResolution'),
    custom: {},
    uboCountLocs: {},
  };

  // Scalar uniform locations
  for (const name of Object.keys(UNIFORM_VALUES)) {
    uniforms.custom[name] = gl.getUniformLocation(program, name);
  }

  // UBO block bindings and count locations
  for (const ubo of UBO_DATA) {
    const blockIndex = gl.getUniformBlockIndex(program, '_ub_' + ubo.name);
    if (blockIndex !== gl.INVALID_INDEX) {
      gl.uniformBlockBinding(program, blockIndex, ubo.binding);
    }
    uniforms.uboCountLocs[ubo.name] = gl.getUniformLocation(program, ubo.name + '_count');
  }

  return { name: pass.name, channels: pass.channels, program, framebuffer, currentTexture, previousTexture, uniforms };
});

// ── UBO Buffers ──

const uboBuffers = UBO_DATA.map(ubo => {
  const buffer = gl.createBuffer();
  gl.bindBuffer(gl.UNIFORM_BUFFER, buffer);
  gl.bufferData(gl.UNIFORM_BUFFER, ubo.data, gl.DYNAMIC_DRAW);
  gl.bindBufferBase(gl.UNIFORM_BUFFER, ubo.binding, buffer);
  return { name: ubo.name, buffer, count: ubo.count, data: ubo.data };
});

const findPass = name => runtimePasses.find(p => p.name === name);
${l ? `
// ── Script Setup ──

const scriptSetup = ${_ || "null"};
const scriptOnFrame = ${R || "null"};

const scriptEngine = {
  setUniformValue(name, value) {
    // Check if this is an array uniform (Float32Array)
    if (value instanceof Float32Array) {
      const ubo = uboBuffers.find(u => u.name === name);
      if (ubo) {
        // Pack to std140: user provides tight data, we need to pad
        // For simplicity, copy directly (assume already padded or vec4/mat4)
        const len = Math.min(value.length, ubo.data.length);
        ubo.data.set(value.subarray(0, len));
        gl.bindBuffer(gl.UNIFORM_BUFFER, ubo.buffer);
        gl.bufferSubData(gl.UNIFORM_BUFFER, 0, ubo.data);
      }
    } else {
      UNIFORM_VALUES[name] = value;
    }
  },
  getUniformValue(name) {
    return UNIFORM_VALUES[name];
  },
  updateTexture(name, w, h, data) {
    updateScriptTexture(name, w, h, data);
  },
  readPixels(passName, x, y, w, h) {
    const pass = findPass(passName);
    if (!pass) return new Uint8Array(w * h * 4);
    gl.bindFramebuffer(gl.FRAMEBUFFER, pass.framebuffer);
    gl.framebufferTexture2D(gl.FRAMEBUFFER, gl.COLOR_ATTACHMENT0, gl.TEXTURE_2D, pass.previousTexture, 0);
    const pixels = new Uint8Array(w * h * 4);
    gl.readPixels(x, y, w, h, gl.RGBA, gl.UNSIGNED_BYTE, pixels);
    gl.framebufferTexture2D(gl.FRAMEBUFFER, gl.COLOR_ATTACHMENT0, gl.TEXTURE_2D, pass.currentTexture, 0);
    return pixels;
  },
  get width() { return width; },
  get height() { return height; },
  setOverlay() {},
};

try {
  if (scriptSetup) scriptSetup(scriptEngine);
} catch(e) { console.error('script setup error:', e); }
` : ""}
// ── Mouse ──

let mouse = [0, 0, 0, 0];
let mouseDown = false;
canvas.addEventListener('mousedown', e => {
  mouseDown = true;
  const rect = canvas.getBoundingClientRect();
  const x = (e.clientX - rect.left) / rect.width * width;
  const y = (1 - (e.clientY - rect.top) / rect.height) * height;
  mouse[0] = x; mouse[1] = y;
  mouse[2] = x; mouse[3] = y;
});
canvas.addEventListener('mousemove', e => {
  if (!mouseDown) return;
  const rect = canvas.getBoundingClientRect();
  mouse[0] = (e.clientX - rect.left) / rect.width * width;
  mouse[1] = (1 - (e.clientY - rect.top) / rect.height) * height;
});
canvas.addEventListener('mouseup', () => {
  mouseDown = false;
  mouse[2] = -Math.abs(mouse[2]);
  mouse[3] = -Math.abs(mouse[3]);
});

// ── Resize ──

let resizeTimer = null;
new ResizeObserver(() => {
  const newW = container.clientWidth * devicePixelRatio;
  const newH = container.clientHeight * devicePixelRatio;
  canvas.width = newW;
  canvas.height = newH;
  if (resizeTimer) clearTimeout(resizeTimer);
  resizeTimer = setTimeout(() => {
    width = newW;
    height = newH;
    runtimePasses.forEach(p => {
      [p.currentTexture, p.previousTexture].forEach(tex => {
        gl.bindTexture(gl.TEXTURE_2D, tex);
        gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA32F, width, height, 0, gl.RGBA, gl.FLOAT, null);
      });
      gl.bindFramebuffer(gl.FRAMEBUFFER, p.framebuffer);
      gl.framebufferTexture2D(gl.FRAMEBUFFER, gl.COLOR_ATTACHMENT0, gl.TEXTURE_2D, p.currentTexture, 0);
    });
    frame = 0;
    startTime = performance.now() / 1000;
    lastTime = 0;
  }, 150);
}).observe(container);

// ── Animation Loop ──

let frame = 0;
let startTime = performance.now() / 1000;
let lastTime = 0;

function render(now) {
  requestAnimationFrame(render);

  const time = now / 1000 - startTime;
  const deltaTime = Math.max(0.001, time - lastTime);
  lastTime = time;

  const date = new Date();
  const iDate = [date.getFullYear(), date.getMonth(), date.getDate(),
    date.getHours() * 3600 + date.getMinutes() * 60 + date.getSeconds() + date.getMilliseconds() / 1000];
${c ? `
  updateKeyboardTexture();` : ""}
${l ? `
  // Run script onFrame
  try {
    if (scriptOnFrame) scriptOnFrame(scriptEngine, time, deltaTime, frame);
  } catch(e) { console.error('script onFrame error:', e); }
` : ""}
  gl.bindVertexArray(vao);

  runtimePasses.forEach(pass => {
    gl.useProgram(pass.program);
    gl.bindFramebuffer(gl.FRAMEBUFFER, pass.framebuffer);
    gl.viewport(0, 0, width, height);

    // Built-in uniforms
    gl.uniform3f(pass.uniforms.iResolution, width, height, 1);
    gl.uniform1f(pass.uniforms.iTime, time);
    gl.uniform1f(pass.uniforms.iTimeDelta, deltaTime);
    gl.uniform1i(pass.uniforms.iFrame, frame);
    gl.uniform4fv(pass.uniforms.iMouse, mouse);
    gl.uniform1i(pass.uniforms.iMousePressed, mouseDown ? 1 : 0);
    gl.uniform4fv(pass.uniforms.iDate, iDate);
    gl.uniform1f(pass.uniforms.iFrameRate, 1 / deltaTime);

    // Scalar custom uniforms
    for (const [name, value] of Object.entries(UNIFORM_VALUES)) {
      const loc = pass.uniforms.custom[name];
      if (!loc) continue;
      if (Array.isArray(value)) {
        if (value.length === 2) gl.uniform2fv(loc, value);
        else if (value.length === 3) gl.uniform3fv(loc, value);
        else if (value.length === 4) gl.uniform4fv(loc, value);
      } else if (typeof value === 'number') {
        gl.uniform1f(loc, value);
      }
    }

    // UBO count uniforms
    for (const ubo of UBO_DATA) {
      const countLoc = pass.uniforms.uboCountLocs[ubo.name];
      if (countLoc) gl.uniform1i(countLoc, ubo.count);
    }

    // Bind channels
    const channelRes = new Float32Array(12); // iChannelResolution[4] × vec3
    pass.channels.forEach((ch, i) => {
      gl.activeTexture(gl.TEXTURE0 + i);
      if (ch === 'none') {
        gl.bindTexture(gl.TEXTURE_2D, blackTex);
      } else if (ch === 'procedural') {
        gl.bindTexture(gl.TEXTURE_2D, proceduralTex);
        channelRes[i*3] = 8; channelRes[i*3+1] = 8; channelRes[i*3+2] = 1;
      } else if (ch === 'keyboard') {
        gl.bindTexture(gl.TEXTURE_2D, ${c ? "keyboardTex" : "blackTex"});
        channelRes[i*3] = 256; channelRes[i*3+1] = 3; channelRes[i*3+2] = 1;
      } else if (ch === 'black') {
        gl.bindTexture(gl.TEXTURE_2D, blackTex);
      } else if (ch.startsWith('buffer:')) {
        const srcPass = findPass(ch.slice(7));
        gl.bindTexture(gl.TEXTURE_2D, srcPass ? srcPass.previousTexture : blackTex);
        channelRes[i*3] = width; channelRes[i*3+1] = height; channelRes[i*3+2] = 1;
      } else if (ch.startsWith('script:')) {
        const stex = scriptTextures?.get(ch.slice(7));
        gl.bindTexture(gl.TEXTURE_2D, stex ? stex.texture : blackTex);
        if (stex) { channelRes[i*3] = stex.width; channelRes[i*3+1] = stex.height; channelRes[i*3+2] = 1; }
      } else {
        gl.bindTexture(gl.TEXTURE_2D, blackTex);
      }
      gl.uniform1i(pass.uniforms.iChannel[i], i);
    });

    if (pass.uniforms.iChannelResolution) {
      gl.uniform3fv(pass.uniforms.iChannelResolution, channelRes);
    }

    gl.drawArrays(gl.TRIANGLES, 0, 3);

    // Swap textures
    const temp = pass.currentTexture;
    pass.currentTexture = pass.previousTexture;
    pass.previousTexture = temp;
    gl.framebufferTexture2D(gl.FRAMEBUFFER, gl.COLOR_ATTACHMENT0, gl.TEXTURE_2D, pass.currentTexture, 0);
  });

  // Blit Image pass to screen
  const imagePass = findPass('Image');
  if (imagePass) {
    gl.bindFramebuffer(gl.FRAMEBUFFER, imagePass.framebuffer);
    gl.framebufferTexture2D(gl.FRAMEBUFFER, gl.COLOR_ATTACHMENT0, gl.TEXTURE_2D, imagePass.previousTexture, 0);
    gl.bindFramebuffer(gl.READ_FRAMEBUFFER, imagePass.framebuffer);
    gl.bindFramebuffer(gl.DRAW_FRAMEBUFFER, null);
    gl.blitFramebuffer(0, 0, width, height, 0, 0, width, height, gl.COLOR_BUFFER_BIT, gl.NEAREST);
    gl.bindFramebuffer(gl.FRAMEBUFFER, imagePass.framebuffer);
    gl.framebufferTexture2D(gl.FRAMEBUFFER, gl.COLOR_ATTACHMENT0, gl.TEXTURE_2D, imagePass.currentTexture, 0);
  }

  frame++;
}

requestAnimationFrame(render);
  <\/script>
</body>
</html>`;
}
class wi {
  constructor(e, t, i) {
    h(this, "isRecording", !1);
    h(this, "canvas");
    h(this, "container");
    h(this, "projectRoot");
    h(this, "mediaRecorder", null);
    h(this, "recordedChunks", []);
    h(this, "recordingIndicator", null);
    this.canvas = e, this.container = t, this.projectRoot = i;
  }
  /**
   * Toggle recording on/off.
   * If paused, calls unpause callback before starting.
   */
  toggle(e, t) {
    this.isRecording ? this.stop() : this.start(e, t);
  }
  /**
   * Start recording the canvas as WebM video.
   */
  start(e, t) {
    if (!MediaRecorder.isTypeSupported("video/webm")) {
      console.error("WebM recording not supported in this browser");
      return;
    }
    e && t();
    const i = this.canvas.captureStream(60);
    this.mediaRecorder = new MediaRecorder(i, {
      mimeType: "video/webm;codecs=vp9",
      videoBitsPerSecond: 8e6
      // 8 Mbps for high quality
    }), this.recordedChunks = [], this.mediaRecorder.ondataavailable = (n) => {
      n.data.size > 0 && this.recordedChunks.push(n.data);
    }, this.mediaRecorder.onstop = () => {
      const n = new Blob(this.recordedChunks, { type: "video/webm" }), r = this.projectRoot.split("/").pop() || "shader", o = /* @__PURE__ */ new Date(), a = o.getFullYear().toString() + (o.getMonth() + 1).toString().padStart(2, "0") + o.getDate().toString().padStart(2, "0") + "-" + o.getHours().toString().padStart(2, "0") + o.getMinutes().toString().padStart(2, "0") + o.getSeconds().toString().padStart(2, "0"), c = `shadertoy-${r}-${a}.webm`, u = URL.createObjectURL(n), l = document.createElement("a");
      l.href = u, l.download = c, l.click(), URL.revokeObjectURL(u), console.log(`Recording saved: ${c}`);
    }, this.mediaRecorder.start(), this.isRecording = !0, this.showRecordingIndicator(), console.log("Recording started");
  }
  /**
   * Stop recording and trigger download.
   */
  stop() {
    this.mediaRecorder && this.mediaRecorder.state !== "inactive" && this.mediaRecorder.stop(), this.isRecording = !1, this.mediaRecorder = null, this.hideRecordingIndicator(), console.log("Recording stopped");
  }
  /**
   * Clean up resources.
   */
  dispose() {
    this.isRecording && this.stop(), this.hideRecordingIndicator();
  }
  /**
   * Show the recording indicator (pulsing red dot in corner).
   */
  showRecordingIndicator() {
    this.recordingIndicator || (this.recordingIndicator = document.createElement("div"), this.recordingIndicator.className = "recording-indicator", this.recordingIndicator.innerHTML = `
      <span class="recording-dot"></span>
      <span class="recording-text">REC</span>
    `, this.container.appendChild(this.recordingIndicator));
  }
  /**
   * Hide the recording indicator.
   */
  hideRecordingIndicator() {
    this.recordingIndicator && (this.recordingIndicator.remove(), this.recordingIndicator = null);
  }
}
class Ei {
  constructor(e) {
    h(this, "container");
    h(this, "statsContainer");
    h(this, "statsGrid");
    h(this, "fpsDisplay");
    h(this, "timeDisplay");
    h(this, "frameDisplay");
    h(this, "resolutionDisplay");
    h(this, "frameCount", 0);
    h(this, "totalFrameCount", 0);
    h(this, "lastFpsUpdate", 0);
    h(this, "currentFps", 0);
    h(this, "isStatsOpen", !1);
    this.container = e, this.statsContainer = document.createElement("div"), this.statsContainer.className = "stats-container", this.fpsDisplay = document.createElement("button"), this.fpsDisplay.className = "fps-counter", this.fpsDisplay.textContent = "0 FPS", this.fpsDisplay.title = "Click to show stats", this.fpsDisplay.addEventListener("click", () => this.toggle()), this.statsGrid = document.createElement("div"), this.statsGrid.className = "stats-grid", this.timeDisplay = document.createElement("div"), this.timeDisplay.className = "stat-item", this.timeDisplay.innerHTML = '<span class="stat-value">0:00</span><span class="stat-label">time</span>', this.statsGrid.appendChild(this.timeDisplay), this.frameDisplay = document.createElement("div"), this.frameDisplay.className = "stat-item", this.frameDisplay.innerHTML = '<span class="stat-value">0</span><span class="stat-label">frame</span>', this.statsGrid.appendChild(this.frameDisplay), this.resolutionDisplay = document.createElement("div"), this.resolutionDisplay.className = "stat-item", this.resolutionDisplay.innerHTML = '<span class="stat-value">0×0</span><span class="stat-label">res</span>', this.statsGrid.appendChild(this.resolutionDisplay), this.statsContainer.appendChild(this.statsGrid), this.statsContainer.appendChild(this.fpsDisplay), this.container.appendChild(this.statsContainer);
  }
  /**
   * Update FPS counter and stats. Call once per frame.
   */
  update(e, t) {
    this.frameCount++, this.totalFrameCount++, this.isStatsOpen && this.updateFrameDisplay(), e - this.lastFpsUpdate >= 1 && (this.currentFps = this.frameCount / (e - this.lastFpsUpdate), this.fpsDisplay.textContent = `${Math.round(this.currentFps)} FPS`, this.frameCount = 0, this.lastFpsUpdate = e, this.isStatsOpen && (this.updateTimeDisplay(t), this.updateResolutionDisplay()));
  }
  /**
   * Reset all counters.
   */
  reset() {
    this.frameCount = 0, this.totalFrameCount = 0, this.lastFpsUpdate = 0, this.isStatsOpen && (this.updateTimeDisplay(0), this.updateFrameDisplay(), this.updateResolutionDisplay());
  }
  /**
   * Update resolution display with current canvas dimensions.
   */
  updateResolution(e, t) {
    this.resolutionDisplay.querySelector(".stat-value").textContent = `${e}×${t}`;
  }
  /**
   * Clean up DOM.
   */
  dispose() {
    this.statsContainer.remove();
  }
  toggle() {
    this.isStatsOpen = !this.isStatsOpen, this.statsGrid.classList.toggle("open", this.isStatsOpen), this.statsContainer.classList.toggle("open", this.isStatsOpen), this.isStatsOpen && (this.updateFrameDisplay(), this.updateResolutionDisplay());
  }
  updateFrameDisplay() {
    let e;
    this.totalFrameCount >= 1e6 ? e = (this.totalFrameCount / 1e6).toFixed(1) + "M" : this.totalFrameCount >= 1e3 ? e = (this.totalFrameCount / 1e3).toFixed(1) + "K" : e = this.totalFrameCount.toString(), this.frameDisplay.querySelector(".stat-value").textContent = e;
  }
  updateTimeDisplay(e) {
    const t = Math.floor(e), i = Math.floor(t / 3600), n = Math.floor(t % 3600 / 60), r = t % 60;
    let o;
    i > 0 ? o = `${i}:${n.toString().padStart(2, "0")}:${r.toString().padStart(2, "0")}` : o = `${n}:${r.toString().padStart(2, "0")}`, this.timeDisplay.querySelector(".stat-value").textContent = o;
  }
  updateResolutionDisplay() {
    this.resolutionDisplay.querySelector(".stat-value").textContent || (this.resolutionDisplay.querySelector(".stat-value").textContent = "0×0");
  }
}
class vi {
  constructor(e, t) {
    h(this, "container");
    h(this, "controlsContainer");
    h(this, "controlsGrid");
    h(this, "menuButton");
    h(this, "playPauseButton");
    h(this, "isMenuOpen", !1);
    this.container = e, this.controlsContainer = document.createElement("div"), this.controlsContainer.className = "playback-controls", this.menuButton = document.createElement("button"), this.menuButton.className = "controls-menu-button", this.menuButton.title = "Controls", this.menuButton.textContent = "+", this.menuButton.addEventListener("click", () => this.toggleMenu()), this.controlsGrid = document.createElement("div"), this.controlsGrid.className = "controls-grid", this.playPauseButton = document.createElement("button"), this.playPauseButton.className = "control-button", this.playPauseButton.title = "Play/Pause (Space)", this.playPauseButton.innerHTML = `
      <svg viewBox="0 0 16 16">
        <path d="M5 3h2v10H5V3zm4 0h2v10H9V3z"/>
      </svg>
    `, this.playPauseButton.addEventListener("click", () => t.onTogglePlayPause());
    const i = document.createElement("button");
    i.className = "control-button", i.title = "Reset (R)", i.innerHTML = `
      <svg viewBox="0 0 16 16">
        <path d="M8 3a5 5 0 1 0 4.546 2.914.5.5 0 0 1 .908-.417A6 6 0 1 1 8 2v1z"/>
        <path d="M8 4.466V.534a.25.25 0 0 1 .41-.192l2.36 1.966c.12.1.12.284 0 .384L8.41 4.658A.25.25 0 0 1 8 4.466z"/>
      </svg>
    `, i.addEventListener("click", () => t.onReset());
    const n = document.createElement("button");
    n.className = "control-button", n.title = "Screenshot (S)", n.innerHTML = `
      <svg viewBox="0 0 16 16">
        <path d="M10.5 8.5a2.5 2.5 0 1 1-5 0 2.5 2.5 0 0 1 5 0z"/>
        <path d="M2 4a2 2 0 0 0-2 2v6a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V6a2 2 0 0 0-2-2h-1.172a2 2 0 0 1-1.414-.586l-.828-.828A2 2 0 0 0 9.172 2H6.828a2 2 0 0 0-1.414.586l-.828.828A2 2 0 0 1 3.172 4H2zm.5 2a.5.5 0 1 1 0-1 .5.5 0 0 1 0 1zm9 2.5a3.5 3.5 0 1 1-7 0 3.5 3.5 0 0 1 7 0z"/>
      </svg>
    `, n.addEventListener("click", () => t.onScreenshot());
    const r = document.createElement("button");
    r.className = "control-button", r.title = "Record Video", r.innerHTML = `
      <svg viewBox="0 0 16 16">
        <circle cx="8" cy="8" r="5"/>
      </svg>
    `, r.addEventListener("click", () => t.onToggleRecording());
    const o = document.createElement("button");
    o.className = "control-button", o.title = "Export HTML", o.innerHTML = `
      <svg viewBox="0 0 16 16">
        <path d="M8 1a.5.5 0 0 1 .5.5v11.793l3.146-3.147a.5.5 0 0 1 .708.708l-4 4a.5.5 0 0 1-.708 0l-4-4a.5.5 0 0 1 .708-.708L7.5 13.293V1.5A.5.5 0 0 1 8 1z"/>
        <path d="M2 14.5a.5.5 0 0 1 .5-.5h11a.5.5 0 0 1 0 1h-11a.5.5 0 0 1-.5-.5z"/>
      </svg>
    `, o.addEventListener("click", () => t.onExportHTML());
    const a = document.createElement("button");
    a.className = "control-button", a.title = "Record", a.innerHTML = `
      <svg viewBox="0 0 16 16">
        <path d="M2 3h12v2H2V3zm0 4h12v2H2V7zm0 4h12v2H2v-2z"/>
      </svg>
    `, a.addEventListener("click", () => t.onRender());
    const c = document.createElement("button");
    c.className = "control-button", c.title = "Close", c.textContent = "−", c.style.fontSize = "20px", c.style.fontWeight = "300", c.addEventListener("click", () => this.toggleMenu()), this.controlsGrid.appendChild(this.playPauseButton), this.controlsGrid.appendChild(i), this.controlsGrid.appendChild(o), this.controlsGrid.appendChild(a), this.controlsGrid.appendChild(n), this.controlsGrid.appendChild(r);
    const u = document.createElement("div");
    this.controlsGrid.appendChild(u), this.controlsGrid.appendChild(c), this.controlsContainer.appendChild(this.controlsGrid), this.controlsContainer.appendChild(this.menuButton), this.container.appendChild(this.controlsContainer);
  }
  /**
   * Update the play/pause button icon.
   */
  setPaused(e) {
    e ? this.playPauseButton.innerHTML = `
        <svg viewBox="0 0 16 16">
          <path d="M4 3v10l8-5-8-5z"/>
        </svg>
      ` : this.playPauseButton.innerHTML = `
        <svg viewBox="0 0 16 16">
          <path d="M5 3h2v10H5V3zm4 0h2v10H9V3z"/>
        </svg>
      `;
  }
  /**
   * Clean up DOM.
   */
  dispose() {
    this.controlsContainer.remove();
  }
  toggleMenu() {
    this.isMenuOpen = !this.isMenuOpen, this.menuButton.textContent = this.isMenuOpen ? "−" : "+", this.controlsGrid.classList.toggle("open", this.isMenuOpen), this.controlsContainer.classList.toggle("open", this.isMenuOpen);
  }
}
const Ti = [
  ["720p", 1280, 720],
  ["1080p", 1920, 1080],
  ["1440p", 2560, 1440],
  ["4K", 3840, 2160],
  ["8K", 7680, 4320]
];
class _i {
  constructor(e, t, i, n, r) {
    h(this, "backdrop");
    h(this, "panel");
    h(this, "callbacks");
    h(this, "uniformControls", null);
    // Resolution
    h(this, "presetSelect");
    h(this, "widthInput");
    h(this, "heightInput");
    h(this, "aspectLocked", !0);
    h(this, "aspectRatio");
    // w/h
    h(this, "lockButton");
    // Time
    h(this, "timeInput");
    h(this, "timeSlider", null);
    h(this, "sliderMinInput", null);
    h(this, "sliderMaxInput", null);
    // State
    h(this, "hasBuffers");
    h(this, "currentTime");
    h(this, "canvasWidth");
    h(this, "canvasHeight");
    // Progress
    h(this, "captureBtn");
    h(this, "progressEl");
    h(this, "progressBar");
    h(this, "progressText");
    h(this, "isBusy", !1);
    this.callbacks = r, this.canvasWidth = t, this.canvasHeight = i, this.aspectRatio = t / i, this.hasBuffers = r.hasBufferPasses(), this.currentTime = r.getCurrentTime(), this.backdrop = document.createElement("div"), this.backdrop.className = "screenshot-panel-backdrop", this.backdrop.addEventListener("click", (b) => {
      b.target === this.backdrop && this.close();
    }), this.panel = document.createElement("div"), this.panel.className = "screenshot-panel";
    const o = document.createElement("div");
    o.className = "screenshot-panel-header", o.innerHTML = `
      <div class="screenshot-panel-title">
        <svg width="16" height="16" viewBox="0 0 16 16" fill="currentColor">
          <path d="M10.5 8.5a2.5 2.5 0 1 1-5 0 2.5 2.5 0 0 1 5 0z"/>
          <path d="M2 4a2 2 0 0 0-2 2v6a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V6a2 2 0 0 0-2-2h-1.172a2 2 0 0 1-1.414-.586l-.828-.828A2 2 0 0 0 9.172 2H6.828a2 2 0 0 0-1.414.586l-.828.828A2 2 0 0 1 3.172 4H2z"/>
        </svg>
        Screenshot
      </div>
    `;
    const a = document.createElement("button");
    a.className = "screenshot-panel-close", a.textContent = "×", a.addEventListener("click", () => this.close()), o.appendChild(a);
    const c = document.createElement("div");
    c.className = "screenshot-panel-body";
    const u = this.createSection("Resolution");
    this.presetSelect = document.createElement("select"), this.presetSelect.className = "screenshot-input screenshot-select";
    const l = document.createElement("option");
    l.value = "current", l.textContent = `Current (${t}×${i})`, this.presetSelect.appendChild(l);
    for (const [b, y, T] of Ti) {
      const C = document.createElement("option");
      C.value = `${y}x${T}`, C.textContent = `${b} (${y}×${T})`, this.presetSelect.appendChild(C);
    }
    const d = document.createElement("option");
    d.value = "custom", d.textContent = "Custom", this.presetSelect.appendChild(d), this.presetSelect.addEventListener("change", () => this.onPresetChange()), u.appendChild(this.presetSelect);
    const m = document.createElement("div");
    m.className = "screenshot-res-row", this.widthInput = this.createNumberInput(t, 1, 7680), this.heightInput = this.createNumberInput(i, 1, 4320), this.widthInput.addEventListener("input", () => {
      if (this.presetSelect.value = "custom", this.aspectLocked) {
        const b = parseInt(this.widthInput.value) || 1;
        this.heightInput.value = String(Math.round(b / this.aspectRatio));
      }
    }), this.heightInput.addEventListener("input", () => {
      if (this.presetSelect.value = "custom", this.aspectLocked) {
        const b = parseInt(this.heightInput.value) || 1;
        this.widthInput.value = String(Math.round(b * this.aspectRatio));
      }
    });
    const g = document.createElement("span");
    g.className = "screenshot-dim-separator", g.textContent = "×", this.lockButton = document.createElement("button"), this.lockButton.className = "screenshot-aspect-lock active", this.lockButton.title = "Lock aspect ratio", this.lockButton.innerHTML = `<svg viewBox="0 0 16 16" width="14" height="14" fill="currentColor">
      <path d="M8 1a2 2 0 0 1 2 2v4H6V3a2 2 0 0 1 2-2zm3 6V3a3 3 0 0 0-6 0v4a2 2 0 0 0-2 2v5a2 2 0 0 0 2 2h6a2 2 0 0 0 2-2V9a2 2 0 0 0-2-2z"/>
    </svg>`, this.lockButton.addEventListener("click", () => this.toggleAspectLock()), m.appendChild(this.widthInput), m.appendChild(g), m.appendChild(this.heightInput), m.appendChild(this.lockButton), u.appendChild(m);
    const E = this.createSection("Time");
    if (!this.hasBuffers) {
      const y = Math.max(0, this.currentTime - 5), T = this.currentTime + 5, C = document.createElement("div");
      C.className = "screenshot-range-row", this.sliderMinInput = document.createElement("input"), this.sliderMinInput.type = "number", this.sliderMinInput.className = "screenshot-input screenshot-range-input", this.sliderMinInput.value = y.toFixed(1), this.sliderMinInput.step = "0.1", this.sliderMinInput.min = "0", this.sliderMinInput.addEventListener("input", () => this.updateSliderRange()), this.sliderMaxInput = document.createElement("input"), this.sliderMaxInput.type = "number", this.sliderMaxInput.className = "screenshot-input screenshot-range-input", this.sliderMaxInput.value = T.toFixed(1), this.sliderMaxInput.step = "0.1", this.sliderMaxInput.min = "0", this.sliderMaxInput.addEventListener("input", () => this.updateSliderRange());
      const A = document.createElement("span");
      A.className = "screenshot-dim-separator", A.textContent = "to";
      const w = document.createElement("span");
      w.className = "screenshot-unit", w.textContent = "sec", C.appendChild(this.sliderMinInput), C.appendChild(A), C.appendChild(this.sliderMaxInput), C.appendChild(w), E.appendChild(C), this.timeSlider = document.createElement("input"), this.timeSlider.type = "range", this.timeSlider.className = "screenshot-time-slider", this.timeSlider.min = String(y), this.timeSlider.max = String(T), this.timeSlider.step = String(1 / 60), this.timeSlider.value = String(this.currentTime), this.timeSlider.addEventListener("input", () => {
        const F = parseFloat(this.timeSlider.value);
        this.timeInput.value = F.toFixed(3), this.callbacks.renderPreviewAtTime(F);
      }), E.appendChild(this.timeSlider);
    }
    const v = document.createElement("div");
    v.className = "screenshot-time-row", this.timeInput = document.createElement("input"), this.timeInput.type = "number", this.timeInput.className = "screenshot-input", this.timeInput.value = this.currentTime.toFixed(3), this.timeInput.step = String(1 / 60), this.timeInput.min = "0", this.hasBuffers || this.timeInput.addEventListener("input", () => {
      const b = parseFloat(this.timeInput.value) || 0;
      this.timeSlider && (this.timeSlider.value = String(b)), this.callbacks.renderPreviewAtTime(b);
    });
    const _ = document.createElement("span");
    if (_.className = "screenshot-unit", _.textContent = "sec", v.appendChild(this.timeInput), v.appendChild(_), this.hasBuffers) {
      const b = document.createElement("button");
      b.className = "screenshot-btn screenshot-btn-secondary", b.textContent = "Render Preview", b.addEventListener("click", () => this.renderBufferPreview()), v.appendChild(b);
    }
    if (E.appendChild(v), this.hasBuffers) {
      const b = document.createElement("div");
      b.className = "screenshot-notice", b.textContent = "This shader has feedback buffers. Preview requires computing all frames from the start.", E.appendChild(b);
    }
    let R = null;
    if (n && Object.values(n).some((b) => Se(b))) {
      R = this.createCollapsibleSection("Uniforms");
      const b = R.querySelector(".screenshot-section-content");
      this.uniformControls = new je({
        container: b,
        uniforms: n,
        onChange: (y, T) => {
          if (r.setUniformValue(y, T), !this.hasBuffers) {
            const C = parseFloat(this.timeInput.value) || 0;
            this.callbacks.renderPreviewAtTime(C);
          }
        }
      });
    }
    this.progressEl = document.createElement("div"), this.progressEl.className = "screenshot-progress", this.progressEl.innerHTML = `
      <div class="screenshot-progress-bar-bg"><div class="screenshot-progress-bar"></div></div>
      <div class="screenshot-progress-text">Preparing...</div>
    `, this.progressBar = this.progressEl.querySelector(".screenshot-progress-bar"), this.progressText = this.progressEl.querySelector(".screenshot-progress-text");
    const p = document.createElement("div");
    p.className = "screenshot-panel-actions";
    const f = document.createElement("button");
    f.className = "screenshot-btn screenshot-btn-cancel", f.textContent = "Cancel", f.addEventListener("click", () => this.close()), this.captureBtn = document.createElement("button"), this.captureBtn.className = "screenshot-btn screenshot-btn-primary", this.captureBtn.textContent = "Capture", this.captureBtn.addEventListener("click", () => this.capture()), p.appendChild(f), p.appendChild(this.captureBtn), c.appendChild(u), c.appendChild(E), R && c.appendChild(R), c.appendChild(this.progressEl), this.panel.appendChild(o), this.panel.appendChild(c), this.panel.appendChild(p), this.backdrop.appendChild(this.panel), e.appendChild(this.backdrop), this.callbacks.pause(), this.hasBuffers || this.callbacks.renderPreviewAtTime(this.currentTime);
  }
  close() {
    var e;
    (e = this.uniformControls) == null || e.destroy(), this.backdrop.remove(), this.callbacks.resume();
  }
  // ===========================================================================
  // Resolution
  // ===========================================================================
  onPresetChange() {
    const e = this.presetSelect.value;
    if (e === "current")
      this.widthInput.value = String(this.canvasWidth), this.heightInput.value = String(this.canvasHeight), this.aspectRatio = this.canvasWidth / this.canvasHeight;
    else if (e !== "custom") {
      const [t, i] = e.split("x").map(Number);
      this.widthInput.value = String(t), this.heightInput.value = String(i), this.aspectRatio = t / i;
    }
  }
  toggleAspectLock() {
    if (this.aspectLocked = !this.aspectLocked, this.lockButton.classList.toggle("active", this.aspectLocked), this.aspectLocked) {
      const e = parseInt(this.widthInput.value) || 1, t = parseInt(this.heightInput.value) || 1;
      this.aspectRatio = e / t;
    }
  }
  // ===========================================================================
  // Time
  // ===========================================================================
  updateSliderRange() {
    if (!this.timeSlider || !this.sliderMinInput || !this.sliderMaxInput) return;
    const e = parseFloat(this.sliderMinInput.value) || 0, t = parseFloat(this.sliderMaxInput.value) || 10;
    this.timeSlider.min = String(Math.max(0, e)), this.timeSlider.max = String(t);
  }
  async renderBufferPreview() {
    if (this.isBusy) return;
    this.isBusy = !0;
    const e = parseFloat(this.timeInput.value) || 0;
    this.showProgress("Rendering preview...");
    const t = await this.callbacks.renderPreviewStepped(
      e,
      60,
      (i, n) => {
        const r = i / n * 100;
        this.progressBar.style.width = `${r}%`, this.progressText.textContent = `Frame ${i} / ${n} (${Math.round(r)}%)`;
      }
    );
    this.hideProgress(), this.isBusy = !1, t && (this.progressText.textContent = "Preview ready");
  }
  // ===========================================================================
  // Capture
  // ===========================================================================
  async capture() {
    if (this.isBusy) return;
    this.isBusy = !0;
    const e = parseInt(this.widthInput.value) || this.canvasWidth, t = parseInt(this.heightInput.value) || this.canvasHeight, i = parseFloat(this.timeInput.value) || 0;
    this.showProgress("Capturing..."), this.captureBtn.classList.add("disabled");
    try {
      const n = await this.callbacks.captureScreenshot({
        width: e,
        height: t,
        time: i,
        hasBuffers: this.hasBuffers,
        onProgress: (r, o) => {
          const a = r / o * 100;
          this.progressBar.style.width = `${a}%`, this.progressText.textContent = `Frame ${r} / ${o} (${Math.round(a)}%)`;
        }
      });
      n && (this.downloadBlob(n, e, t), this.progressText.textContent = "Saved!", setTimeout(() => this.close(), 1e3));
    } catch (n) {
      this.progressText.textContent = `Error: ${n.message}`, this.progressBar.style.background = "#c62828";
    } finally {
      this.captureBtn.classList.remove("disabled"), this.isBusy = !1;
    }
  }
  downloadBlob(e, t, i) {
    const n = /* @__PURE__ */ new Date(), r = n.getFullYear().toString() + (n.getMonth() + 1).toString().padStart(2, "0") + n.getDate().toString().padStart(2, "0") + "-" + n.getHours().toString().padStart(2, "0") + n.getMinutes().toString().padStart(2, "0") + n.getSeconds().toString().padStart(2, "0"), o = `screenshot_${t}x${i}_${r}.png`, a = URL.createObjectURL(e), c = document.createElement("a");
    c.href = a, c.download = o, c.click(), URL.revokeObjectURL(a);
  }
  // ===========================================================================
  // Progress
  // ===========================================================================
  showProgress(e) {
    this.progressEl.classList.add("active"), this.progressBar.style.width = "0%", this.progressBar.style.background = "", this.progressText.textContent = e;
  }
  hideProgress() {
    this.progressEl.classList.remove("active");
  }
  // ===========================================================================
  // DOM Helpers
  // ===========================================================================
  createSection(e) {
    const t = document.createElement("div");
    t.className = "screenshot-section";
    const i = document.createElement("div");
    return i.className = "screenshot-section-label", i.textContent = e, t.appendChild(i), t;
  }
  createCollapsibleSection(e) {
    const t = document.createElement("div");
    t.className = "screenshot-section screenshot-collapsible collapsed";
    const i = document.createElement("div");
    i.className = "screenshot-collapsible-header", i.innerHTML = `<span class="screenshot-collapsible-arrow">&#9654;</span> ${e}`, i.addEventListener("click", () => {
      t.classList.toggle("collapsed");
    });
    const n = document.createElement("div");
    return n.className = "screenshot-section-content", t.appendChild(i), t.appendChild(n), t;
  }
  createNumberInput(e, t, i) {
    const n = document.createElement("input");
    return n.type = "number", n.className = "screenshot-input", n.value = String(Math.round(e)), n.min = String(t), n.max = String(i), n;
  }
}
const Ut = {
  low: 2e6,
  medium: 8e6,
  high: 16e6,
  ultra: 32e6
};
function ye() {
  return typeof VideoEncoder < "u";
}
class xi {
  constructor(e, t, i, n = "high") {
    h(this, "width");
    h(this, "height");
    h(this, "fps");
    h(this, "bitrate");
    h(this, "output", null);
    // mediabunny Output
    h(this, "target", null);
    // mediabunny BufferTarget
    h(this, "videoSource", null);
    // mediabunny EncodedVideoPacketSource
    h(this, "encoder", null);
    h(this, "EncodedPacket", null);
    // mediabunny EncodedPacket class
    h(this, "frameCount", 0);
    this.width = e, this.height = t, this.fps = i, this.bitrate = Ut[n] ?? Ut.high;
  }
  async init() {
    const {
      Output: e,
      BufferTarget: t,
      Mp4OutputFormat: i,
      EncodedVideoPacketSource: n,
      EncodedPacket: r
    } = await Promise.resolve().then(() => So);
    this.EncodedPacket = r, this.target = new t(), this.videoSource = new n("avc"), this.output = new e({
      format: new i({ fastStart: "in-memory" }),
      target: this.target
    }), this.output.addVideoTrack(this.videoSource), await this.output.start(), this.encoder = new VideoEncoder({
      output: (o, a) => {
        const c = this.EncodedPacket.fromEncodedChunk(o);
        this.videoSource.add(c, a ?? void 0);
      },
      error: (o) => {
        console.error("VideoEncoder error:", o);
      }
    }), this.encoder.configure({
      codec: "avc1.640028",
      // H.264 High Profile Level 4.0
      width: this.width,
      height: this.height,
      bitrate: this.bitrate,
      framerate: this.fps
    }), this.frameCount = 0;
  }
  /**
   * Add a frame from a canvas element.
   */
  async addFrame(e) {
    if (!this.encoder) throw new Error("Mp4Encoder not initialized");
    const t = await createImageBitmap(e), i = new VideoFrame(t, {
      timestamp: this.frameCount / this.fps * 1e6,
      // microseconds
      duration: 1 / this.fps * 1e6
    }), n = this.frameCount % (this.fps * 2) === 0;
    this.encoder.encode(i, { keyFrame: n }), i.close(), t.close(), this.frameCount++;
  }
  /**
   * Finalize encoding and return the MP4 as a Blob.
   */
  async finish() {
    if (!this.encoder || !this.output || !this.target)
      throw new Error("Mp4Encoder not initialized");
    await this.encoder.flush(), this.encoder.close(), await this.output.finalize();
    const e = this.target.buffer;
    return new Blob([e], { type: "video/mp4" });
  }
  /**
   * Clean up without finalizing (e.g. on cancel).
   */
  dispose() {
    try {
      this.encoder && this.encoder.state !== "closed" && this.encoder.close();
    } catch {
    }
    try {
      this.output && this.output.state === "started" && this.output.cancel();
    } catch {
    }
    this.encoder = null, this.output = null, this.target = null, this.videoSource = null;
  }
}
const Ci = [
  ["720p", 1280, 720],
  ["1080p", 1920, 1080],
  ["1440p", 2560, 1440],
  ["4K", 3840, 2160],
  ["8K", 7680, 4320]
];
class Si {
  constructor(e, t, i, n, r) {
    h(this, "backdrop");
    h(this, "panel");
    h(this, "callbacks");
    h(this, "uniformControls", null);
    h(this, "cancelRenderFn", null);
    // Resolution
    h(this, "presetSelect");
    h(this, "widthInput");
    h(this, "heightInput");
    h(this, "aspectLocked", !0);
    h(this, "aspectRatio");
    h(this, "lockButton");
    // Timing
    h(this, "startTimeInput");
    h(this, "durationInput");
    h(this, "fpsInput");
    h(this, "estimateEl");
    // Format
    h(this, "formatMp4");
    h(this, "formatWebm");
    h(this, "formatFrames");
    h(this, "mp4Label");
    h(this, "qualityGroup");
    h(this, "qualitySelect");
    // State
    h(this, "hasBuffers");
    h(this, "canvasWidth");
    h(this, "canvasHeight");
    // Progress/actions
    h(this, "bodyEl");
    h(this, "actionsEl");
    h(this, "progressEl");
    h(this, "progressBar");
    h(this, "progressText");
    h(this, "warmupNotice", null);
    this.callbacks = r, this.canvasWidth = t, this.canvasHeight = i, this.aspectRatio = t / i, this.hasBuffers = r.hasBufferPasses(), this.backdrop = document.createElement("div"), this.backdrop.className = "recording-panel-backdrop", this.backdrop.addEventListener("click", (N) => {
      N.target === this.backdrop && this.close();
    }), this.panel = document.createElement("div"), this.panel.className = "recording-panel";
    const o = document.createElement("div");
    o.className = "recording-panel-header", o.innerHTML = `
      <div class="recording-panel-title">
        <svg width="16" height="16" viewBox="0 0 16 16" fill="currentColor">
          <path d="M2 3h12v2H2V3zm0 4h12v2H2V7zm0 4h12v2H2v-2z"/>
        </svg>
        Record
      </div>
    `;
    const a = document.createElement("button");
    a.className = "recording-panel-close", a.textContent = "×", a.addEventListener("click", () => this.close()), o.appendChild(a), this.bodyEl = document.createElement("div"), this.bodyEl.className = "recording-panel-body";
    const c = this.createSection("Resolution");
    this.presetSelect = document.createElement("select"), this.presetSelect.className = "recording-input recording-select";
    const u = document.createElement("option");
    u.value = "current", u.textContent = `Current (${t}×${i})`, this.presetSelect.appendChild(u);
    for (const [N, D, $] of Ci) {
      const O = document.createElement("option");
      O.value = `${D}x${$}`, O.textContent = `${N} (${D}×${$})`, this.presetSelect.appendChild(O);
    }
    const l = document.createElement("option");
    l.value = "custom", l.textContent = "Custom", this.presetSelect.appendChild(l), this.presetSelect.addEventListener("change", () => this.onPresetChange()), c.appendChild(this.presetSelect);
    const d = document.createElement("div");
    d.className = "recording-res-row", this.widthInput = this.createNumberInput(t, 1, 7680), this.heightInput = this.createNumberInput(i, 1, 4320), this.widthInput.addEventListener("input", () => {
      if (this.presetSelect.value = "custom", this.aspectLocked) {
        const N = parseInt(this.widthInput.value) || 1;
        this.heightInput.value = String(Math.round(N / this.aspectRatio));
      }
      this.updateEstimate();
    }), this.heightInput.addEventListener("input", () => {
      if (this.presetSelect.value = "custom", this.aspectLocked) {
        const N = parseInt(this.heightInput.value) || 1;
        this.widthInput.value = String(Math.round(N * this.aspectRatio));
      }
      this.updateEstimate();
    });
    const m = document.createElement("span");
    m.className = "recording-dim-separator", m.textContent = "×", this.lockButton = document.createElement("button"), this.lockButton.className = "recording-aspect-lock active", this.lockButton.title = "Lock aspect ratio", this.lockButton.innerHTML = `<svg viewBox="0 0 16 16" width="14" height="14" fill="currentColor">
      <path d="M8 1a2 2 0 0 1 2 2v4H6V3a2 2 0 0 1 2-2zm3 6V3a3 3 0 0 0-6 0v4a2 2 0 0 0-2 2v5a2 2 0 0 0 2 2h6a2 2 0 0 0 2-2V9a2 2 0 0 0-2-2z"/>
    </svg>`, this.lockButton.addEventListener("click", () => this.toggleAspectLock()), d.appendChild(this.widthInput), d.appendChild(m), d.appendChild(this.heightInput), d.appendChild(this.lockButton), c.appendChild(d);
    const g = this.createSection("Timing"), E = this.createFieldRow("Start Time");
    this.startTimeInput = this.createNumberInput(0, 0, 3600), this.startTimeInput.step = "0.1", this.startTimeInput.addEventListener("input", () => {
      this.updateEstimate(), this.updateWarmupNotice();
    });
    const v = document.createElement("span");
    v.className = "recording-unit", v.textContent = "sec", E.appendChild(this.startTimeInput), E.appendChild(v), g.appendChild(E);
    const _ = this.createFieldRow("Duration");
    this.durationInput = this.createNumberInput(10, 0.1, 3600), this.durationInput.step = "0.1", this.durationInput.addEventListener("input", () => this.updateEstimate());
    const R = document.createElement("span");
    R.className = "recording-unit", R.textContent = "sec", _.appendChild(this.durationInput), _.appendChild(R), g.appendChild(_);
    const p = this.createFieldRow("FPS");
    this.fpsInput = this.createNumberInput(60, 1, 120), this.fpsInput.addEventListener("input", () => this.updateEstimate()), p.appendChild(this.fpsInput), g.appendChild(p), this.hasBuffers && (this.warmupNotice = document.createElement("div"), this.warmupNotice.className = "recording-notice", this.warmupNotice.style.display = "none", g.appendChild(this.warmupNotice)), this.estimateEl = document.createElement("div"), this.estimateEl.className = "recording-estimate", g.appendChild(this.estimateEl);
    const f = this.createSection("Format"), b = document.createElement("div");
    b.className = "recording-format-group";
    const y = document.createElement("div");
    y.className = "recording-format-option", this.formatMp4 = document.createElement("input"), this.formatMp4.type = "radio", this.formatMp4.name = "recording-format", this.formatMp4.id = "rec-fmt-mp4", this.formatMp4.value = "mp4", this.formatMp4.checked = ye(), this.formatMp4.disabled = !ye(), this.mp4Label = document.createElement("label"), this.mp4Label.htmlFor = "rec-fmt-mp4", this.mp4Label.textContent = ye() ? "MP4" : "MP4 (unsupported)", ye() || this.mp4Label.classList.add("disabled"), y.appendChild(this.formatMp4), y.appendChild(this.mp4Label), this.formatMp4.addEventListener("change", () => this.onFormatChange());
    const T = document.createElement("div");
    T.className = "recording-format-option", this.formatWebm = document.createElement("input"), this.formatWebm.type = "radio", this.formatWebm.name = "recording-format", this.formatWebm.id = "rec-fmt-webm", this.formatWebm.value = "webm", this.formatWebm.checked = !ye();
    const C = document.createElement("label");
    C.htmlFor = "rec-fmt-webm", C.textContent = "WebM", T.appendChild(this.formatWebm), T.appendChild(C), this.formatWebm.addEventListener("change", () => this.onFormatChange());
    const A = document.createElement("div");
    A.className = "recording-format-option", this.formatFrames = document.createElement("input"), this.formatFrames.type = "radio", this.formatFrames.name = "recording-format", this.formatFrames.id = "rec-fmt-frames", this.formatFrames.value = "frames";
    const w = document.createElement("label");
    w.htmlFor = "rec-fmt-frames", w.textContent = "PNG Frames", A.appendChild(this.formatFrames), A.appendChild(w), this.formatFrames.addEventListener("change", () => this.onFormatChange()), b.appendChild(y), b.appendChild(T), b.appendChild(A), f.appendChild(b), this.qualityGroup = document.createElement("div"), this.qualityGroup.className = "recording-quality-row";
    const F = document.createElement("span");
    F.className = "recording-field-label", F.textContent = "Quality", this.qualitySelect = document.createElement("select"), this.qualitySelect.className = "recording-input recording-select";
    for (const [N, D] of [["low", "Low (2 Mbps)"], ["medium", "Medium (8 Mbps)"], ["high", "High (16 Mbps)"], ["ultra", "Ultra (32 Mbps)"]]) {
      const $ = document.createElement("option");
      $.value = N, $.textContent = D, N === "high" && ($.selected = !0), this.qualitySelect.appendChild($);
    }
    this.qualityGroup.appendChild(F), this.qualityGroup.appendChild(this.qualitySelect), f.appendChild(this.qualityGroup);
    let L = null;
    if (n && Object.values(n).some((N) => Se(N))) {
      L = this.createCollapsibleSection("Uniforms");
      const N = L.querySelector(".recording-section-content");
      this.uniformControls = new je({
        container: N,
        uniforms: n,
        onChange: (D, $) => {
          r.setUniformValue(D, $);
        }
      });
    }
    this.progressEl = document.createElement("div"), this.progressEl.className = "recording-progress", this.progressEl.innerHTML = `
      <div class="recording-progress-bar-bg"><div class="recording-progress-bar"></div></div>
      <div class="recording-progress-text">Preparing...</div>
    `, this.progressBar = this.progressEl.querySelector(".recording-progress-bar"), this.progressText = this.progressEl.querySelector(".recording-progress-text");
    const k = document.createElement("button");
    k.className = "recording-btn recording-btn-cancel", k.textContent = "Cancel Render", k.style.marginTop = "4px", k.addEventListener("click", () => this.cancelRender()), this.progressEl.appendChild(k), this.actionsEl = document.createElement("div"), this.actionsEl.className = "recording-panel-actions";
    const V = document.createElement("button");
    V.className = "recording-btn recording-btn-cancel", V.textContent = "Cancel", V.addEventListener("click", () => this.close());
    const H = document.createElement("button");
    H.className = "recording-btn recording-btn-primary", H.textContent = "Start Render", H.addEventListener("click", () => this.startRender()), this.actionsEl.appendChild(V), this.actionsEl.appendChild(H), this.bodyEl.appendChild(c), this.bodyEl.appendChild(g), this.bodyEl.appendChild(f), L && this.bodyEl.appendChild(L), this.panel.appendChild(o), this.panel.appendChild(this.bodyEl), this.panel.appendChild(this.actionsEl), this.panel.appendChild(this.progressEl), this.backdrop.appendChild(this.panel), this.updateEstimate(), this.onFormatChange(), e.appendChild(this.backdrop);
  }
  close() {
    var e, t;
    (e = this.cancelRenderFn) == null || e.call(this), this.cancelRenderFn = null, (t = this.uniformControls) == null || t.destroy(), this.backdrop.remove();
  }
  // ===========================================================================
  // Resolution
  // ===========================================================================
  onPresetChange() {
    const e = this.presetSelect.value;
    if (e === "current")
      this.widthInput.value = String(this.canvasWidth), this.heightInput.value = String(this.canvasHeight), this.aspectRatio = this.canvasWidth / this.canvasHeight;
    else if (e !== "custom") {
      const [t, i] = e.split("x").map(Number);
      this.widthInput.value = String(t), this.heightInput.value = String(i), this.aspectRatio = t / i;
    }
    this.updateEstimate();
  }
  toggleAspectLock() {
    if (this.aspectLocked = !this.aspectLocked, this.lockButton.classList.toggle("active", this.aspectLocked), this.aspectLocked) {
      const e = parseInt(this.widthInput.value) || 1, t = parseInt(this.heightInput.value) || 1;
      this.aspectRatio = e / t;
    }
  }
  // ===========================================================================
  // Format
  // ===========================================================================
  onFormatChange() {
    const e = this.formatMp4.checked || this.formatWebm.checked;
    this.qualityGroup.style.display = e ? "flex" : "none";
  }
  getSelectedFormat() {
    return this.formatMp4.checked ? "mp4" : this.formatFrames.checked ? "frames" : "webm";
  }
  // ===========================================================================
  // Estimate
  // ===========================================================================
  updateEstimate() {
    const e = parseInt(this.fpsInput.value) || 0, t = parseFloat(this.durationInput.value) || 0, i = Math.ceil(e * t);
    if (this.formatFrames.checked) {
      const n = parseInt(this.widthInput.value) || 0, r = parseInt(this.heightInput.value) || 0, a = n * r * 4 / (1024 * 1024) * i;
      this.estimateEl.textContent = `${i} frames, ~${a < 1024 ? Math.round(a) + " MB" : (a / 1024).toFixed(1) + " GB"} raw`;
    } else
      this.estimateEl.textContent = `${i} frames, ${t}s at ${e} fps`;
  }
  updateWarmupNotice() {
    if (!this.warmupNotice) return;
    const e = parseFloat(this.startTimeInput.value) || 0, t = parseInt(this.fpsInput.value) || 60;
    if (e > 0) {
      const i = Math.ceil(e * t);
      this.warmupNotice.textContent = `Feedback buffers detected. Will compute ${i} warm-up frames before recording.`, this.warmupNotice.style.display = "";
    } else
      this.warmupNotice.style.display = "none";
  }
  // ===========================================================================
  // Render
  // ===========================================================================
  startRender() {
    const e = parseInt(this.widthInput.value) || this.canvasWidth, t = parseInt(this.heightInput.value) || this.canvasHeight, i = parseInt(this.fpsInput.value) || 60, n = parseFloat(this.startTimeInput.value) || 0, r = parseFloat(this.durationInput.value) || 10, o = this.getSelectedFormat(), a = this.qualitySelect.value;
    this.bodyEl.style.display = "none", this.actionsEl.style.display = "none", this.progressEl.classList.add("active"), this.progressBar.style.width = "0%", this.progressBar.style.background = "", this.progressText.textContent = "Preparing...", this.cancelRenderFn = this.callbacks.startRecording({
      width: e,
      height: t,
      fps: i,
      startTime: n,
      duration: r,
      format: o,
      quality: a,
      onProgress: (c, u, l) => {
        const d = u / l * 100;
        this.progressBar.style.width = `${d}%`, this.progressText.textContent = `${c}: ${u} / ${l} (${Math.round(d)}%)`;
      },
      onComplete: () => {
        this.progressText.textContent = "Done!", this.progressBar.style.width = "100%", setTimeout(() => this.close(), 1500);
      },
      onError: (c) => {
        this.progressText.textContent = `Error: ${c.message}`, this.progressBar.style.background = "#c62828";
      }
    });
  }
  cancelRender() {
    var e;
    (e = this.cancelRenderFn) == null || e.call(this), this.cancelRenderFn = null, this.bodyEl.style.display = "", this.actionsEl.style.display = "", this.progressEl.classList.remove("active");
  }
  // ===========================================================================
  // DOM Helpers
  // ===========================================================================
  createSection(e) {
    const t = document.createElement("div");
    t.className = "recording-section";
    const i = document.createElement("div");
    return i.className = "recording-section-label", i.textContent = e, t.appendChild(i), t;
  }
  createCollapsibleSection(e) {
    const t = document.createElement("div");
    t.className = "recording-section recording-collapsible collapsed";
    const i = document.createElement("div");
    i.className = "recording-collapsible-header", i.innerHTML = `<span class="recording-collapsible-arrow">&#9654;</span> ${e}`, i.addEventListener("click", () => {
      t.classList.toggle("collapsed");
    });
    const n = document.createElement("div");
    return n.className = "recording-section-content", t.appendChild(i), t.appendChild(n), t;
  }
  createFieldRow(e) {
    const t = document.createElement("div");
    t.className = "recording-field-row";
    const i = document.createElement("span");
    return i.className = "recording-field-label", i.textContent = e, t.appendChild(i), t;
  }
  createNumberInput(e, t, i) {
    const n = document.createElement("input");
    return n.type = "number", n.className = "recording-input", n.value = String(Math.round(e)), n.min = String(t), n.max = String(i), n;
  }
}
const le = class le {
  constructor(e) {
    h(this, "container");
    h(this, "views", /* @__PURE__ */ new Map());
    h(this, "primaryView");
    h(this, "project");
    h(this, "isMultiView");
    h(this, "animationId", null);
    h(this, "startTime", 0);
    h(this, "pausedElapsedTime", 0);
    h(this, "disposed", !1);
    // Stats panel (null when controls are disabled)
    h(this, "statsPanel", null);
    // Playback controls
    h(this, "playbackControls", null);
    h(this, "isPaused", !1);
    h(this, "_pauseAfterFirstFrame", !1);
    // Visibility observer (auto-pause when off-screen)
    h(this, "intersectionObserver");
    h(this, "isVisible", !0);
    // Floating uniforms panel
    h(this, "uniformsPanel", null);
    // Script hooks API
    h(this, "scriptAPI", null);
    h(this, "scriptErrorCount", 0);
    h(this, "_lastOnFrameTime", null);
    h(this, "_insideScriptSet", !1);
    // Recording
    h(this, "recorder");
    // Keyboard shortcut handlers (stored for cleanup in dispose)
    h(this, "globalKeyHandler", null);
    h(this, "controlsKeyHandler", null);
    // ===========================================================================
    // Animation Loop
    // ===========================================================================
    h(this, "animate", (e) => {
      var n, r, o;
      if (this.disposed || (this.animationId = requestAnimationFrame(this.animate), this.isPaused || !this.isVisible))
        return;
      for (const a of this.views.values())
        if (a.isContextLost) return;
      const t = e / 1e3, i = t - this.startTime;
      if ((n = this.statsPanel) == null || n.update(t, i), this.runScriptOnFrame(i, ((r = this.statsPanel) == null ? void 0 : r.totalFrameCount) ?? 0), this.isMultiView) {
        const a = /* @__PURE__ */ new Map();
        for (const [c, u] of this.views)
          a.set(c, {
            mouse: u.getMouseState(),
            resolution: u.getResolution(),
            mousePressed: u.getMousePressed()
          });
        for (const c of this.views.values())
          c.step(i, a);
      } else
        this.primaryView.step(i);
      this._pauseAfterFirstFrame && (this._pauseAfterFirstFrame = !1, this.isPaused = !0, (o = this.playbackControls) == null || o.setPaused(!0));
    });
    var c;
    this.container = e.container, this.project = e.project, this.isMultiView = ns(e.project), this.container.hasAttribute("tabindex") || this.container.setAttribute("tabindex", "-1"), this.container.style.outline = "none", this.container.addEventListener("mousedown", () => this.container.focus());
    const t = e.pixelRatio ?? e.project.pixelRatio ?? window.devicePixelRatio;
    if (this.isMultiView) {
      const u = e.project, l = u.views.map((d) => d.name);
      if (!e.viewContainers)
        throw new Error("viewContainers required for multi-view projects");
      for (const d of u.views) {
        const m = e.viewContainers.get(d.name);
        if (!m)
          throw new Error(`No container provided for view "${d.name}"`);
        const g = this.createViewProject(u, d), E = new It({
          container: m,
          project: g,
          keyboardTarget: this.container,
          pixelRatio: t,
          viewNames: l
        });
        this.views.set(d.name, E);
      }
      this.primaryView = this.views.values().next().value;
    } else {
      const u = new It({
        container: e.container,
        project: e.project,
        keyboardTarget: this.container,
        pixelRatio: t
      });
      this.views.set("default", u), this.primaryView = u;
    }
    this.recorder = new wi(this.primaryView.canvas, this.container, this.project.root);
    const i = this.project.stats ?? this.project.controls ?? !1, n = this.project.playback ?? this.project.controls ?? !1, r = this.project.uniformsUI ?? "panel", o = r !== "off", a = r === "panel";
    if (i && (this.statsPanel = new Ei(this.container), this.statsPanel.updateResolution(this.primaryView.canvas.width, this.primaryView.canvas.height)), this.isMultiView) {
      this.primaryView.onResize = (u, l) => {
        var d;
        (d = this.statsPanel) == null || d.updateResolution(u, l);
      };
      for (const u of this.views.values())
        u.onContextRestored = () => {
          var l;
          if (this.scriptAPI && ((l = this.project.script) != null && l.setup))
            try {
              this.project.script.setup(this.scriptAPI, { isRestore: !0 });
            } catch (d) {
              console.error("script.js setup() threw during context restore:", d), this.primaryView.runtimeErrorOverlay.showError("setup", d);
            }
        };
    } else
      this.primaryView.onResize = (u, l) => {
        var d;
        (d = this.statsPanel) == null || d.updateResolution(u, l), this.startTime = performance.now() / 1e3, this.pausedElapsedTime = 0, this.isPaused && this.primaryView.step(0);
      }, this.primaryView.onContextRestored = () => {
        var u;
        if (this.scriptAPI && ((u = this.project.script) != null && u.setup))
          try {
            this.project.script.setup(this.scriptAPI, { isRestore: !0 });
          } catch (l) {
            console.error("script.js setup() threw during context restore:", l), this.primaryView.runtimeErrorOverlay.showError("setup", l);
          }
        this.reset(), this.start();
      };
    if (n && !e.skipPlaybackControls && (this.playbackControls = new vi(this.container, {
      onTogglePlayPause: () => this.togglePlayPause(),
      onReset: () => this.reset(),
      onScreenshot: () => this.openScreenshotPanel(),
      onToggleRecording: () => this.toggleRecording(),
      onExportHTML: () => this.exportHTML(),
      onRender: () => this.openRecordingPanel()
    })), this.project.startPaused && (this._pauseAfterFirstFrame = !0, (c = this.playbackControls) == null || c.setPaused(!0)), this.intersectionObserver = new IntersectionObserver(
      (u) => {
        this.isVisible = u[0].isIntersecting;
      },
      { threshold: 0.1 }
    ), this.intersectionObserver.observe(this.container), this.project.script && (this.initScriptAPI(), this.project.script.setup && this.scriptAPI))
      try {
        this.project.script.setup(this.scriptAPI, { isRestore: !1 });
      } catch (u) {
        console.error("script.js setup() threw:", u), this.primaryView.runtimeErrorOverlay.showError("setup", u);
      }
    o && !e.skipUniformsPanel && this.project.uniforms && Object.values(this.project.uniforms).some((u) => Se(u)) && (this.uniformsPanel = new gi({
      container: this.container,
      uniforms: this.project.uniforms,
      collapsible: a,
      onChange: (u, l) => {
        this.setUniformValue(u, l);
      }
    })), this.setupGlobalShortcuts(), n && this.setupKeyboardShortcuts();
  }
  // ===========================================================================
  // Multi-View Helpers
  // ===========================================================================
  /**
   * Create a single-view ShaderProject from a MultiViewProject + ViewEntry.
   * Each view gets a fullscreen layout with no controls (App manages controls).
   */
  createViewProject(e, t) {
    return {
      mode: e.mode,
      root: e.root,
      meta: {
        ...e.meta,
        title: `${e.meta.title} - ${t.name}`
      },
      layout: "fullscreen",
      theme: e.theme,
      controls: !1,
      uniformsUI: e.uniformsUI,
      startPaused: e.startPaused,
      stickyMouse: e.stickyMouse,
      pixelRatio: e.pixelRatio,
      commonSource: e.commonSource,
      passes: t.passes,
      textures: e.textures,
      uniforms: e.uniforms,
      uniformData: e.uniformData,
      script: null
      // Script handled by App, not individual views
    };
  }
  // ===========================================================================
  // Script API
  // ===========================================================================
  initScriptAPI() {
    const e = this;
    this.scriptAPI = {
      setUniformValue: (t, i) => {
        e._insideScriptSet = !0, e.setUniformValue(t, i), e._insideScriptSet = !1;
      },
      getUniformValue: (t) => e.primaryView.engine.getUniformValue(t),
      updateTexture: (t, i, n, r) => e.primaryView.engine.updateTexture(t, i, n, r),
      readPixels: (t, i, n, r, o) => e.primaryView.engine.readPixels(t, i, n, r, o),
      get width() {
        return e.primaryView.engine.width;
      },
      get height() {
        return e.primaryView.engine.height;
      },
      setOverlay: (t, i, n) => {
        const r = n ? e.views.get(n) : e.primaryView;
        r == null || r.setOverlay(t, i);
      },
      setArrayUniform: (t, i) => {
        for (const n of e.views.values())
          n.engine.setArrayUniform(t, i);
      },
      setArrayElement: (t, i, n) => {
        for (const r of e.views.values())
          r.engine.setArrayElement(t, i, n);
      },
      setActiveCount: (t, i) => {
        for (const n of e.views.values())
          n.engine.setActiveCount(t, i);
      },
      setStructArrayUniform: (t, i) => {
        for (const n of e.views.values())
          n.engine.setStructArrayUniform(t, i);
      },
      setStructArrayElement: (t, i, n) => {
        for (const r of e.views.values())
          r.engine.setStructArrayElement(t, i, n);
      },
      // Multi-view extensions (undefined for single-view)
      getCrossViewState: e.isMultiView ? (t) => e.getCrossViewState(t) : void 0,
      viewNames: e.isMultiView ? e.project.views.map((t) => t.name) : void 0
    };
  }
  /**
   * Run script onFrame hook with error tracking.
   * Called from animate() with error tracking.
   */
  runScriptOnFrame(e, t) {
    var n;
    if (!this.scriptAPI || !((n = this.project.script) != null && n.onFrame) || this.scriptErrorCount >= le.MAX_SCRIPT_ERRORS) return;
    const i = this._lastOnFrameTime !== null ? e - this._lastOnFrameTime : 0;
    try {
      this.project.script.onFrame(this.scriptAPI, e, i, t), this.scriptErrorCount = 0;
    } catch (r) {
      this.scriptErrorCount++, console.error(`script.js onFrame() threw (${this.scriptErrorCount}/${le.MAX_SCRIPT_ERRORS}):`, r), this.primaryView.runtimeErrorOverlay.showError("onFrame", r), this.scriptErrorCount >= le.MAX_SCRIPT_ERRORS && (console.warn("script.js onFrame() disabled after too many errors"), this.primaryView.runtimeErrorOverlay.showDisabled());
    }
    this._lastOnFrameTime = e;
  }
  // ===========================================================================
  // Public API
  // ===========================================================================
  hasErrors() {
    for (const e of this.views.values())
      if (e.hasErrors()) return !0;
    return !1;
  }
  getEngine() {
    return this.primaryView.engine;
  }
  /**
   * Set a uniform value across all views.
   * Fires onUniformChange hook unless the call originated from the script itself.
   */
  setUniformValue(e, t) {
    var i;
    for (const n of this.views.values())
      n.engine.setUniformValue(e, t);
    if (!this._insideScriptSet && this.scriptAPI && ((i = this.project.script) != null && i.onUniformChange))
      try {
        this.project.script.onUniformChange(this.scriptAPI, e, t);
      } catch (n) {
        console.error(`script.js onUniformChange('${e}') threw:`, n);
      }
  }
  /**
   * Get a uniform value from the primary view.
   */
  getUniformValue(e) {
    return this.primaryView.engine.getUniformValue(e);
  }
  /**
   * Start the animation loop.
   */
  start() {
    this.animationId === null && (this.startTime = performance.now() / 1e3, this.animationId = requestAnimationFrame(this.animate));
  }
  stop() {
    this.animationId !== null && (cancelAnimationFrame(this.animationId), this.animationId = null);
  }
  // ===========================================================================
  // Cross-View State
  // ===========================================================================
  getMouseState() {
    return this.primaryView.getMouseState();
  }
  getResolution() {
    return this.primaryView.getResolution();
  }
  getMousePressed() {
    return this.primaryView.getMousePressed();
  }
  /**
   * Get cross-view state for a named view.
   */
  getCrossViewState(e) {
    const t = this.views.get(e);
    if (t)
      return {
        mouse: t.getMouseState(),
        resolution: t.getResolution(),
        mousePressed: t.getMousePressed()
      };
  }
  setOverlay(e, t) {
    this.primaryView.setOverlay(e, t);
  }
  // ===========================================================================
  // Playback Control
  // ===========================================================================
  togglePlayPause() {
    var e;
    this.isPaused ? this.startTime = performance.now() / 1e3 - this.pausedElapsedTime : this.pausedElapsedTime = performance.now() / 1e3 - this.startTime, this.isPaused = !this.isPaused, (e = this.playbackControls) == null || e.setPaused(this.isPaused);
  }
  getPaused() {
    return this.isPaused;
  }
  reset() {
    var e;
    this.startTime = performance.now() / 1e3, this.pausedElapsedTime = 0, this._lastOnFrameTime = null, (e = this.statsPanel) == null || e.reset();
    for (const t of this.views.values())
      t.engine.reset();
  }
  // ===========================================================================
  // Screenshots & Recording
  // ===========================================================================
  /** Quick screenshot at current canvas size (S key shortcut). */
  screenshot() {
    const e = this.project.root.split("/").pop() || "shader", t = /* @__PURE__ */ new Date(), i = t.getFullYear().toString() + (t.getMonth() + 1).toString().padStart(2, "0") + t.getDate().toString().padStart(2, "0") + "-" + t.getHours().toString().padStart(2, "0") + t.getMinutes().toString().padStart(2, "0") + t.getSeconds().toString().padStart(2, "0"), n = `shadertoy-${e}-${i}.png`;
    this.primaryView.canvas.toBlob((r) => {
      if (!r) {
        console.error("Failed to create screenshot blob");
        return;
      }
      const o = URL.createObjectURL(r), a = document.createElement("a");
      a.href = o, a.download = n, a.click(), URL.revokeObjectURL(o), console.log(`Screenshot saved: ${n}`);
    }, "image/png");
  }
  toggleRecording() {
    this.recorder.toggle(this.isPaused, () => this.togglePlayPause());
  }
  /** Check if this shader has feedback buffer passes. */
  hasBufferPasses() {
    if (this.isMultiView) return !1;
    const e = this.project;
    return !!(e.passes.BufferA || e.passes.BufferB || e.passes.BufferC || e.passes.BufferD);
  }
  /** Get current elapsed shader time. */
  getCurrentTime() {
    return performance.now() / 1e3 - this.startTime;
  }
  // ===========================================================================
  // Screenshot Panel
  // ===========================================================================
  openScreenshotPanel() {
    const e = this.isPaused;
    new _i(
      this.container,
      this.primaryView.canvas.width,
      this.primaryView.canvas.height,
      this.project.uniforms,
      {
        renderPreviewAtTime: (t) => {
          this.primaryView.engine.reset(), this.primaryView.engine.step(t, [0, 0, 0, 0], !1), this.primaryView.presentToScreen();
        },
        renderPreviewStepped: async (t, i, n) => {
          var a;
          if (this.primaryView.engine.reset(), this.scriptAPI && ((a = this.project.script) != null && a.setup))
            try {
              this.project.script.setup(this.scriptAPI, { isRestore: !0 });
            } catch {
            }
          const o = Math.ceil(t * i);
          for (let c = 0; c <= o; c++)
            this.stepForRender(c, i, 0), c % 100 === 0 && (n(c, o), await new Promise((u) => setTimeout(u, 0)));
          return this.primaryView.presentToScreen(), n(o, o), !0;
        },
        captureScreenshot: async (t) => {
          var a, c;
          const i = this.primaryView.canvas, n = this.primaryView.engine, r = i.width, o = i.height;
          try {
            if (i.width = t.width, i.height = t.height, n.resize(t.width, t.height), n.reset(), this.scriptAPI && ((a = this.project.script) != null && a.setup))
              try {
                this.project.script.setup(this.scriptAPI, { isRestore: !0 });
              } catch {
              }
            if (t.hasBuffers) {
              const l = Math.ceil(t.time * 60);
              for (let d = 0; d <= l; d++)
                this.stepForRender(d, 60, 0), d % 100 === 0 && (t.onProgress(d, l), await new Promise((m) => setTimeout(m, 0)));
              t.onProgress(l, l);
            } else
              n.step(t.time, [0, 0, 0, 0], !1);
            return this.primaryView.presentToScreen(), await new Promise((u, l) => {
              i.toBlob(
                (d) => d ? u(d) : l(new Error("Failed to capture")),
                "image/png"
              );
            });
          } finally {
            if (i.width = r, i.height = o, n.resize(r, o), n.reset(), this.scriptAPI && ((c = this.project.script) != null && c.setup))
              try {
                this.project.script.setup(this.scriptAPI, { isRestore: !0 });
              } catch {
              }
            if (!this.hasBufferPasses()) {
              const u = this.getCurrentTime();
              this.primaryView.engine.step(u, [0, 0, 0, 0], !1), this.primaryView.presentToScreen();
            }
          }
        },
        getCurrentTime: () => this.getCurrentTime(),
        hasBufferPasses: () => this.hasBufferPasses(),
        setUniformValue: (t, i) => this.setUniformValue(t, i),
        pause: () => {
          this.isPaused || (this.pausedElapsedTime = performance.now() / 1e3 - this.startTime), this.isPaused = !0;
        },
        resume: () => {
          e || (this.startTime = performance.now() / 1e3 - this.pausedElapsedTime, this.isPaused = !1);
        }
      }
    );
  }
  // ===========================================================================
  // Recording Panel
  // ===========================================================================
  openRecordingPanel() {
    new Si(
      this.container,
      this.primaryView.canvas.width,
      this.primaryView.canvas.height,
      this.project.uniforms,
      {
        startRecording: (e) => this.handleRecording(e),
        hasBufferPasses: () => this.hasBufferPasses(),
        setUniformValue: (e, t) => this.setUniformValue(e, t)
      }
    );
  }
  handleRecording(e) {
    let t = !1;
    const i = () => {
      t = !0;
    };
    return (async () => {
      var l, d;
      const r = this.primaryView.canvas, o = this.primaryView.engine, a = r.width, c = r.height, u = this.isPaused;
      try {
        if (this.isPaused = !0, r.width = e.width, r.height = e.height, o.resize(e.width, e.height), o.reset(), this.scriptAPI && ((l = this.project.script) != null && l.setup) && this.project.script.setup(this.scriptAPI, { isRestore: !0 }), e.startTime > 0) {
          const g = Math.ceil(e.startTime * e.fps);
          for (let E = 0; E < g; E++) {
            if (t) return;
            this.stepForRender(E, e.fps, 0), E % 100 === 0 && (e.onProgress("Warming up", E, g), await new Promise((v) => setTimeout(v, 0)));
          }
        }
        const m = Math.ceil(e.fps * e.duration);
        e.format === "mp4" ? await this.renderMp4Frames(m, e.fps, e.startTime, e.quality, () => t, (g, E) => e.onProgress("Recording", g, E)) : e.format === "webm" ? await this.renderWebmFrames(m, e.fps, e.startTime, () => t, (g, E) => e.onProgress("Recording", g, E)) : await this.renderPngFrames(m, e.fps, e.startTime, () => t, (g, E) => e.onProgress("Recording", g, E)), t || e.onComplete();
      } catch (m) {
        t || e.onError(m instanceof Error ? m : new Error(String(m)));
      } finally {
        if (r.width = a, r.height = c, o.resize(a, c), o.reset(), this.scriptAPI && ((d = this.project.script) != null && d.setup))
          try {
            this.project.script.setup(this.scriptAPI, { isRestore: !0 });
          } catch {
          }
        this.isPaused = u;
      }
    })(), i;
  }
  // ===========================================================================
  // HTML Export
  // ===========================================================================
  exportHTML() {
    if (this.isMultiView) {
      console.warn("HTML export is not supported for multi-view projects");
      return;
    }
    bi(this.project, this.primaryView.engine);
  }
  // ===========================================================================
  // Render Helpers
  // ===========================================================================
  async renderPngFrames(e, t, i, n, r) {
    let o = null;
    if ("showDirectoryPicker" in window)
      try {
        o = await window.showDirectoryPicker({ mode: "readwrite" });
      } catch {
      }
    for (let a = 0; a < e; a++) {
      if (n()) return;
      this.stepForRender(a, t, i), this.primaryView.presentToScreen();
      const c = await new Promise((l, d) => {
        this.primaryView.canvas.toBlob((m) => m ? l(m) : d(new Error("Failed to capture frame")), "image/png");
      }), u = `frame_${String(a).padStart(5, "0")}.png`;
      if (o) {
        const d = await (await o.getFileHandle(u, { create: !0 })).createWritable();
        await d.write(c), await d.close();
      } else {
        const l = URL.createObjectURL(c), d = document.createElement("a");
        d.href = l, d.download = u, d.click(), URL.revokeObjectURL(l);
      }
      r(a + 1, e), a % 10 === 0 && await new Promise((l) => setTimeout(l, 0));
    }
  }
  async renderWebmFrames(e, t, i, n, r) {
    const o = this.primaryView.canvas, a = document.createElement("canvas");
    a.width = o.width, a.height = o.height;
    const c = a.getContext("2d"), u = a.captureStream(0), l = new MediaRecorder(u, {
      mimeType: "video/webm;codecs=vp9",
      videoBitsPerSecond: 8e6
    }), d = [];
    l.ondataavailable = (_) => {
      _.data.size > 0 && d.push(_.data);
    };
    const m = new Promise((_) => {
      l.onstop = () => _();
    });
    l.start();
    for (let _ = 0; _ < e; _++) {
      if (n()) {
        l.stop(), await m;
        return;
      }
      this.stepForRender(_, t, i), this.primaryView.presentToScreen(), c.drawImage(o, 0, 0);
      const R = u.getVideoTracks()[0];
      R != null && R.requestFrame && R.requestFrame(), r(_ + 1, e), _ % 10 === 0 && await new Promise((p) => setTimeout(p, 0));
    }
    l.stop(), await m;
    const g = new Blob(d, { type: "video/webm" }), E = URL.createObjectURL(g), v = document.createElement("a");
    v.href = E, v.download = `render_${o.width}x${o.height}_${t}fps.webm`, v.click(), URL.revokeObjectURL(E);
  }
  async renderMp4Frames(e, t, i, n, r, o) {
    const a = this.primaryView.canvas, c = new xi(a.width, a.height, t, n);
    await c.init();
    try {
      for (let m = 0; m < e; m++) {
        if (r()) {
          c.dispose();
          return;
        }
        this.stepForRender(m, t, i), this.primaryView.presentToScreen(), await c.addFrame(a), o(m + 1, e), m % 10 === 0 && await new Promise((g) => setTimeout(g, 0));
      }
      const u = await c.finish(), l = URL.createObjectURL(u), d = document.createElement("a");
      d.href = l, d.download = `render_${a.width}x${a.height}_${t}fps.mp4`, d.click(), URL.revokeObjectURL(l);
    } catch (u) {
      throw c.dispose(), u;
    }
  }
  stepForRender(e, t, i) {
    var o;
    const n = i + e / t, r = 1 / t;
    if (this.scriptAPI && ((o = this.project.script) != null && o.onFrame))
      try {
        this.project.script.onFrame(this.scriptAPI, n, r, e);
      } catch {
      }
    this.primaryView.engine.step(n, [0, 0, 0, 0], !1);
  }
  // ===========================================================================
  // Keyboard Shortcuts
  // ===========================================================================
  static isTextInput(e) {
    const t = e.target;
    if (!t) return !1;
    const i = t.tagName;
    return i === "INPUT" || i === "TEXTAREA" || t.isContentEditable;
  }
  setupGlobalShortcuts() {
    this.globalKeyHandler = (e) => {
      le.isTextInput(e) || e.code === "KeyS" && !e.repeat && (e.preventDefault(), this.screenshot());
    }, this.container.addEventListener("keydown", this.globalKeyHandler);
  }
  setupKeyboardShortcuts() {
    this.controlsKeyHandler = (e) => {
      le.isTextInput(e) || (e.code === "Space" && !e.repeat && (e.preventDefault(), this.togglePlayPause()), e.code === "KeyR" && !e.repeat && (e.preventDefault(), this.reset()));
    }, this.container.addEventListener("keydown", this.controlsKeyHandler);
  }
  // ===========================================================================
  // Lifecycle
  // ===========================================================================
  dispose() {
    var e, t, i, n;
    if (this.disposed = !0, this.stop(), (e = this.project.script) != null && e.dispose)
      try {
        this.project.script.dispose();
      } catch (r) {
        console.error("script.js dispose() threw:", r);
      }
    for (const r of this.views.values())
      r.dispose();
    this.recorder.dispose(), (t = this.playbackControls) == null || t.dispose(), this.intersectionObserver.disconnect(), this.globalKeyHandler && this.container.removeEventListener("keydown", this.globalKeyHandler), this.controlsKeyHandler && this.container.removeEventListener("keydown", this.controlsKeyHandler), (i = this.uniformsPanel) == null || i.destroy(), (n = this.statsPanel) == null || n.dispose();
  }
};
h(le, "MAX_SCRIPT_ERRORS", 10);
let ze = le;
class Ri {
  constructor(e) {
    h(this, "wrapper");
    h(this, "opts");
    h(this, "controlsWrapper");
    h(this, "toggleButton");
    h(this, "panel", null);
    h(this, "controls", null);
    h(this, "isOpen", !1);
    h(this, "isPaused", !1);
    this.wrapper = e.wrapper, this.opts = e, this.isPaused = e.getPaused(), this.controlsWrapper = document.createElement("div"), this.controlsWrapper.className = "multi-view-controls-wrapper", this.toggleButton = document.createElement("button"), this.toggleButton.className = "multi-view-controls-toggle", this.toggleButton.title = "Toggle Controls", this.toggleButton.innerHTML = `
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
        <line x1="4" y1="21" x2="4" y2="14"></line>
        <line x1="4" y1="10" x2="4" y2="3"></line>
        <line x1="12" y1="21" x2="12" y2="12"></line>
        <line x1="12" y1="8" x2="12" y2="3"></line>
        <line x1="20" y1="21" x2="20" y2="16"></line>
        <line x1="20" y1="12" x2="20" y2="3"></line>
        <line x1="1" y1="14" x2="7" y2="14"></line>
        <line x1="9" y1="8" x2="15" y2="8"></line>
        <line x1="17" y1="16" x2="23" y2="16"></line>
      </svg>
    `, this.toggleButton.addEventListener("click", () => this.toggle()), this.controlsWrapper.appendChild(this.toggleButton), this.createPanel(e.uniforms), this.wrapper.appendChild(this.controlsWrapper);
  }
  createPanel(e) {
    this.panel = document.createElement("div"), this.panel.className = "multi-view-controls-panel";
    const t = document.createElement("div");
    t.className = "multi-view-controls-header";
    const i = document.createElement("span");
    i.textContent = "Controls", t.appendChild(i);
    const n = document.createElement("button");
    n.className = "multi-view-controls-close", n.innerHTML = "&times;", n.title = "Close", n.addEventListener("click", () => this.toggle()), t.appendChild(n), this.panel.appendChild(t);
    const r = document.createElement("div");
    r.className = "controls-section playback-controls";
    const o = document.createElement("button");
    o.className = "control-btn play-pause-btn", o.title = "Play/Pause", this.updatePlayPauseIcon(o), o.addEventListener("click", () => {
      this.opts.onTogglePlayPause(), this.isPaused = this.opts.getPaused(), this.updatePlayPauseIcon(o);
    }), r.appendChild(o);
    const a = document.createElement("button");
    if (a.className = "control-btn reset-btn", a.title = "Reset", a.innerHTML = `
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
        <path d="M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8"></path>
        <path d="M3 3v5h5"></path>
      </svg>
    `, a.addEventListener("click", () => {
      this.opts.onReset();
    }), r.appendChild(a), this.panel.appendChild(r), e && Object.values(e).some((c) => Se(c))) {
      const c = document.createElement("div");
      c.className = "controls-section uniforms-section";
      const u = document.createElement("div");
      u.className = "section-label", u.textContent = "Uniforms", c.appendChild(u);
      const l = document.createElement("div");
      l.className = "uniforms-container", this.controls = new je({
        container: l,
        uniforms: e,
        onChange: (d, m) => {
          var g, E;
          (E = (g = this.opts).onSetUniformValue) == null || E.call(g, d, m);
        }
      }), c.appendChild(l), this.panel.appendChild(c);
    }
    this.panel.classList.add("closed"), this.controlsWrapper.appendChild(this.panel);
  }
  updatePlayPauseIcon(e) {
    this.isPaused ? e.innerHTML = `
        <svg viewBox="0 0 24 24" fill="currentColor">
          <polygon points="5 3 19 12 5 21 5 3"></polygon>
        </svg>
      ` : e.innerHTML = `
        <svg viewBox="0 0 24 24" fill="currentColor">
          <rect x="6" y="4" width="4" height="16"></rect>
          <rect x="14" y="4" width="4" height="16"></rect>
        </svg>
      `;
  }
  toggle() {
    var e, t;
    this.isOpen = !this.isOpen, this.isOpen ? ((e = this.panel) == null || e.classList.remove("closed"), this.toggleButton.classList.add("hidden")) : ((t = this.panel) == null || t.classList.add("closed"), this.toggleButton.classList.remove("hidden"));
  }
  dispose() {
    var e;
    (e = this.controls) == null || e.destroy(), this.wrapper.removeChild(this.controlsWrapper);
  }
}
class ki {
  constructor(e) {
    h(this, "container");
    h(this, "root");
    h(this, "canvasContainer");
    this.container = e.container, this.root = document.createElement("div"), this.root.className = "layout-fullscreen", this.canvasContainer = document.createElement("div"), this.canvasContainer.className = "canvas-container", this.root.appendChild(this.canvasContainer), this.container.appendChild(this.root);
  }
  getCanvasContainer() {
    return this.canvasContainer;
  }
  dispose() {
    this.container.innerHTML = "";
  }
}
class Ai {
  constructor(e) {
    h(this, "container");
    h(this, "root");
    h(this, "canvasContainer");
    this.container = e.container, this.root = document.createElement("div"), this.root.className = "layout-default", this.canvasContainer = document.createElement("div"), this.canvasContainer.className = "canvas-container", this.root.appendChild(this.canvasContainer), this.container.appendChild(this.root);
  }
  getCanvasContainer() {
    return this.canvasContainer;
  }
  dispose() {
    this.container.innerHTML = "";
  }
}
class Fi {
  constructor(e) {
    h(this, "container");
    h(this, "project");
    h(this, "root");
    h(this, "canvasContainer");
    h(this, "codePanel");
    h(this, "editorPanel", null);
    h(this, "recompileHandler", null);
    h(this, "_disposed", !1);
    this.container = e.container, this.project = e.project, this.root = document.createElement("div"), this.root.className = "layout-split", this.canvasContainer = document.createElement("div"), this.canvasContainer.className = "canvas-container", this.codePanel = document.createElement("div"), this.codePanel.className = "code-panel", this.buildEditorPanel(), this.root.appendChild(this.canvasContainer), this.root.appendChild(this.codePanel), this.container.appendChild(this.root);
  }
  getCanvasContainer() {
    return this.canvasContainer;
  }
  setRecompileHandler(e) {
    this.recompileHandler = e, this.editorPanel && this.editorPanel.setRecompileHandler(e);
  }
  setUniformHandler(e) {
  }
  dispose() {
    this._disposed = !0, this.editorPanel && (this.editorPanel.dispose(), this.editorPanel = null), this.container.innerHTML = "";
  }
  /**
   * Build editor panel (dynamically loaded).
   */
  async buildEditorPanel() {
    try {
      const { EditorPanel: e } = await Promise.resolve().then(() => ko);
      if (this._disposed) return;
      this.editorPanel = new e(this.codePanel, this.project), this.recompileHandler && this.editorPanel.setRecompileHandler(this.recompileHandler);
    } catch (e) {
      console.error("Failed to load editor panel:", e);
    }
  }
}
class Bi {
  constructor(e) {
    h(this, "container");
    h(this, "project");
    h(this, "root");
    h(this, "canvasContainer");
    h(this, "contentArea");
    h(this, "imageViewer");
    h(this, "editorContainer");
    h(this, "editorInstance", null);
    h(this, "buttonContainer");
    h(this, "copyButton");
    h(this, "recompileButton");
    h(this, "errorDisplay");
    h(this, "recompileHandler", null);
    h(this, "modifiedSources", /* @__PURE__ */ new Map());
    h(this, "tabs", []);
    h(this, "activeTabIndex", 0);
    h(this, "keydownHandler", null);
    this.container = e.container, this.project = e.project, this.root = document.createElement("div"), this.root.className = "layout-tabbed";
    const t = document.createElement("div");
    t.className = "tabbed-wrapper", this.contentArea = document.createElement("div"), this.contentArea.className = "tabbed-content", this.canvasContainer = document.createElement("div"), this.canvasContainer.className = "tabbed-canvas-container", this.imageViewer = document.createElement("div"), this.imageViewer.className = "tabbed-image-viewer", this.imageViewer.style.visibility = "hidden", this.contentArea.appendChild(this.canvasContainer), this.contentArea.appendChild(this.imageViewer), this.editorContainer = document.createElement("div"), this.editorContainer.className = "tabbed-editor-container", this.editorContainer.style.visibility = "hidden", this.contentArea.appendChild(this.editorContainer), this.buttonContainer = document.createElement("div"), this.buttonContainer.className = "tabbed-button-container", this.buttonContainer.style.display = "none", this.copyButton = document.createElement("button"), this.copyButton.className = "tabbed-copy-button", this.copyButton.innerHTML = `
      <svg width="16" height="16" viewBox="0 0 16 16" fill="currentColor">
        <path d="M4 2a2 2 0 0 1 2-2h8a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V2z" opacity="0.4"/>
        <path d="M2 5a2 2 0 0 0-2 2v7a2 2 0 0 0 2 2h7a2 2 0 0 0 2-2V7a2 2 0 0 0-2-2H2zm0 1h7a1 1 0 0 1 1 1v7a1 1 0 0 1-1 1H2a1 1 0 0 1-1-1V7a1 1 0 0 1 1-1z"/>
      </svg>
    `, this.copyButton.title = "Copy code to clipboard", this.copyButton.addEventListener("click", () => this.copyToClipboard()), this.buttonContainer.appendChild(this.copyButton), this.recompileButton = document.createElement("button"), this.recompileButton.className = "tabbed-recompile-button", this.recompileButton.innerHTML = `
      <svg width="14" height="14" viewBox="0 0 16 16" fill="currentColor">
        <path d="M4 3v10l8-5-8-5z"/>
      </svg>
      Recompile
    `, this.recompileButton.title = "Recompile shader (Ctrl+Enter)", this.recompileButton.addEventListener("click", () => this.recompile()), this.buttonContainer.appendChild(this.recompileButton), this.errorDisplay = document.createElement("div"), this.errorDisplay.className = "tabbed-error-display", this.errorDisplay.style.display = "none", this.contentArea.appendChild(this.errorDisplay), this.setupKeyboardShortcut();
    const i = this.buildTabBar();
    t.appendChild(i), t.appendChild(this.contentArea), this.root.appendChild(t), this.container.appendChild(this.root);
  }
  getCanvasContainer() {
    return this.canvasContainer;
  }
  setRecompileHandler(e) {
    this.recompileHandler = e;
  }
  dispose() {
    this.keydownHandler && (this.container.removeEventListener("keydown", this.keydownHandler), this.keydownHandler = null), this.editorInstance && (this.editorInstance.destroy(), this.editorInstance = null), this.container.innerHTML = "";
  }
  setupKeyboardShortcut() {
    this.keydownHandler = (e) => {
      (e.ctrlKey || e.metaKey) && e.key === "Enter" && this.tabs[this.activeTabIndex].kind === "code" && (e.preventDefault(), this.recompile());
    }, this.container.addEventListener("keydown", this.keydownHandler);
  }
  saveCurrentEditorContent() {
    if (this.editorInstance) {
      const e = this.tabs[this.activeTabIndex];
      if (e.kind === "code") {
        const t = this.editorInstance.getSource();
        this.modifiedSources.set(e.passName, t);
      }
    }
  }
  recompile() {
    if (!this.recompileHandler) {
      console.warn("No recompile handler set");
      return;
    }
    this.saveCurrentEditorContent();
    const e = this.tabs[this.activeTabIndex];
    if (e.kind !== "code") return;
    const t = this.modifiedSources.get(e.passName) ?? e.source, i = this.recompileHandler(e.passName, t);
    i.success ? (this.hideError(), e.source = t) : this.showError(i.error || "Compilation failed");
  }
  showError(e) {
    this.errorDisplay && (this.errorDisplay.textContent = e, this.errorDisplay.style.display = "block");
  }
  hideError() {
    this.errorDisplay && (this.errorDisplay.style.display = "none");
  }
  async copyToClipboard() {
    const e = this.tabs[this.activeTabIndex];
    if (e.kind !== "code") return;
    const t = this.editorInstance ? this.editorInstance.getSource() : this.modifiedSources.get(e.passName) ?? e.source;
    try {
      await navigator.clipboard.writeText(t);
      const i = this.copyButton.innerHTML;
      this.copyButton.innerHTML = `
        <svg width="16" height="16" viewBox="0 0 16 16" fill="currentColor">
          <path d="M13.78 4.22a.75.75 0 010 1.06l-7.25 7.25a.75.75 0 01-1.06 0L2.22 9.28a.75.75 0 011.06-1.06L6 10.94l6.72-6.72a.75.75 0 011.06 0z"/>
        </svg>
      `, this.copyButton.classList.add("copied"), setTimeout(() => {
        this.copyButton.innerHTML = i, this.copyButton.classList.remove("copied");
      }, 1500);
    } catch (i) {
      console.error("Failed to copy:", i);
    }
  }
  buildTabBar() {
    const e = document.createElement("div");
    e.className = "tabbed-toolbar";
    const t = document.createElement("div");
    t.className = "tabbed-tab-bar", this.tabs = [], this.tabs.push({ kind: "shader", name: "Shader" }), this.project.commonSource && this.tabs.push({
      kind: "code",
      name: "common.glsl",
      passName: "common",
      source: this.project.commonSource
    });
    const i = [
      "BufferA",
      "BufferB",
      "BufferC",
      "BufferD"
    ];
    for (const o of i) {
      const a = this.project.passes[o];
      a && this.tabs.push({
        kind: "code",
        name: `${o.toLowerCase()}.glsl`,
        passName: o,
        source: a.glslSource
      });
    }
    const n = this.project.passes.Image;
    this.tabs.push({
      kind: "code",
      name: "image.glsl",
      passName: "Image",
      source: n.glslSource
    });
    for (const o of this.project.textures)
      this.tabs.push({
        kind: "image",
        name: o.filename || o.name,
        url: o.source
      });
    const r = async (o) => {
      this.saveCurrentEditorContent();
      const a = this.tabs[o];
      if (this.activeTabIndex = o, t.querySelectorAll(".tabbed-tab-button").forEach((c, u) => {
        c.classList.toggle("active", u === o);
      }), this.canvasContainer.style.visibility = "hidden", this.imageViewer.style.visibility = "hidden", this.editorContainer.style.visibility = "hidden", this.buttonContainer.style.display = "none", this.editorInstance && (this.editorInstance.destroy(), this.editorInstance = null), a.kind === "shader")
        this.canvasContainer.style.visibility = "visible";
      else if (a.kind === "code") {
        this.editorContainer.style.visibility = "visible", this.buttonContainer.style.display = "flex";
        const c = this.modifiedSources.get(a.passName) ?? a.source;
        this.editorContainer.innerHTML = "";
        try {
          const { createEditor: u } = await Promise.resolve().then(() => Os);
          this.editorInstance = u(this.editorContainer, c, (l) => {
            this.modifiedSources.set(a.passName, l);
          });
        } catch (u) {
          console.error("Failed to load editor:", u);
          const l = document.createElement("textarea");
          l.className = "tabbed-fallback-textarea", l.value = c, l.addEventListener("input", () => {
            this.modifiedSources.set(a.passName, l.value);
          }), this.editorContainer.appendChild(l);
        }
      } else {
        this.imageViewer.style.visibility = "visible";
        const c = document.createElement("img");
        c.src = a.url, c.alt = a.name, this.imageViewer.innerHTML = "", this.imageViewer.appendChild(c);
      }
    };
    return this.tabs.forEach((o, a) => {
      const c = document.createElement("button");
      c.className = "tabbed-tab-button", o.kind === "shader" ? c.classList.add("shader-tab") : o.kind === "image" && c.classList.add("image-tab"), c.textContent = o.name, a === 0 && c.classList.add("active"), c.addEventListener("click", () => r(a)), t.appendChild(c);
    }), e.appendChild(t), e.appendChild(this.buttonContainer), e;
  }
}
class Nt {
  constructor(e) {
    h(this, "container");
    h(this, "wrapper");
    h(this, "canvasContainers", /* @__PURE__ */ new Map());
    h(this, "resizeObserver");
    this.container = e.container;
    const t = e.viewNames.length;
    this.wrapper = document.createElement("div"), this.wrapper.className = "layout-multi-view layout-grid-view", this.wrapper.dataset.viewCount = String(t);
    for (const n of e.viewNames) {
      const r = document.createElement("div");
      r.className = "multi-view-canvas", r.setAttribute("data-view-name", n);
      const o = document.createElement("div");
      o.className = "multi-view-label", o.textContent = n, r.appendChild(o), this.canvasContainers.set(n, r), this.wrapper.appendChild(r);
    }
    this.container.appendChild(this.wrapper), this.resizeObserver = new ResizeObserver((n) => {
      for (const r of n) {
        const { width: o, height: a } = r.contentRect;
        this.updateOrientation(o, a);
      }
    }), this.resizeObserver.observe(this.wrapper);
    const i = this.wrapper.getBoundingClientRect();
    this.updateOrientation(i.width, i.height);
  }
  updateOrientation(e, t) {
    const i = e > t;
    this.wrapper.classList.toggle("grid-horizontal", i), this.wrapper.classList.toggle("grid-vertical", !i);
  }
  getCanvasContainers() {
    return this.canvasContainers;
  }
  getWrapperElement() {
    return this.wrapper;
  }
  dispose() {
    this.resizeObserver.disconnect(), this.container.innerHTML = "";
  }
}
class Pi {
  constructor(e) {
    h(this, "container");
    h(this, "wrapper");
    h(this, "canvasContainers", /* @__PURE__ */ new Map());
    h(this, "insetContainer", null);
    h(this, "minimizeBtn", null);
    h(this, "isMinimized", !1);
    h(this, "toggleMinimize", () => {
      this.isMinimized = !this.isMinimized, this.insetContainer && this.insetContainer.classList.toggle("minimized", this.isMinimized), this.minimizeBtn && (this.isMinimized ? (this.minimizeBtn.innerHTML = "&#x25A1;", this.minimizeBtn.title = "Restore", this.minimizeBtn.style.display = "none") : (this.minimizeBtn.innerHTML = "&#x2212;", this.minimizeBtn.title = "Minimize", this.minimizeBtn.style.display = ""));
    });
    if (this.container = e.container, e.viewNames.length < 2)
      throw new Error("InsetViewLayout requires at least 2 views");
    this.wrapper = document.createElement("div"), this.wrapper.className = "layout-multi-view layout-inset-view";
    const t = e.viewNames[0], i = document.createElement("div");
    i.className = "multi-view-canvas inset-main", i.setAttribute("data-view-name", t), this.canvasContainers.set(t, i), this.wrapper.appendChild(i);
    const n = e.viewNames[1];
    this.insetContainer = document.createElement("div"), this.insetContainer.className = "multi-view-canvas inset-overlay", this.insetContainer.setAttribute("data-view-name", n), this.canvasContainers.set(n, this.insetContainer), this.minimizeBtn = document.createElement("button"), this.minimizeBtn.className = "inset-minimize-btn", this.minimizeBtn.innerHTML = "&#x2212;", this.minimizeBtn.title = "Minimize", this.minimizeBtn.addEventListener("click", this.toggleMinimize), this.insetContainer.appendChild(this.minimizeBtn), this.wrapper.appendChild(this.insetContainer), this.insetContainer.addEventListener("click", (r) => {
      this.isMinimized && r.target === this.insetContainer && this.toggleMinimize();
    }), this.container.appendChild(this.wrapper);
  }
  getCanvasContainers() {
    return this.canvasContainers;
  }
  getWrapperElement() {
    return this.wrapper;
  }
  dispose() {
    this.minimizeBtn && this.minimizeBtn.removeEventListener("click", this.toggleMinimize), this.container.innerHTML = "";
  }
}
function Mi(s, e) {
  switch (s) {
    case "fullscreen":
      return new ki(e);
    case "default":
      return new Ai(e);
    case "split":
      return new Fi(e);
    case "tabbed":
      return new Bi(e);
  }
}
function Li(s, e) {
  switch (s) {
    case "split":
    case "quad":
    case "grid":
      return new Nt(e);
    case "inset":
      return new Pi(e);
    default:
      return new Nt(e);
  }
}
function nt(s, e) {
  const { styled: t = !0, pixelRatio: i = window.devicePixelRatio } = e, n = { ...e.project };
  return e.layout !== void 0 && (n.layout = e.layout), e.controls !== void 0 && (n.controls = e.controls), e.stats !== void 0 && (n.stats = e.stats), e.playback !== void 0 && (n.playback = e.playback), e.uniformsUI !== void 0 && (n.uniformsUI = e.uniformsUI), e.theme !== void 0 && (n.theme = e.theme), e.startPaused !== void 0 && (n.startPaused = e.startPaused), e.stickyMouse !== void 0 && (n.stickyMouse = e.stickyMouse), e.pixelRatio !== void 0 && (n.pixelRatio = e.pixelRatio), t || s.classList.add("unstyled"), s.setAttribute("data-theme", n.theme), ns(n) ? Ui(s, n, i) : Ii(s, n, i);
}
function os(s, e) {
  return {
    pause: () => {
      s.getPaused() || s.togglePlayPause();
    },
    resume: () => {
      s.getPaused() && s.togglePlayPause();
    },
    reset: () => s.reset(),
    get isPaused() {
      return s.getPaused();
    },
    setUniform: (t, i) => s.setUniformValue(t, i),
    getUniform: (t) => s.getUniformValue(t),
    destroy: e
  };
}
function Ii(s, e, t) {
  const i = Mi(e.layout, {
    container: s,
    project: e
  }), n = new ze({
    container: i.getCanvasContainer(),
    project: e,
    pixelRatio: t,
    skipUniformsPanel: !1,
    skipPlaybackControls: !1
  });
  return i.setRecompileHandler && i.setRecompileHandler((r, o) => {
    const a = n.getEngine();
    if (!a)
      return { success: !1, error: "Engine not initialized" };
    if (r === "common") {
      const c = a.recompileCommon(o);
      if (c.success)
        return { success: !0 };
      const u = c.errors[0];
      return {
        success: !1,
        error: u ? `${u.passName}: ${u.error}` : "Unknown error"
      };
    }
    return a.recompilePass(r, o);
  }), i.setUniformHandler && i.setUniformHandler((r, o) => {
    const a = n.getEngine();
    a && a.setUniformValue(r, o);
  }), n.hasErrors() || n.start(), os(n, () => {
    n.dispose(), i.dispose();
  });
}
function Ui(s, e, t) {
  const i = e.views.map((a) => a.name), n = Li(e.viewLayout, {
    container: s,
    project: e,
    viewNames: i
  }), r = new ze({
    container: n.getWrapperElement(),
    project: e,
    pixelRatio: t,
    viewContainers: n.getCanvasContainers(),
    skipPlaybackControls: !0,
    skipUniformsPanel: !0
  }), o = new Ri({
    wrapper: n.getWrapperElement(),
    onTogglePlayPause: () => r.togglePlayPause(),
    onReset: () => r.reset(),
    getPaused: () => r.getPaused(),
    onSetUniformValue: (a, c) => r.setUniformValue(a, c),
    uniforms: e.uniforms
  });
  return r.hasErrors() || r.start(), os(r, () => {
    o.dispose(), r.dispose(), n.dispose();
  });
}
function lt(s) {
  return s === "Image" || s === "BufferA" || s === "BufferB" || s === "BufferC" || s === "BufferD";
}
function Ni(s) {
  switch (s) {
    case "Image":
      return "image.glsl";
    case "BufferA":
      return "bufferA.glsl";
    case "BufferB":
      return "bufferB.glsl";
    case "BufferC":
      return "bufferC.glsl";
    case "BufferD":
      return "bufferD.glsl";
  }
}
function as(s) {
  return typeof s == "string" ? lt(s) ? { buffer: s } : s === "keyboard" ? { keyboard: !0 } : s === "audio" ? { audio: !0 } : s === "webcam" ? { webcam: !0 } : { texture: s } : s;
}
const rt = ["Image", "BufferA", "BufferB", "BufferC", "BufferD"], Oi = ["BufferA", "BufferB", "BufferC", "BufferD"], cs = ["iChannel0", "iChannel1", "iChannel2", "iChannel3"], Di = "default", $i = "auto", Vi = /* @__PURE__ */ new Set([
  "iResolution",
  "iTime",
  "iTimeDelta",
  "iFrame",
  "iMouse",
  "iDate",
  "iFrameRate",
  "iChannelResolution",
  "iChannel0",
  "iChannel1",
  "iChannel2",
  "iChannel3",
  "iTouchCount",
  "iTouch0",
  "iTouch1",
  "iTouch2",
  "iPinch",
  "iPinchDelta",
  "iPinchCenter"
]), zi = /^[a-zA-Z_][a-zA-Z0-9_]*$/, ji = /* @__PURE__ */ new Set([
  "attribute",
  "const",
  "uniform",
  "varying",
  "break",
  "continue",
  "do",
  "for",
  "while",
  "if",
  "else",
  "in",
  "out",
  "inout",
  "float",
  "int",
  "void",
  "bool",
  "true",
  "false",
  "discard",
  "return",
  "mat2",
  "mat3",
  "mat4",
  "vec2",
  "vec3",
  "vec4",
  "ivec2",
  "ivec3",
  "ivec4",
  "bvec2",
  "bvec3",
  "bvec4",
  "sampler2D",
  "samplerCube",
  "struct",
  "precision",
  "highp",
  "mediump",
  "lowp",
  "layout",
  "centroid",
  "flat",
  "smooth",
  "noperspective",
  "switch",
  "case",
  "default"
]);
function Ne(s) {
  return zi.test(s) && !ji.has(s);
}
const Ot = /* @__PURE__ */ new Set(["fullscreen", "default", "split", "tabbed"]), Dt = /* @__PURE__ */ new Set(["light", "dark", "system"]), Hi = /* @__PURE__ */ new Set([
  "mode",
  "title",
  "author",
  "description",
  "layout",
  "theme",
  "controls",
  "stats",
  "playback",
  "uniformsUI",
  "common",
  "startPaused",
  "stickyMouse",
  "pixelRatio",
  "uniforms",
  "buffers",
  "textures",
  "Image",
  "BufferA",
  "BufferB",
  "BufferC",
  "BufferD",
  "views"
  // multi-view projects
]), Wi = /* @__PURE__ */ new Set(["source", "iChannel0", "iChannel1", "iChannel2", "iChannel3"]), $t = /* @__PURE__ */ new Set(["keyboard", "audio", "webcam"]);
function Xi(s, e) {
  const t = [], i = [];
  for (const r of Object.keys(s))
    Hi.has(r) || t.push(`Unknown config key '${r}'`);
  if (s.layout !== void 0 && !Ot.has(s.layout) && i.push(`Invalid layout '${s.layout}'. Expected one of: ${[...Ot].join(", ")}`), s.theme !== void 0 && !Dt.has(s.theme) && i.push(`Invalid theme '${s.theme}'. Expected one of: ${[...Dt].join(", ")}`), s.uniforms && typeof s.uniforms == "object")
    for (const r of Object.keys(s.uniforms))
      Vi.has(r) && i.push(`Uniform name '${r}' is reserved (built-in uniform)`), Ne(r) || i.push(`Uniform name '${r}' is not a valid GLSL identifier`);
  const n = /* @__PURE__ */ new Set();
  if (s.buffers) {
    const r = Object.keys(s.buffers);
    for (const o of r) {
      if (typeof o != "string") {
        i.push(`Buffer name must be a string, got ${typeof o}`);
        continue;
      }
      Ne(o) || i.push(`Buffer name '${o}' is not a valid GLSL identifier`), n.add(o);
    }
  }
  if (s.textures && typeof s.textures == "object")
    for (const [r, o] of Object.entries(s.textures))
      Ne(r) || i.push(`Texture name '${r}' is not a valid GLSL identifier`), n.has(r) && i.push(`Texture name '${r}' collides with a buffer name`), typeof o != "string" ? i.push(`Texture source for '${r}' must be a string`) : !$t.has(o) && !/\.\w+$/.test(o) && !Ne(o) && i.push(`Invalid texture source '${o}' for '${r}'. Expected a file path with extension, a script texture name, or one of: ${[...$t].join(", ")}`);
  for (const r of rt) {
    const o = s[r];
    if (!(!o || typeof o != "object")) {
      for (const a of Object.keys(o))
        Wi.has(a) || t.push(`Unknown key '${a}' in pass '${r}'`);
      for (const a of cs) {
        const c = o[a];
        c && typeof c == "string" && lt(c) && c !== "Image" && !s[c] && t.push(`${r}.${a} references '${c}' but no ${c} pass is configured`);
      }
    }
  }
  for (const r of t) console.warn(`[config] ${e}: ${r}`);
  if (i.length > 0)
    throw new Error(
      `Config validation failed for '${e}':
${i.map((r) => `  - ${r}`).join(`
`)}`
    );
}
function ke(s) {
  return {
    mode: s.mode,
    root: s.root,
    meta: {
      title: s.title ?? s.root.split("/").pop() ?? "Untitled",
      author: s.author ?? null,
      description: s.description ?? null
    },
    layout: s.layout ?? Di,
    theme: s.theme ?? $i,
    controls: s.controls,
    stats: s.stats,
    playback: s.playback,
    uniformsUI: s.uniformsUI,
    startPaused: s.startPaused ?? !1,
    stickyMouse: s.stickyMouse ?? !1,
    pixelRatio: s.pixelRatio ?? null,
    commonSource: s.commonSource,
    passes: s.passes,
    textures: s.textures ?? [],
    uniforms: s.uniforms ?? {},
    uniformData: s.uniformData ?? {},
    script: s.script ?? null
  };
}
const Vt = /* @__PURE__ */ new Set(["float", "int", "bool", "vec2", "vec3", "vec4"]), Oe = /* @__PURE__ */ new Set(["float", "vec2", "vec3", "vec4", "mat3", "mat4"]), Gi = {
  vec2: 2,
  vec3: 3,
  vec4: 4
};
function Ki(s, e) {
  for (const [t, i] of Object.entries(s)) {
    const n = `Uniform '${t}' in '${e}'`;
    if (Q(i)) {
      if (typeof i.struct != "object" || i.struct === null || Array.isArray(i.struct))
        throw new Error(`${n}: 'struct' must be an object mapping field names to types`);
      if (Object.keys(i.struct).length === 0)
        throw new Error(`${n}: struct must have at least one field`);
      for (const [a, c] of Object.entries(i.struct))
        if (!Oe.has(c))
          throw new Error(`${n}: invalid struct field type '${c}' for field '${a}'. Expected one of: ${[...Oe].join(", ")}`);
      if (typeof i.count != "number" || i.count < 1 || !Number.isInteger(i.count))
        throw new Error(`${n}: 'count' must be a positive integer, got ${i.count}`);
      continue;
    }
    if (q(i)) {
      if (!Oe.has(i.type))
        throw new Error(`${n}: invalid array type '${i.type}'. Expected one of: ${[...Oe].join(", ")}`);
      if (typeof i.count != "number" || i.count < 1 || !Number.isInteger(i.count))
        throw new Error(`${n}: 'count' must be a positive integer, got ${i.count}`);
      continue;
    }
    if (!i.type)
      throw new Error(`${n}: missing 'type' field`);
    const r = i;
    if (!Vt.has(r.type))
      throw new Error(`${n}: invalid type '${r.type}'. Expected one of: ${[...Vt].join(", ")}`);
    switch (r.type) {
      case "float":
      case "int":
        if (typeof r.value != "number")
          throw new Error(`${n}: 'value' must be a number for type '${r.type}', got ${typeof r.value}`);
        if (r.min !== void 0 && typeof r.min != "number")
          throw new Error(`${n}: 'min' must be a number`);
        if (r.max !== void 0 && typeof r.max != "number")
          throw new Error(`${n}: 'max' must be a number`);
        if (r.step !== void 0 && typeof r.step != "number")
          throw new Error(`${n}: 'step' must be a number`);
        break;
      case "bool":
        if (typeof r.value != "boolean")
          throw new Error(`${n}: 'value' must be a boolean for type 'bool', got ${typeof r.value}`);
        break;
      case "vec2":
      case "vec3":
      case "vec4": {
        const o = Gi[r.type];
        if (!Array.isArray(r.value) || r.value.length !== o)
          throw new Error(`${n}: 'value' must be an array of ${o} numbers for type '${r.type}'`);
        if (r.value.some((c) => typeof c != "number"))
          throw new Error(`${n}: all components of 'value' must be numbers`);
        const a = r;
        for (const c of ["min", "max", "step"]) {
          const u = a[c];
          if (u !== void 0 && (!Array.isArray(u) || u.length !== o))
            throw new Error(`${n}: '${c}' must be an array of ${o} numbers for type '${r.type}'`);
        }
        break;
      }
    }
  }
}
async function Yi(s, e, t) {
  const i = {};
  for (const [n, r] of Object.entries(t)) {
    const o = r.data;
    if (typeof o != "string") continue;
    const a = s.joinPath(e, o);
    if (!await s.exists(a))
      throw new Error(`Uniform '${n}': data file '${o}' not found at '${a}'`);
    const c = await s.readText(a);
    let u;
    try {
      u = JSON.parse(c);
    } catch (l) {
      throw new Error(`Uniform '${n}': invalid JSON in '${o}': ${(l == null ? void 0 : l.message) ?? String(l)}`);
    }
    if (q(r))
      if (Array.isArray(u))
        i[n] = u;
      else if (u && typeof u == "object" && n in u)
        i[n] = u[n];
      else
        throw new Error(`Uniform '${n}': data file '${o}' must be an array or contain key '${n}'`);
    else if (Q(r))
      if (u && typeof u == "object" && !Array.isArray(u))
        i[n] = n in u && typeof u[n] == "object" ? u[n] : u;
      else
        throw new Error(`Uniform '${n}': data file '${o}' must be an object with field data`);
  }
  return i;
}
async function ls(s, e, t) {
  if (t) {
    const n = s.joinPath(e, t);
    if (!await s.exists(n))
      throw new Error(`Common GLSL file '${t}' not found in '${e}'.`);
    return await s.readText(n);
  }
  const i = s.joinPath(e, "common.glsl");
  return await s.exists(i) ? await s.readText(i) : null;
}
class us {
  constructor() {
    h(this, "map", /* @__PURE__ */ new Map());
  }
  register(e, t = "linear", i = "repeat", n) {
    const r = `${e}|${t}|${i}`, o = this.map.get(r);
    if (o) return o.name;
    const a = `tex${this.map.size}`;
    return this.map.set(r, { name: a, filename: n, source: e, filter: t, wrap: i }), a;
  }
  toArray() {
    return Array.from(this.map.values());
  }
}
function qi(s, e, t, i, n, r) {
  if ("buffer" in s) {
    const o = s.buffer;
    if (!lt(o))
      throw new Error(`Invalid buffer name '${o}' for ${t} in pass '${e}' at '${i}'.`);
    return { kind: "buffer", buffer: o, current: !!s.current };
  }
  if ("texture" in s)
    return { kind: "texture", name: (r == null ? void 0 : r.get(s.texture)) ?? n.register(s.texture, s.filter, s.wrap), cubemap: s.type === "cubemap" };
  if ("keyboard" in s) return { kind: "keyboard" };
  if ("audio" in s) return { kind: "audio" };
  if ("webcam" in s) return { kind: "webcam" };
  if ("video" in s) return { kind: "video", src: s.video };
  if ("script" in s) return { kind: "script", name: s.script };
  throw new Error(`Invalid channel object for ${t} in pass '${e}' at '${i}'.`);
}
function De(s, e, t, i, n, r) {
  if (!s) return { kind: "none" };
  const o = as(s);
  return o ? qi(o, e, t, i, n, r) : { kind: "none" };
}
async function Qi(s, e, t) {
  let i = t == null ? void 0 : t.config;
  if (i === void 0) {
    const n = s.joinPath(e, "config.json");
    if (await s.exists(n)) {
      const r = await s.readText(n);
      try {
        i = JSON.parse(r);
      } catch (o) {
        throw new Error(`Invalid JSON in config.json at '${e}': ${(o == null ? void 0 : o.message) ?? String(o)}`);
      }
    }
  }
  return i ? (Xi(i, e), i.mode === "shadertoy" ? Ji(s, e, i, t) : en(s, e, i, t)) : Zi(s, e, t);
}
async function Zi(s, e, t) {
  const i = s.joinPath(e, "image.glsl");
  if (!await s.exists(i))
    throw new Error(`Single-pass project at '${e}' requires 'image.glsl'.`);
  const n = await s.listGlslFiles(e);
  if (n.length > 0 && n.filter((u) => u !== "image.glsl").length > 0)
    throw new Error(
      `Project at '${e}' contains multiple GLSL files (${n.join(", ")}) but no 'config.json'. Add a config file to use multiple passes.`
    );
  if (await s.hasFiles(s.joinPath(e, "textures")))
    throw new Error(
      `Project at '${e}' uses textures (in 'textures/' folder) but has no 'config.json'. Add a config file to define texture bindings.`
    );
  const o = await s.readText(i);
  return ke({
    mode: "standard",
    root: e,
    commonSource: null,
    passes: {
      Image: { name: "Image", glslSource: o, channels: [{ kind: "none" }, { kind: "none" }, { kind: "none" }, { kind: "none" }] }
    },
    script: t == null ? void 0 : t.script
  });
}
async function Ji(s, e, t, i) {
  const n = {
    Image: t.Image,
    BufferA: t.BufferA,
    BufferB: t.BufferB,
    BufferC: t.BufferC,
    BufferD: t.BufferD
  };
  n.Image || n.BufferA || n.BufferB || n.BufferC || n.BufferD || (n.Image = {});
  const o = await ls(s, e, t.common), a = new us(), c = /* @__PURE__ */ new Map();
  if (i != null && i.textureUrlResolver)
    for (const l of rt) {
      const d = n[l];
      if (d)
        for (const m of cs) {
          const g = d[m];
          if (!g) continue;
          const E = as(g);
          if (E && "texture" in E && !c.has(E.texture)) {
            const v = await i.textureUrlResolver(E.texture), _ = E.texture.split("/").pop(), R = a.register(v, E.filter, E.wrap, _);
            c.set(E.texture, R);
          }
        }
    }
  const u = {};
  for (const l of rt) {
    const d = n[l];
    if (!d) continue;
    const m = d.source ?? Ni(l), g = s.joinPath(e, m);
    if (!await s.exists(g))
      throw new Error(`Source GLSL file for pass '${l}' not found at '${m}' in '${e}'.`);
    const E = await s.readText(g), v = [
      De(d.iChannel0, l, "iChannel0", e, a, c),
      De(d.iChannel1, l, "iChannel1", e, a, c),
      De(d.iChannel2, l, "iChannel2", e, a, c),
      De(d.iChannel3, l, "iChannel3", e, a, c)
    ];
    u[l] = { name: l, glslSource: E, channels: v };
  }
  if (!u.Image)
    throw new Error(`config.json at '${e}' must define an Image pass.`);
  return ke({
    mode: "shadertoy",
    root: e,
    title: t.title,
    author: t.author,
    description: t.description,
    layout: t.layout,
    theme: t.theme,
    controls: t.controls,
    stats: t.stats,
    playback: t.playback,
    uniformsUI: t.uniformsUI,
    startPaused: t.startPaused,
    stickyMouse: t.stickyMouse,
    pixelRatio: t.pixelRatio,
    commonSource: o,
    passes: u,
    textures: a.toArray(),
    script: i == null ? void 0 : i.script
  });
}
async function en(s, e, t, i) {
  let n = {};
  t.uniforms && (Ki(t.uniforms, e), n = await Yi(s, e, t.uniforms));
  const r = await ls(s, e, t.common), o = t.buffers ?? {};
  if (Object.keys(o).length > 0 || t.textures && Object.keys(t.textures).length > 0)
    return sn(s, e, t, r, i, n);
  const a = s.joinPath(e, "image.glsl");
  if (!await s.exists(a))
    throw new Error(`Standard mode project at '${e}' requires 'image.glsl'.`);
  const c = await s.readText(a), u = [{ kind: "none" }, { kind: "none" }, { kind: "none" }, { kind: "none" }];
  return ke({
    mode: "standard",
    root: e,
    title: t.title,
    author: t.author,
    description: t.description,
    layout: t.layout,
    theme: t.theme,
    controls: t.controls,
    stats: t.stats,
    playback: t.playback,
    uniformsUI: t.uniformsUI,
    startPaused: t.startPaused,
    stickyMouse: t.stickyMouse,
    pixelRatio: t.pixelRatio,
    commonSource: r,
    passes: {
      Image: { name: "Image", glslSource: c, channels: u }
    },
    uniforms: t.uniforms,
    uniformData: n,
    script: i == null ? void 0 : i.script
  });
}
const tn = /* @__PURE__ */ new Set(["keyboard", "audio", "webcam"]);
async function sn(s, e, t, i, n, r) {
  const o = t.buffers ?? {}, a = Object.keys(o);
  if (a.length > 4)
    throw new Error(
      `Standard mode at '${e}' supports max 4 buffers, got ${a.length}: ${a.join(", ")}`
    );
  const c = /* @__PURE__ */ new Map();
  for (let v = 0; v < a.length; v++)
    c.set(a[v], Oi[v]);
  const u = new us(), l = /* @__PURE__ */ new Map();
  for (const [v, _] of c)
    l.set(v, { kind: "buffer", buffer: _, current: !1 });
  for (const [v, _] of Object.entries(t.textures ?? {}))
    if (_ === "keyboard")
      l.set(v, { kind: "keyboard" });
    else if (_ === "audio")
      l.set(v, { kind: "audio" });
    else if (_ === "webcam")
      l.set(v, { kind: "webcam" });
    else if (/\.\w+$/.test(_)) {
      let R;
      n != null && n.textureUrlResolver ? R = await n.textureUrlResolver(_) : R = _;
      const p = u.register(R);
      l.set(v, { kind: "texture", name: p, cubemap: !1 });
    } else tn.has(_) || l.set(v, { kind: "script", name: _ });
  const d = [{ kind: "none" }, { kind: "none" }, { kind: "none" }, { kind: "none" }], m = s.joinPath(e, "image.glsl");
  if (!await s.exists(m))
    throw new Error(`Standard mode project at '${e}' requires 'image.glsl'.`);
  const E = {
    Image: {
      name: "Image",
      glslSource: await s.readText(m),
      channels: d,
      namedSamplers: new Map(l)
    }
  };
  for (const [v, _] of c) {
    const R = s.joinPath(e, `${v}.glsl`);
    if (!await s.exists(R))
      throw new Error(`Buffer '${v}' requires '${v}.glsl' in '${e}'.`);
    const p = await s.readText(R);
    E[_] = {
      name: _,
      glslSource: p,
      channels: d,
      namedSamplers: new Map(l)
    };
  }
  return ke({
    mode: "standard",
    root: e,
    title: t.title,
    author: t.author,
    description: t.description,
    layout: t.layout,
    theme: t.theme,
    controls: t.controls,
    stats: t.stats,
    playback: t.playback,
    uniformsUI: t.uniformsUI,
    startPaused: t.startPaused,
    stickyMouse: t.stickyMouse,
    pixelRatio: t.pixelRatio,
    commonSource: i,
    passes: E,
    textures: u.toArray(),
    uniforms: t.uniforms,
    uniformData: r,
    script: n == null ? void 0 : n.script
  });
}
function nn(s) {
  const e = /* @__PURE__ */ new Map();
  function t(n) {
    const r = n.replace(/^\.\//, "");
    return new URL(r, s).href;
  }
  function i(n) {
    const r = t(n);
    let o = e.get(r);
    return o || (o = fetch(r).then(
      (a) => a.ok ? a.text() : null,
      () => null
    ), e.set(r, o)), o;
  }
  return {
    async exists(n) {
      return await i(n) !== null;
    },
    async readText(n) {
      const r = await i(n);
      if (r === null)
        throw new Error(`File not found: ${t(n)}`);
      return r;
    },
    async resolveImageUrl(n) {
      return t(n);
    },
    async listGlslFiles() {
      return [];
    },
    async hasFiles() {
      return !1;
    },
    joinPath(...n) {
      return n.map((r, o) => o === 0 ? r : r.replace(/^\/+/, "")).join("/").replace(/\/+/g, "/");
    },
    baseName(n) {
      return n.split("/").pop() || n;
    }
  };
}
async function rn(s) {
  const e = new URL("script.js", s).href;
  try {
    if (!(await fetch(e, { method: "HEAD" })).ok) return null;
  } catch {
    return null;
  }
  try {
    const t = await import(
      /* @vite-ignore */
      e
    ), i = {};
    return typeof t.setup == "function" && (i.setup = t.setup), typeof t.onFrame == "function" && (i.onFrame = t.onFrame), typeof t.dispose == "function" && (i.dispose = t.dispose), typeof t.onUniformChange == "function" && (i.onUniformChange = t.onUniformChange), i.setup || i.onFrame || i.dispose || i.onUniformChange ? i : null;
  } catch (t) {
    return console.error(`[shader-sandbox] Failed to load script: ${e}`, t), null;
  }
}
const on = [
  { kind: "none" },
  { kind: "none" },
  { kind: "none" },
  { kind: "none" }
];
function ds(s, e) {
  return ke({
    mode: "standard",
    root: e,
    commonSource: null,
    passes: {
      Image: { name: "Image", glslSource: s, channels: on }
    }
  });
}
async function an(s, e, t) {
  var a;
  if (/^https?:\/\//.test(e) || (e = new URL(e, document.baseURI).href), /\.(glsl|frag)$/i.test(e)) {
    const c = await fetch(e);
    if (!c.ok) throw new Error(`Failed to fetch shader: ${e}`);
    const u = await c.text(), l = ((a = e.split("/").pop()) == null ? void 0 : a.replace(/\.(glsl|frag)$/i, "")) ?? "shader", d = ds(u, l);
    return nt(s, { project: d, ...t });
  }
  const i = e.endsWith("/") ? e : e + "/", n = nn(i), r = await rn(i), o = await Qi(n, ".", {
    script: r,
    textureUrlResolver: async (c) => new URL(c, i).href
  });
  return nt(s, { project: o, ...t });
}
function cn(s, e, t) {
  const i = ds(e, "inline");
  return nt(s, { project: i, ...t });
}
const ln = `
.ss-loading {
  position: absolute;
  inset: 0;
  background: #111;
  border-radius: inherit;
  overflow: hidden;
}
.ss-loading__shimmer {
  position: absolute;
  inset: 0;
  background: linear-gradient(
    90deg,
    transparent 0%,
    rgba(255,255,255,0.03) 45%,
    rgba(255,255,255,0.06) 50%,
    rgba(255,255,255,0.03) 55%,
    transparent 100%
  );
  animation: ss-shimmer 2s ease-in-out infinite;
}
@keyframes ss-shimmer {
  0% { transform: translateX(-100%); }
  100% { transform: translateX(100%); }
}
.ss-error {
  position: absolute;
  inset: 0;
  background: #111;
  border-radius: inherit;
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 2em;
}
.ss-error__card {
  display: flex;
  max-width: 480px;
  width: 100%;
  background: #1a1a1a;
  border-radius: 8px;
  overflow: hidden;
  box-shadow: 0 4px 24px rgba(0,0,0,0.4);
}
.ss-error__accent {
  width: 4px;
  flex-shrink: 0;
  background: #c44;
}
.ss-error__body {
  padding: 1.25em 1.5em;
  flex: 1;
  min-width: 0;
}
.ss-error__title {
  font: 600 14px/1 system-ui, sans-serif;
  color: #e0e0e0;
  margin-bottom: 0.75em;
}
.ss-error__message {
  font: 12px/1.5 'Monaco','Menlo',monospace;
  color: #ff6b6b;
  white-space: pre-wrap;
  word-break: break-word;
  margin: 0 0 1em;
  max-height: 120px;
  overflow-y: auto;
}
.ss-error__retry {
  font: 500 12px/1 system-ui, sans-serif;
  color: #aaa;
  background: #2a2a2a;
  border: 1px solid #3a3a3a;
  border-radius: 4px;
  padding: 0.5em 1em;
  cursor: pointer;
  transition: background 0.15s, color 0.15s;
}
.ss-error__retry:hover {
  background: #3a3a3a;
  color: #ddd;
}
.ss-fade-in {
  animation: ss-fade-in 0.3s ease-in;
}
@keyframes ss-fade-in {
  from { opacity: 0; }
  to { opacity: 1; }
}
`;
function zt() {
  if (document.getElementById("shader-sandbox-styles")) return;
  const s = document.createElement("style");
  s.id = "shader-sandbox-styles", s.textContent = ln, document.head.appendChild(s);
}
function un(s) {
  return s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
}
const dn = /* @__PURE__ */ new Set([
  "src",
  "fullpage",
  "lazy",
  "static",
  "style",
  "class",
  "id",
  "slot",
  "is"
]);
function hn(s) {
  return s.replace(/-([a-z])/g, (e, t) => t.toUpperCase());
}
function mn(s) {
  if (s === "true" || s === "") return !0;
  if (s === "false") return !1;
  const e = Number(s);
  return isNaN(e) ? s : e;
}
class pn extends HTMLElement {
  constructor() {
    super(...arguments);
    h(this, "_handle", null);
    h(this, "_observer", null);
    h(this, "_mounted", !1);
    h(this, "_loading", !1);
    h(this, "_placeholder", null);
    h(this, "_savedGlsl", null);
  }
  connectedCallback() {
    var r;
    const t = this.getAttribute("src"), i = t ? null : ((r = this.textContent) == null ? void 0 : r.trim()) || null;
    if (!t && !i) {
      console.error('<shader-sandbox>: provide a "src" attribute or inline GLSL content');
      return;
    }
    i && (this._savedGlsl = i, this.textContent = ""), this.hasAttribute("fullpage") ? Object.assign(this.style, {
      display: "block",
      width: "100vw",
      height: "100vh",
      position: "fixed",
      top: "0",
      left: "0"
    }) : (!this.style.display || this.style.display === "inline") && (this.style.display = "block"), (!this.style.position || this.style.position === "static") && (this.style.position = "relative"), this.getAttribute("lazy") !== "false" ? (this._observer = new IntersectionObserver(
      (o) => {
        o[0].isIntersecting ? !this._mounted && !this._loading ? this._mountShader(t, i) : this._handle && this._handle.resume() : this._handle && this._handle.pause();
      },
      { rootMargin: "200px" }
    ), this._observer.observe(this)) : this._mountShader(t, i);
  }
  disconnectedCallback() {
    var t;
    (t = this._observer) == null || t.disconnect(), this._observer = null, this._destroyShader();
  }
  _buildOptions() {
    const t = {};
    for (const i of this.attributes)
      dn.has(i.name) || (t[hn(i.name)] = mn(i.value));
    return this.hasAttribute("static") && (t.startPaused = !0, t.controls = !1), t;
  }
  _showLoading() {
    zt(), this._placeholder = document.createElement("div"), this._placeholder.className = "ss-loading", this._placeholder.innerHTML = '<div class="ss-loading__shimmer"></div>', this.appendChild(this._placeholder);
  }
  _clearPlaceholder() {
    this._placeholder && (this._placeholder.remove(), this._placeholder = null);
  }
  _showError(t) {
    this._clearPlaceholder(), zt();
    const i = t instanceof Error ? t.message : String(t), n = document.createElement("div");
    n.className = "ss-error", n.innerHTML = `
      <div class="ss-error__card">
        <div class="ss-error__accent"></div>
        <div class="ss-error__body">
          <div class="ss-error__title">Shader Error</div>
          <pre class="ss-error__message">${un(i)}</pre>
          <button class="ss-error__retry">Retry</button>
        </div>
      </div>
    `, n.querySelector(".ss-error__retry").addEventListener("click", () => {
      this._destroyShader();
      const r = this.getAttribute("src"), o = r ? null : this._savedGlsl;
      this._mountShader(r, o);
    }), this._placeholder = n, this.appendChild(n);
  }
  async _mountShader(t, i) {
    if (!(this._mounted || this._loading)) {
      this._loading = !0, this._showLoading();
      try {
        const n = this._buildOptions();
        i ? (this._handle = cn(this, i, n), this._clearPlaceholder()) : (this._handle = await an(this, t, n), this._clearPlaceholder());
        const r = this.querySelector(".layout-default, .layout-fullscreen, .layout-split, .layout-tabbed");
        r && r.classList.add("ss-fade-in"), this._mounted = !0;
      } catch (n) {
        console.error("<shader-sandbox>: failed to load shader", n), this._showError(n);
      } finally {
        this._loading = !1;
      }
    }
  }
  _destroyShader() {
    var t;
    this._clearPlaceholder(), this._mounted && ((t = this._handle) == null || t.destroy(), this._handle = null, this._mounted = !1);
  }
}
customElements.define("shader-sandbox", pn);
/*!
 * Copyright (c) 2026-present, Vanilagy and contributors
 *
 * This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at https://mozilla.org/MPL/2.0/.
 */
function P(s) {
  if (!s)
    throw new Error("Assertion failed.");
}
const he = (s) => s && s[s.length - 1], fe = (s) => s >= 0 && s < 2 ** 32, S = (s) => {
  let e = 0;
  for (; s.readBits(1) === 0 && e < 32; )
    e++;
  if (e >= 32)
    throw new Error("Invalid exponential-Golomb code.");
  return (1 << e) - 1 + s.readBits(e);
}, oe = (s) => {
  const e = S(s);
  return e & 1 ? e + 1 >> 1 : -(e >> 1);
}, Ae = (s) => s.constructor === Uint8Array ? s : ArrayBuffer.isView(s) ? new Uint8Array(s.buffer, s.byteOffset, s.byteLength) : new Uint8Array(s), hs = (s) => s.constructor === DataView ? s : ArrayBuffer.isView(s) ? new DataView(s.buffer, s.byteOffset, s.byteLength) : new DataView(s), se = /* @__PURE__ */ new TextEncoder(), ut = {
  bt709: 1,
  // ITU-R BT.709
  bt470bg: 5,
  // ITU-R BT.470BG
  smpte170m: 6,
  // ITU-R BT.601 525 - SMPTE 170M
  bt2020: 9,
  // ITU-R BT.202
  smpte432: 12
  // SMPTE EG 432-1
}, dt = {
  bt709: 1,
  // ITU-R BT.709
  smpte170m: 6,
  // SMPTE 170M
  linear: 8,
  // Linear transfer characteristics
  "iec61966-2-1": 13,
  // IEC 61966-2-1
  pq: 16,
  // Rec. ITU-R BT.2100-2 perceptual quantization (PQ) system
  hlg: 18
  // Rec. ITU-R BT.2100-2 hybrid loggamma (HLG) system
}, ht = {
  rgb: 0,
  // Identity
  bt709: 1,
  // ITU-R BT.709
  bt470bg: 5,
  // ITU-R BT.470BG
  smpte170m: 6,
  // SMPTE 170M
  "bt2020-ncl": 9
  // ITU-R BT.2020-2 (non-constant luminance)
}, fn = (s) => !!s && !!s.primaries && !!s.transfer && !!s.matrix && s.fullRange !== void 0, ms = (s) => s instanceof ArrayBuffer || typeof SharedArrayBuffer < "u" && s instanceof SharedArrayBuffer || ArrayBuffer.isView(s);
class ps {
  constructor() {
    this.currentPromise = Promise.resolve(), this.pending = 0;
  }
  async acquire() {
    let e;
    const t = new Promise((n) => {
      let r = !1;
      e = () => {
        r || (n(), this.pending--, r = !0);
      };
    }), i = this.currentPromise;
    return this.currentPromise = t, this.pending++, await i, e;
  }
}
const gn = () => {
  let s, e;
  return { promise: new Promise((i, n) => {
    s = i, e = n;
  }), resolve: s, reject: e };
}, fs = (s) => {
  throw new Error(`Unexpected value: ${s}`);
}, bn = (s, e, t, i) => {
  t = t >>> 0, t = t & 16777215, s.setUint8(e, t >>> 16 & 255), s.setUint8(e + 1, t >>> 8 & 255), s.setUint8(e + 2, t & 255);
}, yn = "und", wn = /^[a-z]{3}$/, En = (s) => wn.test(s), jt = 1e6 * (1 + Number.EPSILON), vn = (s, e) => {
  const t = s < 0 ? -1 : 1;
  s = Math.abs(s);
  let i = 0, n = 1, r = 1, o = 0, a = s;
  for (; ; ) {
    const c = Math.floor(a), u = c * r + i, l = c * o + n;
    if (l > e)
      return {
        numerator: t * r,
        denominator: o
      };
    if (i = r, n = o, r = u, o = l, a = 1 / (a - c), !isFinite(a))
      break;
  }
  return {
    numerator: t * r,
    denominator: o
  };
}, gs = function* (s) {
  for (const e in s) {
    const t = s[e];
    t !== void 0 && (yield { key: e, value: t });
  }
}, Tn = (s) => {
  P(s.den !== 0);
  let e = Math.abs(s.num), t = Math.abs(s.den);
  for (; t !== 0; ) {
    const n = e % t;
    e = t, t = n;
  }
  const i = e || 1;
  return {
    num: s.num / i,
    den: s.den / i
  };
};
/*!
 * Copyright (c) 2026-present, Vanilagy and contributors
 *
 * This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at https://mozilla.org/MPL/2.0/.
 */
class mt {
  /** Creates a new {@link RichImageData}. */
  constructor(e, t) {
    if (this.data = e, this.mimeType = t, !(e instanceof Uint8Array))
      throw new TypeError("data must be a Uint8Array.");
    if (typeof t != "string")
      throw new TypeError("mimeType must be a string.");
  }
}
class bs {
  /** Creates a new {@link AttachedFile}. */
  constructor(e, t, i, n) {
    if (this.data = e, this.mimeType = t, this.name = i, this.description = n, !(e instanceof Uint8Array))
      throw new TypeError("data must be a Uint8Array.");
    if (t !== void 0 && typeof t != "string")
      throw new TypeError("mimeType, when provided, must be a string.");
    if (i !== void 0 && typeof i != "string")
      throw new TypeError("name, when provided, must be a string.");
    if (n !== void 0 && typeof n != "string")
      throw new TypeError("description, when provided, must be a string.");
  }
}
const _n = (s) => {
  if (!s || typeof s != "object")
    throw new TypeError("tags must be an object.");
  if (s.title !== void 0 && typeof s.title != "string")
    throw new TypeError("tags.title, when provided, must be a string.");
  if (s.description !== void 0 && typeof s.description != "string")
    throw new TypeError("tags.description, when provided, must be a string.");
  if (s.artist !== void 0 && typeof s.artist != "string")
    throw new TypeError("tags.artist, when provided, must be a string.");
  if (s.album !== void 0 && typeof s.album != "string")
    throw new TypeError("tags.album, when provided, must be a string.");
  if (s.albumArtist !== void 0 && typeof s.albumArtist != "string")
    throw new TypeError("tags.albumArtist, when provided, must be a string.");
  if (s.trackNumber !== void 0 && (!Number.isInteger(s.trackNumber) || s.trackNumber <= 0))
    throw new TypeError("tags.trackNumber, when provided, must be a positive integer.");
  if (s.tracksTotal !== void 0 && (!Number.isInteger(s.tracksTotal) || s.tracksTotal <= 0))
    throw new TypeError("tags.tracksTotal, when provided, must be a positive integer.");
  if (s.discNumber !== void 0 && (!Number.isInteger(s.discNumber) || s.discNumber <= 0))
    throw new TypeError("tags.discNumber, when provided, must be a positive integer.");
  if (s.discsTotal !== void 0 && (!Number.isInteger(s.discsTotal) || s.discsTotal <= 0))
    throw new TypeError("tags.discsTotal, when provided, must be a positive integer.");
  if (s.genre !== void 0 && typeof s.genre != "string")
    throw new TypeError("tags.genre, when provided, must be a string.");
  if (s.date !== void 0 && (!(s.date instanceof Date) || Number.isNaN(s.date.getTime())))
    throw new TypeError("tags.date, when provided, must be a valid Date.");
  if (s.lyrics !== void 0 && typeof s.lyrics != "string")
    throw new TypeError("tags.lyrics, when provided, must be a string.");
  if (s.images !== void 0) {
    if (!Array.isArray(s.images))
      throw new TypeError("tags.images, when provided, must be an array.");
    for (const e of s.images) {
      if (!e || typeof e != "object")
        throw new TypeError("Each image in tags.images must be an object.");
      if (!(e.data instanceof Uint8Array))
        throw new TypeError("Each image.data must be a Uint8Array.");
      if (typeof e.mimeType != "string")
        throw new TypeError("Each image.mimeType must be a string.");
      if (!["coverFront", "coverBack", "unknown"].includes(e.kind))
        throw new TypeError("Each image.kind must be 'coverFront', 'coverBack', or 'unknown'.");
    }
  }
  if (s.comment !== void 0 && typeof s.comment != "string")
    throw new TypeError("tags.comment, when provided, must be a string.");
  if (s.raw !== void 0) {
    if (!s.raw || typeof s.raw != "object")
      throw new TypeError("tags.raw, when provided, must be an object.");
    for (const e of Object.values(s.raw))
      if (e !== null && typeof e != "string" && !(e instanceof Uint8Array) && !(e instanceof mt) && !(e instanceof bs))
        throw new TypeError("Each value in tags.raw must be a string, Uint8Array, RichImageData, AttachedFile, or null.");
  }
}, xn = (s) => {
  if (!s || typeof s != "object")
    throw new TypeError("disposition must be an object.");
  if (s.default !== void 0 && typeof s.default != "boolean")
    throw new TypeError("disposition.default must be a boolean.");
  if (s.forced !== void 0 && typeof s.forced != "boolean")
    throw new TypeError("disposition.forced must be a boolean.");
  if (s.original !== void 0 && typeof s.original != "boolean")
    throw new TypeError("disposition.original must be a boolean.");
  if (s.commentary !== void 0 && typeof s.commentary != "boolean")
    throw new TypeError("disposition.commentary must be a boolean.");
  if (s.hearingImpaired !== void 0 && typeof s.hearingImpaired != "boolean")
    throw new TypeError("disposition.hearingImpaired must be a boolean.");
  if (s.visuallyImpaired !== void 0 && typeof s.visuallyImpaired != "boolean")
    throw new TypeError("disposition.visuallyImpaired must be a boolean.");
};
/*!
 * Copyright (c) 2026-present, Vanilagy and contributors
 *
 * This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at https://mozilla.org/MPL/2.0/.
 */
class Z {
  constructor(e) {
    this.bytes = e, this.pos = 0;
  }
  seekToByte(e) {
    this.pos = 8 * e;
  }
  readBit() {
    const e = Math.floor(this.pos / 8), t = this.bytes[e] ?? 0, i = 7 - (this.pos & 7), n = (t & 1 << i) >> i;
    return this.pos++, n;
  }
  readBits(e) {
    if (e === 1)
      return this.readBit();
    let t = 0;
    for (let i = 0; i < e; i++)
      t <<= 1, t |= this.readBit();
    return t;
  }
  writeBits(e, t) {
    const i = this.pos + e;
    for (let n = this.pos; n < i; n++) {
      const r = Math.floor(n / 8);
      let o = this.bytes[r];
      const a = 7 - (n & 7);
      o &= ~(1 << a), o |= (t & 1 << i - n - 1) >> i - n - 1 << a, this.bytes[r] = o;
    }
    this.pos = i;
  }
  readAlignedByte() {
    if (this.pos % 8 !== 0)
      throw new Error("Bitstream is not byte-aligned.");
    const e = this.pos / 8, t = this.bytes[e] ?? 0;
    return this.pos += 8, t;
  }
  skipBits(e) {
    this.pos += e;
  }
  getBitsLeft() {
    return this.bytes.length * 8 - this.pos;
  }
  clone() {
    const e = new Z(this.bytes);
    return e.pos = this.pos, e;
  }
}
/*!
 * Copyright (c) 2026-present, Vanilagy and contributors
 *
 * This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at https://mozilla.org/MPL/2.0/.
 */
const ys = [
  96e3,
  88200,
  64e3,
  48e3,
  44100,
  32e3,
  24e3,
  22050,
  16e3,
  12e3,
  11025,
  8e3,
  7350
], ws = [-1, 1, 2, 3, 4, 5, 6, 8], Cn = (s) => {
  let e = ys.indexOf(s.sampleRate), t = null;
  e === -1 && (e = 15, t = s.sampleRate);
  const i = ws.indexOf(s.numberOfChannels);
  if (i === -1)
    throw new TypeError(`Unsupported number of channels: ${s.numberOfChannels}`);
  let n = 13;
  s.objectType >= 32 && (n += 6), e === 15 && (n += 24);
  const r = Math.ceil(n / 8), o = new Uint8Array(r), a = new Z(o);
  return s.objectType < 32 ? a.writeBits(5, s.objectType) : (a.writeBits(5, 31), a.writeBits(6, s.objectType - 32)), a.writeBits(4, e), e === 15 && a.writeBits(24, t), a.writeBits(4, i), o;
};
/*!
 * Copyright (c) 2026-present, Vanilagy and contributors
 *
 * This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at https://mozilla.org/MPL/2.0/.
 */
const ge = [
  "avc",
  "hevc",
  "vp9",
  "av1",
  "vp8"
], me = [
  "pcm-s16",
  // We don't prefix 'le' so we're compatible with the WebCodecs-registered PCM codec strings
  "pcm-s16be",
  "pcm-s24",
  "pcm-s24be",
  "pcm-s32",
  "pcm-s32be",
  "pcm-f32",
  "pcm-f32be",
  "pcm-f64",
  "pcm-f64be",
  "pcm-u8",
  "pcm-s8",
  "ulaw",
  "alaw"
], pt = [
  "aac",
  "opus",
  "mp3",
  "vorbis",
  "flac",
  "ac3",
  "eac3"
], Te = [
  ...pt,
  ...me
], _e = [
  "webvtt"
], Ht = [
  { maxMacroblocks: 99, maxBitrate: 64e3, maxDpbMbs: 396, level: 10 },
  // Level 1
  { maxMacroblocks: 396, maxBitrate: 192e3, maxDpbMbs: 900, level: 11 },
  // Level 1.1
  { maxMacroblocks: 396, maxBitrate: 384e3, maxDpbMbs: 2376, level: 12 },
  // Level 1.2
  { maxMacroblocks: 396, maxBitrate: 768e3, maxDpbMbs: 2376, level: 13 },
  // Level 1.3
  { maxMacroblocks: 396, maxBitrate: 2e6, maxDpbMbs: 2376, level: 20 },
  // Level 2
  { maxMacroblocks: 792, maxBitrate: 4e6, maxDpbMbs: 4752, level: 21 },
  // Level 2.1
  { maxMacroblocks: 1620, maxBitrate: 4e6, maxDpbMbs: 8100, level: 22 },
  // Level 2.2
  { maxMacroblocks: 1620, maxBitrate: 1e7, maxDpbMbs: 8100, level: 30 },
  // Level 3
  { maxMacroblocks: 3600, maxBitrate: 14e6, maxDpbMbs: 18e3, level: 31 },
  // Level 3.1
  { maxMacroblocks: 5120, maxBitrate: 2e7, maxDpbMbs: 20480, level: 32 },
  // Level 3.2
  { maxMacroblocks: 8192, maxBitrate: 2e7, maxDpbMbs: 32768, level: 40 },
  // Level 4
  { maxMacroblocks: 8192, maxBitrate: 5e7, maxDpbMbs: 32768, level: 41 },
  // Level 4.1
  { maxMacroblocks: 8704, maxBitrate: 5e7, maxDpbMbs: 34816, level: 42 },
  // Level 4.2
  { maxMacroblocks: 22080, maxBitrate: 135e6, maxDpbMbs: 110400, level: 50 },
  // Level 5
  { maxMacroblocks: 36864, maxBitrate: 24e7, maxDpbMbs: 184320, level: 51 },
  // Level 5.1
  { maxMacroblocks: 36864, maxBitrate: 24e7, maxDpbMbs: 184320, level: 52 },
  // Level 5.2
  { maxMacroblocks: 139264, maxBitrate: 24e7, maxDpbMbs: 696320, level: 60 },
  // Level 6
  { maxMacroblocks: 139264, maxBitrate: 48e7, maxDpbMbs: 696320, level: 61 },
  // Level 6.1
  { maxMacroblocks: 139264, maxBitrate: 8e8, maxDpbMbs: 696320, level: 62 }
  // Level 6.2
], Sn = (s) => {
  const e = s.split("."), n = (1 << 7) + 1, r = Number(e[1]), o = e[2], a = Number(o.slice(0, -1)), c = (r << 5) + a, u = o.slice(-1) === "H" ? 1 : 0, d = Number(e[3]) === 8 ? 0 : 1, m = 0, g = e[4] ? Number(e[4]) : 0, E = e[5] ? Number(e[5][0]) : 1, v = e[5] ? Number(e[5][1]) : 1, _ = e[5] ? Number(e[5][2]) : 0, R = (u << 7) + (d << 6) + (m << 5) + (g << 4) + (E << 3) + (v << 2) + _;
  return [n, c, R, 0];
}, Rn = /^pcm-([usf])(\d+)+(be)?$/, Fe = (s) => {
  if (P(me.includes(s)), s === "ulaw")
    return { dataType: "ulaw", sampleSize: 1, littleEndian: !0, silentValue: 255 };
  if (s === "alaw")
    return { dataType: "alaw", sampleSize: 1, littleEndian: !0, silentValue: 213 };
  const e = Rn.exec(s);
  P(e);
  let t;
  e[1] === "u" ? t = "unsigned" : e[1] === "s" ? t = "signed" : t = "float";
  const i = Number(e[2]) / 8, n = e[3] !== "be", r = s === "pcm-u8" ? 2 ** 7 : 0;
  return { dataType: t, sampleSize: i, littleEndian: n, silentValue: r };
}, kn = ["avc1", "avc3", "hev1", "hvc1", "vp8", "vp09", "av01"], An = /^(avc1|avc3)\.[0-9a-fA-F]{6}$/, Fn = /^(hev1|hvc1)\.(?:[ABC]?\d+)\.[0-9a-fA-F]{1,8}\.[LH]\d+(?:\.[0-9a-fA-F]{1,2}){0,6}$/, Bn = /^vp09(?:\.\d{2}){3}(?:(?:\.\d{2}){5})?$/, Pn = /^av01\.\d\.\d{2}[MH]\.\d{2}(?:\.\d\.\d{3}\.\d{2}\.\d{2}\.\d{2}\.\d)?$/, Mn = (s) => {
  if (!s)
    throw new TypeError("Video chunk metadata must be provided.");
  if (typeof s != "object")
    throw new TypeError("Video chunk metadata must be an object.");
  if (!s.decoderConfig)
    throw new TypeError("Video chunk metadata must include a decoder configuration.");
  if (typeof s.decoderConfig != "object")
    throw new TypeError("Video chunk metadata decoder configuration must be an object.");
  if (typeof s.decoderConfig.codec != "string")
    throw new TypeError("Video chunk metadata decoder configuration must specify a codec string.");
  if (!kn.some((e) => s.decoderConfig.codec.startsWith(e)))
    throw new TypeError("Video chunk metadata decoder configuration codec string must be a valid video codec string as specified in the Mediabunny Codec Registry.");
  if (!Number.isInteger(s.decoderConfig.codedWidth) || s.decoderConfig.codedWidth <= 0)
    throw new TypeError("Video chunk metadata decoder configuration must specify a valid codedWidth (positive integer).");
  if (!Number.isInteger(s.decoderConfig.codedHeight) || s.decoderConfig.codedHeight <= 0)
    throw new TypeError("Video chunk metadata decoder configuration must specify a valid codedHeight (positive integer).");
  if (s.decoderConfig.description !== void 0 && !ms(s.decoderConfig.description))
    throw new TypeError("Video chunk metadata decoder configuration description, when defined, must be an ArrayBuffer or an ArrayBuffer view.");
  if (s.decoderConfig.colorSpace !== void 0) {
    const { colorSpace: e } = s.decoderConfig;
    if (typeof e != "object")
      throw new TypeError("Video chunk metadata decoder configuration colorSpace, when provided, must be an object.");
    const t = Object.keys(ut);
    if (e.primaries != null && !t.includes(e.primaries))
      throw new TypeError(`Video chunk metadata decoder configuration colorSpace primaries, when defined, must be one of ${t.join(", ")}.`);
    const i = Object.keys(dt);
    if (e.transfer != null && !i.includes(e.transfer))
      throw new TypeError(`Video chunk metadata decoder configuration colorSpace transfer, when defined, must be one of ${i.join(", ")}.`);
    const n = Object.keys(ht);
    if (e.matrix != null && !n.includes(e.matrix))
      throw new TypeError(`Video chunk metadata decoder configuration colorSpace matrix, when defined, must be one of ${n.join(", ")}.`);
    if (e.fullRange != null && typeof e.fullRange != "boolean")
      throw new TypeError("Video chunk metadata decoder configuration colorSpace fullRange, when defined, must be a boolean.");
  }
  if (s.decoderConfig.codec.startsWith("avc1") || s.decoderConfig.codec.startsWith("avc3")) {
    if (!An.test(s.decoderConfig.codec))
      throw new TypeError("Video chunk metadata decoder configuration codec string for AVC must be a valid AVC codec string as specified in Section 3.4 of RFC 6381.");
  } else if (s.decoderConfig.codec.startsWith("hev1") || s.decoderConfig.codec.startsWith("hvc1")) {
    if (!Fn.test(s.decoderConfig.codec))
      throw new TypeError("Video chunk metadata decoder configuration codec string for HEVC must be a valid HEVC codec string as specified in Section E.3 of ISO 14496-15.");
  } else if (s.decoderConfig.codec.startsWith("vp8")) {
    if (s.decoderConfig.codec !== "vp8")
      throw new TypeError('Video chunk metadata decoder configuration codec string for VP8 must be "vp8".');
  } else if (s.decoderConfig.codec.startsWith("vp09")) {
    if (!Bn.test(s.decoderConfig.codec))
      throw new TypeError('Video chunk metadata decoder configuration codec string for VP9 must be a valid VP9 codec string as specified in Section "Codecs Parameter String" of https://www.webmproject.org/vp9/mp4/.');
  } else if (s.decoderConfig.codec.startsWith("av01") && !Pn.test(s.decoderConfig.codec))
    throw new TypeError('Video chunk metadata decoder configuration codec string for AV1 must be a valid AV1 codec string as specified in Section "Codecs Parameter String" of https://aomediacodec.github.io/av1-isobmff/.');
}, Ln = [
  "mp4a",
  "mp3",
  "opus",
  "vorbis",
  "flac",
  "ulaw",
  "alaw",
  "pcm",
  "ac-3",
  "ec-3"
], In = (s) => {
  if (!s)
    throw new TypeError("Audio chunk metadata must be provided.");
  if (typeof s != "object")
    throw new TypeError("Audio chunk metadata must be an object.");
  if (!s.decoderConfig)
    throw new TypeError("Audio chunk metadata must include a decoder configuration.");
  if (typeof s.decoderConfig != "object")
    throw new TypeError("Audio chunk metadata decoder configuration must be an object.");
  if (typeof s.decoderConfig.codec != "string")
    throw new TypeError("Audio chunk metadata decoder configuration must specify a codec string.");
  if (!Ln.some((e) => s.decoderConfig.codec.startsWith(e)))
    throw new TypeError("Audio chunk metadata decoder configuration codec string must be a valid audio codec string as specified in the Mediabunny Codec Registry.");
  if (!Number.isInteger(s.decoderConfig.sampleRate) || s.decoderConfig.sampleRate <= 0)
    throw new TypeError("Audio chunk metadata decoder configuration must specify a valid sampleRate (positive integer).");
  if (!Number.isInteger(s.decoderConfig.numberOfChannels) || s.decoderConfig.numberOfChannels <= 0)
    throw new TypeError("Audio chunk metadata decoder configuration must specify a valid numberOfChannels (positive integer).");
  if (s.decoderConfig.description !== void 0 && !ms(s.decoderConfig.description))
    throw new TypeError("Audio chunk metadata decoder configuration description, when defined, must be an ArrayBuffer or an ArrayBuffer view.");
  if (s.decoderConfig.codec.startsWith("mp4a") && s.decoderConfig.codec !== "mp4a.69" && s.decoderConfig.codec !== "mp4a.6B" && s.decoderConfig.codec !== "mp4a.6b") {
    if (!["mp4a.40.2", "mp4a.40.02", "mp4a.40.5", "mp4a.40.05", "mp4a.40.29", "mp4a.67"].includes(s.decoderConfig.codec))
      throw new TypeError("Audio chunk metadata decoder configuration codec string for AAC must be a valid AAC codec string as specified in https://www.w3.org/TR/webcodecs-aac-codec-registration/.");
  } else if (s.decoderConfig.codec.startsWith("mp3") || s.decoderConfig.codec.startsWith("mp4a")) {
    if (s.decoderConfig.codec !== "mp3" && s.decoderConfig.codec !== "mp4a.69" && s.decoderConfig.codec !== "mp4a.6B" && s.decoderConfig.codec !== "mp4a.6b")
      throw new TypeError('Audio chunk metadata decoder configuration codec string for MP3 must be "mp3", "mp4a.69" or "mp4a.6B".');
  } else if (s.decoderConfig.codec.startsWith("opus")) {
    if (s.decoderConfig.codec !== "opus")
      throw new TypeError('Audio chunk metadata decoder configuration codec string for Opus must be "opus".');
    if (s.decoderConfig.description && s.decoderConfig.description.byteLength < 18)
      throw new TypeError("Audio chunk metadata decoder configuration description, when specified, is expected to be an Identification Header as specified in Section 5.1 of RFC 7845.");
  } else if (s.decoderConfig.codec.startsWith("vorbis")) {
    if (s.decoderConfig.codec !== "vorbis")
      throw new TypeError('Audio chunk metadata decoder configuration codec string for Vorbis must be "vorbis".');
    if (!s.decoderConfig.description)
      throw new TypeError("Audio chunk metadata decoder configuration for Vorbis must include a description, which is expected to adhere to the format described in https://www.w3.org/TR/webcodecs-vorbis-codec-registration/.");
  } else if (s.decoderConfig.codec.startsWith("flac")) {
    if (s.decoderConfig.codec !== "flac")
      throw new TypeError('Audio chunk metadata decoder configuration codec string for FLAC must be "flac".');
    if (!s.decoderConfig.description || s.decoderConfig.description.byteLength < 42)
      throw new TypeError("Audio chunk metadata decoder configuration for FLAC must include a description, which is expected to adhere to the format described in https://www.w3.org/TR/webcodecs-flac-codec-registration/.");
  } else if (s.decoderConfig.codec.startsWith("ac-3") || s.decoderConfig.codec.startsWith("ac3")) {
    if (s.decoderConfig.codec !== "ac-3")
      throw new TypeError('Audio chunk metadata decoder configuration codec string for AC-3 must be "ac-3".');
  } else if (s.decoderConfig.codec.startsWith("ec-3") || s.decoderConfig.codec.startsWith("eac3")) {
    if (s.decoderConfig.codec !== "ec-3")
      throw new TypeError('Audio chunk metadata decoder configuration codec string for EC-3 must be "ec-3".');
  } else if ((s.decoderConfig.codec.startsWith("pcm") || s.decoderConfig.codec.startsWith("ulaw") || s.decoderConfig.codec.startsWith("alaw")) && !me.includes(s.decoderConfig.codec))
    throw new TypeError(`Audio chunk metadata decoder configuration codec string for PCM must be one of the supported PCM codecs (${me.join(", ")}).`);
}, Un = (s) => {
  if (!s)
    throw new TypeError("Subtitle metadata must be provided.");
  if (typeof s != "object")
    throw new TypeError("Subtitle metadata must be an object.");
  if (!s.config)
    throw new TypeError("Subtitle metadata must include a config object.");
  if (typeof s.config != "object")
    throw new TypeError("Subtitle metadata config must be an object.");
  if (typeof s.config.description != "string")
    throw new TypeError("Subtitle metadata config description must be a string.");
};
/*!
 * Copyright (c) 2026-present, Vanilagy and contributors
 *
 * This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at https://mozilla.org/MPL/2.0/.
 */
const Nn = [48e3, 44100, 32e3], On = [24e3, 22050, 16e3];
/*!
 * Copyright (c) 2026-present, Vanilagy and contributors
 *
 * This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at https://mozilla.org/MPL/2.0/.
 */
var Ee;
(function(s) {
  s[s.NON_IDR_SLICE = 1] = "NON_IDR_SLICE", s[s.SLICE_DPA = 2] = "SLICE_DPA", s[s.SLICE_DPB = 3] = "SLICE_DPB", s[s.SLICE_DPC = 4] = "SLICE_DPC", s[s.IDR = 5] = "IDR", s[s.SEI = 6] = "SEI", s[s.SPS = 7] = "SPS", s[s.PPS = 8] = "PPS", s[s.AUD = 9] = "AUD", s[s.SPS_EXT = 13] = "SPS_EXT";
})(Ee || (Ee = {}));
var te;
(function(s) {
  s[s.RASL_N = 8] = "RASL_N", s[s.RASL_R = 9] = "RASL_R", s[s.BLA_W_LP = 16] = "BLA_W_LP", s[s.RSV_IRAP_VCL23 = 23] = "RSV_IRAP_VCL23", s[s.VPS_NUT = 32] = "VPS_NUT", s[s.SPS_NUT = 33] = "SPS_NUT", s[s.PPS_NUT = 34] = "PPS_NUT", s[s.AUD_NUT = 35] = "AUD_NUT", s[s.PREFIX_SEI_NUT = 39] = "PREFIX_SEI_NUT", s[s.SUFFIX_SEI_NUT = 40] = "SUFFIX_SEI_NUT";
})(te || (te = {}));
const ft = function* (s) {
  let e = 0, t = -1;
  for (; e < s.length - 2; ) {
    const i = s.indexOf(0, e);
    if (i === -1 || i >= s.length - 2)
      break;
    e = i;
    let n = 0;
    if (e + 3 < s.length && s[e + 1] === 0 && s[e + 2] === 0 && s[e + 3] === 1 ? n = 4 : s[e + 1] === 0 && s[e + 2] === 1 && (n = 3), n === 0) {
      e++;
      continue;
    }
    t !== -1 && e > t && (yield {
      offset: t,
      length: e - t
    }), t = e + n, e = t;
  }
  t !== -1 && t < s.length && (yield {
    offset: t,
    length: s.length - t
  });
}, Dn = (s) => s & 31, gt = (s) => {
  const e = [], t = s.length;
  for (let i = 0; i < t; i++)
    i + 2 < t && s[i] === 0 && s[i + 1] === 0 && s[i + 2] === 3 ? (e.push(0, 0), i += 2) : e.push(s[i]);
  return new Uint8Array(e);
}, $n = (s, e) => {
  const t = s.reduce((r, o) => r + e + o.byteLength, 0), i = new Uint8Array(t);
  let n = 0;
  for (const r of s) {
    const o = new DataView(i.buffer, i.byteOffset, i.byteLength);
    switch (e) {
      case 1:
        o.setUint8(n, r.byteLength);
        break;
      case 2:
        o.setUint16(n, r.byteLength, !1);
        break;
      case 3:
        bn(o, n, r.byteLength);
        break;
      case 4:
        o.setUint32(n, r.byteLength, !1);
        break;
    }
    n += e, i.set(r, n), n += r.byteLength;
  }
  return i;
}, Vn = (s) => {
  try {
    const e = [], t = [], i = [];
    for (const a of ft(s)) {
      const c = s.subarray(a.offset, a.offset + a.length), u = Dn(c[0]);
      u === Ee.SPS ? e.push(c) : u === Ee.PPS ? t.push(c) : u === Ee.SPS_EXT && i.push(c);
    }
    if (e.length === 0 || t.length === 0)
      return null;
    const n = e[0], r = jn(n);
    P(r !== null);
    const o = r.profileIdc === 100 || r.profileIdc === 110 || r.profileIdc === 122 || r.profileIdc === 144;
    return {
      configurationVersion: 1,
      avcProfileIndication: r.profileIdc,
      profileCompatibility: r.constraintFlags,
      avcLevelIndication: r.levelIdc,
      lengthSizeMinusOne: 3,
      // Typically 4 bytes for length field
      sequenceParameterSets: e,
      pictureParameterSets: t,
      chromaFormat: o ? r.chromaFormatIdc : null,
      bitDepthLumaMinus8: o ? r.bitDepthLumaMinus8 : null,
      bitDepthChromaMinus8: o ? r.bitDepthChromaMinus8 : null,
      sequenceParameterSetExt: o ? i : null
    };
  } catch (e) {
    return console.error("Error building AVC Decoder Configuration Record:", e), null;
  }
}, zn = (s) => {
  const e = [];
  e.push(s.configurationVersion), e.push(s.avcProfileIndication), e.push(s.profileCompatibility), e.push(s.avcLevelIndication), e.push(252 | s.lengthSizeMinusOne & 3), e.push(224 | s.sequenceParameterSets.length & 31);
  for (const t of s.sequenceParameterSets) {
    const i = t.byteLength;
    e.push(i >> 8), e.push(i & 255);
    for (let n = 0; n < i; n++)
      e.push(t[n]);
  }
  e.push(s.pictureParameterSets.length);
  for (const t of s.pictureParameterSets) {
    const i = t.byteLength;
    e.push(i >> 8), e.push(i & 255);
    for (let n = 0; n < i; n++)
      e.push(t[n]);
  }
  if (s.avcProfileIndication === 100 || s.avcProfileIndication === 110 || s.avcProfileIndication === 122 || s.avcProfileIndication === 144) {
    P(s.chromaFormat !== null), P(s.bitDepthLumaMinus8 !== null), P(s.bitDepthChromaMinus8 !== null), P(s.sequenceParameterSetExt !== null), e.push(252 | s.chromaFormat & 3), e.push(248 | s.bitDepthLumaMinus8 & 7), e.push(248 | s.bitDepthChromaMinus8 & 7), e.push(s.sequenceParameterSetExt.length);
    for (const t of s.sequenceParameterSetExt) {
      const i = t.byteLength;
      e.push(i >> 8), e.push(i & 255);
      for (let n = 0; n < i; n++)
        e.push(t[n]);
    }
  }
  return new Uint8Array(e);
}, Es = {
  1: { num: 1, den: 1 },
  2: { num: 12, den: 11 },
  3: { num: 10, den: 11 },
  4: { num: 16, den: 11 },
  5: { num: 40, den: 33 },
  6: { num: 24, den: 11 },
  7: { num: 20, den: 11 },
  8: { num: 32, den: 11 },
  9: { num: 80, den: 33 },
  10: { num: 18, den: 11 },
  11: { num: 15, den: 11 },
  12: { num: 64, den: 33 },
  13: { num: 160, den: 99 },
  14: { num: 4, den: 3 },
  15: { num: 3, den: 2 },
  16: { num: 2, den: 1 }
}, jn = (s) => {
  try {
    const e = new Z(gt(s));
    if (e.skipBits(1), e.skipBits(2), e.readBits(5) !== 7)
      return null;
    const i = e.readAlignedByte(), n = e.readAlignedByte(), r = e.readAlignedByte();
    S(e);
    let o = 1, a = 0, c = 0, u = 0;
    if ((i === 100 || i === 110 || i === 122 || i === 244 || i === 44 || i === 83 || i === 86 || i === 118 || i === 128) && (o = S(e), o === 3 && (u = e.readBits(1)), a = S(e), c = S(e), e.skipBits(1), e.readBits(1))) {
      for (let k = 0; k < (o !== 3 ? 8 : 12); k++)
        if (e.readBits(1)) {
          const H = k < 6 ? 16 : 64;
          let N = 8, D = 8;
          for (let $ = 0; $ < H; $++) {
            if (D !== 0) {
              const O = oe(e);
              D = (N + O + 256) % 256;
            }
            N = D === 0 ? N : D;
          }
        }
    }
    S(e);
    const l = S(e);
    if (l === 0)
      S(e);
    else if (l === 1) {
      e.skipBits(1), oe(e), oe(e);
      const L = S(e);
      for (let k = 0; k < L; k++)
        oe(e);
    }
    S(e), e.skipBits(1);
    const d = S(e), m = S(e), g = 16 * (d + 1), E = 16 * (m + 1);
    let v = g, _ = E;
    const R = e.readBits(1);
    if (R || e.skipBits(1), e.skipBits(1), e.readBits(1)) {
      const L = S(e), k = S(e), V = S(e), H = S(e);
      let N, D;
      if ((u === 0 ? o : 0) === 0)
        N = 1, D = 2 - R;
      else {
        const O = o === 3 ? 1 : 2, W = o === 1 ? 2 : 1;
        N = O, D = W * (2 - R);
      }
      v -= N * (L + k), _ -= D * (V + H);
    }
    let f = 2, b = 2, y = 2, T = 0, C = { num: 1, den: 1 }, A = null, w = null;
    if (e.readBits(1)) {
      if (e.readBits(1)) {
        const W = e.readBits(8);
        if (W === 255)
          C = {
            num: e.readBits(16),
            den: e.readBits(16)
          };
        else {
          const ne = Es[W];
          ne && (C = ne);
        }
      }
      e.readBits(1) && e.skipBits(1), e.readBits(1) && (e.skipBits(3), T = e.readBits(1), e.readBits(1) && (f = e.readBits(8), b = e.readBits(8), y = e.readBits(8))), e.readBits(1) && (S(e), S(e)), e.readBits(1) && (e.skipBits(32), e.skipBits(32), e.skipBits(1));
      const D = e.readBits(1);
      D && Wt(e);
      const $ = e.readBits(1);
      $ && Wt(e), (D || $) && e.skipBits(1), e.skipBits(1), e.readBits(1) && (e.skipBits(1), S(e), S(e), S(e), S(e), A = S(e), w = S(e));
    }
    if (A === null) {
      P(w === null);
      const L = n & 16;
      if ((i === 44 || i === 86 || i === 100 || i === 110 || i === 122 || i === 244) && L)
        A = 0, w = 0;
      else {
        const k = d + 1, V = m + 1, H = (2 - R) * V, N = Ht.find(($) => $.level >= r) ?? he(Ht), D = Math.min(Math.floor(N.maxDpbMbs / (k * H)), 16);
        A = D, w = D;
      }
    }
    return P(w !== null), {
      profileIdc: i,
      constraintFlags: n,
      levelIdc: r,
      frameMbsOnlyFlag: R,
      chromaFormatIdc: o,
      bitDepthLumaMinus8: a,
      bitDepthChromaMinus8: c,
      codedWidth: g,
      codedHeight: E,
      displayWidth: v,
      displayHeight: _,
      pixelAspectRatio: C,
      colourPrimaries: f,
      matrixCoefficients: y,
      transferCharacteristics: b,
      fullRangeFlag: T,
      numReorderFrames: A,
      maxDecFrameBuffering: w
    };
  } catch (e) {
    return console.error("Error parsing AVC SPS:", e), null;
  }
}, Wt = (s) => {
  const e = S(s);
  s.skipBits(4), s.skipBits(4);
  for (let t = 0; t <= e; t++)
    S(s), S(s), s.skipBits(1);
  s.skipBits(5), s.skipBits(5), s.skipBits(5), s.skipBits(5);
}, Xt = (s) => s >> 1 & 63, Hn = (s) => {
  try {
    const e = new Z(gt(s));
    e.skipBits(16), e.readBits(4);
    const t = e.readBits(3), i = e.readBits(1), { general_profile_space: n, general_tier_flag: r, general_profile_idc: o, general_profile_compatibility_flags: a, general_constraint_indicator_flags: c, general_level_idc: u } = Xn(e, t);
    S(e);
    const l = S(e);
    let d = 0;
    l === 3 && (d = e.readBits(1));
    const m = S(e), g = S(e);
    let E = m, v = g;
    if (e.readBits(1)) {
      const k = S(e), V = S(e), H = S(e), N = S(e);
      let D = 1, $ = 1;
      const O = d === 0 ? l : 0;
      O === 1 ? (D = 2, $ = 2) : O === 2 && (D = 2, $ = 1), E -= (k + V) * D, v -= (H + N) * $;
    }
    const _ = S(e), R = S(e);
    S(e);
    const f = e.readBits(1) ? 0 : t;
    let b = 0;
    for (let k = f; k <= t; k++)
      S(e), b = S(e), S(e);
    S(e), S(e), S(e), S(e), S(e), S(e), e.readBits(1) && e.readBits(1) && Gn(e), e.skipBits(1), e.skipBits(1), e.readBits(1) && (e.skipBits(4), e.skipBits(4), S(e), S(e), e.skipBits(1));
    const y = S(e);
    if (Kn(e, y), e.readBits(1)) {
      const k = S(e);
      for (let V = 0; V < k; V++)
        S(e), e.skipBits(1);
    }
    e.skipBits(1), e.skipBits(1);
    let T = 2, C = 2, A = 2, w = 0, F = 0, L = { num: 1, den: 1 };
    if (e.readBits(1)) {
      const k = qn(e, t);
      L = k.pixelAspectRatio, T = k.colourPrimaries, C = k.transferCharacteristics, A = k.matrixCoefficients, w = k.fullRangeFlag, F = k.minSpatialSegmentationIdc;
    }
    return {
      displayWidth: E,
      displayHeight: v,
      pixelAspectRatio: L,
      colourPrimaries: T,
      transferCharacteristics: C,
      matrixCoefficients: A,
      fullRangeFlag: w,
      maxDecFrameBuffering: b + 1,
      spsMaxSubLayersMinus1: t,
      spsTemporalIdNestingFlag: i,
      generalProfileSpace: n,
      generalTierFlag: r,
      generalProfileIdc: o,
      generalProfileCompatibilityFlags: a,
      generalConstraintIndicatorFlags: c,
      generalLevelIdc: u,
      chromaFormatIdc: l,
      bitDepthLumaMinus8: _,
      bitDepthChromaMinus8: R,
      minSpatialSegmentationIdc: F
    };
  } catch (e) {
    return console.error("Error parsing HEVC SPS:", e), null;
  }
}, Wn = (s) => {
  try {
    const e = [], t = [], i = [], n = [];
    for (const u of ft(s)) {
      const l = s.subarray(u.offset, u.offset + u.length), d = Xt(l[0]);
      d === te.VPS_NUT ? e.push(l) : d === te.SPS_NUT ? t.push(l) : d === te.PPS_NUT ? i.push(l) : (d === te.PREFIX_SEI_NUT || d === te.SUFFIX_SEI_NUT) && n.push(l);
    }
    if (t.length === 0 || i.length === 0)
      return null;
    const r = Hn(t[0]);
    if (!r)
      return null;
    let o = 0;
    if (i.length > 0) {
      const u = i[0], l = new Z(gt(u));
      l.skipBits(16), S(l), S(l), l.skipBits(1), l.skipBits(1), l.skipBits(3), l.skipBits(1), l.skipBits(1), S(l), S(l), oe(l), l.skipBits(1), l.skipBits(1), l.readBits(1) && S(l), oe(l), oe(l), l.skipBits(1), l.skipBits(1), l.skipBits(1), l.skipBits(1);
      const d = l.readBits(1), m = l.readBits(1);
      !d && !m ? o = 0 : d && !m ? o = 2 : !d && m ? o = 3 : o = 0;
    }
    const a = [
      ...e.length ? [
        {
          arrayCompleteness: 1,
          nalUnitType: te.VPS_NUT,
          nalUnits: e
        }
      ] : [],
      ...t.length ? [
        {
          arrayCompleteness: 1,
          nalUnitType: te.SPS_NUT,
          nalUnits: t
        }
      ] : [],
      ...i.length ? [
        {
          arrayCompleteness: 1,
          nalUnitType: te.PPS_NUT,
          nalUnits: i
        }
      ] : [],
      ...n.length ? [
        {
          arrayCompleteness: 1,
          nalUnitType: Xt(n[0][0]),
          nalUnits: n
        }
      ] : []
    ];
    return {
      configurationVersion: 1,
      generalProfileSpace: r.generalProfileSpace,
      generalTierFlag: r.generalTierFlag,
      generalProfileIdc: r.generalProfileIdc,
      generalProfileCompatibilityFlags: r.generalProfileCompatibilityFlags,
      generalConstraintIndicatorFlags: r.generalConstraintIndicatorFlags,
      generalLevelIdc: r.generalLevelIdc,
      minSpatialSegmentationIdc: r.minSpatialSegmentationIdc,
      parallelismType: o,
      chromaFormatIdc: r.chromaFormatIdc,
      bitDepthLumaMinus8: r.bitDepthLumaMinus8,
      bitDepthChromaMinus8: r.bitDepthChromaMinus8,
      avgFrameRate: 0,
      constantFrameRate: 0,
      numTemporalLayers: r.spsMaxSubLayersMinus1 + 1,
      temporalIdNested: r.spsTemporalIdNestingFlag,
      lengthSizeMinusOne: 3,
      arrays: a
    };
  } catch (e) {
    return console.error("Error building HEVC Decoder Configuration Record:", e), null;
  }
}, Xn = (s, e) => {
  const t = s.readBits(2), i = s.readBits(1), n = s.readBits(5);
  let r = 0;
  for (let l = 0; l < 32; l++)
    r = r << 1 | s.readBits(1);
  const o = new Uint8Array(6);
  for (let l = 0; l < 6; l++)
    o[l] = s.readBits(8);
  const a = s.readBits(8), c = [], u = [];
  for (let l = 0; l < e; l++)
    c.push(s.readBits(1)), u.push(s.readBits(1));
  if (e > 0)
    for (let l = e; l < 8; l++)
      s.skipBits(2);
  for (let l = 0; l < e; l++)
    c[l] && s.skipBits(88), u[l] && s.skipBits(8);
  return {
    general_profile_space: t,
    general_tier_flag: i,
    general_profile_idc: n,
    general_profile_compatibility_flags: r,
    general_constraint_indicator_flags: o,
    general_level_idc: a
  };
}, Gn = (s) => {
  for (let e = 0; e < 4; e++)
    for (let t = 0; t < (e === 3 ? 2 : 6); t++)
      if (!s.readBits(1))
        S(s);
      else {
        const n = Math.min(64, 1 << 4 + (e << 1));
        e > 1 && oe(s);
        for (let r = 0; r < n; r++)
          oe(s);
      }
}, Kn = (s, e) => {
  const t = [];
  for (let i = 0; i < e; i++)
    t[i] = Yn(s, i, e, t);
}, Yn = (s, e, t, i) => {
  let n = 0, r = 0, o = 0;
  if (e !== 0 && (r = s.readBits(1)), r) {
    if (e === t) {
      const c = S(s);
      o = e - (c + 1);
    } else
      o = e - 1;
    s.readBits(1), S(s);
    const a = i[o] ?? 0;
    for (let c = 0; c <= a; c++)
      s.readBits(1) || s.readBits(1);
    n = i[o];
  } else {
    const a = S(s), c = S(s);
    for (let u = 0; u < a; u++)
      S(s), s.readBits(1);
    for (let u = 0; u < c; u++)
      S(s), s.readBits(1);
    n = a + c;
  }
  return n;
}, qn = (s, e) => {
  let t = 2, i = 2, n = 2, r = 0, o = 0, a = { num: 1, den: 1 };
  if (s.readBits(1)) {
    const c = s.readBits(8);
    if (c === 255)
      a = {
        num: s.readBits(16),
        den: s.readBits(16)
      };
    else {
      const u = Es[c];
      u && (a = u);
    }
  }
  return s.readBits(1) && s.readBits(1), s.readBits(1) && (s.readBits(3), r = s.readBits(1), s.readBits(1) && (t = s.readBits(8), i = s.readBits(8), n = s.readBits(8))), s.readBits(1) && (S(s), S(s)), s.readBits(1), s.readBits(1), s.readBits(1), s.readBits(1) && (S(s), S(s), S(s), S(s)), s.readBits(1) && (s.readBits(32), s.readBits(32), s.readBits(1) && S(s), s.readBits(1) && Qn(s, !0, e)), s.readBits(1) && (s.readBits(1), s.readBits(1), s.readBits(1), o = S(s), S(s), S(s), S(s), S(s)), {
    pixelAspectRatio: a,
    colourPrimaries: t,
    transferCharacteristics: i,
    matrixCoefficients: n,
    fullRangeFlag: r,
    minSpatialSegmentationIdc: o
  };
}, Qn = (s, e, t) => {
  let i = !1, n = !1, r = !1;
  i = s.readBits(1) === 1, n = s.readBits(1) === 1, (i || n) && (r = s.readBits(1) === 1, r && (s.readBits(8), s.readBits(5), s.readBits(1), s.readBits(5)), s.readBits(4), s.readBits(4), r && s.readBits(4), s.readBits(5), s.readBits(5), s.readBits(5));
  for (let o = 0; o <= t; o++) {
    const a = s.readBits(1) === 1;
    let c = !0;
    a || (c = s.readBits(1) === 1);
    let u = !1;
    c ? S(s) : u = s.readBits(1) === 1;
    let l = 1;
    u || (l = S(s) + 1), i && Gt(s, l, r), n && Gt(s, l, r);
  }
}, Gt = (s, e, t) => {
  for (let i = 0; i < e; i++)
    S(s), S(s), t && (S(s), S(s)), s.readBits(1);
}, Zn = (s) => {
  const e = [];
  e.push(s.configurationVersion), e.push((s.generalProfileSpace & 3) << 6 | (s.generalTierFlag & 1) << 5 | s.generalProfileIdc & 31), e.push(s.generalProfileCompatibilityFlags >>> 24 & 255), e.push(s.generalProfileCompatibilityFlags >>> 16 & 255), e.push(s.generalProfileCompatibilityFlags >>> 8 & 255), e.push(s.generalProfileCompatibilityFlags & 255), e.push(...s.generalConstraintIndicatorFlags), e.push(s.generalLevelIdc & 255), e.push(240 | s.minSpatialSegmentationIdc >> 8 & 15), e.push(s.minSpatialSegmentationIdc & 255), e.push(252 | s.parallelismType & 3), e.push(252 | s.chromaFormatIdc & 3), e.push(248 | s.bitDepthLumaMinus8 & 7), e.push(248 | s.bitDepthChromaMinus8 & 7), e.push(s.avgFrameRate >> 8 & 255), e.push(s.avgFrameRate & 255), e.push((s.constantFrameRate & 3) << 6 | (s.numTemporalLayers & 7) << 3 | (s.temporalIdNested & 1) << 2 | s.lengthSizeMinusOne & 3), e.push(s.arrays.length & 255);
  for (const t of s.arrays) {
    e.push((t.arrayCompleteness & 1) << 7 | 0 | t.nalUnitType & 63), e.push(t.nalUnits.length >> 8 & 255), e.push(t.nalUnits.length & 255);
    for (const i of t.nalUnits) {
      e.push(i.length >> 8 & 255), e.push(i.length & 255);
      for (let n = 0; n < i.length; n++)
        e.push(i[n]);
    }
  }
  return new Uint8Array(e);
}, Jn = (s) => {
  const e = hs(s), t = e.getUint8(9), i = e.getUint16(10, !0), n = e.getUint32(12, !0), r = e.getInt16(16, !0), o = e.getUint8(18);
  let a = null;
  return o && (a = s.subarray(19, 21 + t)), {
    outputChannelCount: t,
    preSkip: i,
    inputSampleRate: n,
    outputGain: r,
    channelMappingFamily: o,
    channelMappingTable: a
  };
};
var Kt;
(function(s) {
  s[s.STREAMINFO = 0] = "STREAMINFO", s[s.VORBIS_COMMENT = 4] = "VORBIS_COMMENT", s[s.PICTURE = 6] = "PICTURE";
})(Kt || (Kt = {}));
const er = (s) => {
  if (s.length < 7 || s[0] !== 11 || s[1] !== 119)
    return null;
  const e = new Z(s);
  e.skipBits(16), e.skipBits(16);
  const t = e.readBits(2);
  if (t === 3)
    return null;
  const i = e.readBits(6), n = e.readBits(5);
  if (n > 8)
    return null;
  const r = e.readBits(3), o = e.readBits(3);
  o & 1 && o !== 1 && e.skipBits(2), o & 4 && e.skipBits(2), o === 2 && e.skipBits(2);
  const a = e.readBits(1), c = Math.floor(i / 2);
  return { fscod: t, bsid: n, bsmod: r, acmod: o, lfeon: a, bitRateCode: c };
}, tr = [1, 2, 3, 6], sr = (s) => {
  if (s.length < 6 || s[0] !== 11 || s[1] !== 119)
    return null;
  const e = new Z(s);
  e.skipBits(16);
  const t = e.readBits(2);
  if (e.skipBits(3), t !== 0 && t !== 2)
    return null;
  const i = e.readBits(11), n = e.readBits(2);
  let r = 0, o;
  n === 3 ? (r = e.readBits(2), o = 3) : o = e.readBits(2);
  const a = e.readBits(3), c = e.readBits(1), u = e.readBits(5);
  if (u < 11 || u > 16)
    return null;
  const l = tr[o];
  let d;
  return n < 3 ? d = Nn[n] / 1e3 : d = On[r] / 1e3, {
    dataRate: Math.round((i + 1) * d / (l * 16)),
    substreams: [{
      fscod: n,
      fscod2: r,
      bsid: u,
      bsmod: 0,
      acmod: a,
      lfeon: c,
      numDepSub: 0,
      chanLoc: 0
    }]
  };
};
/*!
 * Copyright (c) 2026-present, Vanilagy and contributors
 *
 * This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at https://mozilla.org/MPL/2.0/.
 */
const Yt = /* @__PURE__ */ new Uint8Array(0);
class xe {
  /** Creates a new {@link EncodedPacket} from raw bytes and timing information. */
  constructor(e, t, i, n, r = -1, o, a) {
    if (this.data = e, this.type = t, this.timestamp = i, this.duration = n, this.sequenceNumber = r, e === Yt && o === void 0)
      throw new Error("Internal error: byteLength must be explicitly provided when constructing metadata-only packets.");
    if (o === void 0 && (o = e.byteLength), !(e instanceof Uint8Array))
      throw new TypeError("data must be a Uint8Array.");
    if (t !== "key" && t !== "delta")
      throw new TypeError('type must be either "key" or "delta".');
    if (!Number.isFinite(i))
      throw new TypeError("timestamp must be a number.");
    if (!Number.isFinite(n) || n < 0)
      throw new TypeError("duration must be a non-negative number.");
    if (!Number.isFinite(r))
      throw new TypeError("sequenceNumber must be a number.");
    if (!Number.isInteger(o) || o < 0)
      throw new TypeError("byteLength must be a non-negative integer.");
    if (a !== void 0 && (typeof a != "object" || !a))
      throw new TypeError("sideData, when provided, must be an object.");
    if ((a == null ? void 0 : a.alpha) !== void 0 && !(a.alpha instanceof Uint8Array))
      throw new TypeError("sideData.alpha, when provided, must be a Uint8Array.");
    if ((a == null ? void 0 : a.alphaByteLength) !== void 0 && (!Number.isInteger(a.alphaByteLength) || a.alphaByteLength < 0))
      throw new TypeError("sideData.alphaByteLength, when provided, must be a non-negative integer.");
    this.byteLength = o, this.sideData = a ?? {}, this.sideData.alpha && this.sideData.alphaByteLength === void 0 && (this.sideData.alphaByteLength = this.sideData.alpha.byteLength);
  }
  /**
   * If this packet is a metadata-only packet. Metadata-only packets don't contain their packet data. They are the
   * result of retrieving packets with {@link PacketRetrievalOptions.metadataOnly} set to `true`.
   */
  get isMetadataOnly() {
    return this.data === Yt;
  }
  /** The timestamp of this packet in microseconds. */
  get microsecondTimestamp() {
    return Math.trunc(jt * this.timestamp);
  }
  /** The duration of this packet in microseconds. */
  get microsecondDuration() {
    return Math.trunc(jt * this.duration);
  }
  /** Converts this packet to an
   * [`EncodedVideoChunk`](https://developer.mozilla.org/en-US/docs/Web/API/EncodedVideoChunk) for use with the
   * WebCodecs API. */
  toEncodedVideoChunk() {
    if (this.isMetadataOnly)
      throw new TypeError("Metadata-only packets cannot be converted to a video chunk.");
    if (typeof EncodedVideoChunk > "u")
      throw new Error("Your browser does not support EncodedVideoChunk.");
    return new EncodedVideoChunk({
      data: this.data,
      type: this.type,
      timestamp: this.microsecondTimestamp,
      duration: this.microsecondDuration
    });
  }
  /**
   * Converts this packet to an
   * [`EncodedVideoChunk`](https://developer.mozilla.org/en-US/docs/Web/API/EncodedVideoChunk) for use with the
   * WebCodecs API, using the alpha side data instead of the color data. Throws if no alpha side data is defined.
   */
  alphaToEncodedVideoChunk(e = this.type) {
    if (!this.sideData.alpha)
      throw new TypeError("This packet does not contain alpha side data.");
    if (this.isMetadataOnly)
      throw new TypeError("Metadata-only packets cannot be converted to a video chunk.");
    if (typeof EncodedVideoChunk > "u")
      throw new Error("Your browser does not support EncodedVideoChunk.");
    return new EncodedVideoChunk({
      data: this.sideData.alpha,
      type: e,
      timestamp: this.microsecondTimestamp,
      duration: this.microsecondDuration
    });
  }
  /** Converts this packet to an
   * [`EncodedAudioChunk`](https://developer.mozilla.org/en-US/docs/Web/API/EncodedAudioChunk) for use with the
   * WebCodecs API. */
  toEncodedAudioChunk() {
    if (this.isMetadataOnly)
      throw new TypeError("Metadata-only packets cannot be converted to an audio chunk.");
    if (typeof EncodedAudioChunk > "u")
      throw new Error("Your browser does not support EncodedAudioChunk.");
    return new EncodedAudioChunk({
      data: this.data,
      type: this.type,
      timestamp: this.microsecondTimestamp,
      duration: this.microsecondDuration
    });
  }
  /**
   * Creates an {@link EncodedPacket} from an
   * [`EncodedVideoChunk`](https://developer.mozilla.org/en-US/docs/Web/API/EncodedVideoChunk) or
   * [`EncodedAudioChunk`](https://developer.mozilla.org/en-US/docs/Web/API/EncodedAudioChunk). This method is useful
   * for converting chunks from the WebCodecs API to `EncodedPacket` instances.
   */
  static fromEncodedChunk(e, t) {
    if (!(e instanceof EncodedVideoChunk || e instanceof EncodedAudioChunk))
      throw new TypeError("chunk must be an EncodedVideoChunk or EncodedAudioChunk.");
    const i = new Uint8Array(e.byteLength);
    return e.copyTo(i), new xe(i, e.type, e.timestamp / 1e6, (e.duration ?? 0) / 1e6, void 0, void 0, t);
  }
  /** Clones this packet while optionally modifying the new packet's data. */
  clone(e) {
    if (e !== void 0 && (typeof e != "object" || e === null))
      throw new TypeError("options, when provided, must be an object.");
    if ((e == null ? void 0 : e.data) !== void 0 && !(e.data instanceof Uint8Array))
      throw new TypeError("options.data, when provided, must be a Uint8Array.");
    if ((e == null ? void 0 : e.type) !== void 0 && e.type !== "key" && e.type !== "delta")
      throw new TypeError('options.type, when provided, must be either "key" or "delta".');
    if ((e == null ? void 0 : e.timestamp) !== void 0 && !Number.isFinite(e.timestamp))
      throw new TypeError("options.timestamp, when provided, must be a number.");
    if ((e == null ? void 0 : e.duration) !== void 0 && !Number.isFinite(e.duration))
      throw new TypeError("options.duration, when provided, must be a number.");
    if ((e == null ? void 0 : e.sequenceNumber) !== void 0 && !Number.isFinite(e.sequenceNumber))
      throw new TypeError("options.sequenceNumber, when provided, must be a number.");
    if ((e == null ? void 0 : e.sideData) !== void 0 && (typeof e.sideData != "object" || e.sideData === null))
      throw new TypeError("options.sideData, when provided, must be an object.");
    return new xe((e == null ? void 0 : e.data) ?? this.data, (e == null ? void 0 : e.type) ?? this.type, (e == null ? void 0 : e.timestamp) ?? this.timestamp, (e == null ? void 0 : e.duration) ?? this.duration, (e == null ? void 0 : e.sequenceNumber) ?? this.sequenceNumber, this.byteLength, (e == null ? void 0 : e.sideData) ?? this.sideData);
  }
}
/*!
 * Copyright (c) 2026-present, Vanilagy and contributors
 *
 * This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at https://mozilla.org/MPL/2.0/.
 */
const ir = (s) => {
  let t = (s.hasVideo ? "video/" : s.hasAudio ? "audio/" : "application/") + (s.isQuickTime ? "quicktime" : "mp4");
  if (s.codecStrings.length > 0) {
    const i = [...new Set(s.codecStrings)];
    t += `; codecs="${i.join(", ")}"`;
  }
  return t;
};
/*!
 * Copyright (c) 2026-present, Vanilagy and contributors
 *
 * This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at https://mozilla.org/MPL/2.0/.
 */
const qe = 8, qt = 16;
/*!
 * Copyright (c) 2026-present, Vanilagy and contributors
 *
 * This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at https://mozilla.org/MPL/2.0/.
 */
const nr = 7, rr = 9, Qt = (s) => {
  const e = s.filePos, t = ar(s, 9), i = new Z(t);
  if (i.readBits(12) !== 4095 || (i.skipBits(1), i.readBits(2) !== 0))
    return null;
  const o = i.readBits(1), a = i.readBits(2) + 1, c = i.readBits(4);
  if (c === 15)
    return null;
  i.skipBits(1);
  const u = i.readBits(3);
  if (u === 0)
    throw new Error("ADTS frames with channel configuration 0 are not supported.");
  i.skipBits(1), i.skipBits(1), i.skipBits(1), i.skipBits(1);
  const l = i.readBits(13);
  i.skipBits(11);
  const d = i.readBits(2) + 1;
  if (d !== 1)
    throw new Error("ADTS frames with more than one AAC frame are not supported.");
  let m = null;
  return o === 1 ? s.filePos -= 2 : m = i.readBits(16), {
    objectType: a,
    samplingFrequencyIndex: c,
    channelConfiguration: u,
    frameLength: l,
    numberOfAacFrames: d,
    crcCheck: m,
    startPos: e
  };
};
/*!
 * Copyright (c) 2026-present, Vanilagy and contributors
 *
 * This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at https://mozilla.org/MPL/2.0/.
 */
class Ce {
  constructor(e, t, i, n, r) {
    this.bytes = e, this.view = t, this.offset = i, this.start = n, this.end = r, this.bufferPos = n - i;
  }
  static tempFromBytes(e) {
    return new Ce(e, hs(e), 0, 0, e.length);
  }
  get length() {
    return this.end - this.start;
  }
  get filePos() {
    return this.offset + this.bufferPos;
  }
  set filePos(e) {
    this.bufferPos = e - this.offset;
  }
  /** The number of bytes left from the current pos to the end of the slice. */
  get remainingLength() {
    return Math.max(this.end - this.filePos, 0);
  }
  skip(e) {
    this.bufferPos += e;
  }
  /** Creates a new subslice of this slice whose byte range must be contained within this slice. */
  slice(e, t = this.end - e) {
    if (e < this.start || e + t > this.end)
      throw new RangeError("Slicing outside of original slice.");
    return new Ce(this.bytes, this.view, this.offset, e, e + t);
  }
}
const or = (s, e) => {
  if (s.filePos < s.start || s.filePos + e > s.end)
    throw new RangeError(`Tried reading [${s.filePos}, ${s.filePos + e}), but slice is [${s.start}, ${s.end}). This is likely an internal error, please report it alongside the file that caused it.`);
}, ar = (s, e) => {
  or(s, e);
  const t = s.bytes.subarray(s.bufferPos, s.bufferPos + e);
  return s.bufferPos += e, t;
};
/*!
 * Copyright (c) 2026-present, Vanilagy and contributors
 *
 * This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at https://mozilla.org/MPL/2.0/.
 */
class cr {
  constructor(e) {
    this.mutex = new ps(), this.firstMediaStreamTimestamp = null, this.trackTimestampInfo = /* @__PURE__ */ new WeakMap(), this.output = e;
  }
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  onTrackClose(e) {
  }
  validateAndNormalizeTimestamp(e, t, i) {
    if (t += e.source._timestampOffset, t < 0)
      throw new Error(`Timestamps must be non-negative (got ${t}s).`);
    let n = this.trackTimestampInfo.get(e);
    if (n) {
      if (i && (n.maxTimestampBeforeLastKeyPacket = n.maxTimestamp), n.maxTimestampBeforeLastKeyPacket !== null && t < n.maxTimestampBeforeLastKeyPacket)
        throw new Error(`Timestamps cannot be smaller than the largest timestamp of the previous GOP (a GOP begins with a key packet and ends right before the next key packet). Got ${t}s, but largest timestamp is ${n.maxTimestampBeforeLastKeyPacket}s.`);
      n.maxTimestamp = Math.max(n.maxTimestamp, t);
    } else {
      if (!i)
        throw new Error("First packet must be a key packet.");
      n = {
        maxTimestamp: t,
        maxTimestampBeforeLastKeyPacket: null
      }, this.trackTimestampInfo.set(e, n);
    }
    return t;
  }
}
/*!
 * Copyright (c) 2026-present, Vanilagy and contributors
 *
 * This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at https://mozilla.org/MPL/2.0/.
 */
const Zt = /<(?:(\d{2}):)?(\d{2}):(\d{2}).(\d{3})>/g, lr = (s) => {
  const e = Math.floor(s / 36e5), t = Math.floor(s % (60 * 60 * 1e3) / (60 * 1e3)), i = Math.floor(s % (60 * 1e3) / 1e3), n = s % 1e3;
  return e.toString().padStart(2, "0") + ":" + t.toString().padStart(2, "0") + ":" + i.toString().padStart(2, "0") + "." + n.toString().padStart(3, "0");
};
/*!
 * Copyright (c) 2026-present, Vanilagy and contributors
 *
 * This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at https://mozilla.org/MPL/2.0/.
 */
class Jt {
  constructor(e) {
    this.writer = e, this.helper = new Uint8Array(8), this.helperView = new DataView(this.helper.buffer), this.offsets = /* @__PURE__ */ new WeakMap();
  }
  writeU32(e) {
    this.helperView.setUint32(0, e, !1), this.writer.write(this.helper.subarray(0, 4));
  }
  writeU64(e) {
    this.helperView.setUint32(0, Math.floor(e / 2 ** 32), !1), this.helperView.setUint32(4, e, !1), this.writer.write(this.helper.subarray(0, 8));
  }
  writeAscii(e) {
    for (let t = 0; t < e.length; t++)
      this.helperView.setUint8(t % 8, e.charCodeAt(t)), t % 8 === 7 && this.writer.write(this.helper);
    e.length % 8 !== 0 && this.writer.write(this.helper.subarray(0, e.length % 8));
  }
  writeBox(e) {
    if (this.offsets.set(e, this.writer.getPos()), e.contents && !e.children)
      this.writeBoxHeader(e, e.size ?? e.contents.byteLength + 8), this.writer.write(e.contents);
    else {
      const t = this.writer.getPos();
      if (this.writeBoxHeader(e, 0), e.contents && this.writer.write(e.contents), e.children)
        for (const r of e.children)
          r && this.writeBox(r);
      const i = this.writer.getPos(), n = e.size ?? i - t;
      this.writer.seek(t), this.writeBoxHeader(e, n), this.writer.seek(i);
    }
  }
  writeBoxHeader(e, t) {
    this.writeU32(e.largeSize ? 1 : t), this.writeAscii(e.type), e.largeSize && this.writeU64(t);
  }
  measureBoxHeader(e) {
    return 8 + (e.largeSize ? 8 : 0);
  }
  patchBox(e) {
    const t = this.offsets.get(e);
    P(t !== void 0);
    const i = this.writer.getPos();
    this.writer.seek(t), this.writeBox(e), this.writer.seek(i);
  }
  measureBox(e) {
    if (e.contents && !e.children)
      return this.measureBoxHeader(e) + e.contents.byteLength;
    {
      let t = this.measureBoxHeader(e);
      if (e.contents && (t += e.contents.byteLength), e.children)
        for (const i of e.children)
          i && (t += this.measureBox(i));
      return t;
    }
  }
}
const I = /* @__PURE__ */ new Uint8Array(8), ie = /* @__PURE__ */ new DataView(I.buffer), z = (s) => [(s % 256 + 256) % 256], M = (s) => (ie.setUint16(0, s, !1), [I[0], I[1]]), bt = (s) => (ie.setInt16(0, s, !1), [I[0], I[1]]), vs = (s) => (ie.setUint32(0, s, !1), [I[1], I[2], I[3]]), x = (s) => (ie.setUint32(0, s, !1), [I[0], I[1], I[2], I[3]]), de = (s) => (ie.setInt32(0, s, !1), [I[0], I[1], I[2], I[3]]), pe = (s) => (ie.setUint32(0, Math.floor(s / 2 ** 32), !1), ie.setUint32(4, s, !1), [I[0], I[1], I[2], I[3], I[4], I[5], I[6], I[7]]), Ts = (s) => (ie.setInt16(0, 2 ** 8 * s, !1), [I[0], I[1]]), re = (s) => (ie.setInt32(0, 2 ** 16 * s, !1), [I[0], I[1], I[2], I[3]]), Qe = (s) => (ie.setInt32(0, 2 ** 30 * s, !1), [I[0], I[1], I[2], I[3]]), Ze = (s, e) => {
  const t = [];
  let i = s;
  do {
    let n = i & 127;
    i >>= 7, t.length > 0 && (n |= 128), t.push(n);
  } while (i > 0 || e);
  return t.reverse();
}, X = (s, e = !1) => {
  const t = Array(s.length).fill(null).map((i, n) => s.charCodeAt(n));
  return e && t.push(0), t;
}, yt = (s) => {
  let e = null;
  for (const t of s)
    (!e || t.timestamp > e.timestamp) && (e = t);
  return e;
}, _s = (s) => {
  const e = s * (Math.PI / 180), t = Math.round(Math.cos(e)), i = Math.round(Math.sin(e));
  return [
    t,
    i,
    0,
    -i,
    t,
    0,
    0,
    0,
    1
  ];
}, xs = /* @__PURE__ */ _s(0), Cs = (s) => [
  re(s[0]),
  re(s[1]),
  Qe(s[2]),
  re(s[3]),
  re(s[4]),
  Qe(s[5]),
  re(s[6]),
  re(s[7]),
  Qe(s[8])
], B = (s, e, t) => ({
  type: s,
  contents: e && new Uint8Array(e.flat(10)),
  children: t
}), U = (s, e, t, i, n) => B(s, [z(e), vs(t), i ?? []], n), ur = (s) => s.isQuickTime ? B("ftyp", [
  X("qt  "),
  // Major brand
  x(512),
  // Minor version
  // Compatible brands
  X("qt  ")
]) : s.fragmented ? B("ftyp", [
  X("iso5"),
  // Major brand
  x(512),
  // Minor version
  // Compatible brands
  X("iso5"),
  X("iso6"),
  X("mp41")
]) : B("ftyp", [
  X("isom"),
  // Major brand
  x(512),
  // Minor version
  // Compatible brands
  X("isom"),
  s.holdsAvc ? X("avc1") : [],
  X("mp41")
]), $e = (s) => ({ type: "mdat", largeSize: s }), dr = (s) => ({ type: "free", size: s }), we = (s) => B("moov", void 0, [
  hr(s.creationTime, s.trackDatas),
  ...s.trackDatas.map((e) => mr(e, s.creationTime)),
  s.isFragmented ? Qr(s.trackDatas) : null,
  uo(s)
]), hr = (s, e) => {
  const t = j(Math.max(0, ...e.filter((o) => o.samples.length > 0).map((o) => {
    const a = yt(o.samples);
    return a.timestamp + a.duration;
  })), ot), i = Math.max(0, ...e.map((o) => o.track.id)) + 1, n = !fe(s) || !fe(t), r = n ? pe : x;
  return U("mvhd", +n, 0, [
    r(s),
    // Creation time
    r(s),
    // Modification time
    x(ot),
    // Timescale
    r(t),
    // Duration
    re(1),
    // Preferred rate
    Ts(1),
    // Preferred volume
    Array(10).fill(0),
    // Reserved
    Cs(xs),
    // Matrix
    Array(24).fill(0),
    // Pre-defined
    x(i)
    // Next track ID
  ]);
}, mr = (s, e) => {
  const t = To(s);
  return B("trak", void 0, [
    pr(s, e),
    fr(s, e),
    t.name !== void 0 ? B("udta", void 0, [
      B("name", [
        ...se.encode(t.name)
      ])
    ]) : null
  ]);
}, pr = (s, e) => {
  var c;
  const t = yt(s.samples), i = j(t ? t.timestamp + t.duration : 0, ot), n = !fe(e) || !fe(i), r = n ? pe : x;
  let o;
  if (s.type === "video") {
    const u = s.track.metadata.rotation;
    o = _s(u ?? 0);
  } else
    o = xs;
  let a = 2;
  return ((c = s.track.metadata.disposition) == null ? void 0 : c.default) !== !1 && (a |= 1), U("tkhd", +n, a, [
    r(e),
    // Creation time
    r(e),
    // Modification time
    x(s.track.id),
    // Track ID
    x(0),
    // Reserved
    r(i),
    // Duration
    Array(8).fill(0),
    // Reserved
    M(0),
    // Layer
    M(s.track.id),
    // Alternate group
    Ts(s.type === "audio" ? 1 : 0),
    // Volume
    M(0),
    // Reserved
    Cs(o),
    // Matrix
    re(s.type === "video" ? s.info.width : 0),
    // Track width
    re(s.type === "video" ? s.info.height : 0)
    // Track height
  ]);
}, fr = (s, e) => B("mdia", void 0, [
  gr(s, e),
  wt(!0, br[s.type], yr[s.type]),
  wr(s)
]), gr = (s, e) => {
  const t = yt(s.samples), i = j(t ? t.timestamp + t.duration : 0, s.timescale), n = !fe(e) || !fe(i), r = n ? pe : x;
  return U("mdhd", +n, 0, [
    r(e),
    // Creation time
    r(e),
    // Modification time
    x(s.timescale),
    // Timescale
    r(i),
    // Duration
    M(As(s.track.metadata.languageCode ?? yn)),
    // Language
    M(0)
    // Quality
  ]);
}, br = {
  video: "vide",
  audio: "soun",
  subtitle: "text"
}, yr = {
  video: "MediabunnyVideoHandler",
  audio: "MediabunnySoundHandler",
  subtitle: "MediabunnyTextHandler"
}, wt = (s, e, t, i = "\0\0\0\0") => U("hdlr", 0, 0, [
  s ? X("mhlr") : x(0),
  // Component type
  X(e),
  // Component subtype
  X(i),
  // Component manufacturer
  x(0),
  // Component flags
  x(0),
  // Component flags mask
  X(t, !0)
  // Component name
]), wr = (s) => B("minf", void 0, [
  _r[s.type](),
  xr(),
  Rr(s)
]), Er = () => U("vmhd", 0, 1, [
  M(0),
  // Graphics mode
  M(0),
  // Opcolor R
  M(0),
  // Opcolor G
  M(0)
  // Opcolor B
]), vr = () => U("smhd", 0, 0, [
  M(0),
  // Balance
  M(0)
  // Reserved
]), Tr = () => U("nmhd", 0, 0), _r = {
  video: Er,
  audio: vr,
  subtitle: Tr
}, xr = () => B("dinf", void 0, [
  Cr()
]), Cr = () => U("dref", 0, 0, [
  x(1)
  // Entry count
], [
  Sr()
]), Sr = () => U("url ", 0, 1), Rr = (s) => {
  const e = s.compositionTimeOffsetTable.length > 1 || s.compositionTimeOffsetTable.some((t) => t.sampleCompositionTimeOffset !== 0);
  return B("stbl", void 0, [
    kr(s),
    Hr(s),
    e ? Yr(s) : null,
    e ? qr(s) : null,
    Xr(s),
    Gr(s),
    Kr(s),
    Wr(s)
  ]);
}, kr = (s) => {
  let e;
  if (s.type === "video")
    e = Ar(fo(s.track.source._codec, s.info.decoderConfig.codec), s);
  else if (s.type === "audio") {
    const t = ks(s.track.source._codec, s.muxer.isQuickTime);
    P(t), e = Ir(t, s);
  } else s.type === "subtitle" && (e = zr(yo[s.track.source._codec], s));
  return P(e), U("stsd", 0, 0, [
    x(1)
    // Entry count
  ], [
    e
  ]);
}, Ar = (s, e) => B(s, [
  Array(6).fill(0),
  // Reserved
  M(1),
  // Data reference index
  M(0),
  // Pre-defined
  M(0),
  // Reserved
  Array(12).fill(0),
  // Pre-defined
  M(e.info.width),
  // Width
  M(e.info.height),
  // Height
  x(4718592),
  // Horizontal resolution
  x(4718592),
  // Vertical resolution
  x(0),
  // Reserved
  M(1),
  // Frame count
  Array(32).fill(0),
  // Compressor name
  M(24),
  // Depth
  bt(65535)
  // Pre-defined
], [
  go[e.track.source._codec](e),
  Fr(e),
  fn(e.info.decoderConfig.colorSpace) ? Br(e) : null
]), Fr = (s) => s.info.pixelAspectRatio.num === s.info.pixelAspectRatio.den ? null : B("pasp", [
  x(s.info.pixelAspectRatio.num),
  x(s.info.pixelAspectRatio.den)
]), Br = (s) => B("colr", [
  X("nclx"),
  // Colour type
  M(ut[s.info.decoderConfig.colorSpace.primaries]),
  // Colour primaries
  M(dt[s.info.decoderConfig.colorSpace.transfer]),
  // Transfer characteristics
  M(ht[s.info.decoderConfig.colorSpace.matrix]),
  // Matrix coefficients
  z((s.info.decoderConfig.colorSpace.fullRange ? 1 : 0) << 7)
  // Full range flag
]), Pr = (s) => s.info.decoderConfig && B("avcC", [
  // For AVC, description is an AVCDecoderConfigurationRecord, so nothing else to do here
  ...Ae(s.info.decoderConfig.description)
]), Mr = (s) => s.info.decoderConfig && B("hvcC", [
  // For HEVC, description is an HEVCDecoderConfigurationRecord, so nothing else to do here
  ...Ae(s.info.decoderConfig.description)
]), es = (s) => {
  var m, g, E, v;
  if (!s.info.decoderConfig)
    return null;
  const e = s.info.decoderConfig, t = e.codec.split("."), i = Number(t[1]), n = Number(t[2]), r = Number(t[3]), o = t[4] ? Number(t[4]) : 1, a = t[8] ? Number(t[8]) : Number(((m = e.colorSpace) == null ? void 0 : m.fullRange) ?? 0), c = (r << 4) + (o << 1) + a, u = t[5] ? Number(t[5]) : (g = e.colorSpace) != null && g.primaries ? ut[e.colorSpace.primaries] : 2, l = t[6] ? Number(t[6]) : (E = e.colorSpace) != null && E.transfer ? dt[e.colorSpace.transfer] : 2, d = t[7] ? Number(t[7]) : (v = e.colorSpace) != null && v.matrix ? ht[e.colorSpace.matrix] : 2;
  return U("vpcC", 1, 0, [
    z(i),
    // Profile
    z(n),
    // Level
    z(c),
    // Bit depth, chroma subsampling, full range
    z(u),
    // Colour primaries
    z(l),
    // Transfer characteristics
    z(d),
    // Matrix coefficients
    M(0)
    // Codec initialization data size
  ]);
}, Lr = (s) => B("av1C", Sn(s.info.decoderConfig.codec)), Ir = (s, e) => {
  var o;
  let t = 0, i, n = 16;
  const r = me.includes(e.track.source._codec);
  if (r) {
    const a = e.track.source._codec, { sampleSize: c } = Fe(a);
    n = 8 * c, n > 16 && (t = 1);
  }
  if (e.muxer.isQuickTime && (t = 1), t === 0)
    i = [
      Array(6).fill(0),
      // Reserved
      M(1),
      // Data reference index
      M(t),
      // Version
      M(0),
      // Revision level
      x(0),
      // Vendor
      M(e.info.numberOfChannels),
      // Number of channels
      M(n),
      // Sample size (bits)
      M(0),
      // Compression ID
      M(0),
      // Packet size
      M(e.info.sampleRate < 2 ** 16 ? e.info.sampleRate : 0),
      // Sample rate (upper)
      M(0)
      // Sample rate (lower)
    ];
  else {
    const a = r ? 0 : -2;
    i = [
      Array(6).fill(0),
      // Reserved
      M(1),
      // Data reference index
      M(t),
      // Version
      M(0),
      // Revision level
      x(0),
      // Vendor
      M(e.info.numberOfChannels),
      // Number of channels
      M(Math.min(n, 16)),
      // Sample size (bits)
      bt(a),
      // Compression ID
      M(0),
      // Packet size
      M(e.info.sampleRate < 2 ** 16 ? e.info.sampleRate : 0),
      // Sample rate (upper)
      M(0),
      // Sample rate (lower)
      r ? [
        x(1),
        // Samples per packet (must be 1 for uncompressed formats)
        x(n / 8),
        // Bytes per packet
        x(e.info.numberOfChannels * n / 8)
        // Bytes per frame
      ] : [
        x(0),
        // Samples per packet (don't bother, still works with 0)
        x(0),
        // Bytes per packet (variable)
        x(0)
        // Bytes per frame (variable)
      ],
      x(2)
      // Bytes per sample (constant in FFmpeg)
    ];
  }
  return B(s, i, [
    ((o = bo(e.track.source._codec, e.muxer.isQuickTime)) == null ? void 0 : o(e)) ?? null
  ]);
}, Je = (s) => {
  let e;
  switch (s.track.source._codec) {
    case "aac":
      e = 64;
      break;
    case "mp3":
      e = 107;
      break;
    case "vorbis":
      e = 221;
      break;
    default:
      throw new Error(`Unhandled audio codec: ${s.track.source._codec}`);
  }
  let t = [
    ...z(e),
    // Object type indication
    ...z(21),
    // stream type(6bits)=5 audio, flags(2bits)=1
    ...vs(0),
    // 24bit buffer size
    ...x(0),
    // max bitrate
    ...x(0)
    // avg bitrate
  ];
  if (s.info.decoderConfig.description) {
    const i = Ae(s.info.decoderConfig.description);
    t = [
      ...t,
      ...z(5),
      // TAG(5) = DecoderSpecificInfo
      ...Ze(i.byteLength),
      ...i
    ];
  }
  return t = [
    ...M(1),
    // ES_ID = 1
    ...z(0),
    // flags etc = 0
    ...z(4),
    // TAG(4) = ES Descriptor
    ...Ze(t.length),
    ...t,
    ...z(6),
    // TAG(6)
    ...z(1),
    // length
    ...z(2)
    // data
  ], t = [
    ...z(3),
    // TAG(3) = Object Descriptor
    ...Ze(t.length),
    ...t
  ], U("esds", 0, 0, t);
}, ce = (s) => B("wave", void 0, [
  Ur(s),
  Nr(s),
  B("\0\0\0\0")
  // NULL tag at the end
]), Ur = (s) => B("frma", [
  X(ks(s.track.source._codec, s.muxer.isQuickTime))
]), Nr = (s) => {
  const { littleEndian: e } = Fe(s.track.source._codec);
  return B("enda", [
    M(+e)
  ]);
}, Or = (s) => {
  var c;
  let e = s.info.numberOfChannels, t = 3840, i = s.info.sampleRate, n = 0, r = 0, o = new Uint8Array(0);
  const a = (c = s.info.decoderConfig) == null ? void 0 : c.description;
  if (a) {
    P(a.byteLength >= 18);
    const u = Ae(a), l = Jn(u);
    e = l.outputChannelCount, t = l.preSkip, i = l.inputSampleRate, n = l.outputGain, r = l.channelMappingFamily, l.channelMappingTable && (o = l.channelMappingTable);
  }
  return B("dOps", [
    z(0),
    // Version
    z(e),
    // OutputChannelCount
    M(t),
    // PreSkip
    x(i),
    // InputSampleRate
    bt(n),
    // OutputGain
    z(r),
    // ChannelMappingFamily
    ...o
  ]);
}, Dr = (s) => {
  var i;
  const e = (i = s.info.decoderConfig) == null ? void 0 : i.description;
  P(e);
  const t = Ae(e);
  return U("dfLa", 0, 0, [
    ...t.subarray(4)
  ]);
}, J = (s) => {
  const { littleEndian: e, sampleSize: t } = Fe(s.track.source._codec), i = +e;
  return U("pcmC", 0, 0, [
    z(i),
    z(8 * t)
  ]);
}, $r = (s) => {
  const e = er(s.info.firstPacket.data);
  if (!e)
    throw new Error("Couldn't extract AC-3 frame info from the audio packet. Ensure the packets contain valid AC-3 sync frames (as specified in ETSI TS 102 366).");
  const t = new Uint8Array(3), i = new Z(t);
  return i.writeBits(2, e.fscod), i.writeBits(5, e.bsid), i.writeBits(3, e.bsmod), i.writeBits(3, e.acmod), i.writeBits(1, e.lfeon), i.writeBits(5, e.bitRateCode), i.writeBits(5, 0), B("dac3", [...t]);
}, Vr = (s) => {
  const e = sr(s.info.firstPacket.data);
  if (!e)
    throw new Error("Couldn't extract E-AC-3 frame info from the audio packet. Ensure the packets contain valid E-AC-3 sync frames (as specified in ETSI TS 102 366).");
  let t = 16;
  for (const o of e.substreams)
    t += 23, o.numDepSub > 0 ? t += 9 : t += 1;
  const i = Math.ceil(t / 8), n = new Uint8Array(i), r = new Z(n);
  r.writeBits(13, e.dataRate), r.writeBits(3, e.substreams.length - 1);
  for (const o of e.substreams)
    r.writeBits(2, o.fscod), r.writeBits(5, o.bsid), r.writeBits(1, 0), r.writeBits(1, 0), r.writeBits(3, o.bsmod), r.writeBits(3, o.acmod), r.writeBits(1, o.lfeon), r.writeBits(3, 0), r.writeBits(4, o.numDepSub), o.numDepSub > 0 ? r.writeBits(9, o.chanLoc) : r.writeBits(1, 0);
  return B("dec3", [...n]);
}, zr = (s, e) => B(s, [
  Array(6).fill(0),
  // Reserved
  M(1)
  // Data reference index
], [
  wo[e.track.source._codec](e)
]), jr = (s) => B("vttC", [
  ...se.encode(s.info.config.description)
]), Hr = (s) => U("stts", 0, 0, [
  x(s.timeToSampleTable.length),
  // Number of entries
  s.timeToSampleTable.map((e) => [
    x(e.sampleCount),
    // Sample count
    x(e.sampleDelta)
    // Sample duration
  ])
]), Wr = (s) => {
  if (s.samples.every((t) => t.type === "key"))
    return null;
  const e = [...s.samples.entries()].filter(([, t]) => t.type === "key");
  return U("stss", 0, 0, [
    x(e.length),
    // Number of entries
    e.map(([t]) => x(t + 1))
    // Sync sample table
  ]);
}, Xr = (s) => U("stsc", 0, 0, [
  x(s.compactlyCodedChunkTable.length),
  // Number of entries
  s.compactlyCodedChunkTable.map((e) => [
    x(e.firstChunk),
    // First chunk
    x(e.samplesPerChunk),
    // Samples per chunk
    x(1)
    // Sample description index
  ])
]), Gr = (s) => {
  if (s.type === "audio" && s.info.requiresPcmTransformation) {
    const { sampleSize: e } = Fe(s.track.source._codec);
    return U("stsz", 0, 0, [
      x(e * s.info.numberOfChannels),
      // Sample size
      x(s.samples.reduce((t, i) => t + j(i.duration, s.timescale), 0))
    ]);
  }
  return U("stsz", 0, 0, [
    x(0),
    // Sample size (0 means non-constant size)
    x(s.samples.length),
    // Number of entries
    s.samples.map((e) => x(e.size))
    // Sample size table
  ]);
}, Kr = (s) => s.finalizedChunks.length > 0 && he(s.finalizedChunks).offset >= 2 ** 32 ? U("co64", 0, 0, [
  x(s.finalizedChunks.length),
  // Number of entries
  s.finalizedChunks.map((e) => pe(e.offset))
  // Chunk offset table
]) : U("stco", 0, 0, [
  x(s.finalizedChunks.length),
  // Number of entries
  s.finalizedChunks.map((e) => x(e.offset))
  // Chunk offset table
]), Yr = (s) => U("ctts", 1, 0, [
  x(s.compositionTimeOffsetTable.length),
  // Number of entries
  s.compositionTimeOffsetTable.map((e) => [
    x(e.sampleCount),
    // Sample count
    de(e.sampleCompositionTimeOffset)
    // Sample offset
  ])
]), qr = (s) => {
  let e = 1 / 0, t = -1 / 0, i = 1 / 0, n = -1 / 0;
  P(s.compositionTimeOffsetTable.length > 0), P(s.samples.length > 0);
  for (let o = 0; o < s.compositionTimeOffsetTable.length; o++) {
    const a = s.compositionTimeOffsetTable[o];
    e = Math.min(e, a.sampleCompositionTimeOffset), t = Math.max(t, a.sampleCompositionTimeOffset);
  }
  for (let o = 0; o < s.samples.length; o++) {
    const a = s.samples[o];
    i = Math.min(i, j(a.timestamp, s.timescale)), n = Math.max(n, j(a.timestamp + a.duration, s.timescale));
  }
  const r = Math.max(-e, 0);
  return n >= 2 ** 31 ? null : U("cslg", 0, 0, [
    de(r),
    // Composition to DTS shift
    de(e),
    // Least decode to display delta
    de(t),
    // Greatest decode to display delta
    de(i),
    // Composition start time
    de(n)
    // Composition end time
  ]);
}, Qr = (s) => B("mvex", void 0, s.map(Zr)), Zr = (s) => U("trex", 0, 0, [
  x(s.track.id),
  // Track ID
  x(1),
  // Default sample description index
  x(0),
  // Default sample duration
  x(0),
  // Default sample size
  x(0)
  // Default sample flags
]), ts = (s, e) => B("moof", void 0, [
  Jr(s),
  ...e.map(eo)
]), Jr = (s) => U("mfhd", 0, 0, [
  x(s)
  // Sequence number
]), Ss = (s) => {
  let e = 0, t = 0;
  const i = 0, n = 0, r = s.type === "delta";
  return t |= +r, r ? e |= 1 : e |= 2, e << 24 | t << 16 | i << 8 | n;
}, eo = (s) => B("traf", void 0, [
  to(s),
  so(s),
  io(s)
]), to = (s) => {
  P(s.currentChunk);
  let e = 0;
  e |= 8, e |= 16, e |= 32, e |= 131072;
  const t = s.currentChunk.samples[1] ?? s.currentChunk.samples[0], i = {
    duration: t.timescaleUnitsToNextSample,
    size: t.size,
    flags: Ss(t)
  };
  return U("tfhd", 0, e, [
    x(s.track.id),
    // Track ID
    x(i.duration),
    // Default sample duration
    x(i.size),
    // Default sample size
    x(i.flags)
    // Default sample flags
  ]);
}, so = (s) => (P(s.currentChunk), U("tfdt", 1, 0, [
  pe(j(s.currentChunk.startTimestamp, s.timescale))
  // Base Media Decode Time
])), io = (s) => {
  P(s.currentChunk);
  const e = s.currentChunk.samples.map((v) => v.timescaleUnitsToNextSample), t = s.currentChunk.samples.map((v) => v.size), i = s.currentChunk.samples.map(Ss), n = s.currentChunk.samples.map((v) => j(v.timestamp - v.decodeTimestamp, s.timescale)), r = new Set(e), o = new Set(t), a = new Set(i), c = new Set(n), u = a.size === 2 && i[0] !== i[1], l = r.size > 1, d = o.size > 1, m = !u && a.size > 1, g = c.size > 1 || [...c].some((v) => v !== 0);
  let E = 0;
  return E |= 1, E |= 4 * +u, E |= 256 * +l, E |= 512 * +d, E |= 1024 * +m, E |= 2048 * +g, U("trun", 1, E, [
    x(s.currentChunk.samples.length),
    // Sample count
    x(s.currentChunk.offset - s.currentChunk.moofOffset || 0),
    // Data offset
    u ? x(i[0]) : [],
    s.currentChunk.samples.map((v, _) => [
      l ? x(e[_]) : [],
      // Sample duration
      d ? x(t[_]) : [],
      // Sample size
      m ? x(i[_]) : [],
      // Sample flags
      // Sample composition time offsets
      g ? de(n[_]) : []
    ])
  ]);
}, no = (s) => B("mfra", void 0, [
  ...s.map(ro),
  oo()
]), ro = (s, e) => U("tfra", 1, 0, [
  x(s.track.id),
  // Track ID
  x(63),
  // This specifies that traf number, trun number and sample number are 32-bit ints
  x(s.finalizedChunks.length),
  // Number of entries
  s.finalizedChunks.map((i) => [
    pe(j(i.samples[0].timestamp, s.timescale)),
    // Time (in presentation time)
    pe(i.moofOffset),
    // moof offset
    x(e + 1),
    // traf number
    x(1),
    // trun number
    x(1)
    // Sample number
  ])
]), oo = () => U("mfro", 0, 0, [
  // This value needs to be overwritten manually from the outside, where the actual size of the enclosing mfra box
  // is known
  x(0)
  // Size
]), ao = () => B("vtte"), co = (s, e, t, i, n) => B("vttc", void 0, [
  n !== null ? B("vsid", [de(n)]) : null,
  t !== null ? B("iden", [...se.encode(t)]) : null,
  e !== null ? B("ctim", [...se.encode(lr(e))]) : null,
  i !== null ? B("sttg", [...se.encode(i)]) : null,
  B("payl", [...se.encode(s)])
]), lo = (s) => B("vtta", [...se.encode(s)]), uo = (s) => {
  const e = [], t = s.format._options.metadataFormat ?? "auto", i = s.output._metadataTags;
  if (t === "mdir" || t === "auto" && !s.isQuickTime) {
    const n = mo(i);
    n && e.push(n);
  } else if (t === "mdta") {
    const n = po(i);
    n && e.push(n);
  } else (t === "udta" || t === "auto" && s.isQuickTime) && ho(e, s.output._metadataTags);
  return e.length === 0 ? null : B("udta", void 0, e);
}, ho = (s, e) => {
  for (const { key: t, value: i } of gs(e))
    switch (t) {
      case "title":
        s.push(ee("©nam", i));
        break;
      case "description":
        s.push(ee("©des", i));
        break;
      case "artist":
        s.push(ee("©ART", i));
        break;
      case "album":
        s.push(ee("©alb", i));
        break;
      case "albumArtist":
        s.push(ee("albr", i));
        break;
      case "genre":
        s.push(ee("©gen", i));
        break;
      case "date":
        s.push(ee("©day", i.toISOString().slice(0, 10)));
        break;
      case "comment":
        s.push(ee("©cmt", i));
        break;
      case "lyrics":
        s.push(ee("©lyr", i));
        break;
      case "raw":
        break;
      case "discNumber":
      case "discsTotal":
      case "trackNumber":
      case "tracksTotal":
      case "images":
        break;
      default:
        fs(t);
    }
  if (e.raw)
    for (const t in e.raw) {
      const i = e.raw[t];
      i == null || t.length !== 4 || s.some((n) => n.type === t) || (typeof i == "string" ? s.push(ee(t, i)) : i instanceof Uint8Array && s.push(B(t, Array.from(i))));
    }
}, ee = (s, e) => {
  const t = se.encode(e);
  return B(s, [
    M(t.length),
    M(As("und")),
    Array.from(t)
  ]);
}, ss = {
  "image/jpeg": 13,
  "image/png": 14,
  "image/bmp": 27
}, Rs = (s, e) => {
  const t = [];
  for (const { key: i, value: n } of gs(s))
    switch (i) {
      case "title":
        t.push({ key: e ? "title" : "©nam", value: Y(n) });
        break;
      case "description":
        t.push({ key: e ? "description" : "©des", value: Y(n) });
        break;
      case "artist":
        t.push({ key: e ? "artist" : "©ART", value: Y(n) });
        break;
      case "album":
        t.push({ key: e ? "album" : "©alb", value: Y(n) });
        break;
      case "albumArtist":
        t.push({ key: e ? "album_artist" : "aART", value: Y(n) });
        break;
      case "comment":
        t.push({ key: e ? "comment" : "©cmt", value: Y(n) });
        break;
      case "genre":
        t.push({ key: e ? "genre" : "©gen", value: Y(n) });
        break;
      case "lyrics":
        t.push({ key: e ? "lyrics" : "©lyr", value: Y(n) });
        break;
      case "date":
        t.push({
          key: e ? "date" : "©day",
          value: Y(n.toISOString().slice(0, 10))
        });
        break;
      case "images":
        for (const r of n)
          r.kind === "coverFront" && t.push({ key: "covr", value: B("data", [
            x(ss[r.mimeType] ?? 0),
            // Type indicator
            x(0),
            // Locale indicator
            Array.from(r.data)
            // Kinda slow, hopefully temp
          ]) });
        break;
      case "trackNumber":
        if (e) {
          const r = s.tracksTotal !== void 0 ? `${n}/${s.tracksTotal}` : n.toString();
          t.push({ key: "track", value: Y(r) });
        } else
          t.push({ key: "trkn", value: B("data", [
            x(0),
            // 8 bytes empty
            x(0),
            M(0),
            // Empty
            M(n),
            M(s.tracksTotal ?? 0),
            M(0)
            // Empty
          ]) });
        break;
      case "discNumber":
        e || t.push({ key: "disc", value: B("data", [
          x(0),
          // 8 bytes empty
          x(0),
          M(0),
          // Empty
          M(n),
          M(s.discsTotal ?? 0),
          M(0)
          // Empty
        ]) });
        break;
      case "tracksTotal":
      case "discsTotal":
        break;
      case "raw":
        break;
      default:
        fs(i);
    }
  if (s.raw)
    for (const i in s.raw) {
      const n = s.raw[i];
      n == null || !e && i.length !== 4 || t.some((r) => r.key === i) || (typeof n == "string" ? t.push({ key: i, value: Y(n) }) : n instanceof Uint8Array ? t.push({ key: i, value: B("data", [
        x(0),
        // Type indicator
        x(0),
        // Locale indicator
        Array.from(n)
      ]) }) : n instanceof mt && t.push({ key: i, value: B("data", [
        x(ss[n.mimeType] ?? 0),
        // Type indicator
        x(0),
        // Locale indicator
        Array.from(n.data)
        // Kinda slow, hopefully temp
      ]) }));
    }
  return t;
}, mo = (s) => {
  const e = Rs(s, !1);
  return e.length === 0 ? null : U("meta", 0, 0, void 0, [
    wt(!1, "mdir", "", "appl"),
    // mdir handler
    B("ilst", void 0, e.map((t) => B(t.key, void 0, [t.value])))
    // Item list without keys box
  ]);
}, po = (s) => {
  const e = Rs(s, !0);
  return e.length === 0 ? null : B("meta", void 0, [
    wt(!1, "mdta", ""),
    // mdta handler
    U("keys", 0, 0, [
      x(e.length)
    ], e.map((t) => B("mdta", [
      ...se.encode(t.key)
    ]))),
    B("ilst", void 0, e.map((t, i) => {
      const n = String.fromCharCode(...x(i + 1));
      return B(n, void 0, [t.value]);
    }))
  ]);
}, Y = (s) => B("data", [
  x(1),
  // Type indicator (UTF-8)
  x(0),
  // Locale indicator
  ...se.encode(s)
]), fo = (s, e) => {
  switch (s) {
    case "avc":
      return e.startsWith("avc3") ? "avc3" : "avc1";
    case "hevc":
      return "hvc1";
    case "vp8":
      return "vp08";
    case "vp9":
      return "vp09";
    case "av1":
      return "av01";
  }
}, go = {
  avc: Pr,
  hevc: Mr,
  vp8: es,
  vp9: es,
  av1: Lr
}, ks = (s, e) => {
  switch (s) {
    case "aac":
      return "mp4a";
    case "mp3":
      return "mp4a";
    case "opus":
      return "Opus";
    case "vorbis":
      return "mp4a";
    case "flac":
      return "fLaC";
    case "ulaw":
      return "ulaw";
    case "alaw":
      return "alaw";
    case "pcm-u8":
      return "raw ";
    case "pcm-s8":
      return "sowt";
    case "ac3":
      return "ac-3";
    case "eac3":
      return "ec-3";
  }
  if (e)
    switch (s) {
      case "pcm-s16":
        return "sowt";
      case "pcm-s16be":
        return "twos";
      case "pcm-s24":
        return "in24";
      case "pcm-s24be":
        return "in24";
      case "pcm-s32":
        return "in32";
      case "pcm-s32be":
        return "in32";
      case "pcm-f32":
        return "fl32";
      case "pcm-f32be":
        return "fl32";
      case "pcm-f64":
        return "fl64";
      case "pcm-f64be":
        return "fl64";
    }
  else
    switch (s) {
      case "pcm-s16":
        return "ipcm";
      case "pcm-s16be":
        return "ipcm";
      case "pcm-s24":
        return "ipcm";
      case "pcm-s24be":
        return "ipcm";
      case "pcm-s32":
        return "ipcm";
      case "pcm-s32be":
        return "ipcm";
      case "pcm-f32":
        return "fpcm";
      case "pcm-f32be":
        return "fpcm";
      case "pcm-f64":
        return "fpcm";
      case "pcm-f64be":
        return "fpcm";
    }
}, bo = (s, e) => {
  switch (s) {
    case "aac":
      return Je;
    case "mp3":
      return Je;
    case "opus":
      return Or;
    case "vorbis":
      return Je;
    case "flac":
      return Dr;
    case "ac3":
      return $r;
    case "eac3":
      return Vr;
  }
  if (e)
    switch (s) {
      case "pcm-s24":
        return ce;
      case "pcm-s24be":
        return ce;
      case "pcm-s32":
        return ce;
      case "pcm-s32be":
        return ce;
      case "pcm-f32":
        return ce;
      case "pcm-f32be":
        return ce;
      case "pcm-f64":
        return ce;
      case "pcm-f64be":
        return ce;
    }
  else
    switch (s) {
      case "pcm-s16":
        return J;
      case "pcm-s16be":
        return J;
      case "pcm-s24":
        return J;
      case "pcm-s24be":
        return J;
      case "pcm-s32":
        return J;
      case "pcm-s32be":
        return J;
      case "pcm-f32":
        return J;
      case "pcm-f32be":
        return J;
      case "pcm-f64":
        return J;
      case "pcm-f64be":
        return J;
    }
  return null;
}, yo = {
  webvtt: "wvtt"
}, wo = {
  webvtt: jr
}, As = (s) => {
  P(s.length === 3);
  let e = 0;
  for (let t = 0; t < 3; t++)
    e <<= 5, e += s.charCodeAt(t) - 96;
  return e;
};
/*!
 * Copyright (c) 2026-present, Vanilagy and contributors
 *
 * This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at https://mozilla.org/MPL/2.0/.
 */
class Eo {
  constructor() {
    this.ensureMonotonicity = !1, this.trackedWrites = null, this.trackedStart = -1, this.trackedEnd = -1;
  }
  start() {
  }
  maybeTrackWrites(e) {
    if (!this.trackedWrites)
      return;
    let t = this.getPos();
    if (t < this.trackedStart) {
      if (t + e.byteLength <= this.trackedStart)
        return;
      e = e.subarray(this.trackedStart - t), t = 0;
    }
    const i = t + e.byteLength - this.trackedStart;
    let n = this.trackedWrites.byteLength;
    for (; n < i; )
      n *= 2;
    if (n !== this.trackedWrites.byteLength) {
      const r = new Uint8Array(n);
      r.set(this.trackedWrites, 0), this.trackedWrites = r;
    }
    this.trackedWrites.set(e, t - this.trackedStart), this.trackedEnd = Math.max(this.trackedEnd, t + e.byteLength);
  }
  startTrackingWrites() {
    this.trackedWrites = new Uint8Array(2 ** 10), this.trackedStart = this.getPos(), this.trackedEnd = this.trackedStart;
  }
  stopTrackingWrites() {
    if (!this.trackedWrites)
      throw new Error("Internal error: Can't get tracked writes since nothing was tracked.");
    const t = {
      data: this.trackedWrites.subarray(0, this.trackedEnd - this.trackedStart),
      start: this.trackedStart,
      end: this.trackedEnd
    };
    return this.trackedWrites = null, t;
  }
}
const et = 2 ** 16, tt = 2 ** 32;
class Fs extends Eo {
  constructor(e) {
    if (super(), this.pos = 0, this.maxPos = 0, this.target = e, this.supportsResize = "resize" in new ArrayBuffer(0), this.supportsResize)
      try {
        this.buffer = new ArrayBuffer(et, { maxByteLength: tt });
      } catch {
        this.buffer = new ArrayBuffer(et), this.supportsResize = !1;
      }
    else
      this.buffer = new ArrayBuffer(et);
    this.bytes = new Uint8Array(this.buffer);
  }
  ensureSize(e) {
    let t = this.buffer.byteLength;
    for (; t < e; )
      t *= 2;
    if (t !== this.buffer.byteLength) {
      if (t > tt)
        throw new Error(`ArrayBuffer exceeded maximum size of ${tt} bytes. Please consider using another target.`);
      if (this.supportsResize)
        this.buffer.resize(t);
      else {
        const i = new ArrayBuffer(t), n = new Uint8Array(i);
        n.set(this.bytes, 0), this.buffer = i, this.bytes = n;
      }
    }
  }
  write(e) {
    var t, i;
    this.maybeTrackWrites(e), this.ensureSize(this.pos + e.byteLength), this.bytes.set(e, this.pos), (i = (t = this.target).onwrite) == null || i.call(t, this.pos, this.pos + e.byteLength), this.pos += e.byteLength, this.maxPos = Math.max(this.maxPos, this.pos);
  }
  seek(e) {
    this.pos = e;
  }
  getPos() {
    return this.pos;
  }
  async flush() {
  }
  async finalize() {
    this.ensureSize(this.pos), this.target.buffer = this.buffer.slice(0, Math.max(this.maxPos, this.pos));
  }
  async close() {
  }
  getSlice(e, t) {
    return this.bytes.slice(e, t);
  }
}
/*!
 * Copyright (c) 2026-present, Vanilagy and contributors
 *
 * This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at https://mozilla.org/MPL/2.0/.
 */
class Et {
  constructor() {
    this._output = null, this.onwrite = null;
  }
}
class Bs extends Et {
  constructor() {
    super(...arguments), this.buffer = null;
  }
  /** @internal */
  _createWriter() {
    return new Fs(this);
  }
}
/*!
 * Copyright (c) 2026-present, Vanilagy and contributors
 *
 * This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at https://mozilla.org/MPL/2.0/.
 */
const ot = 1e3, vo = 2082844800, To = (s) => {
  const e = {}, t = s.track;
  return t.metadata.name !== void 0 && (e.name = t.metadata.name), e;
}, j = (s, e, t = !0) => {
  const i = s * e;
  return t ? Math.round(i) : i;
};
class _o extends cr {
  constructor(e, t) {
    super(e), this.auxTarget = new Bs(), this.auxWriter = this.auxTarget._createWriter(), this.auxBoxWriter = new Jt(this.auxWriter), this.mdat = null, this.ftypSize = null, this.trackDatas = [], this.allTracksKnown = gn(), this.creationTime = Math.floor(Date.now() / 1e3) + vo, this.finalizedChunks = [], this.nextFragmentNumber = 1, this.maxWrittenTimestamp = -1 / 0, this.format = t, this.writer = e._writer, this.boxWriter = new Jt(this.writer), this.isQuickTime = t instanceof _t;
    const i = this.writer instanceof Fs ? "in-memory" : !1;
    this.fastStart = t._options.fastStart ?? i, this.isFragmented = this.fastStart === "fragmented", (this.fastStart === "in-memory" || this.isFragmented) && (this.writer.ensureMonotonicity = !0), this.minimumFragmentDuration = t._options.minimumFragmentDuration ?? 1;
  }
  async start() {
    const e = await this.mutex.acquire(), t = this.output._tracks.some((i) => i.type === "video" && i.source._codec === "avc");
    if (this.format._options.onFtyp && this.writer.startTrackingWrites(), this.boxWriter.writeBox(ur({
      isQuickTime: this.isQuickTime,
      holdsAvc: t,
      fragmented: this.isFragmented
    })), this.format._options.onFtyp) {
      const { data: i, start: n } = this.writer.stopTrackingWrites();
      this.format._options.onFtyp(i, n);
    }
    if (this.ftypSize = this.writer.getPos(), this.fastStart !== "in-memory") if (this.fastStart === "reserve") {
      for (const i of this.output._tracks)
        if (i.metadata.maximumPacketCount === void 0)
          throw new Error("All tracks must specify maximumPacketCount in their metadata when using fastStart: 'reserve'.");
    } else this.isFragmented || (this.format._options.onMdat && this.writer.startTrackingWrites(), this.mdat = $e(!0), this.boxWriter.writeBox(this.mdat));
    await this.writer.flush(), e();
  }
  allTracksAreKnown() {
    for (const e of this.output._tracks)
      if (!e.source._closed && !this.trackDatas.some((t) => t.track === e))
        return !1;
    return !0;
  }
  async getMimeType() {
    await this.allTracksKnown.promise;
    const e = this.trackDatas.map((t) => t.type === "video" || t.type === "audio" ? t.info.decoderConfig.codec : {
      webvtt: "wvtt"
    }[t.track.source._codec]);
    return ir({
      isQuickTime: this.isQuickTime,
      hasVideo: this.trackDatas.some((t) => t.type === "video"),
      hasAudio: this.trackDatas.some((t) => t.type === "audio"),
      codecStrings: e
    });
  }
  getVideoTrackData(e, t, i) {
    const n = this.trackDatas.find((m) => m.track === e);
    if (n)
      return n;
    Mn(i), P(i), P(i.decoderConfig);
    const r = { ...i.decoderConfig };
    P(r.codedWidth !== void 0), P(r.codedHeight !== void 0);
    let o = !1;
    if (e.source._codec === "avc" && !r.description) {
      const m = Vn(t.data);
      if (!m)
        throw new Error("Couldn't extract an AVCDecoderConfigurationRecord from the AVC packet. Make sure the packets are in Annex B format (as specified in ITU-T-REC-H.264) when not providing a description, or provide a description (must be an AVCDecoderConfigurationRecord as specified in ISO 14496-15) and ensure the packets are in AVCC format.");
      r.description = zn(m), o = !0;
    } else if (e.source._codec === "hevc" && !r.description) {
      const m = Wn(t.data);
      if (!m)
        throw new Error("Couldn't extract an HEVCDecoderConfigurationRecord from the HEVC packet. Make sure the packets are in Annex B format (as specified in ITU-T-REC-H.265) when not providing a description, or provide a description (must be an HEVCDecoderConfigurationRecord as specified in ISO 14496-15) and ensure the packets are in HEVC format.");
      r.description = Zn(m), o = !0;
    }
    const a = vn(1 / (e.metadata.frameRate ?? 57600), 1e6).denominator, c = r.displayAspectWidth, u = r.displayAspectHeight, l = c === void 0 || u === void 0 ? { num: 1, den: 1 } : Tn({
      num: c * r.codedHeight,
      den: u * r.codedWidth
    }), d = {
      muxer: this,
      track: e,
      type: "video",
      info: {
        width: r.codedWidth,
        height: r.codedHeight,
        pixelAspectRatio: l,
        decoderConfig: r,
        requiresAnnexBTransformation: o
      },
      timescale: a,
      samples: [],
      sampleQueue: [],
      timestampProcessingQueue: [],
      timeToSampleTable: [],
      compositionTimeOffsetTable: [],
      lastTimescaleUnits: null,
      lastSample: null,
      finalizedChunks: [],
      currentChunk: null,
      compactlyCodedChunkTable: []
    };
    return this.trackDatas.push(d), this.trackDatas.sort((m, g) => m.track.id - g.track.id), this.allTracksAreKnown() && this.allTracksKnown.resolve(), d;
  }
  getAudioTrackData(e, t, i) {
    const n = this.trackDatas.find((c) => c.track === e);
    if (n)
      return n;
    In(i), P(i), P(i.decoderConfig);
    const r = { ...i.decoderConfig };
    let o = !1;
    if (e.source._codec === "aac" && !r.description) {
      const c = Qt(Ce.tempFromBytes(t.data));
      if (!c)
        throw new Error("Couldn't parse ADTS header from the AAC packet. Make sure the packets are in ADTS format (as specified in ISO 13818-7) when not providing a description, or provide a description (must be an AudioSpecificConfig as specified in ISO 14496-3) and ensure the packets are raw AAC data.");
      const u = ys[c.samplingFrequencyIndex], l = ws[c.channelConfiguration];
      if (u === void 0 || l === void 0)
        throw new Error("Invalid ADTS frame header.");
      r.description = Cn({
        objectType: c.objectType,
        sampleRate: u,
        numberOfChannels: l
      }), o = !0;
    }
    const a = {
      muxer: this,
      track: e,
      type: "audio",
      info: {
        numberOfChannels: i.decoderConfig.numberOfChannels,
        sampleRate: i.decoderConfig.sampleRate,
        decoderConfig: r,
        requiresPcmTransformation: !this.isFragmented && me.includes(e.source._codec),
        requiresAdtsStripping: o,
        firstPacket: t
      },
      timescale: r.sampleRate,
      samples: [],
      sampleQueue: [],
      timestampProcessingQueue: [],
      timeToSampleTable: [],
      compositionTimeOffsetTable: [],
      lastTimescaleUnits: null,
      lastSample: null,
      finalizedChunks: [],
      currentChunk: null,
      compactlyCodedChunkTable: []
    };
    return this.trackDatas.push(a), this.trackDatas.sort((c, u) => c.track.id - u.track.id), this.allTracksAreKnown() && this.allTracksKnown.resolve(), a;
  }
  getSubtitleTrackData(e, t) {
    const i = this.trackDatas.find((r) => r.track === e);
    if (i)
      return i;
    Un(t), P(t), P(t.config);
    const n = {
      muxer: this,
      track: e,
      type: "subtitle",
      info: {
        config: t.config
      },
      timescale: 1e3,
      // Reasonable
      samples: [],
      sampleQueue: [],
      timestampProcessingQueue: [],
      timeToSampleTable: [],
      compositionTimeOffsetTable: [],
      lastTimescaleUnits: null,
      lastSample: null,
      finalizedChunks: [],
      currentChunk: null,
      compactlyCodedChunkTable: [],
      lastCueEndTimestamp: 0,
      cueQueue: [],
      nextSourceId: 0,
      cueToSourceId: /* @__PURE__ */ new WeakMap()
    };
    return this.trackDatas.push(n), this.trackDatas.sort((r, o) => r.track.id - o.track.id), this.allTracksAreKnown() && this.allTracksKnown.resolve(), n;
  }
  async addEncodedVideoPacket(e, t, i) {
    const n = await this.mutex.acquire();
    try {
      const r = this.getVideoTrackData(e, t, i);
      let o = t.data;
      if (r.info.requiresAnnexBTransformation) {
        const u = [...ft(o)].map((l) => o.subarray(l.offset, l.offset + l.length));
        if (u.length === 0)
          throw new Error("Failed to transform packet data. Make sure all packets are provided in Annex B format, as specified in ITU-T-REC-H.264 and ITU-T-REC-H.265.");
        o = $n(u, 4);
      }
      const a = this.validateAndNormalizeTimestamp(r.track, t.timestamp, t.type === "key"), c = this.createSampleForTrack(r, o, a, t.duration, t.type);
      await this.registerSample(r, c);
    } finally {
      n();
    }
  }
  async addEncodedAudioPacket(e, t, i) {
    const n = await this.mutex.acquire();
    try {
      const r = this.getAudioTrackData(e, t, i);
      let o = t.data;
      if (r.info.requiresAdtsStripping) {
        const u = Qt(Ce.tempFromBytes(o));
        if (!u)
          throw new Error("Expected ADTS frame, didn't get one.");
        const l = u.crcCheck === null ? nr : rr;
        o = o.subarray(l);
      }
      const a = this.validateAndNormalizeTimestamp(r.track, t.timestamp, t.type === "key"), c = this.createSampleForTrack(r, o, a, t.duration, t.type);
      r.info.requiresPcmTransformation && await this.maybePadWithSilence(r, a), await this.registerSample(r, c);
    } finally {
      n();
    }
  }
  async maybePadWithSilence(e, t) {
    const i = he(e.samples), n = i ? i.timestamp + i.duration : 0, r = t - n, o = j(r, e.timescale);
    if (o > 0) {
      const { sampleSize: a, silentValue: c } = Fe(e.info.decoderConfig.codec), u = o * e.info.numberOfChannels, l = new Uint8Array(a * u).fill(c), d = this.createSampleForTrack(e, new Uint8Array(l.buffer), n, r, "key");
      await this.registerSample(e, d);
    }
  }
  async addSubtitleCue(e, t, i) {
    const n = await this.mutex.acquire();
    try {
      const r = this.getSubtitleTrackData(e, i);
      this.validateAndNormalizeTimestamp(r.track, t.timestamp, !0), e.source._codec === "webvtt" && (r.cueQueue.push(t), await this.processWebVTTCues(r, t.timestamp));
    } finally {
      n();
    }
  }
  async processWebVTTCues(e, t) {
    for (; e.cueQueue.length > 0; ) {
      const i = /* @__PURE__ */ new Set([]);
      for (const u of e.cueQueue)
        P(u.timestamp <= t), P(e.lastCueEndTimestamp <= u.timestamp + u.duration), i.add(Math.max(u.timestamp, e.lastCueEndTimestamp)), i.add(u.timestamp + u.duration);
      const n = [...i].sort((u, l) => u - l), r = n[0], o = n[1] ?? r;
      if (t < o)
        break;
      if (e.lastCueEndTimestamp < r) {
        this.auxWriter.seek(0);
        const u = ao();
        this.auxBoxWriter.writeBox(u);
        const l = this.auxWriter.getSlice(0, this.auxWriter.getPos()), d = this.createSampleForTrack(e, l, e.lastCueEndTimestamp, r - e.lastCueEndTimestamp, "key");
        await this.registerSample(e, d), e.lastCueEndTimestamp = r;
      }
      this.auxWriter.seek(0);
      for (let u = 0; u < e.cueQueue.length; u++) {
        const l = e.cueQueue[u];
        if (l.timestamp >= o)
          break;
        Zt.lastIndex = 0;
        const d = Zt.test(l.text), m = l.timestamp + l.duration;
        let g = e.cueToSourceId.get(l);
        if (g === void 0 && o < m && (g = e.nextSourceId++, e.cueToSourceId.set(l, g)), l.notes) {
          const v = lo(l.notes);
          this.auxBoxWriter.writeBox(v);
        }
        const E = co(l.text, d ? r : null, l.identifier ?? null, l.settings ?? null, g ?? null);
        this.auxBoxWriter.writeBox(E), m === o && e.cueQueue.splice(u--, 1);
      }
      const a = this.auxWriter.getSlice(0, this.auxWriter.getPos()), c = this.createSampleForTrack(e, a, r, o - r, "key");
      await this.registerSample(e, c), e.lastCueEndTimestamp = o;
    }
  }
  createSampleForTrack(e, t, i, n, r) {
    return {
      timestamp: i,
      decodeTimestamp: i,
      // This may be refined later
      duration: n,
      data: t,
      size: t.byteLength,
      type: r,
      timescaleUnitsToNextSample: j(n, e.timescale)
      // Will be refined
    };
  }
  processTimestamps(e, t) {
    if (e.timestampProcessingQueue.length === 0)
      return;
    if (e.type === "audio" && e.info.requiresPcmTransformation) {
      let n = 0;
      for (let r = 0; r < e.timestampProcessingQueue.length; r++) {
        const o = e.timestampProcessingQueue[r], a = j(o.duration, e.timescale);
        n += a;
      }
      if (e.timeToSampleTable.length === 0)
        e.timeToSampleTable.push({
          sampleCount: n,
          sampleDelta: 1
        });
      else {
        const r = he(e.timeToSampleTable);
        r.sampleCount += n;
      }
      e.timestampProcessingQueue.length = 0;
      return;
    }
    const i = e.timestampProcessingQueue.map((n) => n.timestamp).sort((n, r) => n - r);
    for (let n = 0; n < e.timestampProcessingQueue.length; n++) {
      const r = e.timestampProcessingQueue[n];
      r.decodeTimestamp = i[n], !this.isFragmented && e.lastTimescaleUnits === null && (r.decodeTimestamp = 0);
      const o = j(r.timestamp - r.decodeTimestamp, e.timescale), a = j(r.duration, e.timescale);
      if (e.lastTimescaleUnits !== null) {
        P(e.lastSample);
        const c = j(r.decodeTimestamp, e.timescale, !1), u = Math.round(c - e.lastTimescaleUnits);
        if (P(u >= 0), e.lastTimescaleUnits += u, e.lastSample.timescaleUnitsToNextSample = u, !this.isFragmented) {
          let l = he(e.timeToSampleTable);
          if (P(l), l.sampleCount === 1) {
            l.sampleDelta = u;
            const m = e.timeToSampleTable[e.timeToSampleTable.length - 2];
            m && m.sampleDelta === u && (m.sampleCount++, e.timeToSampleTable.pop(), l = m);
          } else l.sampleDelta !== u && (l.sampleCount--, e.timeToSampleTable.push(l = {
            sampleCount: 1,
            sampleDelta: u
          }));
          l.sampleDelta === a ? l.sampleCount++ : e.timeToSampleTable.push({
            sampleCount: 1,
            sampleDelta: a
          });
          const d = he(e.compositionTimeOffsetTable);
          P(d), d.sampleCompositionTimeOffset === o ? d.sampleCount++ : e.compositionTimeOffsetTable.push({
            sampleCount: 1,
            sampleCompositionTimeOffset: o
          });
        }
      } else
        e.lastTimescaleUnits = j(r.decodeTimestamp, e.timescale, !1), this.isFragmented || (e.timeToSampleTable.push({
          sampleCount: 1,
          sampleDelta: a
        }), e.compositionTimeOffsetTable.push({
          sampleCount: 1,
          sampleCompositionTimeOffset: o
        }));
      e.lastSample = r;
    }
    if (e.timestampProcessingQueue.length = 0, P(e.lastSample), P(e.lastTimescaleUnits !== null), t !== void 0 && e.lastSample.timescaleUnitsToNextSample === 0) {
      P(t.type === "key");
      const n = j(t.timestamp, e.timescale, !1), r = Math.round(n - e.lastTimescaleUnits);
      e.lastSample.timescaleUnitsToNextSample = r;
    }
  }
  async registerSample(e, t) {
    t.type === "key" && this.processTimestamps(e, t), e.timestampProcessingQueue.push(t), this.isFragmented ? (e.sampleQueue.push(t), await this.interleaveSamples()) : this.fastStart === "reserve" ? await this.registerSampleFastStartReserve(e, t) : await this.addSampleToTrack(e, t);
  }
  async addSampleToTrack(e, t) {
    if (!this.isFragmented && (e.samples.push(t), this.fastStart === "reserve")) {
      const n = e.track.metadata.maximumPacketCount;
      if (P(n !== void 0), e.samples.length > n)
        throw new Error(`Track #${e.track.id} has already reached the maximum packet count (${n}). Either add less packets or increase the maximum packet count.`);
    }
    let i = !1;
    if (!e.currentChunk)
      i = !0;
    else {
      e.currentChunk.startTimestamp = Math.min(e.currentChunk.startTimestamp, t.timestamp);
      const n = t.timestamp - e.currentChunk.startTimestamp;
      if (this.isFragmented) {
        const r = this.trackDatas.every((o) => {
          if (e === o)
            return t.type === "key";
          const a = o.sampleQueue[0];
          return a ? a.type === "key" : o.track.source._closed;
        });
        n >= this.minimumFragmentDuration && r && t.timestamp > this.maxWrittenTimestamp && (i = !0, await this.finalizeFragment());
      } else
        i = n >= 0.5;
    }
    i && (e.currentChunk && await this.finalizeCurrentChunk(e), e.currentChunk = {
      startTimestamp: t.timestamp,
      samples: [],
      offset: null,
      moofOffset: null
    }), P(e.currentChunk), e.currentChunk.samples.push(t), this.isFragmented && (this.maxWrittenTimestamp = Math.max(this.maxWrittenTimestamp, t.timestamp));
  }
  async finalizeCurrentChunk(e) {
    if (P(!this.isFragmented), !e.currentChunk)
      return;
    e.finalizedChunks.push(e.currentChunk), this.finalizedChunks.push(e.currentChunk);
    let t = e.currentChunk.samples.length;
    if (e.type === "audio" && e.info.requiresPcmTransformation && (t = e.currentChunk.samples.reduce((i, n) => i + j(n.duration, e.timescale), 0)), (e.compactlyCodedChunkTable.length === 0 || he(e.compactlyCodedChunkTable).samplesPerChunk !== t) && e.compactlyCodedChunkTable.push({
      firstChunk: e.finalizedChunks.length,
      // 1-indexed
      samplesPerChunk: t
    }), this.fastStart === "in-memory") {
      e.currentChunk.offset = 0;
      return;
    }
    e.currentChunk.offset = this.writer.getPos();
    for (const i of e.currentChunk.samples)
      P(i.data), this.writer.write(i.data), i.data = null;
    await this.writer.flush();
  }
  async interleaveSamples(e = !1) {
    if (P(this.isFragmented), !(!e && !this.allTracksAreKnown()))
      e: for (; ; ) {
        let t = null, i = 1 / 0;
        for (const r of this.trackDatas) {
          if (!e && r.sampleQueue.length === 0 && !r.track.source._closed)
            break e;
          r.sampleQueue.length > 0 && r.sampleQueue[0].timestamp < i && (t = r, i = r.sampleQueue[0].timestamp);
        }
        if (!t)
          break;
        const n = t.sampleQueue.shift();
        await this.addSampleToTrack(t, n);
      }
  }
  async finalizeFragment(e = !0) {
    P(this.isFragmented);
    const t = this.nextFragmentNumber++;
    if (t === 1) {
      this.format._options.onMoov && this.writer.startTrackingWrites();
      const g = we(this);
      if (this.boxWriter.writeBox(g), this.format._options.onMoov) {
        const { data: E, start: v } = this.writer.stopTrackingWrites();
        this.format._options.onMoov(E, v);
      }
    }
    const i = this.trackDatas.filter((g) => g.currentChunk), n = ts(t, i), r = this.writer.getPos(), o = r + this.boxWriter.measureBox(n);
    let a = o + qe, c = 1 / 0;
    for (const g of i) {
      g.currentChunk.offset = a, g.currentChunk.moofOffset = r;
      for (const E of g.currentChunk.samples)
        a += E.size;
      c = Math.min(c, g.currentChunk.startTimestamp);
    }
    const u = a - o, l = u >= 2 ** 32;
    if (l)
      for (const g of i)
        g.currentChunk.offset += qt - qe;
    this.format._options.onMoof && this.writer.startTrackingWrites();
    const d = ts(t, i);
    if (this.boxWriter.writeBox(d), this.format._options.onMoof) {
      const { data: g, start: E } = this.writer.stopTrackingWrites();
      this.format._options.onMoof(g, E, c);
    }
    P(this.writer.getPos() === o), this.format._options.onMdat && this.writer.startTrackingWrites();
    const m = $e(l);
    m.size = u, this.boxWriter.writeBox(m), this.writer.seek(o + (l ? qt : qe));
    for (const g of i)
      for (const E of g.currentChunk.samples)
        this.writer.write(E.data), E.data = null;
    if (this.format._options.onMdat) {
      const { data: g, start: E } = this.writer.stopTrackingWrites();
      this.format._options.onMdat(g, E);
    }
    for (const g of i)
      g.finalizedChunks.push(g.currentChunk), this.finalizedChunks.push(g.currentChunk), g.currentChunk = null;
    e && await this.writer.flush();
  }
  async registerSampleFastStartReserve(e, t) {
    if (this.allTracksAreKnown()) {
      if (!this.mdat) {
        const i = we(this), r = this.boxWriter.measureBox(i) + this.computeSampleTableSizeUpperBound() + 4096;
        P(this.ftypSize !== null), this.writer.seek(this.ftypSize + r), this.format._options.onMdat && this.writer.startTrackingWrites(), this.mdat = $e(!0), this.boxWriter.writeBox(this.mdat);
        for (const o of this.trackDatas) {
          for (const a of o.sampleQueue)
            await this.addSampleToTrack(o, a);
          o.sampleQueue.length = 0;
        }
      }
      await this.addSampleToTrack(e, t);
    } else
      e.sampleQueue.push(t);
  }
  computeSampleTableSizeUpperBound() {
    P(this.fastStart === "reserve");
    let e = 0;
    for (const t of this.trackDatas) {
      const i = t.track.metadata.maximumPacketCount;
      P(i !== void 0), e += 8 * Math.ceil(2 / 3 * i), e += 4 * i, e += 8 * Math.ceil(2 / 3 * i), e += 12 * Math.ceil(2 / 3 * i), e += 4 * i, e += 8 * i;
    }
    return e;
  }
  // eslint-disable-next-line @typescript-eslint/no-misused-promises
  async onTrackClose(e) {
    const t = await this.mutex.acquire(), i = this.trackDatas.find((n) => n.track === e);
    i && (i.type === "subtitle" && e.source._codec === "webvtt" && await this.processWebVTTCues(i, 1 / 0), this.processTimestamps(i)), this.allTracksAreKnown() && this.allTracksKnown.resolve(), this.isFragmented && await this.interleaveSamples(), t();
  }
  /** Finalizes the file, making it ready for use. Must be called after all video and audio chunks have been added. */
  async finalize() {
    const e = await this.mutex.acquire();
    this.allTracksKnown.resolve();
    for (const t of this.trackDatas)
      t.type === "subtitle" && t.track.source._codec === "webvtt" && await this.processWebVTTCues(t, 1 / 0), this.processTimestamps(t);
    if (this.isFragmented)
      await this.interleaveSamples(!0), await this.finalizeFragment(!1);
    else
      for (const t of this.trackDatas)
        await this.finalizeCurrentChunk(t);
    if (this.fastStart === "in-memory") {
      this.mdat = $e(!1);
      let t;
      for (let n = 0; n < 2; n++) {
        const r = we(this), o = this.boxWriter.measureBox(r);
        t = this.boxWriter.measureBox(this.mdat);
        let a = this.writer.getPos() + o + t;
        for (const c of this.finalizedChunks) {
          c.offset = a;
          for (const { data: u } of c.samples)
            P(u), a += u.byteLength, t += u.byteLength;
        }
        if (a < 2 ** 32)
          break;
        t >= 2 ** 32 && (this.mdat.largeSize = !0);
      }
      this.format._options.onMoov && this.writer.startTrackingWrites();
      const i = we(this);
      if (this.boxWriter.writeBox(i), this.format._options.onMoov) {
        const { data: n, start: r } = this.writer.stopTrackingWrites();
        this.format._options.onMoov(n, r);
      }
      this.format._options.onMdat && this.writer.startTrackingWrites(), this.mdat.size = t, this.boxWriter.writeBox(this.mdat);
      for (const n of this.finalizedChunks)
        for (const r of n.samples)
          P(r.data), this.writer.write(r.data), r.data = null;
      if (this.format._options.onMdat) {
        const { data: n, start: r } = this.writer.stopTrackingWrites();
        this.format._options.onMdat(n, r);
      }
    } else if (this.isFragmented) {
      const t = this.writer.getPos(), i = no(this.trackDatas);
      this.boxWriter.writeBox(i);
      const n = this.writer.getPos() - t;
      this.writer.seek(this.writer.getPos() - 4), this.boxWriter.writeU32(n);
    } else {
      P(this.mdat);
      const t = this.boxWriter.offsets.get(this.mdat);
      P(t !== void 0);
      const i = this.writer.getPos() - t;
      if (this.mdat.size = i, this.mdat.largeSize = i >= 2 ** 32, this.boxWriter.patchBox(this.mdat), this.format._options.onMdat) {
        const { data: r, start: o } = this.writer.stopTrackingWrites();
        this.format._options.onMdat(r, o);
      }
      const n = we(this);
      if (this.fastStart === "reserve") {
        P(this.ftypSize !== null), this.writer.seek(this.ftypSize), this.format._options.onMoov && this.writer.startTrackingWrites(), this.boxWriter.writeBox(n);
        const r = this.boxWriter.offsets.get(this.mdat) - this.writer.getPos();
        this.boxWriter.writeBox(dr(r));
      } else
        this.format._options.onMoov && this.writer.startTrackingWrites(), this.boxWriter.writeBox(n);
      if (this.format._options.onMoov) {
        const { data: r, start: o } = this.writer.stopTrackingWrites();
        this.format._options.onMoov(r, o);
      }
    }
    e();
  }
}
/*!
 * Copyright (c) 2026-present, Vanilagy and contributors
 *
 * This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at https://mozilla.org/MPL/2.0/.
 */
class vt {
  /** Returns a list of video codecs that this output format can contain. */
  getSupportedVideoCodecs() {
    return this.getSupportedCodecs().filter((e) => ge.includes(e));
  }
  /** Returns a list of audio codecs that this output format can contain. */
  getSupportedAudioCodecs() {
    return this.getSupportedCodecs().filter((e) => Te.includes(e));
  }
  /** Returns a list of subtitle codecs that this output format can contain. */
  getSupportedSubtitleCodecs() {
    return this.getSupportedCodecs().filter((e) => _e.includes(e));
  }
  /** @internal */
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  _codecUnsupportedHint(e) {
    return "";
  }
}
class Tt extends vt {
  /** Internal constructor. */
  constructor(e = {}) {
    if (!e || typeof e != "object")
      throw new TypeError("options must be an object.");
    if (e.fastStart !== void 0 && ![!1, "in-memory", "reserve", "fragmented"].includes(e.fastStart))
      throw new TypeError("options.fastStart, when provided, must be false, 'in-memory', 'reserve', or 'fragmented'.");
    if (e.minimumFragmentDuration !== void 0 && (!Number.isFinite(e.minimumFragmentDuration) || e.minimumFragmentDuration < 0))
      throw new TypeError("options.minimumFragmentDuration, when provided, must be a non-negative number.");
    if (e.onFtyp !== void 0 && typeof e.onFtyp != "function")
      throw new TypeError("options.onFtyp, when provided, must be a function.");
    if (e.onMoov !== void 0 && typeof e.onMoov != "function")
      throw new TypeError("options.onMoov, when provided, must be a function.");
    if (e.onMdat !== void 0 && typeof e.onMdat != "function")
      throw new TypeError("options.onMdat, when provided, must be a function.");
    if (e.onMoof !== void 0 && typeof e.onMoof != "function")
      throw new TypeError("options.onMoof, when provided, must be a function.");
    if (e.metadataFormat !== void 0 && !["mdir", "mdta", "udta", "auto"].includes(e.metadataFormat))
      throw new TypeError("options.metadataFormat, when provided, must be either 'auto', 'mdir', 'mdta', or 'udta'.");
    super(), this._options = e;
  }
  getSupportedTrackCounts() {
    return {
      video: { min: 0, max: 4294967295 },
      audio: { min: 0, max: 4294967295 },
      subtitle: { min: 0, max: 4294967295 },
      total: { min: 1, max: 4294967295 }
    };
  }
  get supportsVideoRotationMetadata() {
    return !0;
  }
  get supportsTimestampedMediaData() {
    return !0;
  }
  /** @internal */
  _createMuxer(e) {
    return new _o(e, this);
  }
}
class Ps extends Tt {
  /** Creates a new {@link Mp4OutputFormat} configured with the specified `options`. */
  constructor(e) {
    super(e);
  }
  /** @internal */
  get _name() {
    return "MP4";
  }
  get fileExtension() {
    return ".mp4";
  }
  get mimeType() {
    return "video/mp4";
  }
  getSupportedCodecs() {
    return [
      ...ge,
      ...pt,
      // These are supported via ISO/IEC 23003-5:
      "pcm-s16",
      "pcm-s16be",
      "pcm-s24",
      "pcm-s24be",
      "pcm-s32",
      "pcm-s32be",
      "pcm-f32",
      "pcm-f32be",
      "pcm-f64",
      "pcm-f64be",
      ..._e
    ];
  }
  /** @internal */
  _codecUnsupportedHint(e) {
    return new _t().getSupportedCodecs().includes(e) ? " Switching to MOV will grant support for this codec." : "";
  }
}
class _t extends Tt {
  /** Creates a new {@link MovOutputFormat} configured with the specified `options`. */
  constructor(e) {
    super(e);
  }
  /** @internal */
  get _name() {
    return "MOV";
  }
  get fileExtension() {
    return ".mov";
  }
  get mimeType() {
    return "video/quicktime";
  }
  getSupportedCodecs() {
    return [
      ...ge,
      ...Te
    ];
  }
  /** @internal */
  _codecUnsupportedHint(e) {
    return new Ps().getSupportedCodecs().includes(e) ? " Switching to MP4 will grant support for this codec." : "";
  }
}
/*!
 * Copyright (c) 2026-present, Vanilagy and contributors
 *
 * This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at https://mozilla.org/MPL/2.0/.
 */
class He {
  constructor() {
    this._connectedTrack = null, this._closingPromise = null, this._closed = !1, this._timestampOffset = 0;
  }
  /** @internal */
  _ensureValidAdd() {
    if (!this._connectedTrack)
      throw new Error("Source is not connected to an output track.");
    if (this._connectedTrack.output.state === "canceled")
      throw new Error("Output has been canceled.");
    if (this._connectedTrack.output.state === "finalizing" || this._connectedTrack.output.state === "finalized")
      throw new Error("Output has been finalized.");
    if (this._connectedTrack.output.state === "pending")
      throw new Error("Output has not started.");
    if (this._closed)
      throw new Error("Source is closed.");
  }
  /** @internal */
  async _start() {
  }
  /** @internal */
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  async _flushAndClose(e) {
  }
  /**
   * Closes this source. This prevents future samples from being added and signals to the output file that no further
   * samples will come in for this track. Calling `.close()` is optional but recommended after adding the
   * last sample - for improved performance and reduced memory usage.
   */
  close() {
    if (this._closingPromise)
      return;
    const e = this._connectedTrack;
    if (!e)
      throw new Error("Cannot call close without connecting the source to an output track.");
    if (e.output.state === "pending")
      throw new Error("Cannot call close before output has been started.");
    this._closingPromise = (async () => {
      await this._flushAndClose(!1), this._closed = !0, !(e.output.state === "finalizing" || e.output.state === "finalized") && e.output._muxer.onTrackClose(e);
    })();
  }
  /** @internal */
  async _flushOrWaitForOngoingClose(e) {
    return this._closingPromise ?? (this._closingPromise = (async () => {
      await this._flushAndClose(e), this._closed = !0;
    })());
  }
}
class xt extends He {
  /** Internal constructor. */
  constructor(e) {
    if (super(), this._connectedTrack = null, !ge.includes(e))
      throw new TypeError(`Invalid video codec '${e}'. Must be one of: ${ge.join(", ")}.`);
    this._codec = e;
  }
}
class xo extends xt {
  /** Creates a new {@link EncodedVideoPacketSource} whose packets are encoded using `codec`. */
  constructor(e) {
    super(e);
  }
  /**
   * Adds an encoded packet to the output video track. Packets must be added in *decode order*, while a packet's
   * timestamp must be its *presentation timestamp*. B-frames are handled automatically.
   *
   * @param meta - Additional metadata from the encoder. You should pass this for the first call, including a valid
   * decoder config.
   *
   * @returns A Promise that resolves once the output is ready to receive more samples. You should await this Promise
   * to respect writer and encoder backpressure.
   */
  add(e, t) {
    if (!(e instanceof xe))
      throw new TypeError("packet must be an EncodedPacket.");
    if (e.isMetadataOnly)
      throw new TypeError("Metadata-only packets cannot be added.");
    if (t !== void 0 && (!t || typeof t != "object"))
      throw new TypeError("meta, when provided, must be an object.");
    return this._ensureValidAdd(), this._connectedTrack.output._muxer.addEncodedVideoPacket(this._connectedTrack, e, t);
  }
}
class Ms extends He {
  /** Internal constructor. */
  constructor(e) {
    if (super(), this._connectedTrack = null, !Te.includes(e))
      throw new TypeError(`Invalid audio codec '${e}'. Must be one of: ${Te.join(", ")}.`);
    this._codec = e;
  }
}
class Ls extends He {
  /** Internal constructor. */
  constructor(e) {
    if (super(), this._connectedTrack = null, !_e.includes(e))
      throw new TypeError(`Invalid subtitle codec '${e}'. Must be one of: ${_e.join(", ")}.`);
    this._codec = e;
  }
}
/*!
 * Copyright (c) 2026-present, Vanilagy and contributors
 *
 * This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at https://mozilla.org/MPL/2.0/.
 */
const Is = ["video", "audio", "subtitle"], st = (s) => {
  if (!s || typeof s != "object")
    throw new TypeError("metadata must be an object.");
  if (s.languageCode !== void 0 && !En(s.languageCode))
    throw new TypeError("metadata.languageCode, when provided, must be a three-letter, ISO 639-2/T language code.");
  if (s.name !== void 0 && typeof s.name != "string")
    throw new TypeError("metadata.name, when provided, must be a string.");
  if (s.disposition !== void 0 && xn(s.disposition), s.maximumPacketCount !== void 0 && (!Number.isInteger(s.maximumPacketCount) || s.maximumPacketCount < 0))
    throw new TypeError("metadata.maximumPacketCount, when provided, must be a non-negative integer.");
};
class Co {
  /**
   * Creates a new instance of {@link Output} which can then be used to create a new media file according to the
   * specified {@link OutputOptions}.
   */
  constructor(e) {
    if (this.state = "pending", this._tracks = [], this._startPromise = null, this._cancelPromise = null, this._finalizePromise = null, this._mutex = new ps(), this._metadataTags = {}, !e || typeof e != "object")
      throw new TypeError("options must be an object.");
    if (!(e.format instanceof vt))
      throw new TypeError("options.format must be an OutputFormat.");
    if (!(e.target instanceof Et))
      throw new TypeError("options.target must be a Target.");
    if (e.target._output)
      throw new Error("Target is already used for another output.");
    e.target._output = this, this.format = e.format, this.target = e.target, this._writer = e.target._createWriter(), this._muxer = e.format._createMuxer(this);
  }
  /** Adds a video track to the output with the given source. Can only be called before the output is started. */
  addVideoTrack(e, t = {}) {
    if (!(e instanceof xt))
      throw new TypeError("source must be a VideoSource.");
    if (st(t), t.rotation !== void 0 && ![0, 90, 180, 270].includes(t.rotation))
      throw new TypeError(`Invalid video rotation: ${t.rotation}. Has to be 0, 90, 180 or 270.`);
    if (!this.format.supportsVideoRotationMetadata && t.rotation)
      throw new Error(`${this.format._name} does not support video rotation metadata.`);
    if (t.frameRate !== void 0 && (!Number.isFinite(t.frameRate) || t.frameRate <= 0))
      throw new TypeError(`Invalid video frame rate: ${t.frameRate}. Must be a positive number.`);
    this._addTrack("video", e, t);
  }
  /** Adds an audio track to the output with the given source. Can only be called before the output is started. */
  addAudioTrack(e, t = {}) {
    if (!(e instanceof Ms))
      throw new TypeError("source must be an AudioSource.");
    st(t), this._addTrack("audio", e, t);
  }
  /** Adds a subtitle track to the output with the given source. Can only be called before the output is started. */
  addSubtitleTrack(e, t = {}) {
    if (!(e instanceof Ls))
      throw new TypeError("source must be a SubtitleSource.");
    st(t), this._addTrack("subtitle", e, t);
  }
  /**
   * Sets descriptive metadata tags about the media file, such as title, author, date, or cover art. When called
   * multiple times, only the metadata from the last call will be used.
   *
   * Can only be called before the output is started.
   */
  setMetadataTags(e) {
    if (_n(e), this.state !== "pending")
      throw new Error("Cannot set metadata tags after output has been started or canceled.");
    this._metadataTags = e;
  }
  /** @internal */
  _addTrack(e, t, i) {
    if (this.state !== "pending")
      throw new Error("Cannot add track after output has been started or canceled.");
    if (t._connectedTrack)
      throw new Error("Source is already used for a track.");
    const n = this.format.getSupportedTrackCounts(), r = this._tracks.reduce((u, l) => u + (l.type === e ? 1 : 0), 0), o = n[e].max;
    if (r === o)
      throw new Error(o === 0 ? `${this.format._name} does not support ${e} tracks.` : `${this.format._name} does not support more than ${o} ${e} track${o === 1 ? "" : "s"}.`);
    const a = n.total.max;
    if (this._tracks.length === a)
      throw new Error(`${this.format._name} does not support more than ${a} tracks${a === 1 ? "" : "s"} in total.`);
    const c = {
      id: this._tracks.length + 1,
      output: this,
      type: e,
      source: t,
      metadata: i
    };
    if (c.type === "video") {
      const u = this.format.getSupportedVideoCodecs();
      if (u.length === 0)
        throw new Error(`${this.format._name} does not support video tracks.` + this.format._codecUnsupportedHint(c.source._codec));
      if (!u.includes(c.source._codec))
        throw new Error(`Codec '${c.source._codec}' cannot be contained within ${this.format._name}. Supported video codecs are: ${u.map((l) => `'${l}'`).join(", ")}.` + this.format._codecUnsupportedHint(c.source._codec));
    } else if (c.type === "audio") {
      const u = this.format.getSupportedAudioCodecs();
      if (u.length === 0)
        throw new Error(`${this.format._name} does not support audio tracks.` + this.format._codecUnsupportedHint(c.source._codec));
      if (!u.includes(c.source._codec))
        throw new Error(`Codec '${c.source._codec}' cannot be contained within ${this.format._name}. Supported audio codecs are: ${u.map((l) => `'${l}'`).join(", ")}.` + this.format._codecUnsupportedHint(c.source._codec));
    } else if (c.type === "subtitle") {
      const u = this.format.getSupportedSubtitleCodecs();
      if (u.length === 0)
        throw new Error(`${this.format._name} does not support subtitle tracks.` + this.format._codecUnsupportedHint(c.source._codec));
      if (!u.includes(c.source._codec))
        throw new Error(`Codec '${c.source._codec}' cannot be contained within ${this.format._name}. Supported subtitle codecs are: ${u.map((l) => `'${l}'`).join(", ")}.` + this.format._codecUnsupportedHint(c.source._codec));
    }
    this._tracks.push(c), t._connectedTrack = c;
  }
  /**
   * Starts the creation of the output file. This method should be called after all tracks have been added. Only after
   * the output has started can media samples be added to the tracks.
   *
   * @returns A promise that resolves when the output has successfully started and is ready to receive media samples.
   */
  async start() {
    const e = this.format.getSupportedTrackCounts();
    for (const i of Is) {
      const n = this._tracks.reduce((o, a) => o + (a.type === i ? 1 : 0), 0), r = e[i].min;
      if (n < r)
        throw new Error(r === e[i].max ? `${this.format._name} requires exactly ${r} ${i} track${r === 1 ? "" : "s"}.` : `${this.format._name} requires at least ${r} ${i} track${r === 1 ? "" : "s"}.`);
    }
    const t = e.total.min;
    if (this._tracks.length < t)
      throw new Error(t === e.total.max ? `${this.format._name} requires exactly ${t} track${t === 1 ? "" : "s"}.` : `${this.format._name} requires at least ${t} track${t === 1 ? "" : "s"}.`);
    if (this.state === "canceled")
      throw new Error("Output has been canceled.");
    return this._startPromise ? (console.warn("Output has already been started."), this._startPromise) : this._startPromise = (async () => {
      this.state = "started", this._writer.start();
      const i = await this._mutex.acquire();
      await this._muxer.start();
      const n = this._tracks.map((r) => r.source._start());
      await Promise.all(n), i();
    })();
  }
  /**
   * Resolves with the full MIME type of the output file, including track codecs.
   *
   * The returned promise will resolve only once the precise codec strings of all tracks are known.
   */
  getMimeType() {
    return this._muxer.getMimeType();
  }
  /**
   * Cancels the creation of the output file, releasing internal resources like encoders and preventing further
   * samples from being added.
   *
   * @returns A promise that resolves once all internal resources have been released.
   */
  async cancel() {
    if (this._cancelPromise)
      return console.warn("Output has already been canceled."), this._cancelPromise;
    if (this.state === "finalizing" || this.state === "finalized") {
      console.warn("Output has already been finalized.");
      return;
    }
    return this._cancelPromise = (async () => {
      this.state = "canceled";
      const e = await this._mutex.acquire(), t = this._tracks.map((i) => i.source._flushOrWaitForOngoingClose(!0));
      await Promise.all(t), await this._writer.close(), e();
    })();
  }
  /**
   * Finalizes the output file. This method must be called after all media samples across all tracks have been added.
   * Once the Promise returned by this method completes, the output file is ready.
   */
  async finalize() {
    if (this.state === "pending")
      throw new Error("Cannot finalize before starting.");
    if (this.state === "canceled")
      throw new Error("Cannot finalize after canceling.");
    return this._finalizePromise ? (console.warn("Output has already been finalized."), this._finalizePromise) : this._finalizePromise = (async () => {
      this.state = "finalizing";
      const e = await this._mutex.acquire(), t = this._tracks.map((i) => i.source._flushOrWaitForOngoingClose(!1));
      await Promise.all(t), await this._muxer.finalize(), await this._writer.flush(), await this._writer.finalize(), this.state = "finalized", e();
    })();
  }
}
/*!
 * Copyright (c) 2026-present, Vanilagy and contributors
 *
 * This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at https://mozilla.org/MPL/2.0/.
 */
const Us = Symbol.for("mediabunny loaded");
globalThis[Us] && console.error(`[WARNING]
Mediabunny was loaded twice. This will likely cause Mediabunny not to work correctly. Check if multiple dependencies are importing different versions of Mediabunny, or if something is being bundled incorrectly.`);
globalThis[Us] = !0;
const So = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  ALL_TRACK_TYPES: Is,
  AUDIO_CODECS: Te,
  AttachedFile: bs,
  AudioSource: Ms,
  BufferTarget: Bs,
  EncodedPacket: xe,
  EncodedVideoPacketSource: xo,
  IsobmffOutputFormat: Tt,
  MediaSource: He,
  MovOutputFormat: _t,
  Mp4OutputFormat: Ps,
  NON_PCM_AUDIO_CODECS: pt,
  Output: Co,
  OutputFormat: vt,
  PCM_AUDIO_CODECS: me,
  RichImageData: mt,
  SUBTITLE_CODECS: _e,
  SubtitleSource: Ls,
  Target: Et,
  VIDEO_CODECS: ge,
  VideoSource: xt
}, Symbol.toStringTag, { value: "Module" }));
class Ro {
  constructor(e, t) {
    h(this, "container");
    h(this, "project");
    h(this, "recompileHandler", null);
    h(this, "tabBar");
    h(this, "contentArea");
    h(this, "copyButton");
    h(this, "recompileButton");
    h(this, "errorDisplay");
    h(this, "tabs", []);
    h(this, "activeTabIndex", 0);
    // Editor instance (null if not in editor mode or viewing image)
    h(this, "editorInstance", null);
    // Track modified sources (passName -> modified source)
    h(this, "modifiedSources", /* @__PURE__ */ new Map());
    // Stored for cleanup in dispose()
    h(this, "keydownHandler", null);
    this.container = e, this.project = t, this.buildTabs(), this.tabBar = document.createElement("div"), this.tabBar.className = "editor-tab-bar", this.buildTabBar(), this.contentArea = document.createElement("div"), this.contentArea.className = "editor-content-area", this.copyButton = document.createElement("button"), this.copyButton.className = "editor-copy-button", this.copyButton.innerHTML = `
      <svg width="16" height="16" viewBox="0 0 16 16" fill="currentColor">
        <path d="M4 2a2 2 0 0 1 2-2h8a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V2z" opacity="0.4"/>
        <path d="M2 5a2 2 0 0 0-2 2v7a2 2 0 0 0 2 2h7a2 2 0 0 0 2-2V7a2 2 0 0 0-2-2H2zm0 1h7a1 1 0 0 1 1 1v7a1 1 0 0 1-1 1H2a1 1 0 0 1-1-1V7a1 1 0 0 1 1-1z"/>
      </svg>
    `, this.copyButton.title = "Copy code to clipboard", this.copyButton.addEventListener("click", () => this.copyToClipboard()), this.recompileButton = document.createElement("button"), this.recompileButton.className = "editor-recompile-button", this.recompileButton.innerHTML = `
      <svg width="14" height="14" viewBox="0 0 16 16" fill="currentColor">
        <path d="M4 3v10l8-5-8-5z"/>
      </svg>
      Recompile
    `, this.recompileButton.title = "Recompile shader (Ctrl+Enter)", this.recompileButton.addEventListener("click", () => this.recompile()), this.errorDisplay = document.createElement("div"), this.errorDisplay.className = "editor-error-display", this.errorDisplay.style.display = "none";
    const i = document.createElement("div");
    i.className = "editor-toolbar", i.appendChild(this.tabBar), i.appendChild(this.copyButton), i.appendChild(this.recompileButton), this.container.appendChild(i), this.container.appendChild(this.contentArea), this.container.appendChild(this.errorDisplay), this.setupKeyboardShortcut(), this.showTab(0);
  }
  setRecompileHandler(e) {
    this.recompileHandler = e;
  }
  dispose() {
    this.keydownHandler && (this.container.removeEventListener("keydown", this.keydownHandler), this.keydownHandler = null), this.editorInstance && (this.editorInstance.destroy(), this.editorInstance = null), this.container.innerHTML = "";
  }
  buildTabs() {
    this.tabs = [], this.project.commonSource && this.tabs.push({
      kind: "code",
      name: "common.glsl",
      passName: "common",
      source: this.project.commonSource
    });
    const e = [
      "BufferA",
      "BufferB",
      "BufferC",
      "BufferD"
    ];
    for (const i of e) {
      const n = this.project.passes[i];
      n && this.tabs.push({
        kind: "code",
        name: `${i.toLowerCase()}.glsl`,
        passName: i,
        source: n.glslSource
      });
    }
    const t = this.project.passes.Image;
    this.tabs.push({
      kind: "code",
      name: "image.glsl",
      passName: "Image",
      source: t.glslSource
    });
    for (const i of this.project.textures)
      this.tabs.push({
        kind: "image",
        name: i.filename || i.name,
        url: i.source
      });
  }
  buildTabBar() {
    this.tabBar.innerHTML = "", this.tabs.forEach((e, t) => {
      const i = document.createElement("button");
      i.className = "editor-tab-button", e.kind === "image" && i.classList.add("image-tab"), i.textContent = e.name, t === this.activeTabIndex && i.classList.add("active"), i.addEventListener("click", () => this.showTab(t)), this.tabBar.appendChild(i);
    });
  }
  async showTab(e) {
    this.saveCurrentEditorContent(), this.activeTabIndex = e;
    const t = this.tabs[e];
    if (this.tabBar.querySelectorAll(".editor-tab-button").forEach((i, n) => {
      i.classList.toggle("active", n === e);
    }), this.editorInstance && (this.editorInstance.destroy(), this.editorInstance = null), this.contentArea.innerHTML = "", t.kind === "code") {
      this.copyButton.style.display = "", this.recompileButton.style.display = "";
      const i = this.modifiedSources.get(t.passName) ?? t.source, n = document.createElement("div");
      n.className = "editor-prism-container", this.contentArea.appendChild(n);
      try {
        const { createEditor: r } = await Promise.resolve().then(() => Os);
        this.editorInstance = r(n, i, (o) => {
          this.modifiedSources.set(t.passName, o);
        });
      } catch (r) {
        console.error("Failed to load editor:", r);
        const o = document.createElement("textarea");
        o.className = "editor-fallback-textarea", o.value = i, o.addEventListener("input", () => {
          this.modifiedSources.set(t.passName, o.value);
        }), n.appendChild(o);
      }
    } else {
      this.copyButton.style.display = "none", this.recompileButton.style.display = "none";
      const i = document.createElement("div");
      i.className = "editor-image-viewer";
      const n = document.createElement("img");
      n.src = t.url, n.alt = t.name, i.appendChild(n), this.contentArea.appendChild(i);
    }
  }
  saveCurrentEditorContent() {
    if (this.editorInstance) {
      const e = this.tabs[this.activeTabIndex];
      if (e.kind === "code") {
        const t = this.editorInstance.getSource();
        this.modifiedSources.set(e.passName, t);
      }
    }
  }
  recompile() {
    if (!this.recompileHandler) {
      console.warn("No recompile handler set");
      return;
    }
    this.saveCurrentEditorContent();
    const e = this.tabs[this.activeTabIndex];
    if (e.kind !== "code")
      return;
    const t = this.modifiedSources.get(e.passName) ?? e.source, i = this.recompileHandler(e.passName, t);
    i.success ? (this.hideError(), e.source = t) : this.showError(i.error || "Compilation failed");
  }
  showError(e) {
    this.errorDisplay.textContent = e, this.errorDisplay.style.display = "block";
  }
  hideError() {
    this.errorDisplay.style.display = "none";
  }
  async copyToClipboard() {
    const e = this.tabs[this.activeTabIndex];
    if (e.kind !== "code") return;
    const t = this.editorInstance ? this.editorInstance.getSource() : this.modifiedSources.get(e.passName) ?? e.source;
    try {
      await navigator.clipboard.writeText(t);
      const i = this.copyButton.innerHTML;
      this.copyButton.innerHTML = `
        <svg width="16" height="16" viewBox="0 0 16 16" fill="currentColor">
          <path d="M13.78 4.22a.75.75 0 010 1.06l-7.25 7.25a.75.75 0 01-1.06 0L2.22 9.28a.75.75 0 011.06-1.06L6 10.94l6.72-6.72a.75.75 0 011.06 0z"/>
        </svg>
      `, this.copyButton.classList.add("copied"), setTimeout(() => {
        this.copyButton.innerHTML = i, this.copyButton.classList.remove("copied");
      }, 1500);
    } catch (i) {
      console.error("Failed to copy:", i);
    }
  }
  setupKeyboardShortcut() {
    this.keydownHandler = (e) => {
      (e.ctrlKey || e.metaKey) && e.key === "Enter" && (e.preventDefault(), this.recompile());
    }, this.container.addEventListener("keydown", this.keydownHandler);
  }
}
const ko = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  EditorPanel: Ro
}, Symbol.toStringTag, { value: "Module" }));
var is = typeof globalThis < "u" ? globalThis : typeof window < "u" ? window : typeof global < "u" ? global : typeof self < "u" ? self : {}, Ns = { exports: {} };
(function(s) {
  var e = typeof window < "u" ? window : typeof WorkerGlobalScope < "u" && self instanceof WorkerGlobalScope ? self : {};
  /**
   * Prism: Lightweight, robust, elegant syntax highlighting
   *
   * @license MIT <https://opensource.org/licenses/MIT>
   * @author Lea Verou <https://lea.verou.me>
   * @namespace
   * @public
   */
  var t = function(i) {
    var n = /(?:^|\s)lang(?:uage)?-([\w-]+)(?=\s|$)/i, r = 0, o = {}, a = {
      /**
       * By default, Prism will attempt to highlight all code elements (by calling {@link Prism.highlightAll}) on the
       * current page after the page finished loading. This might be a problem if e.g. you wanted to asynchronously load
       * additional languages or plugins yourself.
       *
       * By setting this value to `true`, Prism will not automatically highlight all code elements on the page.
       *
       * You obviously have to change this value before the automatic highlighting started. To do this, you can add an
       * empty Prism object into the global scope before loading the Prism script like this:
       *
       * ```js
       * window.Prism = window.Prism || {};
       * Prism.manual = true;
       * // add a new <script> to load Prism's script
       * ```
       *
       * @default false
       * @type {boolean}
       * @memberof Prism
       * @public
       */
      manual: i.Prism && i.Prism.manual,
      /**
       * By default, if Prism is in a web worker, it assumes that it is in a worker it created itself, so it uses
       * `addEventListener` to communicate with its parent instance. However, if you're using Prism manually in your
       * own worker, you don't want it to do this.
       *
       * By setting this value to `true`, Prism will not add its own listeners to the worker.
       *
       * You obviously have to change this value before Prism executes. To do this, you can add an
       * empty Prism object into the global scope before loading the Prism script like this:
       *
       * ```js
       * window.Prism = window.Prism || {};
       * Prism.disableWorkerMessageHandler = true;
       * // Load Prism's script
       * ```
       *
       * @default false
       * @type {boolean}
       * @memberof Prism
       * @public
       */
      disableWorkerMessageHandler: i.Prism && i.Prism.disableWorkerMessageHandler,
      /**
       * A namespace for utility methods.
       *
       * All function in this namespace that are not explicitly marked as _public_ are for __internal use only__ and may
       * change or disappear at any time.
       *
       * @namespace
       * @memberof Prism
       */
      util: {
        encode: function p(f) {
          return f instanceof c ? new c(f.type, p(f.content), f.alias) : Array.isArray(f) ? f.map(p) : f.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/\u00a0/g, " ");
        },
        /**
         * Returns the name of the type of the given value.
         *
         * @param {any} o
         * @returns {string}
         * @example
         * type(null)      === 'Null'
         * type(undefined) === 'Undefined'
         * type(123)       === 'Number'
         * type('foo')     === 'String'
         * type(true)      === 'Boolean'
         * type([1, 2])    === 'Array'
         * type({})        === 'Object'
         * type(String)    === 'Function'
         * type(/abc+/)    === 'RegExp'
         */
        type: function(p) {
          return Object.prototype.toString.call(p).slice(8, -1);
        },
        /**
         * Returns a unique number for the given object. Later calls will still return the same number.
         *
         * @param {Object} obj
         * @returns {number}
         */
        objId: function(p) {
          return p.__id || Object.defineProperty(p, "__id", { value: ++r }), p.__id;
        },
        /**
         * Creates a deep clone of the given object.
         *
         * The main intended use of this function is to clone language definitions.
         *
         * @param {T} o
         * @param {Record<number, any>} [visited]
         * @returns {T}
         * @template T
         */
        clone: function p(f, b) {
          b = b || {};
          var y, T;
          switch (a.util.type(f)) {
            case "Object":
              if (T = a.util.objId(f), b[T])
                return b[T];
              y = /** @type {Record<string, any>} */
              {}, b[T] = y;
              for (var C in f)
                f.hasOwnProperty(C) && (y[C] = p(f[C], b));
              return (
                /** @type {any} */
                y
              );
            case "Array":
              return T = a.util.objId(f), b[T] ? b[T] : (y = [], b[T] = y, /** @type {Array} */
              /** @type {any} */
              f.forEach(function(A, w) {
                y[w] = p(A, b);
              }), /** @type {any} */
              y);
            default:
              return f;
          }
        },
        /**
         * Returns the Prism language of the given element set by a `language-xxxx` or `lang-xxxx` class.
         *
         * If no language is set for the element or the element is `null` or `undefined`, `none` will be returned.
         *
         * @param {Element} element
         * @returns {string}
         */
        getLanguage: function(p) {
          for (; p; ) {
            var f = n.exec(p.className);
            if (f)
              return f[1].toLowerCase();
            p = p.parentElement;
          }
          return "none";
        },
        /**
         * Sets the Prism `language-xxxx` class of the given element.
         *
         * @param {Element} element
         * @param {string} language
         * @returns {void}
         */
        setLanguage: function(p, f) {
          p.className = p.className.replace(RegExp(n, "gi"), ""), p.classList.add("language-" + f);
        },
        /**
         * Returns the script element that is currently executing.
         *
         * This does __not__ work for line script element.
         *
         * @returns {HTMLScriptElement | null}
         */
        currentScript: function() {
          if (typeof document > "u")
            return null;
          if (document.currentScript && document.currentScript.tagName === "SCRIPT")
            return (
              /** @type {any} */
              document.currentScript
            );
          try {
            throw new Error();
          } catch (y) {
            var p = (/at [^(\r\n]*\((.*):[^:]+:[^:]+\)$/i.exec(y.stack) || [])[1];
            if (p) {
              var f = document.getElementsByTagName("script");
              for (var b in f)
                if (f[b].src == p)
                  return f[b];
            }
            return null;
          }
        },
        /**
         * Returns whether a given class is active for `element`.
         *
         * The class can be activated if `element` or one of its ancestors has the given class and it can be deactivated
         * if `element` or one of its ancestors has the negated version of the given class. The _negated version_ of the
         * given class is just the given class with a `no-` prefix.
         *
         * Whether the class is active is determined by the closest ancestor of `element` (where `element` itself is
         * closest ancestor) that has the given class or the negated version of it. If neither `element` nor any of its
         * ancestors have the given class or the negated version of it, then the default activation will be returned.
         *
         * In the paradoxical situation where the closest ancestor contains __both__ the given class and the negated
         * version of it, the class is considered active.
         *
         * @param {Element} element
         * @param {string} className
         * @param {boolean} [defaultActivation=false]
         * @returns {boolean}
         */
        isActive: function(p, f, b) {
          for (var y = "no-" + f; p; ) {
            var T = p.classList;
            if (T.contains(f))
              return !0;
            if (T.contains(y))
              return !1;
            p = p.parentElement;
          }
          return !!b;
        }
      },
      /**
       * This namespace contains all currently loaded languages and the some helper functions to create and modify languages.
       *
       * @namespace
       * @memberof Prism
       * @public
       */
      languages: {
        /**
         * The grammar for plain, unformatted text.
         */
        plain: o,
        plaintext: o,
        text: o,
        txt: o,
        /**
         * Creates a deep copy of the language with the given id and appends the given tokens.
         *
         * If a token in `redef` also appears in the copied language, then the existing token in the copied language
         * will be overwritten at its original position.
         *
         * ## Best practices
         *
         * Since the position of overwriting tokens (token in `redef` that overwrite tokens in the copied language)
         * doesn't matter, they can technically be in any order. However, this can be confusing to others that trying to
         * understand the language definition because, normally, the order of tokens matters in Prism grammars.
         *
         * Therefore, it is encouraged to order overwriting tokens according to the positions of the overwritten tokens.
         * Furthermore, all non-overwriting tokens should be placed after the overwriting ones.
         *
         * @param {string} id The id of the language to extend. This has to be a key in `Prism.languages`.
         * @param {Grammar} redef The new tokens to append.
         * @returns {Grammar} The new language created.
         * @public
         * @example
         * Prism.languages['css-with-colors'] = Prism.languages.extend('css', {
         *     // Prism.languages.css already has a 'comment' token, so this token will overwrite CSS' 'comment' token
         *     // at its original position
         *     'comment': { ... },
         *     // CSS doesn't have a 'color' token, so this token will be appended
         *     'color': /\b(?:red|green|blue)\b/
         * });
         */
        extend: function(p, f) {
          var b = a.util.clone(a.languages[p]);
          for (var y in f)
            b[y] = f[y];
          return b;
        },
        /**
         * Inserts tokens _before_ another token in a language definition or any other grammar.
         *
         * ## Usage
         *
         * This helper method makes it easy to modify existing languages. For example, the CSS language definition
         * not only defines CSS highlighting for CSS documents, but also needs to define highlighting for CSS embedded
         * in HTML through `<style>` elements. To do this, it needs to modify `Prism.languages.markup` and add the
         * appropriate tokens. However, `Prism.languages.markup` is a regular JavaScript object literal, so if you do
         * this:
         *
         * ```js
         * Prism.languages.markup.style = {
         *     // token
         * };
         * ```
         *
         * then the `style` token will be added (and processed) at the end. `insertBefore` allows you to insert tokens
         * before existing tokens. For the CSS example above, you would use it like this:
         *
         * ```js
         * Prism.languages.insertBefore('markup', 'cdata', {
         *     'style': {
         *         // token
         *     }
         * });
         * ```
         *
         * ## Special cases
         *
         * If the grammars of `inside` and `insert` have tokens with the same name, the tokens in `inside`'s grammar
         * will be ignored.
         *
         * This behavior can be used to insert tokens after `before`:
         *
         * ```js
         * Prism.languages.insertBefore('markup', 'comment', {
         *     'comment': Prism.languages.markup.comment,
         *     // tokens after 'comment'
         * });
         * ```
         *
         * ## Limitations
         *
         * The main problem `insertBefore` has to solve is iteration order. Since ES2015, the iteration order for object
         * properties is guaranteed to be the insertion order (except for integer keys) but some browsers behave
         * differently when keys are deleted and re-inserted. So `insertBefore` can't be implemented by temporarily
         * deleting properties which is necessary to insert at arbitrary positions.
         *
         * To solve this problem, `insertBefore` doesn't actually insert the given tokens into the target object.
         * Instead, it will create a new object and replace all references to the target object with the new one. This
         * can be done without temporarily deleting properties, so the iteration order is well-defined.
         *
         * However, only references that can be reached from `Prism.languages` or `insert` will be replaced. I.e. if
         * you hold the target object in a variable, then the value of the variable will not change.
         *
         * ```js
         * var oldMarkup = Prism.languages.markup;
         * var newMarkup = Prism.languages.insertBefore('markup', 'comment', { ... });
         *
         * assert(oldMarkup !== Prism.languages.markup);
         * assert(newMarkup === Prism.languages.markup);
         * ```
         *
         * @param {string} inside The property of `root` (e.g. a language id in `Prism.languages`) that contains the
         * object to be modified.
         * @param {string} before The key to insert before.
         * @param {Grammar} insert An object containing the key-value pairs to be inserted.
         * @param {Object<string, any>} [root] The object containing `inside`, i.e. the object that contains the
         * object to be modified.
         *
         * Defaults to `Prism.languages`.
         * @returns {Grammar} The new grammar object.
         * @public
         */
        insertBefore: function(p, f, b, y) {
          y = y || /** @type {any} */
          a.languages;
          var T = y[p], C = {};
          for (var A in T)
            if (T.hasOwnProperty(A)) {
              if (A == f)
                for (var w in b)
                  b.hasOwnProperty(w) && (C[w] = b[w]);
              b.hasOwnProperty(A) || (C[A] = T[A]);
            }
          var F = y[p];
          return y[p] = C, a.languages.DFS(a.languages, function(L, k) {
            k === F && L != p && (this[L] = C);
          }), C;
        },
        // Traverse a language definition with Depth First Search
        DFS: function p(f, b, y, T) {
          T = T || {};
          var C = a.util.objId;
          for (var A in f)
            if (f.hasOwnProperty(A)) {
              b.call(f, A, f[A], y || A);
              var w = f[A], F = a.util.type(w);
              F === "Object" && !T[C(w)] ? (T[C(w)] = !0, p(w, b, null, T)) : F === "Array" && !T[C(w)] && (T[C(w)] = !0, p(w, b, A, T));
            }
        }
      },
      plugins: {},
      /**
       * This is the most high-level function in Prism’s API.
       * It fetches all the elements that have a `.language-xxxx` class and then calls {@link Prism.highlightElement} on
       * each one of them.
       *
       * This is equivalent to `Prism.highlightAllUnder(document, async, callback)`.
       *
       * @param {boolean} [async=false] Same as in {@link Prism.highlightAllUnder}.
       * @param {HighlightCallback} [callback] Same as in {@link Prism.highlightAllUnder}.
       * @memberof Prism
       * @public
       */
      highlightAll: function(p, f) {
        a.highlightAllUnder(document, p, f);
      },
      /**
       * Fetches all the descendants of `container` that have a `.language-xxxx` class and then calls
       * {@link Prism.highlightElement} on each one of them.
       *
       * The following hooks will be run:
       * 1. `before-highlightall`
       * 2. `before-all-elements-highlight`
       * 3. All hooks of {@link Prism.highlightElement} for each element.
       *
       * @param {ParentNode} container The root element, whose descendants that have a `.language-xxxx` class will be highlighted.
       * @param {boolean} [async=false] Whether each element is to be highlighted asynchronously using Web Workers.
       * @param {HighlightCallback} [callback] An optional callback to be invoked on each element after its highlighting is done.
       * @memberof Prism
       * @public
       */
      highlightAllUnder: function(p, f, b) {
        var y = {
          callback: b,
          container: p,
          selector: 'code[class*="language-"], [class*="language-"] code, code[class*="lang-"], [class*="lang-"] code'
        };
        a.hooks.run("before-highlightall", y), y.elements = Array.prototype.slice.apply(y.container.querySelectorAll(y.selector)), a.hooks.run("before-all-elements-highlight", y);
        for (var T = 0, C; C = y.elements[T++]; )
          a.highlightElement(C, f === !0, y.callback);
      },
      /**
       * Highlights the code inside a single element.
       *
       * The following hooks will be run:
       * 1. `before-sanity-check`
       * 2. `before-highlight`
       * 3. All hooks of {@link Prism.highlight}. These hooks will be run by an asynchronous worker if `async` is `true`.
       * 4. `before-insert`
       * 5. `after-highlight`
       * 6. `complete`
       *
       * Some the above hooks will be skipped if the element doesn't contain any text or there is no grammar loaded for
       * the element's language.
       *
       * @param {Element} element The element containing the code.
       * It must have a class of `language-xxxx` to be processed, where `xxxx` is a valid language identifier.
       * @param {boolean} [async=false] Whether the element is to be highlighted asynchronously using Web Workers
       * to improve performance and avoid blocking the UI when highlighting very large chunks of code. This option is
       * [disabled by default](https://prismjs.com/faq.html#why-is-asynchronous-highlighting-disabled-by-default).
       *
       * Note: All language definitions required to highlight the code must be included in the main `prism.js` file for
       * asynchronous highlighting to work. You can build your own bundle on the
       * [Download page](https://prismjs.com/download.html).
       * @param {HighlightCallback} [callback] An optional callback to be invoked after the highlighting is done.
       * Mostly useful when `async` is `true`, since in that case, the highlighting is done asynchronously.
       * @memberof Prism
       * @public
       */
      highlightElement: function(p, f, b) {
        var y = a.util.getLanguage(p), T = a.languages[y];
        a.util.setLanguage(p, y);
        var C = p.parentElement;
        C && C.nodeName.toLowerCase() === "pre" && a.util.setLanguage(C, y);
        var A = p.textContent, w = {
          element: p,
          language: y,
          grammar: T,
          code: A
        };
        function F(k) {
          w.highlightedCode = k, a.hooks.run("before-insert", w), w.element.innerHTML = w.highlightedCode, a.hooks.run("after-highlight", w), a.hooks.run("complete", w), b && b.call(w.element);
        }
        if (a.hooks.run("before-sanity-check", w), C = w.element.parentElement, C && C.nodeName.toLowerCase() === "pre" && !C.hasAttribute("tabindex") && C.setAttribute("tabindex", "0"), !w.code) {
          a.hooks.run("complete", w), b && b.call(w.element);
          return;
        }
        if (a.hooks.run("before-highlight", w), !w.grammar) {
          F(a.util.encode(w.code));
          return;
        }
        if (f && i.Worker) {
          var L = new Worker(a.filename);
          L.onmessage = function(k) {
            F(k.data);
          }, L.postMessage(JSON.stringify({
            language: w.language,
            code: w.code,
            immediateClose: !0
          }));
        } else
          F(a.highlight(w.code, w.grammar, w.language));
      },
      /**
       * Low-level function, only use if you know what you’re doing. It accepts a string of text as input
       * and the language definitions to use, and returns a string with the HTML produced.
       *
       * The following hooks will be run:
       * 1. `before-tokenize`
       * 2. `after-tokenize`
       * 3. `wrap`: On each {@link Token}.
       *
       * @param {string} text A string with the code to be highlighted.
       * @param {Grammar} grammar An object containing the tokens to use.
       *
       * Usually a language definition like `Prism.languages.markup`.
       * @param {string} language The name of the language definition passed to `grammar`.
       * @returns {string} The highlighted HTML.
       * @memberof Prism
       * @public
       * @example
       * Prism.highlight('var foo = true;', Prism.languages.javascript, 'javascript');
       */
      highlight: function(p, f, b) {
        var y = {
          code: p,
          grammar: f,
          language: b
        };
        if (a.hooks.run("before-tokenize", y), !y.grammar)
          throw new Error('The language "' + y.language + '" has no grammar.');
        return y.tokens = a.tokenize(y.code, y.grammar), a.hooks.run("after-tokenize", y), c.stringify(a.util.encode(y.tokens), y.language);
      },
      /**
       * This is the heart of Prism, and the most low-level function you can use. It accepts a string of text as input
       * and the language definitions to use, and returns an array with the tokenized code.
       *
       * When the language definition includes nested tokens, the function is called recursively on each of these tokens.
       *
       * This method could be useful in other contexts as well, as a very crude parser.
       *
       * @param {string} text A string with the code to be highlighted.
       * @param {Grammar} grammar An object containing the tokens to use.
       *
       * Usually a language definition like `Prism.languages.markup`.
       * @returns {TokenStream} An array of strings and tokens, a token stream.
       * @memberof Prism
       * @public
       * @example
       * let code = `var foo = 0;`;
       * let tokens = Prism.tokenize(code, Prism.languages.javascript);
       * tokens.forEach(token => {
       *     if (token instanceof Prism.Token && token.type === 'number') {
       *         console.log(`Found numeric literal: ${token.content}`);
       *     }
       * });
       */
      tokenize: function(p, f) {
        var b = f.rest;
        if (b) {
          for (var y in b)
            f[y] = b[y];
          delete f.rest;
        }
        var T = new d();
        return m(T, T.head, p), l(p, T, f, T.head, 0), E(T);
      },
      /**
       * @namespace
       * @memberof Prism
       * @public
       */
      hooks: {
        all: {},
        /**
         * Adds the given callback to the list of callbacks for the given hook.
         *
         * The callback will be invoked when the hook it is registered for is run.
         * Hooks are usually directly run by a highlight function but you can also run hooks yourself.
         *
         * One callback function can be registered to multiple hooks and the same hook multiple times.
         *
         * @param {string} name The name of the hook.
         * @param {HookCallback} callback The callback function which is given environment variables.
         * @public
         */
        add: function(p, f) {
          var b = a.hooks.all;
          b[p] = b[p] || [], b[p].push(f);
        },
        /**
         * Runs a hook invoking all registered callbacks with the given environment variables.
         *
         * Callbacks will be invoked synchronously and in the order in which they were registered.
         *
         * @param {string} name The name of the hook.
         * @param {Object<string, any>} env The environment variables of the hook passed to all callbacks registered.
         * @public
         */
        run: function(p, f) {
          var b = a.hooks.all[p];
          if (!(!b || !b.length))
            for (var y = 0, T; T = b[y++]; )
              T(f);
        }
      },
      Token: c
    };
    i.Prism = a;
    function c(p, f, b, y) {
      this.type = p, this.content = f, this.alias = b, this.length = (y || "").length | 0;
    }
    c.stringify = function p(f, b) {
      if (typeof f == "string")
        return f;
      if (Array.isArray(f)) {
        var y = "";
        return f.forEach(function(F) {
          y += p(F, b);
        }), y;
      }
      var T = {
        type: f.type,
        content: p(f.content, b),
        tag: "span",
        classes: ["token", f.type],
        attributes: {},
        language: b
      }, C = f.alias;
      C && (Array.isArray(C) ? Array.prototype.push.apply(T.classes, C) : T.classes.push(C)), a.hooks.run("wrap", T);
      var A = "";
      for (var w in T.attributes)
        A += " " + w + '="' + (T.attributes[w] || "").replace(/"/g, "&quot;") + '"';
      return "<" + T.tag + ' class="' + T.classes.join(" ") + '"' + A + ">" + T.content + "</" + T.tag + ">";
    };
    function u(p, f, b, y) {
      p.lastIndex = f;
      var T = p.exec(b);
      if (T && y && T[1]) {
        var C = T[1].length;
        T.index += C, T[0] = T[0].slice(C);
      }
      return T;
    }
    function l(p, f, b, y, T, C) {
      for (var A in b)
        if (!(!b.hasOwnProperty(A) || !b[A])) {
          var w = b[A];
          w = Array.isArray(w) ? w : [w];
          for (var F = 0; F < w.length; ++F) {
            if (C && C.cause == A + "," + F)
              return;
            var L = w[F], k = L.inside, V = !!L.lookbehind, H = !!L.greedy, N = L.alias;
            if (H && !L.pattern.global) {
              var D = L.pattern.toString().match(/[imsuy]*$/)[0];
              L.pattern = RegExp(L.pattern.source, D + "g");
            }
            for (var $ = L.pattern || L, O = y.next, W = T; O !== f.tail && !(C && W >= C.reach); W += O.value.length, O = O.next) {
              var ne = O.value;
              if (f.length > p.length)
                return;
              if (!(ne instanceof c)) {
                var Be = 1, K;
                if (H) {
                  if (K = u($, W, p, V), !K || K.index >= p.length)
                    break;
                  var Pe = K.index, Ds = K.index + K[0].length, ae = W;
                  for (ae += O.value.length; Pe >= ae; )
                    O = O.next, ae += O.value.length;
                  if (ae -= O.value.length, W = ae, O.value instanceof c)
                    continue;
                  for (var be = O; be !== f.tail && (ae < Ds || typeof be.value == "string"); be = be.next)
                    Be++, ae += be.value.length;
                  Be--, ne = p.slice(W, ae), K.index -= W;
                } else if (K = u($, 0, ne, V), !K)
                  continue;
                var Pe = K.index, Me = K[0], We = ne.slice(0, Pe), Ct = ne.slice(Pe + Me.length), Xe = W + ne.length;
                C && Xe > C.reach && (C.reach = Xe);
                var Le = O.prev;
                We && (Le = m(f, Le, We), W += We.length), g(f, Le, Be);
                var $s = new c(A, k ? a.tokenize(Me, k) : Me, N, Me);
                if (O = m(f, Le, $s), Ct && m(f, O, Ct), Be > 1) {
                  var Ge = {
                    cause: A + "," + F,
                    reach: Xe
                  };
                  l(p, f, b, O.prev, W, Ge), C && Ge.reach > C.reach && (C.reach = Ge.reach);
                }
              }
            }
          }
        }
    }
    function d() {
      var p = { value: null, prev: null, next: null }, f = { value: null, prev: p, next: null };
      p.next = f, this.head = p, this.tail = f, this.length = 0;
    }
    function m(p, f, b) {
      var y = f.next, T = { value: b, prev: f, next: y };
      return f.next = T, y.prev = T, p.length++, T;
    }
    function g(p, f, b) {
      for (var y = f.next, T = 0; T < b && y !== p.tail; T++)
        y = y.next;
      f.next = y, y.prev = f, p.length -= T;
    }
    function E(p) {
      for (var f = [], b = p.head.next; b !== p.tail; )
        f.push(b.value), b = b.next;
      return f;
    }
    if (!i.document)
      return i.addEventListener && (a.disableWorkerMessageHandler || i.addEventListener("message", function(p) {
        var f = JSON.parse(p.data), b = f.language, y = f.code, T = f.immediateClose;
        i.postMessage(a.highlight(y, a.languages[b], b)), T && i.close();
      }, !1)), a;
    var v = a.util.currentScript();
    v && (a.filename = v.src, v.hasAttribute("data-manual") && (a.manual = !0));
    function _() {
      a.manual || a.highlightAll();
    }
    if (!a.manual) {
      var R = document.readyState;
      R === "loading" || R === "interactive" && v && v.defer ? document.addEventListener("DOMContentLoaded", _) : window.requestAnimationFrame ? window.requestAnimationFrame(_) : window.setTimeout(_, 16);
    }
    return a;
  }(e);
  s.exports && (s.exports = t), typeof is < "u" && (is.Prism = t), t.languages.markup = {
    comment: {
      pattern: /<!--(?:(?!<!--)[\s\S])*?-->/,
      greedy: !0
    },
    prolog: {
      pattern: /<\?[\s\S]+?\?>/,
      greedy: !0
    },
    doctype: {
      // https://www.w3.org/TR/xml/#NT-doctypedecl
      pattern: /<!DOCTYPE(?:[^>"'[\]]|"[^"]*"|'[^']*')+(?:\[(?:[^<"'\]]|"[^"]*"|'[^']*'|<(?!!--)|<!--(?:[^-]|-(?!->))*-->)*\]\s*)?>/i,
      greedy: !0,
      inside: {
        "internal-subset": {
          pattern: /(^[^\[]*\[)[\s\S]+(?=\]>$)/,
          lookbehind: !0,
          greedy: !0,
          inside: null
          // see below
        },
        string: {
          pattern: /"[^"]*"|'[^']*'/,
          greedy: !0
        },
        punctuation: /^<!|>$|[[\]]/,
        "doctype-tag": /^DOCTYPE/i,
        name: /[^\s<>'"]+/
      }
    },
    cdata: {
      pattern: /<!\[CDATA\[[\s\S]*?\]\]>/i,
      greedy: !0
    },
    tag: {
      pattern: /<\/?(?!\d)[^\s>\/=$<%]+(?:\s(?:\s*[^\s>\/=]+(?:\s*=\s*(?:"[^"]*"|'[^']*'|[^\s'">=]+(?=[\s>]))|(?=[\s/>])))+)?\s*\/?>/,
      greedy: !0,
      inside: {
        tag: {
          pattern: /^<\/?[^\s>\/]+/,
          inside: {
            punctuation: /^<\/?/,
            namespace: /^[^\s>\/:]+:/
          }
        },
        "special-attr": [],
        "attr-value": {
          pattern: /=\s*(?:"[^"]*"|'[^']*'|[^\s'">=]+)/,
          inside: {
            punctuation: [
              {
                pattern: /^=/,
                alias: "attr-equals"
              },
              {
                pattern: /^(\s*)["']|["']$/,
                lookbehind: !0
              }
            ]
          }
        },
        punctuation: /\/?>/,
        "attr-name": {
          pattern: /[^\s>\/]+/,
          inside: {
            namespace: /^[^\s>\/:]+:/
          }
        }
      }
    },
    entity: [
      {
        pattern: /&[\da-z]{1,8};/i,
        alias: "named-entity"
      },
      /&#x?[\da-f]{1,8};/i
    ]
  }, t.languages.markup.tag.inside["attr-value"].inside.entity = t.languages.markup.entity, t.languages.markup.doctype.inside["internal-subset"].inside = t.languages.markup, t.hooks.add("wrap", function(i) {
    i.type === "entity" && (i.attributes.title = i.content.replace(/&amp;/, "&"));
  }), Object.defineProperty(t.languages.markup.tag, "addInlined", {
    /**
     * Adds an inlined language to markup.
     *
     * An example of an inlined language is CSS with `<style>` tags.
     *
     * @param {string} tagName The name of the tag that contains the inlined language. This name will be treated as
     * case insensitive.
     * @param {string} lang The language key.
     * @example
     * addInlined('style', 'css');
     */
    value: function(n, r) {
      var o = {};
      o["language-" + r] = {
        pattern: /(^<!\[CDATA\[)[\s\S]+?(?=\]\]>$)/i,
        lookbehind: !0,
        inside: t.languages[r]
      }, o.cdata = /^<!\[CDATA\[|\]\]>$/i;
      var a = {
        "included-cdata": {
          pattern: /<!\[CDATA\[[\s\S]*?\]\]>/i,
          inside: o
        }
      };
      a["language-" + r] = {
        pattern: /[\s\S]+/,
        inside: t.languages[r]
      };
      var c = {};
      c[n] = {
        pattern: RegExp(/(<__[^>]*>)(?:<!\[CDATA\[(?:[^\]]|\](?!\]>))*\]\]>|(?!<!\[CDATA\[)[\s\S])*?(?=<\/__>)/.source.replace(/__/g, function() {
          return n;
        }), "i"),
        lookbehind: !0,
        greedy: !0,
        inside: a
      }, t.languages.insertBefore("markup", "cdata", c);
    }
  }), Object.defineProperty(t.languages.markup.tag, "addAttribute", {
    /**
     * Adds an pattern to highlight languages embedded in HTML attributes.
     *
     * An example of an inlined language is CSS with `style` attributes.
     *
     * @param {string} attrName The name of the tag that contains the inlined language. This name will be treated as
     * case insensitive.
     * @param {string} lang The language key.
     * @example
     * addAttribute('style', 'css');
     */
    value: function(i, n) {
      t.languages.markup.tag.inside["special-attr"].push({
        pattern: RegExp(
          /(^|["'\s])/.source + "(?:" + i + ")" + /\s*=\s*(?:"[^"]*"|'[^']*'|[^\s'">=]+(?=[\s>]))/.source,
          "i"
        ),
        lookbehind: !0,
        inside: {
          "attr-name": /^[^\s=]+/,
          "attr-value": {
            pattern: /=[\s\S]+/,
            inside: {
              value: {
                pattern: /(^=\s*(["']|(?!["'])))\S[\s\S]*(?=\2$)/,
                lookbehind: !0,
                alias: [n, "language-" + n],
                inside: t.languages[n]
              },
              punctuation: [
                {
                  pattern: /^=/,
                  alias: "attr-equals"
                },
                /"|'/
              ]
            }
          }
        }
      });
    }
  }), t.languages.html = t.languages.markup, t.languages.mathml = t.languages.markup, t.languages.svg = t.languages.markup, t.languages.xml = t.languages.extend("markup", {}), t.languages.ssml = t.languages.xml, t.languages.atom = t.languages.xml, t.languages.rss = t.languages.xml, function(i) {
    var n = /(?:"(?:\\(?:\r\n|[\s\S])|[^"\\\r\n])*"|'(?:\\(?:\r\n|[\s\S])|[^'\\\r\n])*')/;
    i.languages.css = {
      comment: /\/\*[\s\S]*?\*\//,
      atrule: {
        pattern: RegExp("@[\\w-](?:" + /[^;{\s"']|\s+(?!\s)/.source + "|" + n.source + ")*?" + /(?:;|(?=\s*\{))/.source),
        inside: {
          rule: /^@[\w-]+/,
          "selector-function-argument": {
            pattern: /(\bselector\s*\(\s*(?![\s)]))(?:[^()\s]|\s+(?![\s)])|\((?:[^()]|\([^()]*\))*\))+(?=\s*\))/,
            lookbehind: !0,
            alias: "selector"
          },
          keyword: {
            pattern: /(^|[^\w-])(?:and|not|only|or)(?![\w-])/,
            lookbehind: !0
          }
          // See rest below
        }
      },
      url: {
        // https://drafts.csswg.org/css-values-3/#urls
        pattern: RegExp("\\burl\\((?:" + n.source + "|" + /(?:[^\\\r\n()"']|\\[\s\S])*/.source + ")\\)", "i"),
        greedy: !0,
        inside: {
          function: /^url/i,
          punctuation: /^\(|\)$/,
          string: {
            pattern: RegExp("^" + n.source + "$"),
            alias: "url"
          }
        }
      },
      selector: {
        pattern: RegExp(`(^|[{}\\s])[^{}\\s](?:[^{};"'\\s]|\\s+(?![\\s{])|` + n.source + ")*(?=\\s*\\{)"),
        lookbehind: !0
      },
      string: {
        pattern: n,
        greedy: !0
      },
      property: {
        pattern: /(^|[^-\w\xA0-\uFFFF])(?!\s)[-_a-z\xA0-\uFFFF](?:(?!\s)[-\w\xA0-\uFFFF])*(?=\s*:)/i,
        lookbehind: !0
      },
      important: /!important\b/i,
      function: {
        pattern: /(^|[^-a-z0-9])[-a-z0-9]+(?=\()/i,
        lookbehind: !0
      },
      punctuation: /[(){};:,]/
    }, i.languages.css.atrule.inside.rest = i.languages.css;
    var r = i.languages.markup;
    r && (r.tag.addInlined("style", "css"), r.tag.addAttribute("style", "css"));
  }(t), t.languages.clike = {
    comment: [
      {
        pattern: /(^|[^\\])\/\*[\s\S]*?(?:\*\/|$)/,
        lookbehind: !0,
        greedy: !0
      },
      {
        pattern: /(^|[^\\:])\/\/.*/,
        lookbehind: !0,
        greedy: !0
      }
    ],
    string: {
      pattern: /(["'])(?:\\(?:\r\n|[\s\S])|(?!\1)[^\\\r\n])*\1/,
      greedy: !0
    },
    "class-name": {
      pattern: /(\b(?:class|extends|implements|instanceof|interface|new|trait)\s+|\bcatch\s+\()[\w.\\]+/i,
      lookbehind: !0,
      inside: {
        punctuation: /[.\\]/
      }
    },
    keyword: /\b(?:break|catch|continue|do|else|finally|for|function|if|in|instanceof|new|null|return|throw|try|while)\b/,
    boolean: /\b(?:false|true)\b/,
    function: /\b\w+(?=\()/,
    number: /\b0x[\da-f]+\b|(?:\b\d+(?:\.\d*)?|\B\.\d+)(?:e[+-]?\d+)?/i,
    operator: /[<>]=?|[!=]=?=?|--?|\+\+?|&&?|\|\|?|[?*/~^%]/,
    punctuation: /[{}[\];(),.:]/
  }, t.languages.javascript = t.languages.extend("clike", {
    "class-name": [
      t.languages.clike["class-name"],
      {
        pattern: /(^|[^$\w\xA0-\uFFFF])(?!\s)[_$A-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\.(?:constructor|prototype))/,
        lookbehind: !0
      }
    ],
    keyword: [
      {
        pattern: /((?:^|\})\s*)catch\b/,
        lookbehind: !0
      },
      {
        pattern: /(^|[^.]|\.\.\.\s*)\b(?:as|assert(?=\s*\{)|async(?=\s*(?:function\b|\(|[$\w\xA0-\uFFFF]|$))|await|break|case|class|const|continue|debugger|default|delete|do|else|enum|export|extends|finally(?=\s*(?:\{|$))|for|from(?=\s*(?:['"]|$))|function|(?:get|set)(?=\s*(?:[#\[$\w\xA0-\uFFFF]|$))|if|implements|import|in|instanceof|interface|let|new|null|of|package|private|protected|public|return|static|super|switch|this|throw|try|typeof|undefined|var|void|while|with|yield)\b/,
        lookbehind: !0
      }
    ],
    // Allow for all non-ASCII characters (See http://stackoverflow.com/a/2008444)
    function: /#?(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\s*(?:\.\s*(?:apply|bind|call)\s*)?\()/,
    number: {
      pattern: RegExp(
        /(^|[^\w$])/.source + "(?:" + // constant
        (/NaN|Infinity/.source + "|" + // binary integer
        /0[bB][01]+(?:_[01]+)*n?/.source + "|" + // octal integer
        /0[oO][0-7]+(?:_[0-7]+)*n?/.source + "|" + // hexadecimal integer
        /0[xX][\dA-Fa-f]+(?:_[\dA-Fa-f]+)*n?/.source + "|" + // decimal bigint
        /\d+(?:_\d+)*n/.source + "|" + // decimal number (integer or float) but no bigint
        /(?:\d+(?:_\d+)*(?:\.(?:\d+(?:_\d+)*)?)?|\.\d+(?:_\d+)*)(?:[Ee][+-]?\d+(?:_\d+)*)?/.source) + ")" + /(?![\w$])/.source
      ),
      lookbehind: !0
    },
    operator: /--|\+\+|\*\*=?|=>|&&=?|\|\|=?|[!=]==|<<=?|>>>?=?|[-+*/%&|^!=<>]=?|\.{3}|\?\?=?|\?\.?|[~:]/
  }), t.languages.javascript["class-name"][0].pattern = /(\b(?:class|extends|implements|instanceof|interface|new)\s+)[\w.\\]+/, t.languages.insertBefore("javascript", "keyword", {
    regex: {
      pattern: RegExp(
        // lookbehind
        // eslint-disable-next-line regexp/no-dupe-characters-character-class
        /((?:^|[^$\w\xA0-\uFFFF."'\])\s]|\b(?:return|yield))\s*)/.source + // Regex pattern:
        // There are 2 regex patterns here. The RegExp set notation proposal added support for nested character
        // classes if the `v` flag is present. Unfortunately, nested CCs are both context-free and incompatible
        // with the only syntax, so we have to define 2 different regex patterns.
        /\//.source + "(?:" + /(?:\[(?:[^\]\\\r\n]|\\.)*\]|\\.|[^/\\\[\r\n])+\/[dgimyus]{0,7}/.source + "|" + // `v` flag syntax. This supports 3 levels of nested character classes.
        /(?:\[(?:[^[\]\\\r\n]|\\.|\[(?:[^[\]\\\r\n]|\\.|\[(?:[^[\]\\\r\n]|\\.)*\])*\])*\]|\\.|[^/\\\[\r\n])+\/[dgimyus]{0,7}v[dgimyus]{0,7}/.source + ")" + // lookahead
        /(?=(?:\s|\/\*(?:[^*]|\*(?!\/))*\*\/)*(?:$|[\r\n,.;:})\]]|\/\/))/.source
      ),
      lookbehind: !0,
      greedy: !0,
      inside: {
        "regex-source": {
          pattern: /^(\/)[\s\S]+(?=\/[a-z]*$)/,
          lookbehind: !0,
          alias: "language-regex",
          inside: t.languages.regex
        },
        "regex-delimiter": /^\/|\/$/,
        "regex-flags": /^[a-z]+$/
      }
    },
    // This must be declared before keyword because we use "function" inside the look-forward
    "function-variable": {
      pattern: /#?(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\s*[=:]\s*(?:async\s*)?(?:\bfunction\b|(?:\((?:[^()]|\([^()]*\))*\)|(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*)\s*=>))/,
      alias: "function"
    },
    parameter: [
      {
        pattern: /(function(?:\s+(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*)?\s*\(\s*)(?!\s)(?:[^()\s]|\s+(?![\s)])|\([^()]*\))+(?=\s*\))/,
        lookbehind: !0,
        inside: t.languages.javascript
      },
      {
        pattern: /(^|[^$\w\xA0-\uFFFF])(?!\s)[_$a-z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\s*=>)/i,
        lookbehind: !0,
        inside: t.languages.javascript
      },
      {
        pattern: /(\(\s*)(?!\s)(?:[^()\s]|\s+(?![\s)])|\([^()]*\))+(?=\s*\)\s*=>)/,
        lookbehind: !0,
        inside: t.languages.javascript
      },
      {
        pattern: /((?:\b|\s|^)(?!(?:as|async|await|break|case|catch|class|const|continue|debugger|default|delete|do|else|enum|export|extends|finally|for|from|function|get|if|implements|import|in|instanceof|interface|let|new|null|of|package|private|protected|public|return|set|static|super|switch|this|throw|try|typeof|undefined|var|void|while|with|yield)(?![$\w\xA0-\uFFFF]))(?:(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*\s*)\(\s*|\]\s*\(\s*)(?!\s)(?:[^()\s]|\s+(?![\s)])|\([^()]*\))+(?=\s*\)\s*\{)/,
        lookbehind: !0,
        inside: t.languages.javascript
      }
    ],
    constant: /\b[A-Z](?:[A-Z_]|\dx?)*\b/
  }), t.languages.insertBefore("javascript", "string", {
    hashbang: {
      pattern: /^#!.*/,
      greedy: !0,
      alias: "comment"
    },
    "template-string": {
      pattern: /`(?:\\[\s\S]|\$\{(?:[^{}]|\{(?:[^{}]|\{[^}]*\})*\})+\}|(?!\$\{)[^\\`])*`/,
      greedy: !0,
      inside: {
        "template-punctuation": {
          pattern: /^`|`$/,
          alias: "string"
        },
        interpolation: {
          pattern: /((?:^|[^\\])(?:\\{2})*)\$\{(?:[^{}]|\{(?:[^{}]|\{[^}]*\})*\})+\}/,
          lookbehind: !0,
          inside: {
            "interpolation-punctuation": {
              pattern: /^\$\{|\}$/,
              alias: "punctuation"
            },
            rest: t.languages.javascript
          }
        },
        string: /[\s\S]+/
      }
    },
    "string-property": {
      pattern: /((?:^|[,{])[ \t]*)(["'])(?:\\(?:\r\n|[\s\S])|(?!\2)[^\\\r\n])*\2(?=\s*:)/m,
      lookbehind: !0,
      greedy: !0,
      alias: "property"
    }
  }), t.languages.insertBefore("javascript", "operator", {
    "literal-property": {
      pattern: /((?:^|[,{])[ \t]*)(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\s*:)/m,
      lookbehind: !0,
      alias: "property"
    }
  }), t.languages.markup && (t.languages.markup.tag.addInlined("script", "javascript"), t.languages.markup.tag.addAttribute(
    /on(?:abort|blur|change|click|composition(?:end|start|update)|dblclick|error|focus(?:in|out)?|key(?:down|up)|load|mouse(?:down|enter|leave|move|out|over|up)|reset|resize|scroll|select|slotchange|submit|unload|wheel)/.source,
    "javascript"
  )), t.languages.js = t.languages.javascript, function() {
    if (typeof t > "u" || typeof document > "u")
      return;
    Element.prototype.matches || (Element.prototype.matches = Element.prototype.msMatchesSelector || Element.prototype.webkitMatchesSelector);
    var i = "Loading…", n = function(v, _) {
      return "✖ Error " + v + " while fetching file: " + _;
    }, r = "✖ Error: File does not exist or is empty", o = {
      js: "javascript",
      py: "python",
      rb: "ruby",
      ps1: "powershell",
      psm1: "powershell",
      sh: "bash",
      bat: "batch",
      h: "c",
      tex: "latex"
    }, a = "data-src-status", c = "loading", u = "loaded", l = "failed", d = "pre[data-src]:not([" + a + '="' + u + '"]):not([' + a + '="' + c + '"])';
    function m(v, _, R) {
      var p = new XMLHttpRequest();
      p.open("GET", v, !0), p.onreadystatechange = function() {
        p.readyState == 4 && (p.status < 400 && p.responseText ? _(p.responseText) : p.status >= 400 ? R(n(p.status, p.statusText)) : R(r));
      }, p.send(null);
    }
    function g(v) {
      var _ = /^\s*(\d+)\s*(?:(,)\s*(?:(\d+)\s*)?)?$/.exec(v || "");
      if (_) {
        var R = Number(_[1]), p = _[2], f = _[3];
        return p ? f ? [R, Number(f)] : [R, void 0] : [R, R];
      }
    }
    t.hooks.add("before-highlightall", function(v) {
      v.selector += ", " + d;
    }), t.hooks.add("before-sanity-check", function(v) {
      var _ = (
        /** @type {HTMLPreElement} */
        v.element
      );
      if (_.matches(d)) {
        v.code = "", _.setAttribute(a, c);
        var R = _.appendChild(document.createElement("CODE"));
        R.textContent = i;
        var p = _.getAttribute("data-src"), f = v.language;
        if (f === "none") {
          var b = (/\.(\w+)$/.exec(p) || [, "none"])[1];
          f = o[b] || b;
        }
        t.util.setLanguage(R, f), t.util.setLanguage(_, f);
        var y = t.plugins.autoloader;
        y && y.loadLanguages(f), m(
          p,
          function(T) {
            _.setAttribute(a, u);
            var C = g(_.getAttribute("data-range"));
            if (C) {
              var A = T.split(/\r\n?|\n/g), w = C[0], F = C[1] == null ? A.length : C[1];
              w < 0 && (w += A.length), w = Math.max(0, Math.min(w - 1, A.length)), F < 0 && (F += A.length), F = Math.max(0, Math.min(F, A.length)), T = A.slice(w, F).join(`
`), _.hasAttribute("data-start") || _.setAttribute("data-start", String(w + 1));
            }
            R.textContent = T, t.highlightElement(R);
          },
          function(T) {
            _.setAttribute(a, l), R.textContent = T;
          }
        );
      }
    }), t.plugins.fileHighlight = {
      /**
       * Executes the File Highlight plugin for all matching `pre` elements under the given container.
       *
       * Note: Elements which are already loaded or currently loading will not be touched by this method.
       *
       * @param {ParentNode} [container=document]
       */
      highlight: function(_) {
        for (var R = (_ || document).querySelectorAll(d), p = 0, f; f = R[p++]; )
          t.highlightElement(f);
      }
    };
    var E = !1;
    t.fileHighlight = function() {
      E || (console.warn("Prism.fileHighlight is deprecated. Use `Prism.plugins.fileHighlight.highlight` instead."), E = !0), t.plugins.fileHighlight.highlight.apply(this, arguments);
    };
  }();
})(Ns);
var Ao = Ns.exports;
Prism.languages.c = Prism.languages.extend("clike", {
  comment: {
    pattern: /\/\/(?:[^\r\n\\]|\\(?:\r\n?|\n|(?![\r\n])))*|\/\*[\s\S]*?(?:\*\/|$)/,
    greedy: !0
  },
  string: {
    // https://en.cppreference.com/w/c/language/string_literal
    pattern: /"(?:\\(?:\r\n|[\s\S])|[^"\\\r\n])*"/,
    greedy: !0
  },
  "class-name": {
    pattern: /(\b(?:enum|struct)\s+(?:__attribute__\s*\(\([\s\S]*?\)\)\s*)?)\w+|\b[a-z]\w*_t\b/,
    lookbehind: !0
  },
  keyword: /\b(?:_Alignas|_Alignof|_Atomic|_Bool|_Complex|_Generic|_Imaginary|_Noreturn|_Static_assert|_Thread_local|__attribute__|asm|auto|break|case|char|const|continue|default|do|double|else|enum|extern|float|for|goto|if|inline|int|long|register|return|short|signed|sizeof|static|struct|switch|typedef|typeof|union|unsigned|void|volatile|while)\b/,
  function: /\b[a-z_]\w*(?=\s*\()/i,
  number: /(?:\b0x(?:[\da-f]+(?:\.[\da-f]*)?|\.[\da-f]+)(?:p[+-]?\d+)?|(?:\b\d+(?:\.\d*)?|\B\.\d+)(?:e[+-]?\d+)?)[ful]{0,4}/i,
  operator: />>=?|<<=?|->|([-+&|:])\1|[?:~]|[-+*/%&|^!=<>]=?/
});
Prism.languages.insertBefore("c", "string", {
  char: {
    // https://en.cppreference.com/w/c/language/character_constant
    pattern: /'(?:\\(?:\r\n|[\s\S])|[^'\\\r\n]){0,32}'/,
    greedy: !0
  }
});
Prism.languages.insertBefore("c", "string", {
  macro: {
    // allow for multiline macro definitions
    // spaces after the # character compile fine with gcc
    pattern: /(^[\t ]*)#\s*[a-z](?:[^\r\n\\/]|\/(?!\*)|\/\*(?:[^*]|\*(?!\/))*\*\/|\\(?:\r\n|[\s\S]))*/im,
    lookbehind: !0,
    greedy: !0,
    alias: "property",
    inside: {
      string: [
        {
          // highlight the path of the include statement as a string
          pattern: /^(#\s*include\s*)<[^>]+>/,
          lookbehind: !0
        },
        Prism.languages.c.string
      ],
      char: Prism.languages.c.char,
      comment: Prism.languages.c.comment,
      "macro-name": [
        {
          pattern: /(^#\s*define\s+)\w+\b(?!\()/i,
          lookbehind: !0
        },
        {
          pattern: /(^#\s*define\s+)\w+\b(?=\()/i,
          lookbehind: !0,
          alias: "function"
        }
      ],
      // highlight macro directives as keywords
      directive: {
        pattern: /^(#\s*)[a-z]+/,
        lookbehind: !0,
        alias: "keyword"
      },
      "directive-hash": /^#/,
      punctuation: /##|\\(?=[\r\n])/,
      expression: {
        pattern: /\S[\s\S]*/,
        inside: Prism.languages.c
      }
    }
  }
});
Prism.languages.insertBefore("c", "function", {
  // highlight predefined macros as constants
  constant: /\b(?:EOF|NULL|SEEK_CUR|SEEK_END|SEEK_SET|__DATE__|__FILE__|__LINE__|__TIMESTAMP__|__TIME__|__func__|stderr|stdin|stdout)\b/
});
delete Prism.languages.c.boolean;
(function(s) {
  var e = /\b(?:alignas|alignof|asm|auto|bool|break|case|catch|char|char16_t|char32_t|char8_t|class|co_await|co_return|co_yield|compl|concept|const|const_cast|consteval|constexpr|constinit|continue|decltype|default|delete|do|double|dynamic_cast|else|enum|explicit|export|extern|final|float|for|friend|goto|if|import|inline|int|int16_t|int32_t|int64_t|int8_t|long|module|mutable|namespace|new|noexcept|nullptr|operator|override|private|protected|public|register|reinterpret_cast|requires|return|short|signed|sizeof|static|static_assert|static_cast|struct|switch|template|this|thread_local|throw|try|typedef|typeid|typename|uint16_t|uint32_t|uint64_t|uint8_t|union|unsigned|using|virtual|void|volatile|wchar_t|while)\b/, t = /\b(?!<keyword>)\w+(?:\s*\.\s*\w+)*\b/.source.replace(/<keyword>/g, function() {
    return e.source;
  });
  s.languages.cpp = s.languages.extend("c", {
    "class-name": [
      {
        pattern: RegExp(/(\b(?:class|concept|enum|struct|typename)\s+)(?!<keyword>)\w+/.source.replace(/<keyword>/g, function() {
          return e.source;
        })),
        lookbehind: !0
      },
      // This is intended to capture the class name of method implementations like:
      //   void foo::bar() const {}
      // However! The `foo` in the above example could also be a namespace, so we only capture the class name if
      // it starts with an uppercase letter. This approximation should give decent results.
      /\b[A-Z]\w*(?=\s*::\s*\w+\s*\()/,
      // This will capture the class name before destructors like:
      //   Foo::~Foo() {}
      /\b[A-Z_]\w*(?=\s*::\s*~\w+\s*\()/i,
      // This also intends to capture the class name of method implementations but here the class has template
      // parameters, so it can't be a namespace (until C++ adds generic namespaces).
      /\b\w+(?=\s*<(?:[^<>]|<(?:[^<>]|<[^<>]*>)*>)*>\s*::\s*\w+\s*\()/
    ],
    keyword: e,
    number: {
      pattern: /(?:\b0b[01']+|\b0x(?:[\da-f']+(?:\.[\da-f']*)?|\.[\da-f']+)(?:p[+-]?[\d']+)?|(?:\b[\d']+(?:\.[\d']*)?|\B\.[\d']+)(?:e[+-]?[\d']+)?)[ful]{0,4}/i,
      greedy: !0
    },
    operator: />>=?|<<=?|->|--|\+\+|&&|\|\||[?:~]|<=>|[-+*/%&|^!=<>]=?|\b(?:and|and_eq|bitand|bitor|not|not_eq|or|or_eq|xor|xor_eq)\b/,
    boolean: /\b(?:false|true)\b/
  }), s.languages.insertBefore("cpp", "string", {
    module: {
      // https://en.cppreference.com/w/cpp/language/modules
      pattern: RegExp(
        /(\b(?:import|module)\s+)/.source + "(?:" + // header-name
        /"(?:\\(?:\r\n|[\s\S])|[^"\\\r\n])*"|<[^<>\r\n]*>/.source + "|" + // module name or partition or both
        /<mod-name>(?:\s*:\s*<mod-name>)?|:\s*<mod-name>/.source.replace(/<mod-name>/g, function() {
          return t;
        }) + ")"
      ),
      lookbehind: !0,
      greedy: !0,
      inside: {
        string: /^[<"][\s\S]+/,
        operator: /:/,
        punctuation: /\./
      }
    },
    "raw-string": {
      pattern: /R"([^()\\ ]{0,16})\([\s\S]*?\)\1"/,
      alias: "string",
      greedy: !0
    }
  }), s.languages.insertBefore("cpp", "keyword", {
    "generic-function": {
      pattern: /\b(?!operator\b)[a-z_]\w*\s*<(?:[^<>]|<[^<>]*>)*>(?=\s*\()/i,
      inside: {
        function: /^\w+/,
        generic: {
          pattern: /<[\s\S]+/,
          alias: "class-name",
          inside: s.languages.cpp
        }
      }
    }
  }), s.languages.insertBefore("cpp", "operator", {
    "double-colon": {
      pattern: /::/,
      alias: "punctuation"
    }
  }), s.languages.insertBefore("cpp", "class-name", {
    // the base clause is an optional list of parent classes
    // https://en.cppreference.com/w/cpp/language/class
    "base-clause": {
      pattern: /(\b(?:class|struct)\s+\w+\s*:\s*)[^;{}"'\s]+(?:\s+[^;{}"'\s]+)*(?=\s*[;{])/,
      lookbehind: !0,
      greedy: !0,
      inside: s.languages.extend("cpp", {})
    }
  }), s.languages.insertBefore("inside", "double-colon", {
    // All untokenized words that are not namespaces should be class names
    "class-name": /\b[a-z_]\w*\b(?!\s*::)/i
  }, s.languages.cpp["base-clause"]);
})(Prism);
function Fo(s, e, t) {
  const i = document.createElement("div");
  i.className = "prism-editor-wrapper";
  const n = document.createElement("div");
  n.className = "prism-editor-line-numbers";
  const r = document.createElement("div");
  r.className = "prism-editor-area";
  const o = document.createElement("textarea");
  o.className = "prism-editor-textarea", o.value = e, o.spellcheck = !1, o.autocapitalize = "off", o.autocomplete = "off";
  const a = document.createElement("div");
  a.className = "prism-editor-highlight";
  const c = document.createElement("code");
  c.className = "language-cpp", a.appendChild(c), r.appendChild(o), r.appendChild(a), i.appendChild(n), i.appendChild(r), s.appendChild(i);
  function u() {
    const m = o.value;
    c.textContent = m + `
`, Ao.highlightElement(c);
    const g = m.split(`
`);
    n.innerHTML = g.map((E, v) => `<span>${v + 1}</span>`).join(""), t && t(m);
  }
  function l() {
    a.scrollTop = o.scrollTop, a.scrollLeft = o.scrollLeft, n.scrollTop = o.scrollTop;
  }
  function d(m) {
    if (m.key === "Tab") {
      m.preventDefault();
      const g = o.selectionStart, E = o.selectionEnd, v = o.value;
      o.value = v.substring(0, g) + "  " + v.substring(E), o.selectionStart = o.selectionEnd = g + 2, u();
    }
  }
  return o.addEventListener("input", u), o.addEventListener("scroll", l), o.addEventListener("keydown", d), u(), {
    getSource: () => o.value,
    setSource: (m) => {
      o.value = m, u();
    },
    destroy: () => {
      o.removeEventListener("input", u), o.removeEventListener("scroll", l), o.removeEventListener("keydown", d), i.parentNode && i.parentNode.removeChild(i);
    }
  };
}
const Os = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  createEditor: Fo
}, Symbol.toStringTag, { value: "Module" }));
export {
  an as loadFromFolder,
  cn as loadFromSource
};
