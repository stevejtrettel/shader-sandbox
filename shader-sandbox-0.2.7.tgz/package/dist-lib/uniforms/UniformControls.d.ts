/**
 * Uniform Controls Component
 *
 * Renders UI controls for custom uniforms defined in config.json.
 * Supports: float, int, bool, vec2 (XY pad), vec3 (color picker or sliders), vec4 (sliders)
 */
import './uniform-controls.css';
import { UniformDefinitions, UniformValue, UniformValues } from '../project/types';
export interface UniformControlsOptions {
    /** Container element to mount controls into */
    container: HTMLElement;
    /** Uniform definitions from project config */
    uniforms: UniformDefinitions;
    /** Callback when a uniform value changes */
    onChange: (name: string, value: UniformValue) => void;
    /** Initial values (optional, defaults to definition values) */
    initialValues?: UniformValues;
}
export declare class UniformControls {
    private container;
    private uniforms;
    private onChange;
    private values;
    private updaters;
    private documentListeners;
    constructor(opts: UniformControlsOptions);
    /**
     * Render all uniform controls.
     */
    private render;
    /**
     * Create a control element for a uniform.
     */
    private createControl;
    private createSliderRow;
    private createFloatSlider;
    private createIntSlider;
    private createBoolToggle;
    private createVec2Pad;
    private createColorPicker;
    private createColorPicker4;
    private createVecSliders;
    private formatNumber;
    private formatVec2;
    private rgbToHex;
    private hexToRgb;
    /**
     * Update a uniform value externally (e.g., from reset).
     */
    setValue(name: string, value: UniformValue): void;
    /**
     * Reset all uniforms to their default values.
     */
    resetToDefaults(): void;
    /**
     * Destroy the controls and clean up.
     */
    destroy(): void;
}
//# sourceMappingURL=UniformControls.d.ts.map