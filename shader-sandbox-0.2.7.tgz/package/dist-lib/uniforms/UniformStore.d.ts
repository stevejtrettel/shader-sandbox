/**
 * UniformStore - Simple state manager for custom uniforms
 *
 * Encapsulates uniform values and provides clean get/set interface.
 * Used by the engine to manage uniform state.
 */
import { UniformDefinitions, UniformDefinition, UniformValue, UniformValues } from '../project/types';
export declare class UniformStore {
    private definitions;
    private values;
    constructor(definitions: UniformDefinitions);
    /**
     * Initialize all values to their definition defaults.
     */
    private initializeDefaults;
    /**
     * Clone a value to avoid mutation of arrays.
     */
    private cloneValue;
    /**
     * Get the definition for a uniform.
     */
    getDefinition(name: string): UniformDefinition | undefined;
    /**
     * Get all definitions.
     */
    getDefinitions(): UniformDefinitions;
    /**
     * Check if a uniform exists.
     */
    has(name: string): boolean;
    /**
     * Get the current value of a uniform.
     */
    get(name: string): UniformValue | undefined;
    /**
     * Get all current values (returns a shallow copy).
     */
    getAll(): UniformValues;
    /**
     * Set the value of a uniform.
     * Returns true if the value was set, false if the uniform doesn't exist.
     */
    set(name: string, value: UniformValue): boolean;
    /**
     * Set without cloning — caller is responsible for not mutating the value afterward.
     * For engine-internal use (e.g., array uniforms where data is immediately packed into UBO).
     */
    setRaw(name: string, value: UniformValue): boolean;
    /**
     * Get the internal reference without cloning. For engine-internal use only.
     */
    getRaw(name: string): UniformValue | undefined;
    /**
     * Set multiple values at once.
     */
    setAll(values: Partial<UniformValues>): void;
    /**
     * Reset a single uniform to its default value.
     */
    reset(name: string): boolean;
    /**
     * Reset all uniforms to their default values.
     */
    resetAll(): void;
    /**
     * Get the default value for a uniform.
     */
    getDefault(name: string): UniformValue | undefined;
    /**
     * Iterate over all uniforms (name, definition, current value).
     */
    entries(): IterableIterator<[string, UniformDefinition, UniformValue]>;
    /**
     * Get the number of uniforms.
     */
    get size(): number;
    /**
     * Check if there are any uniforms.
     */
    get isEmpty(): boolean;
}
//# sourceMappingURL=UniformStore.d.ts.map