/**
 * UniformStore - Simple state manager for custom uniforms
 *
 * Encapsulates uniform values and provides clean get/set interface.
 * Used by the engine to manage uniform state.
 */
import { isArrayUniform, isStructArrayUniform, } from '../project/types';
import { tightFloatCount, computeStructLayout } from '../engine/std140';
export class UniformStore {
    constructor(definitions) {
        this.values = {};
        this.definitions = definitions;
        this.initializeDefaults();
    }
    /**
     * Initialize all values to their definition defaults.
     */
    initializeDefaults() {
        for (const [name, def] of Object.entries(this.definitions)) {
            if (isStructArrayUniform(def)) {
                const layout = computeStructLayout(def.struct);
                this.values[name] = new Float32Array(layout.tightFloatsPerElement * def.count);
            }
            else if (isArrayUniform(def)) {
                this.values[name] = new Float32Array(tightFloatCount(def.type, def.count));
            }
            else {
                this.values[name] = this.cloneValue(def.value);
            }
        }
    }
    /**
     * Clone a value to avoid mutation of arrays.
     */
    cloneValue(value) {
        if (value instanceof Float32Array)
            return value.slice();
        return Array.isArray(value) ? [...value] : value;
    }
    /**
     * Get the definition for a uniform.
     */
    getDefinition(name) {
        return this.definitions[name];
    }
    /**
     * Get all definitions.
     */
    getDefinitions() {
        return this.definitions;
    }
    /**
     * Check if a uniform exists.
     */
    has(name) {
        return name in this.definitions;
    }
    /**
     * Get the current value of a uniform.
     */
    get(name) {
        const value = this.values[name];
        return value !== undefined ? this.cloneValue(value) : undefined;
    }
    /**
     * Get all current values (returns a shallow copy).
     */
    getAll() {
        const result = {};
        for (const [name, value] of Object.entries(this.values)) {
            result[name] = this.cloneValue(value);
        }
        return result;
    }
    /**
     * Set the value of a uniform.
     * Returns true if the value was set, false if the uniform doesn't exist.
     */
    set(name, value) {
        if (!this.has(name)) {
            return false;
        }
        this.values[name] = this.cloneValue(value);
        return true;
    }
    /**
     * Set without cloning — caller is responsible for not mutating the value afterward.
     * For engine-internal use (e.g., array uniforms where data is immediately packed into UBO).
     */
    setRaw(name, value) {
        if (!this.has(name))
            return false;
        this.values[name] = value;
        return true;
    }
    /**
     * Get the internal reference without cloning. For engine-internal use only.
     */
    getRaw(name) {
        return this.values[name];
    }
    /**
     * Set multiple values at once.
     */
    setAll(values) {
        for (const [name, value] of Object.entries(values)) {
            if (value !== undefined) {
                this.set(name, value);
            }
        }
    }
    /**
     * Reset a single uniform to its default value.
     */
    reset(name) {
        const def = this.definitions[name];
        if (!def) {
            return false;
        }
        if (isStructArrayUniform(def)) {
            const layout = computeStructLayout(def.struct);
            this.values[name] = new Float32Array(layout.tightFloatsPerElement * def.count);
        }
        else if (isArrayUniform(def)) {
            this.values[name] = new Float32Array(tightFloatCount(def.type, def.count));
        }
        else {
            this.values[name] = this.cloneValue(def.value);
        }
        return true;
    }
    /**
     * Reset all uniforms to their default values.
     */
    resetAll() {
        this.initializeDefaults();
    }
    /**
     * Get the default value for a uniform.
     */
    getDefault(name) {
        const def = this.definitions[name];
        if (!def)
            return undefined;
        if (isStructArrayUniform(def)) {
            const layout = computeStructLayout(def.struct);
            return new Float32Array(layout.tightFloatsPerElement * def.count);
        }
        if (isArrayUniform(def))
            return new Float32Array(tightFloatCount(def.type, def.count));
        return this.cloneValue(def.value);
    }
    /**
     * Iterate over all uniforms (name, definition, current value).
     */
    *entries() {
        for (const [name, def] of Object.entries(this.definitions)) {
            yield [name, def, this.values[name]];
        }
    }
    /**
     * Get the number of uniforms.
     */
    get size() {
        return Object.keys(this.definitions).length;
    }
    /**
     * Check if there are any uniforms.
     */
    get isEmpty() {
        return this.size === 0;
    }
}
