/**
 * Uniforms Panel - Floating overlay for uniform controls
 *
 * A compact panel that floats on the right side of the canvas.
 * Includes a toggle button to show/hide. Starts closed by default.
 */
import './uniforms-panel.css';
import { UniformDefinitions, UniformValue, UniformValues } from '../project/types';
export interface UniformsPanelOptions {
    /** Parent container to attach the panel to */
    container: HTMLElement;
    /** Uniform definitions from project */
    uniforms: UniformDefinitions;
    /** Callback when uniform value changes */
    onChange: (name: string, value: UniformValue) => void;
    /** Initial values (optional) */
    initialValues?: UniformValues;
    /** Start with panel open (default: false). Ignored when collapsible is false. */
    startOpen?: boolean;
    /** If true (default), the panel collapses behind a toggle button. If false,
     *  the panel is always visible inline over the shader, with no toggle or
     *  header chrome. */
    collapsible?: boolean;
}
export declare class UniformsPanel {
    private wrapper;
    private panel;
    private toggleButton;
    private controls;
    private collapsible;
    private isOpen;
    constructor(opts: UniformsPanelOptions);
    /**
     * Update a uniform value from external source.
     */
    setValue(name: string, value: UniformValue): void;
    /**
     * Show the panel.
     */
    show(): void;
    /**
     * Hide the panel.
     */
    hide(): void;
    /**
     * Toggle panel visibility.
     */
    toggle(): void;
    /**
     * Check if panel is visible.
     */
    isVisible(): boolean;
    /**
     * Destroy the panel.
     */
    destroy(): void;
}
//# sourceMappingURL=UniformsPanel.d.ts.map