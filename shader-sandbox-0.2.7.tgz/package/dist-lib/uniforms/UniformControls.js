/**
 * Uniform Controls Component
 *
 * Renders UI controls for custom uniforms defined in config.json.
 * Supports: float, int, bool, vec2 (XY pad), vec3 (color picker or sliders), vec4 (sliders)
 */
import './uniform-controls.css';
import { isAnyUBOUniform, } from '../project/types';
export class UniformControls {
    constructor(opts) {
        this.values = {};
        this.updaters = new Map();
        // Track document-level event listeners for cleanup
        this.documentListeners = [];
        this.container = opts.container;
        this.uniforms = opts.uniforms;
        this.onChange = opts.onChange;
        // Initialize values
        for (const [name, def] of Object.entries(this.uniforms)) {
            if (isAnyUBOUniform(def) || def.hidden)
                continue;
            this.values[name] = opts.initialValues?.[name] ?? def.value;
        }
        this.render();
    }
    /**
     * Render all uniform controls.
     */
    render() {
        this.container.innerHTML = '';
        this.container.className = 'uniform-controls';
        const uniformEntries = Object.entries(this.uniforms);
        if (uniformEntries.length === 0) {
            const emptyMsg = document.createElement('div');
            emptyMsg.className = 'uniform-controls-empty';
            emptyMsg.textContent = 'No uniforms defined';
            this.container.appendChild(emptyMsg);
            return;
        }
        // Header with reset button
        const header = document.createElement('div');
        header.className = 'uniform-controls-header';
        const resetButton = document.createElement('button');
        resetButton.className = 'uniform-controls-reset';
        resetButton.textContent = 'Reset';
        resetButton.title = 'Reset all uniforms to defaults';
        resetButton.addEventListener('click', () => this.resetToDefaults());
        header.appendChild(resetButton);
        this.container.appendChild(header);
        // Control list
        const controlList = document.createElement('div');
        controlList.className = 'uniform-controls-list';
        for (const [name, def] of uniformEntries) {
            if (isAnyUBOUniform(def) || def.hidden)
                continue;
            const result = this.createControl(name, def);
            if (result) {
                this.updaters.set(name, result.update);
                controlList.appendChild(result.element);
            }
        }
        this.container.appendChild(controlList);
    }
    /**
     * Create a control element for a uniform.
     */
    createControl(name, def) {
        if (isAnyUBOUniform(def) || def.hidden)
            return null;
        switch (def.type) {
            case 'float':
                return this.createFloatSlider(name, def);
            case 'int':
                return this.createIntSlider(name, def);
            case 'bool':
                return this.createBoolToggle(name, def);
            case 'vec2':
                return this.createVec2Pad(name, def);
            case 'vec3':
                return def.color ? this.createColorPicker(name, def) : this.createVecSliders(name, def, 3);
            case 'vec4':
                return def.color ? this.createColorPicker4(name, def) : this.createVecSliders(name, def, 4);
            default:
                console.warn(`Uniform '${name}': unknown type '${def.type}'`);
                return null;
        }
    }
    // ===========================================================================
    // Shared Slider Row Helper
    // ===========================================================================
    createSliderRow(opts) {
        const wrapper = document.createElement('div');
        wrapper.className = 'uniform-control-label-row';
        const labelEl = document.createElement('label');
        labelEl.className = 'uniform-control-label';
        labelEl.textContent = opts.label;
        const valueDisplay = document.createElement('span');
        valueDisplay.className = 'uniform-control-value';
        valueDisplay.textContent = opts.format(opts.value);
        wrapper.appendChild(labelEl);
        wrapper.appendChild(valueDisplay);
        const slider = document.createElement('input');
        slider.type = 'range';
        slider.className = 'uniform-control-slider';
        slider.min = String(opts.min);
        slider.max = String(opts.max);
        slider.step = String(opts.step);
        slider.value = String(opts.value);
        slider.addEventListener('input', () => {
            const v = parseFloat(slider.value);
            opts.onInput(v);
            valueDisplay.textContent = opts.format(v);
        });
        const update = (v) => {
            slider.value = String(v);
            valueDisplay.textContent = opts.format(v);
        };
        return { elements: [wrapper, slider], update };
    }
    // ===========================================================================
    // Float Slider
    // ===========================================================================
    createFloatSlider(name, def) {
        const step = def.step ?? 0.01;
        const { elements, update: sliderUpdate } = this.createSliderRow({
            label: def.label ?? name,
            min: def.min ?? 0,
            max: def.max ?? 1,
            step,
            value: this.values[name],
            format: (v) => this.formatNumber(v, step),
            onInput: (v) => {
                this.values[name] = v;
                this.onChange(name, v);
            },
        });
        const wrapper = document.createElement('div');
        wrapper.className = 'uniform-control uniform-control-float';
        for (const el of elements)
            wrapper.appendChild(el);
        return {
            element: wrapper,
            update: (v) => sliderUpdate(v),
        };
    }
    // ===========================================================================
    // Int Slider
    // ===========================================================================
    createIntSlider(name, def) {
        const { elements, update: sliderUpdate } = this.createSliderRow({
            label: def.label ?? name,
            min: def.min ?? 0,
            max: def.max ?? 10,
            step: def.step ?? 1,
            value: this.values[name],
            format: (v) => String(Math.round(v)),
            onInput: (v) => {
                const intVal = Math.round(v);
                this.values[name] = intVal;
                this.onChange(name, intVal);
            },
        });
        const wrapper = document.createElement('div');
        wrapper.className = 'uniform-control uniform-control-int';
        for (const el of elements)
            wrapper.appendChild(el);
        return {
            element: wrapper,
            update: (v) => sliderUpdate(v),
        };
    }
    // ===========================================================================
    // Bool Toggle
    // ===========================================================================
    createBoolToggle(name, def) {
        const value = this.values[name];
        const label = def.label ?? name;
        const wrapper = document.createElement('div');
        wrapper.className = 'uniform-control uniform-control-bool';
        const labelRow = document.createElement('div');
        labelRow.className = 'uniform-control-label-row';
        const labelEl = document.createElement('label');
        labelEl.className = 'uniform-control-label';
        labelEl.textContent = label;
        const toggleWrapper = document.createElement('label');
        toggleWrapper.className = 'uniform-control-toggle';
        const checkbox = document.createElement('input');
        checkbox.type = 'checkbox';
        checkbox.checked = value;
        const slider = document.createElement('span');
        slider.className = 'uniform-control-toggle-slider';
        checkbox.addEventListener('change', () => {
            const newValue = checkbox.checked;
            this.values[name] = newValue;
            this.onChange(name, newValue);
        });
        toggleWrapper.appendChild(checkbox);
        toggleWrapper.appendChild(slider);
        labelRow.appendChild(labelEl);
        labelRow.appendChild(toggleWrapper);
        wrapper.appendChild(labelRow);
        return {
            element: wrapper,
            update: (v) => { checkbox.checked = v; },
        };
    }
    // ===========================================================================
    // Vec2 XY Pad
    // ===========================================================================
    createVec2Pad(name, def) {
        const value = this.values[name];
        const min = def.min ?? [0, 0];
        const max = def.max ?? [1, 1];
        const label = def.label ?? name;
        const wrapper = document.createElement('div');
        wrapper.className = 'uniform-control uniform-control-vec2';
        const labelRow = document.createElement('div');
        labelRow.className = 'uniform-control-label-row';
        const labelEl = document.createElement('label');
        labelEl.className = 'uniform-control-label';
        labelEl.textContent = label;
        const valueDisplay = document.createElement('span');
        valueDisplay.className = 'uniform-control-value';
        valueDisplay.textContent = this.formatVec2(value);
        labelRow.appendChild(labelEl);
        labelRow.appendChild(valueDisplay);
        const padContainer = document.createElement('div');
        padContainer.className = 'uniform-control-xy-pad';
        const handle = document.createElement('div');
        handle.className = 'uniform-control-xy-handle';
        padContainer.appendChild(handle);
        const positionHandle = (v) => {
            const xPercent = ((v[0] - min[0]) / (max[0] - min[0])) * 100;
            const yPercent = (1 - (v[1] - min[1]) / (max[1] - min[1])) * 100;
            handle.style.left = `${xPercent}%`;
            handle.style.top = `${yPercent}%`;
        };
        positionHandle(value);
        let isDragging = false;
        const updateFromEvent = (e) => {
            const rect = padContainer.getBoundingClientRect();
            const clientX = 'touches' in e ? e.touches[0].clientX : e.clientX;
            const clientY = 'touches' in e ? e.touches[0].clientY : e.clientY;
            let xPercent = Math.max(0, Math.min(1, (clientX - rect.left) / rect.width));
            let yPercent = Math.max(0, Math.min(1, (clientY - rect.top) / rect.height));
            const newX = min[0] + xPercent * (max[0] - min[0]);
            const newY = min[1] + (1 - yPercent) * (max[1] - min[1]);
            const newValue = [newX, newY];
            this.values[name] = newValue;
            handle.style.left = `${xPercent * 100}%`;
            handle.style.top = `${yPercent * 100}%`;
            valueDisplay.textContent = this.formatVec2(newValue);
            this.onChange(name, newValue);
        };
        const onMouseDown = (e) => { isDragging = true; updateFromEvent(e); e.preventDefault(); };
        const onMouseMove = (e) => { if (isDragging)
            updateFromEvent(e); };
        const onMouseUp = () => { isDragging = false; };
        padContainer.addEventListener('mousedown', onMouseDown);
        document.addEventListener('mousemove', onMouseMove);
        document.addEventListener('mouseup', onMouseUp);
        this.documentListeners.push({ type: 'mousemove', handler: onMouseMove });
        this.documentListeners.push({ type: 'mouseup', handler: onMouseUp });
        const onTouchStart = (e) => { isDragging = true; updateFromEvent(e); e.preventDefault(); };
        const onTouchMove = (e) => { if (isDragging)
            updateFromEvent(e); };
        padContainer.addEventListener('touchstart', onTouchStart);
        document.addEventListener('touchmove', onTouchMove);
        document.addEventListener('touchend', onMouseUp);
        this.documentListeners.push({ type: 'touchmove', handler: onTouchMove });
        this.documentListeners.push({ type: 'touchend', handler: onMouseUp });
        wrapper.appendChild(labelRow);
        wrapper.appendChild(padContainer);
        return {
            element: wrapper,
            update: (v) => {
                const vec = v;
                positionHandle(vec);
                valueDisplay.textContent = this.formatVec2(vec);
            },
        };
    }
    // ===========================================================================
    // Vec3 Color Picker
    // ===========================================================================
    createColorPicker(name, def) {
        const value = this.values[name];
        const label = def.label ?? name;
        const wrapper = document.createElement('div');
        wrapper.className = 'uniform-control uniform-control-color';
        const labelRow = document.createElement('div');
        labelRow.className = 'uniform-control-label-row';
        const labelEl = document.createElement('label');
        labelEl.className = 'uniform-control-label';
        labelEl.textContent = label;
        const valueDisplay = document.createElement('span');
        valueDisplay.className = 'uniform-control-value';
        valueDisplay.textContent = this.rgbToHex(value);
        labelRow.appendChild(labelEl);
        labelRow.appendChild(valueDisplay);
        const colorWrapper = document.createElement('div');
        colorWrapper.className = 'uniform-control-color-wrapper';
        const colorInput = document.createElement('input');
        colorInput.type = 'color';
        colorInput.className = 'uniform-control-color-input';
        colorInput.value = this.rgbToHex(value);
        const swatch = document.createElement('div');
        swatch.className = 'uniform-control-color-swatch';
        swatch.style.backgroundColor = this.rgbToHex(value);
        colorInput.addEventListener('input', () => {
            const newValue = this.hexToRgb(colorInput.value);
            this.values[name] = newValue;
            valueDisplay.textContent = colorInput.value;
            swatch.style.backgroundColor = colorInput.value;
            this.onChange(name, newValue);
        });
        swatch.addEventListener('click', () => colorInput.click());
        colorWrapper.appendChild(swatch);
        colorWrapper.appendChild(colorInput);
        wrapper.appendChild(labelRow);
        wrapper.appendChild(colorWrapper);
        return {
            element: wrapper,
            update: (v) => {
                const hex = this.rgbToHex(v);
                colorInput.value = hex;
                swatch.style.backgroundColor = hex;
                valueDisplay.textContent = hex;
            },
        };
    }
    // ===========================================================================
    // Vec4 Color Picker (with alpha)
    // ===========================================================================
    createColorPicker4(name, def) {
        // Build RGB color picker + alpha slider from scratch (no cloneNode hacks)
        const value = this.values[name];
        const label = def.label ?? name;
        const wrapper = document.createElement('div');
        wrapper.className = 'uniform-control uniform-control-color';
        // Label row
        const labelRow = document.createElement('div');
        labelRow.className = 'uniform-control-label-row';
        const labelEl = document.createElement('label');
        labelEl.className = 'uniform-control-label';
        labelEl.textContent = label;
        const valueDisplay = document.createElement('span');
        valueDisplay.className = 'uniform-control-value';
        valueDisplay.textContent = this.rgbToHex(value);
        labelRow.appendChild(labelEl);
        labelRow.appendChild(valueDisplay);
        // Color picker for RGB
        const colorWrapper = document.createElement('div');
        colorWrapper.className = 'uniform-control-color-wrapper';
        const colorInput = document.createElement('input');
        colorInput.type = 'color';
        colorInput.className = 'uniform-control-color-input';
        colorInput.value = this.rgbToHex(value);
        const swatch = document.createElement('div');
        swatch.className = 'uniform-control-color-swatch';
        swatch.style.backgroundColor = this.rgbToHex(value);
        colorInput.addEventListener('input', () => {
            const rgb = this.hexToRgb(colorInput.value);
            const current = this.values[name];
            current[0] = rgb[0];
            current[1] = rgb[1];
            current[2] = rgb[2];
            valueDisplay.textContent = colorInput.value;
            swatch.style.backgroundColor = colorInput.value;
            this.onChange(name, [...current]);
        });
        swatch.addEventListener('click', () => colorInput.click());
        colorWrapper.appendChild(swatch);
        colorWrapper.appendChild(colorInput);
        // Alpha slider
        const alphaStep = def.step?.[3] ?? 0.01;
        const { elements: alphaElements, update: alphaUpdate } = this.createSliderRow({
            label: 'Alpha',
            min: def.min?.[3] ?? 0,
            max: def.max?.[3] ?? 1,
            step: alphaStep,
            value: value[3],
            format: (v) => this.formatNumber(v, alphaStep),
            onInput: (v) => {
                const current = this.values[name];
                current[3] = v;
                this.onChange(name, [...current]);
            },
        });
        wrapper.appendChild(labelRow);
        wrapper.appendChild(colorWrapper);
        for (const el of alphaElements)
            wrapper.appendChild(el);
        return {
            element: wrapper,
            update: (v) => {
                const vec = v;
                const hex = this.rgbToHex(vec);
                colorInput.value = hex;
                swatch.style.backgroundColor = hex;
                valueDisplay.textContent = hex;
                alphaUpdate(vec[3]);
            },
        };
    }
    // ===========================================================================
    // Vec3/Vec4 Component Sliders
    // ===========================================================================
    createVecSliders(name, def, count) {
        const value = this.values[name];
        const label = def.label ?? name;
        const components = count === 3 ? ['X', 'Y', 'Z'] : ['X', 'Y', 'Z', 'W'];
        const wrapper = document.createElement('div');
        wrapper.className = `uniform-control uniform-control-vec${count}`;
        const labelEl = document.createElement('div');
        labelEl.className = 'uniform-control-label';
        labelEl.textContent = label;
        wrapper.appendChild(labelEl);
        const sliderUpdaters = [];
        components.forEach((comp, i) => {
            const step = def.step?.[i] ?? 0.01;
            const { elements: rowElements, update: rowUpdate } = this.createSliderRow({
                label: comp,
                min: def.min?.[i] ?? 0,
                max: def.max?.[i] ?? 1,
                step,
                value: value[i],
                format: (v) => this.formatNumber(v, step),
                onInput: (v) => {
                    const currentValue = this.values[name];
                    currentValue[i] = v;
                    this.onChange(name, [...currentValue]);
                },
            });
            // Style the row for vec component layout
            const [labelRow, slider] = rowElements;
            labelRow.classList.add('uniform-control-vec-slider-row');
            labelRow.querySelector('.uniform-control-label')?.classList.add('uniform-control-vec-component');
            labelRow.querySelector('.uniform-control-value')?.classList.add('uniform-control-vec-value');
            slider.classList.add('uniform-control-vec-slider');
            // Group label-row + slider as a single visual unit so the vec wrapper's
            // gap separates components rather than every label-row/slider pair.
            const componentGroup = document.createElement('div');
            componentGroup.className = 'uniform-control-vec-component-group';
            componentGroup.appendChild(labelRow);
            componentGroup.appendChild(slider);
            sliderUpdaters.push(rowUpdate);
            wrapper.appendChild(componentGroup);
        });
        return {
            element: wrapper,
            update: (v) => {
                const vec = v;
                sliderUpdaters.forEach((upd, i) => upd(vec[i]));
            },
        };
    }
    // ===========================================================================
    // Utility Methods
    // ===========================================================================
    formatNumber(value, step) {
        const stepStr = String(step);
        const decimalIndex = stepStr.indexOf('.');
        const decimals = decimalIndex === -1 ? 0 : stepStr.length - decimalIndex - 1;
        return value.toFixed(decimals);
    }
    formatVec2(value) {
        return `(${value[0].toFixed(2)}, ${value[1].toFixed(2)})`;
    }
    rgbToHex(rgb) {
        const r = Math.round(rgb[0] * 255);
        const g = Math.round(rgb[1] * 255);
        const b = Math.round(rgb[2] * 255);
        return `#${r.toString(16).padStart(2, '0')}${g.toString(16).padStart(2, '0')}${b.toString(16).padStart(2, '0')}`;
    }
    hexToRgb(hex) {
        const result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
        if (!result)
            return [0, 0, 0];
        return [
            parseInt(result[1], 16) / 255,
            parseInt(result[2], 16) / 255,
            parseInt(result[3], 16) / 255,
        ];
    }
    // ===========================================================================
    // Public Methods
    // ===========================================================================
    /**
     * Update a uniform value externally (e.g., from reset).
     */
    setValue(name, value) {
        if (!(name in this.uniforms))
            return;
        this.values[name] = value;
        this.updaters.get(name)?.(value);
    }
    /**
     * Reset all uniforms to their default values.
     */
    resetToDefaults() {
        for (const [name, def] of Object.entries(this.uniforms)) {
            if (isAnyUBOUniform(def) || def.hidden)
                continue;
            this.setValue(name, def.value);
            this.onChange(name, def.value);
        }
    }
    /**
     * Destroy the controls and clean up.
     */
    destroy() {
        for (const { type, handler } of this.documentListeners) {
            document.removeEventListener(type, handler);
        }
        this.documentListeners = [];
        this.container.innerHTML = '';
        this.updaters.clear();
    }
}
