/**
 * Runtime Loader — fetch-based shader loading, no build step.
 *
 * A standalone entry point that loads shader projects directly from a folder
 * of raw files over HTTP. No Vite, no Node, no compile step — just a static
 * file server.
 *
 * Exports:
 *   - loadFromFolder(el, url, options)  — load from a shader folder or .glsl URL
 *   - loadFromSource(el, glsl, options) — load from inline GLSL source
 *
 * Also registers the <shader-sandbox> custom element:
 *   <shader-sandbox src="/shaders/mandelbrot/" controls="false"></shader-sandbox>
 *   <shader-sandbox src="/shaders/heatmap.glsl" static></shader-sandbox>
 *   <shader-sandbox>void mainImage(...) { ... }</shader-sandbox>
 */
import { MountHandle, MountPresentationOptions } from './mount';
/**
 * Load a shader project from a URL and mount it into a DOM element.
 *
 * Supports two URL shapes:
 *   - Folder URL ("/shaders/mandelbrot/")     — full project with config.json
 *   - Single GLSL file ("/shaders/heatmap.glsl") — single-pass, no config needed
 */
export declare function loadFromFolder(el: HTMLElement, url: string, options?: MountPresentationOptions): Promise<MountHandle>;
/**
 * Mount a shader from inline GLSL source (no fetch).
 */
export declare function loadFromSource(el: HTMLElement, glsl: string, options?: MountPresentationOptions): MountHandle;
export type { MountHandle, MountPresentationOptions };
//# sourceMappingURL=runtime.d.ts.map