/**
 * <live-app> Custom Element
 *
 * A generic launcher for any module that exports mount(el, options?).
 * Works with shader-sandbox, three.js apps, or any other visual module.
 *
 * Usage:
 *   <script type="module" src="/js/live-app.js"></script>
 *   <live-app src="/viz/my-shader/main.js" style="width:100%;height:400px;display:block;"></live-app>
 *
 * Reserved attributes (control the component itself):
 *   src       — Path to the module (must export mount)
 *   fullpage  — Present: fill the viewport (position:fixed, 100vw x 100vh)
 *   lazy      — "false" to disable lazy loading (default: lazy-loads on scroll)
 *
 * All other attributes are passed as options to mount():
 *   controls="false"    → { controls: false }
 *   theme="dark"        → { theme: 'dark' }
 *   start-paused="true" → { startPaused: true }
 *   pixel-ratio="2"     → { pixelRatio: 2 }
 *   camera-fov="75"     → { cameraFov: 75 }
 *
 * Type coercion: "true"/"false" → boolean, numeric strings → number.
 * Attribute names are converted from kebab-case to camelCase.
 *
 * Module contract:
 *   The imported module must export:
 *     mount(el, options?) → Promise<{ destroy() }> | { destroy() }
 */
/** Attributes reserved for component behavior (not passed as options). */
declare const RESERVED_ATTRS: Set<string>;
type MountFn = (el: HTMLElement, options?: Record<string, unknown>) => Promise<{
    destroy: () => void;
}> | {
    destroy: () => void;
};
interface AppModule {
    mount: MountFn;
}
/**
 * Convert kebab-case to camelCase: "start-paused" → "startPaused"
 */
declare function kebabToCamel(s: string): string;
/**
 * Coerce a string attribute value to a JS type:
 *   "true"/"false" → boolean
 *   numeric string  → number
 *   everything else → string
 */
declare function coerceValue(value: string): string | number | boolean;
declare class LiveApp extends HTMLElement {
    private _handle;
    private _observer;
    private _unmountTimer;
    private _mounted;
    connectedCallback(): void;
    disconnectedCallback(): void;
    /**
     * Collect non-reserved attributes into an options object.
     */
    private _buildOptions;
    private _mountApp;
    private _unmountApp;
}
//# sourceMappingURL=live-app.d.ts.map