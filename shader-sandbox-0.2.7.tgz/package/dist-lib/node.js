/**
 * Node-safe entry point.
 *
 * This file is intentionally self-contained (no runtime imports), so Node/SSR
 * can import the package without evaluating browser/CSS modules.
 */
const BROWSER_ONLY_ERROR = "This API is browser-only. Import 'shader-sandbox' in your browser bundle, not in Node runtime.";
export function mount(_el, _options) {
    throw new Error(BROWSER_ONLY_ERROR);
}
export class App {
    constructor() {
        throw new Error(BROWSER_ONLY_ERROR);
    }
}
export class ShaderView {
    constructor() {
        throw new Error(BROWSER_ONLY_ERROR);
    }
}
export class MultiViewControls {
    constructor() {
        throw new Error(BROWSER_ONLY_ERROR);
    }
}
export function createLayout() {
    throw new Error(BROWSER_ONLY_ERROR);
}
export function createMultiViewLayout() {
    throw new Error(BROWSER_ONLY_ERROR);
}
export function applyTheme() {
    throw new Error(BROWSER_ONLY_ERROR);
}
export function loadDemo() {
    throw new Error(BROWSER_ONLY_ERROR);
}
export function isArrayUniform(def) {
    return !!def && typeof def === 'object' && 'count' in def && !('struct' in def);
}
export function isMultiViewProject(project) {
    return !!project && typeof project === 'object' && Array.isArray(project.views);
}
export function isMultiViewConfig(config) {
    return !!config && typeof config === 'object' && Array.isArray(config.views);
}
