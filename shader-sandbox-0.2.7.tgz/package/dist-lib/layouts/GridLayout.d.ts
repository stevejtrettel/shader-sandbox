/**
 * Grid Layout
 *
 * Adaptive multi-view layout that arranges N shader views using CSS Grid.
 * Replaces SplitViewLayout and QuadViewLayout with a single responsive class.
 *
 * View count behavior:
 * - 2 views: side-by-side (wide) or stacked (narrow), responsive
 * - 3 views: 2-column grid, last view spans full width
 * - 4 views: 2x2 grid
 */
import './multi-view.css';
import { MultiViewLayout, MultiViewLayoutOptions } from './types';
export declare class GridLayout implements MultiViewLayout {
    private container;
    private wrapper;
    private canvasContainers;
    private resizeObserver;
    constructor(opts: MultiViewLayoutOptions);
    private updateOrientation;
    getCanvasContainers(): Map<string, HTMLElement>;
    getWrapperElement(): HTMLElement;
    dispose(): void;
}
//# sourceMappingURL=GridLayout.d.ts.map