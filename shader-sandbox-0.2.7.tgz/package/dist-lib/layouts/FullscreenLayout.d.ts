/**
 * Fullscreen Layout
 *
 * Canvas fills entire viewport, no padding or styling.
 * Used for immersive shader experiences.
 */
import './fullscreen.css';
import { BaseLayout, LayoutOptions } from './types';
export declare class FullscreenLayout implements BaseLayout {
    private container;
    private root;
    private canvasContainer;
    constructor(opts: LayoutOptions);
    getCanvasContainer(): HTMLElement;
    dispose(): void;
}
//# sourceMappingURL=FullscreenLayout.d.ts.map