/**
 * UI Layout
 *
 * Shader on left, uniform controls panel on right (~200px wide).
 * Playback controls (play/pause, reset, screenshot) at bottom of UI panel.
 * Responsive: stacks vertically on small screens (<600px).
 */
import './ui.css';
import { BaseLayout, LayoutOptions } from './types';
import { UniformValue } from '../project/types';
export declare class UILayout implements BaseLayout {
    private container;
    private project;
    private root;
    private canvasContainer;
    private uiPanel;
    private uniformsContainer;
    private uniformControls;
    private playbackContainer;
    private playPauseButton;
    private onPlayPause;
    private onReset;
    private onScreenshot;
    private onUniformChange;
    private _disposed;
    constructor(opts: LayoutOptions);
    getCanvasContainer(): HTMLElement;
    /**
     * Set callbacks for playback controls.
     * Called by App after initialization.
     */
    setPlaybackCallbacks(callbacks: {
        onPlayPause: () => void;
        onReset: () => void;
        onScreenshot: () => void;
    }): void;
    /**
     * Set callback for uniform changes.
     * Called by App after initialization.
     */
    setUniformCallback(callback: (name: string, value: UniformValue) => void): void;
    /**
     * Update play/pause button state.
     */
    setPaused(paused: boolean): void;
    dispose(): void;
    /**
     * Build playback control buttons.
     */
    private buildPlaybackControls;
    /**
     * Load uniform controls dynamically.
     */
    private loadUniformControls;
}
//# sourceMappingURL=UILayout.d.ts.map