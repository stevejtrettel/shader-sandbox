/**
 * Default Layout
 *
 * Centered canvas with rounded corners and drop shadow.
 * Default layout mode for a polished presentation.
 */
import './default.css';
import { BaseLayout, LayoutOptions } from './types';
export declare class DefaultLayout implements BaseLayout {
    private container;
    private root;
    private canvasContainer;
    constructor(opts: LayoutOptions);
    getCanvasContainer(): HTMLElement;
    dispose(): void;
}
//# sourceMappingURL=DefaultLayout.d.ts.map