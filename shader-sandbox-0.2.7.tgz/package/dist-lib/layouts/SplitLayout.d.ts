/**
 * Split Layout
 *
 * Shader on left, editable code on right with syntax highlighting.
 * Ideal for teaching and presentations where viewers can tweak the code.
 */
import './split.css';
import { BaseLayout, LayoutOptions, RecompileHandler, UniformChangeHandler } from './types';
export declare class SplitLayout implements BaseLayout {
    private container;
    private project;
    private root;
    private canvasContainer;
    private codePanel;
    private editorPanel;
    private recompileHandler;
    private _disposed;
    constructor(opts: LayoutOptions);
    getCanvasContainer(): HTMLElement;
    setRecompileHandler(handler: RecompileHandler): void;
    setUniformHandler(_handler: UniformChangeHandler): void;
    dispose(): void;
    /**
     * Build editor panel (dynamically loaded).
     */
    private buildEditorPanel;
}
//# sourceMappingURL=SplitLayout.d.ts.map