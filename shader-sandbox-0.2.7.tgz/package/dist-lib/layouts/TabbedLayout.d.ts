/**
 * Tabbed Layout
 *
 * Single window with tabs to switch between shader output, editable code, and textures.
 * First tab shows the live shader, remaining tabs show editable GLSL source files and images.
 */
import './tabbed.css';
import { BaseLayout, LayoutOptions, RecompileHandler } from './types';
export declare class TabbedLayout implements BaseLayout {
    private container;
    private project;
    private root;
    private canvasContainer;
    private contentArea;
    private imageViewer;
    private editorContainer;
    private editorInstance;
    private buttonContainer;
    private copyButton;
    private recompileButton;
    private errorDisplay;
    private recompileHandler;
    private modifiedSources;
    private tabs;
    private activeTabIndex;
    private keydownHandler;
    constructor(opts: LayoutOptions);
    getCanvasContainer(): HTMLElement;
    setRecompileHandler(handler: RecompileHandler): void;
    dispose(): void;
    private setupKeyboardShortcut;
    private saveCurrentEditorContent;
    private recompile;
    private showError;
    private hideError;
    private copyToClipboard;
    private buildTabBar;
}
//# sourceMappingURL=TabbedLayout.d.ts.map