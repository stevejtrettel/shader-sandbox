/**
 * Inset View Layout
 *
 * Displays two views: one fullscreen (main) and one as a small overlay (inset).
 * The inset can be minimized to show the full main view.
 */
import './multi-view.css';
import { MultiViewLayout, MultiViewLayoutOptions } from './types';
export declare class InsetViewLayout implements MultiViewLayout {
    private container;
    private wrapper;
    private canvasContainers;
    private insetContainer;
    private minimizeBtn;
    private isMinimized;
    constructor(opts: MultiViewLayoutOptions);
    private toggleMinimize;
    getCanvasContainers(): Map<string, HTMLElement>;
    getWrapperElement(): HTMLElement;
    dispose(): void;
}
//# sourceMappingURL=InsetViewLayout.d.ts.map