/**
 * Split Layout
 *
 * Shader on left, editable code on right with syntax highlighting.
 * Ideal for teaching and presentations where viewers can tweak the code.
 */
import './split.css';
export class SplitLayout {
    constructor(opts) {
        this.editorPanel = null;
        this.recompileHandler = null;
        this._disposed = false;
        this.container = opts.container;
        this.project = opts.project;
        // Create root layout container
        this.root = document.createElement('div');
        this.root.className = 'layout-split';
        // Create canvas container (left side)
        this.canvasContainer = document.createElement('div');
        this.canvasContainer.className = 'canvas-container';
        // Create code panel (right side)
        this.codePanel = document.createElement('div');
        this.codePanel.className = 'code-panel';
        // Build editor panel
        this.buildEditorPanel();
        // Assemble and append to DOM
        this.root.appendChild(this.canvasContainer);
        this.root.appendChild(this.codePanel);
        this.container.appendChild(this.root);
    }
    getCanvasContainer() {
        return this.canvasContainer;
    }
    setRecompileHandler(handler) {
        this.recompileHandler = handler;
        if (this.editorPanel) {
            this.editorPanel.setRecompileHandler(handler);
        }
    }
    setUniformHandler(_handler) {
        // Uniform editing is handled by the floating UniformsPanel overlay,
        // not by the code editor in this layout.
    }
    dispose() {
        this._disposed = true;
        if (this.editorPanel) {
            this.editorPanel.dispose();
            this.editorPanel = null;
        }
        this.container.innerHTML = '';
    }
    /**
     * Build editor panel (dynamically loaded).
     */
    async buildEditorPanel() {
        try {
            const { EditorPanel } = await import('../editor/EditorPanel');
            if (this._disposed)
                return;
            this.editorPanel = new EditorPanel(this.codePanel, this.project);
            if (this.recompileHandler) {
                this.editorPanel.setRecompileHandler(this.recompileHandler);
            }
        }
        catch (err) {
            console.error('Failed to load editor panel:', err);
        }
    }
}
