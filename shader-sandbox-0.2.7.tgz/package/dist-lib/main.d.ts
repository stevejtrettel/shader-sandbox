/**
 * Main Entry Point (Dev Server)
 *
 * Thin wrapper around mount() that adds dev-only padding and debug globals.
 *
 * To run a specific demo:
 *   npm run dev:demo <demo-name>
 *
 * Examples:
 *   npm run dev:demo keyboard-test
 *   npm run dev:demo simple-gradient
 *   npm run dev:demo mandelbrot-julia (multi-view)
 */
import './styles/dev.css';
//# sourceMappingURL=main.d.ts.map