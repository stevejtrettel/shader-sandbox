// Auto-generated - DO NOT EDIT
import { loadDemo } from './loaderHelper';
export const DEMO_NAME = 'demos/examples/inline-controls';
// Transform glob keys from "/path" to "./path" format
function transformKeys(files) {
    const result = {};
    for (const [key, value] of Object.entries(files)) {
        // Convert /demos/... to ./demos/...
        const newKey = key.startsWith('/') ? '.' + key : key;
        result[newKey] = value;
    }
    return result;
}
export async function loadDemoProject() {
    // Use root-relative paths for globs (works from any file location)
    const glslFilesRaw = import.meta.glob('/demos/examples/inline-controls/**/*.glsl', {
        query: '?raw',
        import: 'default',
    });
    const jsonFilesRaw = import.meta.glob('/demos/examples/inline-controls/**/*.json', {
        import: 'default',
    });
    const imageFilesRaw = import.meta.glob('/demos/examples/inline-controls/**/*.{jpg,jpeg,png,gif,webp,bmp}', {
        query: '?url',
        import: 'default',
    });
    // Script files (setup.js / script.js hooks for JS-driven computation)
    const scriptFilesRaw = import.meta.glob('/demos/examples/inline-controls/**/script.js');
    // Transform keys to ./ format that loadDemo expects
    const glslFiles = transformKeys(glslFilesRaw);
    const jsonFiles = transformKeys(jsonFilesRaw);
    const imageFiles = transformKeys(imageFilesRaw);
    const scriptFiles = transformKeys(scriptFilesRaw);
    return loadDemo(DEMO_NAME, glslFiles, jsonFiles, imageFiles, scriptFiles);
}
