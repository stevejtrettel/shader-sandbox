/**
 * Core project loading logic shared between Node (loadProject.ts) and
 * browser (loaderHelper.ts) environments.
 *
 * All file I/O goes through the FileLoader interface, so this module
 * has no direct dependency on Node's fs or Vite's import.meta.glob.
 */
import type { FileLoader } from './FileLoader';
import { ThemeMode, ShaderProject, ShaderTexture2D, UniformDefinitions, DemoScriptHooks } from './types';
export interface ShaderProjectInput {
    mode: 'shadertoy' | 'standard';
    root: string;
    title?: string;
    author?: string;
    description?: string;
    layout?: 'fullscreen' | 'default' | 'split' | 'tabbed';
    theme?: ThemeMode;
    controls?: boolean;
    stats?: boolean;
    playback?: boolean;
    uniformsUI?: 'panel' | 'inline' | 'off';
    startPaused?: boolean;
    stickyMouse?: boolean;
    pixelRatio?: number;
    commonSource: string | null;
    passes: ShaderProject['passes'];
    textures?: ShaderTexture2D[];
    uniforms?: UniformDefinitions;
    uniformData?: Record<string, unknown>;
    script?: DemoScriptHooks | null;
}
/**
 * Build a ShaderProject with sensible defaults.
 * Eliminates the 8+ repeated object literals across loaders.
 */
export declare function buildShaderProject(input: ShaderProjectInput): ShaderProject;
export declare function validateUniforms(uniforms: UniformDefinitions, root: string): void;
export declare function resolveCommonSource(loader: FileLoader, root: string, commonField?: string): Promise<string | null>;
/**
 * Load a shader project using the provided FileLoader.
 * Handles all three project shapes: single-pass, shadertoy, and standard.
 */
export declare function loadProjectFromFiles(loader: FileLoader, root: string, opts?: {
    /** Pre-parsed config (browser loader pre-loads JSON). If absent, reads config.json from disk. */
    config?: any;
    /** Pre-loaded script hooks (browser loader pre-imports script.js). */
    script?: DemoScriptHooks | null;
    /** Pre-resolved texture path → URL map (browser loader resolves via Vite). */
    textureUrlResolver?: (path: string) => Promise<string>;
}): Promise<ShaderProject>;
//# sourceMappingURL=loadProjectCore.d.ts.map