/**
 * Project Layer - Node/CLI Loader
 *
 * Thin adapter that implements FileLoader using Node's fs/path,
 * then delegates to the shared loadProjectFromFiles() core.
 */
import { promises as fs } from 'fs';
import * as path from 'path';
import { loadProjectFromFiles } from './loadProjectCore';
// =============================================================================
// Node FileLoader Implementation
// =============================================================================
function createNodeFileLoader() {
    return {
        async exists(p) {
            try {
                await fs.access(p);
                return true;
            }
            catch {
                return false;
            }
        },
        async readText(p) {
            return fs.readFile(p, 'utf8');
        },
        async resolveImageUrl(p) {
            // Node: just return the file path as-is
            return p;
        },
        async listGlslFiles(directory) {
            try {
                const entries = await fs.readdir(directory, { withFileTypes: true });
                return entries
                    .filter((e) => e.isFile() && e.name.toLowerCase().endsWith('.glsl'))
                    .map((e) => e.name);
            }
            catch {
                return [];
            }
        },
        async hasFiles(directory) {
            try {
                const entries = await fs.readdir(directory, { withFileTypes: true });
                return entries.some((e) => e.isFile());
            }
            catch {
                return false;
            }
        },
        joinPath(...parts) {
            return path.join(...parts);
        },
        baseName(p) {
            return path.basename(p);
        },
    };
}
// =============================================================================
// Public API
// =============================================================================
/**
 * Load a shader project from disk (Node/CLI environment).
 *
 * @param root - Absolute path to project directory
 * @returns Fully normalized ShaderProject
 * @throws Error with descriptive message if project is invalid
 */
export async function loadProject(root) {
    const loader = createNodeFileLoader();
    return loadProjectFromFiles(loader, root);
}
