/**
 * Project Layer - Node/CLI Loader
 *
 * Thin adapter that implements FileLoader using Node's fs/path,
 * then delegates to the shared loadProjectFromFiles() core.
 */
import type { ShaderProject } from './types';
/**
 * Load a shader project from disk (Node/CLI environment).
 *
 * @param root - Absolute path to project directory
 * @returns Fully normalized ShaderProject
 * @throws Error with descriptive message if project is invalid
 */
export declare function loadProject(root: string): Promise<ShaderProject>;
//# sourceMappingURL=loadProject.d.ts.map