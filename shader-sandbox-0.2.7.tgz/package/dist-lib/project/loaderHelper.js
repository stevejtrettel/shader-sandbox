/**
 * Project Layer - Browser/Vite Loader
 *
 * Thin adapter that implements FileLoader over Vite's import.meta.glob
 * record maps, then delegates to the shared loadProjectFromFiles() core.
 */
import { loadProjectFromFiles } from './loadProjectCore';
import { isMultiViewConfig } from './types';
import { validateMultiViewConfig } from './configHelpers';
// =============================================================================
// Case-Insensitive File Lookup
// =============================================================================
function findFileCaseInsensitive(files, path) {
    if (path in files)
        return path;
    const lowerPath = path.toLowerCase();
    for (const key of Object.keys(files)) {
        if (key.toLowerCase() === lowerPath) {
            return key;
        }
    }
    return null;
}
// =============================================================================
// Script Loading
// =============================================================================
async function loadScript(demoPath, scriptFiles) {
    if (!scriptFiles)
        return null;
    const scriptPath = `${demoPath}/script.js`;
    const actualPath = findFileCaseInsensitive(scriptFiles, scriptPath);
    if (!actualPath)
        return null;
    const mod = await scriptFiles[actualPath]();
    const hooks = {};
    if (typeof mod.setup === 'function')
        hooks.setup = mod.setup;
    if (typeof mod.onFrame === 'function')
        hooks.onFrame = mod.onFrame;
    if (typeof mod.dispose === 'function')
        hooks.dispose = mod.dispose;
    if (typeof mod.onUniformChange === 'function')
        hooks.onUniformChange = mod.onUniformChange;
    return (hooks.setup || hooks.onFrame || hooks.dispose || hooks.onUniformChange) ? hooks : null;
}
// =============================================================================
// Browser FileLoader Implementation
// =============================================================================
function createBrowserFileLoader(glslFiles, imageFiles) {
    return {
        async exists(path) {
            return findFileCaseInsensitive(glslFiles, path) !== null
                || findFileCaseInsensitive(imageFiles, path) !== null;
        },
        async readText(path) {
            const actualPath = findFileCaseInsensitive(glslFiles, path);
            if (!actualPath) {
                throw new Error(`File not found: ${path}`);
            }
            return glslFiles[actualPath]();
        },
        async resolveImageUrl(path) {
            const actualPath = findFileCaseInsensitive(imageFiles, path);
            if (!actualPath) {
                throw new Error(`Image not found: ${path}`);
            }
            return imageFiles[actualPath]();
        },
        async listGlslFiles() {
            // Browser loader doesn't support directory listing for validation;
            // return empty to skip the extra-files check in loadProjectCore.
            return [];
        },
        async hasFiles() {
            // Browser loader doesn't have directory awareness
            return false;
        },
        joinPath(...parts) {
            // Simple path join for browser (forward-slash based)
            return parts
                .map((p, i) => i === 0 ? p : p.replace(/^\/+/, ''))
                .join('/')
                .replace(/\/+/g, '/');
        },
        baseName(path) {
            return path.split('/').pop() || path;
        },
    };
}
// =============================================================================
// Title Helper
// =============================================================================
function titleFromPath(demoPath) {
    const demoName = demoPath.split('/').pop() || demoPath;
    return demoName.split('-').map(w => w.charAt(0).toUpperCase() + w.slice(1)).join(' ');
}
// =============================================================================
// Main Entry Point
// =============================================================================
export async function loadDemo(demoPath, glslFiles, jsonFiles, imageFiles, scriptFiles) {
    const normalizedPath = demoPath.startsWith('./') ? demoPath : `./${demoPath}`;
    // Pre-load config if present
    const configPath = `${normalizedPath}/config.json`;
    let config = undefined;
    if (configPath in jsonFiles) {
        config = await jsonFiles[configPath]();
    }
    // Check if this is a multi-view config
    if (config && isMultiViewConfig(config)) {
        validateMultiViewConfig(config, normalizedPath);
        return loadMultiViewDemo(normalizedPath, config, glslFiles, imageFiles, scriptFiles);
    }
    // Pre-load script hooks
    const script = await loadScript(normalizedPath, scriptFiles);
    // Create the FileLoader adapter
    const loader = createBrowserFileLoader(glslFiles, imageFiles);
    // Build a texture URL resolver that goes through Vite's imageFiles
    const textureUrlResolver = async (texturePath) => {
        const fullPath = `${normalizedPath}/${texturePath.replace(/^\.\//, '')}`;
        return loader.resolveImageUrl(fullPath);
    };
    const project = await loadProjectFromFiles(loader, normalizedPath, {
        config,
        script,
        textureUrlResolver,
    });
    // Override title with pretty-formatted version if not set by config
    if (!config?.title) {
        project.meta.title = titleFromPath(normalizedPath);
    }
    return project;
}
// =============================================================================
// Multi-View Loading
// =============================================================================
async function loadMultiViewDemo(demoPath, config, glslFiles, imageFiles, scriptFiles) {
    const loader = createBrowserFileLoader(glslFiles, imageFiles);
    const script = await loadScript(demoPath, scriptFiles);
    // Load common.glsl if present
    let commonSource = null;
    const commonPath = `${demoPath}/common.glsl`;
    if (findFileCaseInsensitive(glslFiles, commonPath)) {
        commonSource = await loader.readText(commonPath);
    }
    // Load each view's shader(s)
    const views = [];
    const defaultChannels = [
        { kind: 'none' },
        { kind: 'none' },
        { kind: 'none' },
        { kind: 'none' },
    ];
    for (const viewName of config.views) {
        // Try flat file first: {viewName}.glsl
        const flatPath = `${demoPath}/${viewName}.glsl`;
        const folderImagePath = `${demoPath}/${viewName}/image.glsl`;
        let imageSource;
        if (findFileCaseInsensitive(glslFiles, flatPath)) {
            imageSource = await loader.readText(flatPath);
        }
        else if (findFileCaseInsensitive(glslFiles, folderImagePath)) {
            imageSource = await loader.readText(folderImagePath);
        }
        else {
            throw new Error(`Multi-view: No shader found for view "${viewName}". Expected ${viewName}.glsl or ${viewName}/image.glsl`);
        }
        const imagePass = {
            name: 'Image',
            glslSource: imageSource,
            channels: defaultChannels,
            namedSamplers: new Map(),
        };
        views.push({
            name: viewName,
            passes: { Image: imagePass },
        });
    }
    return {
        mode: 'standard',
        root: demoPath,
        meta: {
            title: config.title ?? titleFromPath(demoPath),
            author: config.author ?? null,
            description: config.description ?? null,
        },
        theme: config.theme ?? 'light',
        controls: config.controls,
        stats: config.stats,
        playback: config.playback,
        uniformsUI: config.uniformsUI,
        startPaused: config.startPaused ?? false,
        stickyMouse: config.stickyMouse ?? false,
        pixelRatio: config.pixelRatio ?? null,
        commonSource,
        uniforms: config.uniforms ?? {},
        uniformData: {},
        textures: [],
        script,
        views,
        viewLayout: config.layout ?? 'split',
    };
}
