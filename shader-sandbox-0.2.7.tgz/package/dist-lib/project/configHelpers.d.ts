/**
 * Shared helpers for config loading.
 * Used by both the Node/CLI loader (loadProject.ts) and
 * the browser/Vite loader (loaderHelper.ts).
 */
import type { PassName, ChannelValue, ChannelJSONObject, MultiViewConfig } from './types';
/**
 * Type guard for PassName.
 */
export declare function isPassName(s: string): s is PassName;
/**
 * Get default source file name for a pass.
 */
export declare function defaultSourceForPass(name: PassName): string;
/**
 * Parse a channel value (string shorthand or object) into normalized ChannelJSONObject.
 *
 * String shortcuts:
 * - "BufferA", "BufferB", etc. → buffer reference
 * - "keyboard" → keyboard input
 * - "audio" → microphone audio input
 * - "webcam" → webcam video input
 * - "photo.jpg" (with extension) → texture file
 */
export declare function parseChannelValue(value: ChannelValue): ChannelJSONObject | null;
/** The ordered list of pass names for iteration. */
export declare const PASS_ORDER: readonly ["Image", "BufferA", "BufferB", "BufferC", "BufferD"];
/** The four buffer pass names (excludes Image). */
export declare const BUFFER_PASS_NAMES: PassName[];
/** The four channel keys. */
export declare const CHANNEL_KEYS: readonly ["iChannel0", "iChannel1", "iChannel2", "iChannel3"];
/** Default layout for projects. */
export declare const DEFAULT_LAYOUT: "default";
/** Default theme. */
export declare const DEFAULT_THEME: "auto";
/** Check if a string is a valid GLSL identifier (not a reserved word). */
export declare function isValidGLSLIdentifier(name: string): boolean;
/**
 * Validate a project config and throw on errors.
 * Logs warnings for non-fatal issues.
 */
export declare function validateConfig(config: Record<string, any>, root: string): void;
/**
 * Validate a multi-view config and throw on errors.
 */
export declare function validateMultiViewConfig(config: MultiViewConfig, root: string): void;
//# sourceMappingURL=configHelpers.d.ts.map