/**
 * Project Layer - Type Definitions for Shadertoy Projects
 *
 * Pure TypeScript interfaces matching Shadertoy's mental model.
 * Based on docs/project-spec.md
 */
/**
 * Type guard: returns true if a uniform definition is a plain array uniform (not struct).
 */
export function isArrayUniform(def) {
    return 'count' in def && typeof def.count === 'number' && !('struct' in def);
}
/**
 * Type guard: returns true if a uniform definition is a struct array uniform.
 */
export function isStructArrayUniform(def) {
    return 'struct' in def && typeof def.struct === 'object' && 'count' in def;
}
/**
 * Type guard: returns true if a uniform definition is any UBO-backed uniform (array or struct array).
 */
export function isAnyUBOUniform(def) {
    return isArrayUniform(def) || isStructArrayUniform(def);
}
/**
 * Returns true if a uniform should have a UI control.
 * Excludes UBO-backed uniforms and hidden uniforms (script-only).
 */
export function hasUIControl(def) {
    return !isAnyUBOUniform(def) && !def.hidden;
}
/**
 * Check if a config is a multi-view config.
 */
export function isMultiViewConfig(config) {
    return 'views' in config && Array.isArray(config.views);
}
/**
 * Type guard to check if a project is a multi-view project.
 */
export function isMultiViewProject(project) {
    return 'views' in project && Array.isArray(project.views);
}
