export declare const DEMO_NAME = "demos/examples/inline-controls";
export declare function loadDemoProject(): Promise<import("./types").ShaderProject | import("./types").MultiViewProject>;
//# sourceMappingURL=generatedLoader.d.ts.map