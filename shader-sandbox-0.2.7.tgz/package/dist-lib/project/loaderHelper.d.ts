/**
 * Project Layer - Browser/Vite Loader
 *
 * Thin adapter that implements FileLoader over Vite's import.meta.glob
 * record maps, then delegates to the shared loadProjectFromFiles() core.
 */
import type { ShaderProject, ProjectConfig, MultiViewProject, MultiViewConfig } from './types';
export declare function loadDemo(demoPath: string, glslFiles: Record<string, () => Promise<string>>, jsonFiles: Record<string, () => Promise<ProjectConfig | MultiViewConfig>>, imageFiles: Record<string, () => Promise<string>>, scriptFiles?: Record<string, () => Promise<any>>): Promise<ShaderProject | MultiViewProject>;
//# sourceMappingURL=loaderHelper.d.ts.map