/**
 * Build Entry Point
 *
 * This is the entry point for compiled shader modules.
 * Exports:
 *   - mount(el, options?) — consumer API (auto-loads baked-in project)
 *   - DEMO_NAME           — name of the baked-in demo
 */
import { MountHandle, MountPresentationOptions } from './mount';
import { DEMO_NAME } from './project/generatedLoader';
/**
 * Mount the baked-in shader project into a DOM element.
 * This is the primary consumer-facing API for build output.
 */
export declare function mount(el: HTMLElement, options?: MountPresentationOptions): Promise<MountHandle>;
export { DEMO_NAME };
export type { MountHandle, MountPresentationOptions } from './mount';
//# sourceMappingURL=embed.d.ts.map