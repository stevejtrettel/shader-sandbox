/**
 * InputManager - Mouse, touch, and keyboard input tracking
 *
 * Tracks all input state without calling into the engine.
 * App reads state each frame and forwards to engine.
 */
import type { MouseState, TouchState } from './types';
export interface KeyEvent {
    keycode: number;
    down: boolean;
}
export declare class InputManager {
    readonly mouse: MouseState;
    isMouseDown: boolean;
    stickyMouse: boolean;
    readonly touchState: TouchState;
    /** Callback fired on first user gesture (for media init). */
    onFirstGesture: (() => void) | null;
    private canvas;
    private pixelRatio;
    private activePointers;
    private gestureTriggered;
    private keyEvents;
    private keydownHandler;
    private keyupHandler;
    private keyboardTarget;
    private canvasListeners;
    constructor(canvas: HTMLCanvasElement, pixelRatio: number, keyboardTarget?: HTMLElement);
    /**
     * Drain and return accumulated key events since last call.
     */
    getAndClearKeyEvents(): KeyEvent[];
    /**
     * Clean up all event listeners.
     */
    dispose(): void;
    private triggerGesture;
    private setupMouseTracking;
    private setupTouchTracking;
    private updateTouchState;
}
//# sourceMappingURL=InputManager.d.ts.map