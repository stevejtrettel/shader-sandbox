/**
 * RuntimeErrorOverlay - Visual error reporting for runtime errors
 *
 * Shows a dismissible banner for:
 * - Script errors (setup/onFrame throws)
 * - Asset load failures (texture, framebuffer)
 *
 * Auto-hides after a timeout if no new errors occur.
 * Shows a persistent warning when onFrame() is disabled after too many errors.
 */
export declare class RuntimeErrorOverlay {
    private container;
    private overlay;
    private autoHideTimer;
    private static readonly AUTO_HIDE_MS;
    constructor(container: HTMLElement);
    /**
     * Show an error from setup() or onFrame().
     */
    showError(hook: 'setup' | 'onFrame', error: unknown): void;
    /**
     * Show a persistent warning when onFrame() has been disabled.
     */
    showDisabled(): void;
    /**
     * Show a warning banner for asset load errors (textures, framebuffers).
     */
    showWarning(title: string, message: string): void;
    /**
     * Hide the overlay.
     */
    hide(): void;
    /**
     * Clean up resources.
     */
    dispose(): void;
    private ensureOverlay;
    private wireClose;
    private clearAutoHide;
}
//# sourceMappingURL=RuntimeErrorOverlay.d.ts.map