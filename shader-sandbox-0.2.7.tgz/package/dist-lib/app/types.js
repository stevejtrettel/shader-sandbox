/**
 * App Layer - Type Definitions
 *
 * Types for the browser runtime coordinator.
 */
export {};
