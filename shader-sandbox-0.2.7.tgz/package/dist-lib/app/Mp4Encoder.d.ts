/**
 * Mp4Encoder - Frame-by-frame MP4 encoding via mediabunny + WebCodecs
 *
 * Dynamically imports mediabunny to avoid bundle impact when not used.
 * Falls back gracefully when WebCodecs (VideoEncoder) is unavailable.
 */
/**
 * Check if the browser supports WebCodecs VideoEncoder (required for MP4).
 */
export declare function isMP4Supported(): boolean;
export declare class Mp4Encoder {
    private width;
    private height;
    private fps;
    private bitrate;
    private output;
    private target;
    private videoSource;
    private encoder;
    private EncodedPacket;
    private frameCount;
    constructor(width: number, height: number, fps: number, quality?: string);
    init(): Promise<void>;
    /**
     * Add a frame from a canvas element.
     */
    addFrame(canvas: HTMLCanvasElement): Promise<void>;
    /**
     * Finalize encoding and return the MP4 as a Blob.
     */
    finish(): Promise<Blob>;
    /**
     * Clean up without finalizing (e.g. on cancel).
     */
    dispose(): void;
}
//# sourceMappingURL=Mp4Encoder.d.ts.map