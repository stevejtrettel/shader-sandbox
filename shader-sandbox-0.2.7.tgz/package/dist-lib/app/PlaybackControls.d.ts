/**
 * PlaybackControls - Collapsible button panel for playback actions
 *
 * DOM-only: creates buttons and wires them to callbacks.
 * Keyboard shortcuts stay in App.ts (document-level bindings).
 */
export interface PlaybackCallbacks {
    onTogglePlayPause: () => void;
    onReset: () => void;
    onScreenshot: () => void;
    onToggleRecording: () => void;
    onExportHTML: () => void;
    onRender: () => void;
}
export declare class PlaybackControls {
    private container;
    private controlsContainer;
    private controlsGrid;
    private menuButton;
    private playPauseButton;
    private isMenuOpen;
    constructor(container: HTMLElement, callbacks: PlaybackCallbacks);
    /**
     * Update the play/pause button icon.
     */
    setPaused(paused: boolean): void;
    /**
     * Clean up DOM.
     */
    dispose(): void;
    private toggleMenu;
}
//# sourceMappingURL=PlaybackControls.d.ts.map