/**
 * HTML Export - Standalone shader export
 *
 * Exports the current shader project as a self-contained HTML file
 * with embedded WebGL2 renderer. Supports:
 * - Multi-pass buffers with ping-pong FBOs
 * - Scalar uniforms (baked current values)
 * - Array uniforms via UBOs (baked std140 data)
 * - Scripts (setup/onFrame inlined via Function.toString)
 * - Keyboard texture with event handlers
 * - Procedural grid for texture channels
 * - Black texture for audio/webcam/video channels
 */
import type { ShaderProject } from '../project/types';
import type { ShaderEngine } from '../engine/ShaderEngine';
/**
 * Export the current shader as a standalone HTML file and trigger download.
 */
export declare function exportHTML(project: ShaderProject, engine: ShaderEngine): void;
//# sourceMappingURL=exportHTML.d.ts.map