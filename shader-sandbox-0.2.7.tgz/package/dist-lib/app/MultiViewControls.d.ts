/**
 * MultiViewControls - Shared controls panel for multi-view projects
 *
 * A floating panel in the upper-right corner of the wrapper that provides:
 * - Play/Pause toggle
 * - Reset button
 * - Screenshot button
 * - Uniform sliders (if any defined)
 *
 * Decoupled from App — uses callbacks for all interactions.
 */
import './multi-view-controls.css';
import { UniformDefinitions, UniformValue } from '../project/types';
export interface MultiViewControlsOptions {
    /** Wrapper element to attach controls to */
    wrapper: HTMLElement;
    /** Toggle play/pause callback */
    onTogglePlayPause: () => void;
    /** Reset callback */
    onReset: () => void;
    /** Get current paused state */
    getPaused: () => boolean;
    /** Set uniform value callback (optional) */
    onSetUniformValue?: (name: string, value: UniformValue) => void;
    /** Uniform definitions (optional) */
    uniforms?: UniformDefinitions;
}
export declare class MultiViewControls {
    private wrapper;
    private opts;
    private controlsWrapper;
    private toggleButton;
    private panel;
    private controls;
    private isOpen;
    private isPaused;
    constructor(opts: MultiViewControlsOptions);
    private createPanel;
    private updatePlayPauseIcon;
    private toggle;
    dispose(): void;
}
//# sourceMappingURL=MultiViewControls.d.ts.map