/**
 * ErrorOverlay - Shader compilation error display
 *
 * Shows shader compilation errors in a dismissible overlay with
 * source context, user-friendly error messages, and line mapping.
 */
import type { LineMapping } from '../engine/ShaderEngine';
import type { ShaderProject } from '../project/types';
/** Error info as provided by the engine. */
export interface CompilationError {
    passName: string;
    error: string;
    source: string;
    isFromCommon: boolean;
    originalLine: number | null;
    lineMapping: LineMapping;
}
export declare class ErrorOverlay {
    private container;
    private overlay;
    constructor(container: HTMLElement);
    /**
     * Display shader compilation errors in an overlay.
     */
    show(errors: CompilationError[], project: ShaderProject): void;
    /**
     * Hide the error overlay.
     */
    hide(): void;
    /**
     * Clean up resources.
     */
    dispose(): void;
}
//# sourceMappingURL=ErrorOverlay.d.ts.map