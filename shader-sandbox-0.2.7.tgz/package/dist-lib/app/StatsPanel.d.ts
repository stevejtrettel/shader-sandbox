/**
 * StatsPanel - FPS counter and expandable stats display
 *
 * Shows an FPS counter button that expands to reveal time, frame count,
 * and resolution stats.
 */
export declare class StatsPanel {
    private container;
    private statsContainer;
    private statsGrid;
    private fpsDisplay;
    private timeDisplay;
    private frameDisplay;
    private resolutionDisplay;
    private frameCount;
    totalFrameCount: number;
    private lastFpsUpdate;
    private currentFps;
    private isStatsOpen;
    constructor(container: HTMLElement);
    /**
     * Update FPS counter and stats. Call once per frame.
     */
    update(currentTimeSec: number, elapsedTime: number): void;
    /**
     * Reset all counters.
     */
    reset(): void;
    /**
     * Update resolution display with current canvas dimensions.
     */
    updateResolution(w: number, h: number): void;
    /**
     * Clean up DOM.
     */
    dispose(): void;
    private toggle;
    private updateFrameDisplay;
    private updateTimeDisplay;
    private updateResolutionDisplay;
}
//# sourceMappingURL=StatsPanel.d.ts.map