/**
 * RecordingPanel - Full-featured video/frame sequence recording panel
 *
 * Provides resolution presets, timing controls (start time, duration, FPS),
 * format selection (MP4/WebM/PNG frames), quality settings,
 * collapsible uniform controls, and progress tracking.
 */
import './recording-panel.css';
import { UniformDefinitions, UniformValue } from '../project/types';
export type RecordingFormat = 'mp4' | 'webm' | 'frames';
export type RecordingQuality = 'low' | 'medium' | 'high' | 'ultra';
export interface RecordingRequest {
    width: number;
    height: number;
    fps: number;
    startTime: number;
    duration: number;
    format: RecordingFormat;
    quality: RecordingQuality;
    onProgress: (phase: string, frame: number, totalFrames: number) => void;
    onComplete: () => void;
    onError: (error: Error) => void;
}
export interface RecordingPanelCallbacks {
    /** Start an offline render. Returns a cancel function. */
    startRecording: (req: RecordingRequest) => () => void;
    /** Whether this shader has buffer passes (feedback). */
    hasBufferPasses: () => boolean;
    /** Set a uniform value (live). */
    setUniformValue: (name: string, value: UniformValue) => void;
}
export declare class RecordingPanel {
    private backdrop;
    private panel;
    private callbacks;
    private uniformControls;
    private cancelRenderFn;
    private presetSelect;
    private widthInput;
    private heightInput;
    private aspectLocked;
    private aspectRatio;
    private lockButton;
    private startTimeInput;
    private durationInput;
    private fpsInput;
    private estimateEl;
    private formatMp4;
    private formatWebm;
    private formatFrames;
    private mp4Label;
    private qualityGroup;
    private qualitySelect;
    private hasBuffers;
    private canvasWidth;
    private canvasHeight;
    private bodyEl;
    private actionsEl;
    private progressEl;
    private progressBar;
    private progressText;
    private warmupNotice;
    constructor(parentContainer: HTMLElement, canvasWidth: number, canvasHeight: number, uniforms: UniformDefinitions | undefined, callbacks: RecordingPanelCallbacks);
    close(): void;
    private onPresetChange;
    private toggleAspectLock;
    private onFormatChange;
    private getSelectedFormat;
    private updateEstimate;
    private updateWarmupNotice;
    private startRender;
    private cancelRender;
    private createSection;
    private createCollapsibleSection;
    private createFieldRow;
    private createNumberInput;
}
//# sourceMappingURL=RecordingPanel.d.ts.map