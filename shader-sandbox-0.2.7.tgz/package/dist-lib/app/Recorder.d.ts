/**
 * Recorder - Video recording from canvas
 *
 * Captures the canvas as a WebM video using MediaRecorder API.
 * Handles start/stop, recording indicator UI, and file download.
 */
export declare class Recorder {
    isRecording: boolean;
    private canvas;
    private container;
    private projectRoot;
    private mediaRecorder;
    private recordedChunks;
    private recordingIndicator;
    constructor(canvas: HTMLCanvasElement, container: HTMLElement, projectRoot: string);
    /**
     * Toggle recording on/off.
     * If paused, calls unpause callback before starting.
     */
    toggle(isPaused: boolean, unpause: () => void): void;
    /**
     * Start recording the canvas as WebM video.
     */
    private start;
    /**
     * Stop recording and trigger download.
     */
    stop(): void;
    /**
     * Clean up resources.
     */
    dispose(): void;
    /**
     * Show the recording indicator (pulsing red dot in corner).
     */
    private showRecordingIndicator;
    /**
     * Hide the recording indicator.
     */
    private hideRecordingIndicator;
}
//# sourceMappingURL=Recorder.d.ts.map