/**
 * App - Browser Runtime Coordinator
 *
 * Coordinates one or more ShaderViews with shared:
 *  - Animation loop (requestAnimationFrame)
 *  - Playback controls (play/pause/reset)
 *  - Stats panel, Recorder, UniformsPanel
 *  - Script hooks (setup/onFrame)
 *  - Keyboard shortcuts
 *  - Visibility observer (auto-pause when off-screen)
 *
 * Single-view: App has 1 ShaderView.
 * Multi-view: App has N ShaderViews with shared time/uniforms and cross-view state.
 *
 * Per-canvas concerns (GL context, engine, input, resize) are handled
 * by ShaderView instances.
 */
import './app.css';
import { ShaderEngine } from '../engine/ShaderEngine';
import { CrossViewState, OverlayPosition, UniformValue } from '../project/types';
import { AppOptions, MouseState } from './types';
export declare class App {
    private container;
    private views;
    private primaryView;
    private project;
    private isMultiView;
    private animationId;
    private startTime;
    private pausedElapsedTime;
    private disposed;
    private statsPanel;
    private playbackControls;
    private isPaused;
    private _pauseAfterFirstFrame;
    private intersectionObserver;
    private isVisible;
    private uniformsPanel;
    private scriptAPI;
    private scriptErrorCount;
    private _lastOnFrameTime;
    private _insideScriptSet;
    private static readonly MAX_SCRIPT_ERRORS;
    private recorder;
    private globalKeyHandler;
    private controlsKeyHandler;
    constructor(opts: AppOptions);
    /**
     * Create a single-view ShaderProject from a MultiViewProject + ViewEntry.
     * Each view gets a fullscreen layout with no controls (App manages controls).
     */
    private createViewProject;
    private initScriptAPI;
    /**
     * Run script onFrame hook with error tracking.
     * Called from animate() with error tracking.
     */
    private runScriptOnFrame;
    hasErrors(): boolean;
    getEngine(): ShaderEngine;
    /**
     * Set a uniform value across all views.
     * Fires onUniformChange hook unless the call originated from the script itself.
     */
    setUniformValue(name: string, value: UniformValue): void;
    /**
     * Get a uniform value from the primary view.
     */
    getUniformValue(name: string): UniformValue | undefined;
    /**
     * Start the animation loop.
     */
    start(): void;
    stop(): void;
    getMouseState(): MouseState;
    getResolution(): [number, number, number];
    getMousePressed(): boolean;
    /**
     * Get cross-view state for a named view.
     */
    getCrossViewState(viewName: string): CrossViewState | undefined;
    setOverlay(position: OverlayPosition, text: string | null): void;
    private animate;
    togglePlayPause(): void;
    getPaused(): boolean;
    reset(): void;
    /** Quick screenshot at current canvas size (S key shortcut). */
    screenshot(): void;
    toggleRecording(): void;
    /** Check if this shader has feedback buffer passes. */
    private hasBufferPasses;
    /** Get current elapsed shader time. */
    private getCurrentTime;
    openScreenshotPanel(): void;
    openRecordingPanel(): void;
    private handleRecording;
    exportHTML(): void;
    private renderPngFrames;
    private renderWebmFrames;
    private renderMp4Frames;
    private stepForRender;
    private static isTextInput;
    private setupGlobalShortcuts;
    private setupKeyboardShortcuts;
    dispose(): void;
}
//# sourceMappingURL=App.d.ts.map