/**
 * ShaderView - Per-Canvas Rendering Unit
 *
 * Owns everything that is truly per-canvas:
 *  - Canvas element + WebGL2 context
 *  - ShaderEngine (passes, uniforms, textures)
 *  - InputManager (mouse, touch, keyboard)
 *  - ResizeObserver (debounced resize + engine resize)
 *  - Context loss/restore handling
 *  - Error overlays
 *  - Media initialization (audio/webcam/video)
 *  - Script info overlays
 *
 * Does NOT own: animation loop, PlaybackControls, StatsPanel, Recorder,
 * UniformsPanel, script hooks, keyboard shortcuts. Those are coordinator
 * concerns managed by App.
 */
import { ShaderEngine } from '../engine/ShaderEngine';
import { ErrorOverlay } from './ErrorOverlay';
import { RuntimeErrorOverlay } from './RuntimeErrorOverlay';
import { ShaderProject, CrossViewState, OverlayPosition } from '../project/types';
import { InputManager } from './InputManager';
import { MouseState } from './types';
export interface ShaderViewOptions {
    container: HTMLElement;
    project: ShaderProject;
    pixelRatio: number;
    viewNames?: string[];
    /** Element to listen for keyboard events on. Defaults to document. */
    keyboardTarget?: HTMLElement;
}
export declare class ShaderView {
    readonly container: HTMLElement;
    readonly canvas: HTMLCanvasElement;
    readonly gl: WebGL2RenderingContext;
    readonly errorOverlay: ErrorOverlay;
    readonly runtimeErrorOverlay: RuntimeErrorOverlay;
    readonly input: InputManager;
    private _engine;
    private _project;
    private _pixelRatio;
    private _viewNames?;
    private _resizeObserver;
    private _resizeDebounceTimer;
    private _contextLostOverlay;
    private _isContextLost;
    private _mediaBanner;
    private _mediaInitialized;
    private _overlays;
    onResize: ((width: number, height: number) => void) | null;
    onContextRestored: (() => void) | null;
    get engine(): ShaderEngine;
    get isContextLost(): boolean;
    constructor(opts: ShaderViewOptions);
    /**
     * Step this view for one frame: forward input, run engine, blit to screen.
     */
    step(time: number, crossViewStates?: Map<string, CrossViewState>): void;
    /**
     * Blit engine Image pass output to the canvas.
     */
    presentToScreen(): void;
    getMouseState(): MouseState;
    getResolution(): [number, number, number];
    getMousePressed(): boolean;
    hasErrors(): boolean;
    setOverlay(position: OverlayPosition, text: string | null): void;
    dispose(): void;
    private updateCanvasSize;
    private setupContextLossHandling;
    private handleContextLost;
    private handleContextRestored;
    private showContextLostOverlay;
    private hideContextLostOverlay;
    private initMediaOnGesture;
    private initVideoFiles;
    private showMediaBanner;
    private hideMediaBanner;
}
//# sourceMappingURL=ShaderView.d.ts.map