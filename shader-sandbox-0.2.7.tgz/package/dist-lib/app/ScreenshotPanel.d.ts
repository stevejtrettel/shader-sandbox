/**
 * ScreenshotPanel - Full-featured screenshot capture panel
 *
 * Provides resolution presets, time scrubbing (with live preview for
 * non-buffer shaders), collapsible uniform controls, and high-res capture.
 */
import './screenshot-panel.css';
import { UniformDefinitions, UniformValue } from '../project/types';
export interface ScreenshotPanelCallbacks {
    /** Render a single frame at the given time and return without capturing.
     *  Used for live preview. Engine should render at current canvas size. */
    renderPreviewAtTime: (time: number) => void;
    /** Step the engine from frame 0 to the target time (for buffer shaders).
     *  Calls onProgress during stepping. Resolves when done. */
    renderPreviewStepped: (time: number, fps: number, onProgress: (frame: number, total: number) => void) => Promise<boolean>;
    /** Capture a high-res screenshot at the given time.
     *  Resizes canvas, renders, captures PNG blob, restores canvas.
     *  Calls onProgress during buffer shader stepping. */
    captureScreenshot: (opts: {
        width: number;
        height: number;
        time: number;
        hasBuffers: boolean;
        onProgress: (frame: number, total: number) => void;
    }) => Promise<Blob | null>;
    /** Get current elapsed shader time. */
    getCurrentTime: () => number;
    /** Whether this shader has buffer passes (feedback). */
    hasBufferPasses: () => boolean;
    /** Set a uniform value (live). */
    setUniformValue: (name: string, value: UniformValue) => void;
    /** Pause the animation loop so preview renders aren't overwritten. */
    pause: () => void;
    /** Resume the animation loop when panel closes. */
    resume: () => void;
}
export declare class ScreenshotPanel {
    private backdrop;
    private panel;
    private callbacks;
    private uniformControls;
    private presetSelect;
    private widthInput;
    private heightInput;
    private aspectLocked;
    private aspectRatio;
    private lockButton;
    private timeInput;
    private timeSlider;
    private sliderMinInput;
    private sliderMaxInput;
    private hasBuffers;
    private currentTime;
    private canvasWidth;
    private canvasHeight;
    private captureBtn;
    private progressEl;
    private progressBar;
    private progressText;
    private isBusy;
    constructor(parentContainer: HTMLElement, canvasWidth: number, canvasHeight: number, uniforms: UniformDefinitions | undefined, callbacks: ScreenshotPanelCallbacks);
    close(): void;
    private onPresetChange;
    private toggleAspectLock;
    private updateSliderRange;
    private renderBufferPreview;
    private capture;
    private downloadBlob;
    private showProgress;
    private hideProgress;
    private createSection;
    private createCollapsibleSection;
    private createNumberInput;
}
//# sourceMappingURL=ScreenshotPanel.d.ts.map