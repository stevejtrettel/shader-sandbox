/**
 * Node-safe entry point.
 *
 * This file is intentionally self-contained (no runtime imports), so Node/SSR
 * can import the package without evaluating browser/CSS modules.
 */
import type { MountHandle, MountOptions } from './mount';
export type { MountOptions, MountHandle, } from './mount';
export type { ShaderProject, ProjectConfig, PassName, ThemeMode, DemoScriptHooks, ScriptEngineAPI, ArrayUniformDefinition, UniformValue, MultiViewProject, MultiViewConfig, MultiViewLayoutMode, ViewEntry, CrossViewState, } from './project/types';
export type { RecompileResult, BaseLayout, LayoutMode, LayoutOptions, RecompileHandler, UniformChangeHandler, MultiViewLayout, MultiViewLayoutOptions, } from './layouts/types';
export declare function mount(_el: HTMLElement, _options: MountOptions): MountHandle;
export declare class App {
    constructor();
}
export declare class ShaderView {
    constructor();
}
export declare class MultiViewControls {
    constructor();
}
export declare function createLayout(): never;
export declare function createMultiViewLayout(): never;
export declare function applyTheme(): never;
export declare function loadDemo(): never;
export declare function isArrayUniform(def: unknown): boolean;
export declare function isMultiViewProject(project: unknown): boolean;
export declare function isMultiViewConfig(config: unknown): boolean;
//# sourceMappingURL=node.d.ts.map