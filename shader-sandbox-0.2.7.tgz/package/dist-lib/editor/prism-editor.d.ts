/**
 * Lightweight Prism Editor
 *
 * Simple textarea with Prism syntax highlighting overlay.
 * Uses the existing Prism.js dependency - adds ~0 extra bytes to bundle.
 */
import 'prismjs/components/prism-c';
import 'prismjs/components/prism-cpp';
import './prism-editor.css';
export interface EditorInstance {
    getSource: () => string;
    setSource: (source: string) => void;
    destroy: () => void;
}
/**
 * Create a lightweight editor with Prism syntax highlighting.
 */
export declare function createEditor(container: HTMLElement, initialSource: string, onChange?: (source: string) => void): EditorInstance;
//# sourceMappingURL=prism-editor.d.ts.map