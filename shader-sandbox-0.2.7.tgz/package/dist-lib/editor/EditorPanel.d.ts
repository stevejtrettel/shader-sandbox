/**
 * Editor Panel - Shared component for code editing in layouts
 *
 * Provides:
 * - CodeMirror editor (dynamically loaded)
 * - Recompile button with keyboard shortcut
 * - Error display
 * - Tab management for multiple passes
 */
import { ShaderProject } from '../project/types';
import { RecompileHandler } from '../layouts/types';
import './editor-panel.css';
export declare class EditorPanel {
    private container;
    private project;
    private recompileHandler;
    private tabBar;
    private contentArea;
    private copyButton;
    private recompileButton;
    private errorDisplay;
    private tabs;
    private activeTabIndex;
    private editorInstance;
    private modifiedSources;
    private keydownHandler;
    constructor(container: HTMLElement, project: ShaderProject);
    setRecompileHandler(handler: RecompileHandler): void;
    dispose(): void;
    private buildTabs;
    private buildTabBar;
    private showTab;
    private saveCurrentEditorContent;
    private recompile;
    private showError;
    private hideError;
    private copyToClipboard;
    private setupKeyboardShortcut;
}
//# sourceMappingURL=EditorPanel.d.ts.map