/**
 * shaderSource - GLSL shader source building
 *
 * Pure functions and constants for constructing fragment shaders
 * with Shadertoy boilerplate, uniform declarations, and cubemap preprocessing.
 */
import { ChannelSource, ArrayUniformDefinition, StructArrayUniformDefinition } from '../project/types';
import { StructLayout } from './std140';
import { LineMapping } from './ShaderEngine';
export declare const VERTEX_SHADER_SOURCE = "#version 300 es\nprecision highp float;\n\nlayout(location = 0) in vec2 position;\n\nvoid main() {\n  gl_Position = vec4(position, 0.0, 1.0);\n}\n";
/** Metadata about a UBO needed for shader source generation. */
export interface UBOInfo {
    name: string;
    def: ArrayUniformDefinition | StructArrayUniformDefinition;
    count: number;
    /** Present for struct array uniforms */
    structLayout?: StructLayout;
}
/** Options for building a fragment shader. */
export interface BuildShaderOpts {
    commonSource: string;
    ubos: UBOInfo[];
    uniforms: Record<string, any>;
    namedSamplers?: Map<string, ChannelSource>;
    /** View names for multi-view projects (enables cross-view uniforms) */
    viewNames?: string[];
}
/**
 * Build complete fragment shader source with Shadertoy boilerplate.
 *
 * @param userSource - The user's GLSL source code
 * @param channels - Channel configuration for this pass (to detect cubemap textures)
 * @param opts - Common source, UBO info, uniforms, and named samplers
 */
export declare function buildFragmentShader(userSource: string, channels: ChannelSource[], opts: BuildShaderOpts): {
    source: string;
    lineMapping: LineMapping;
};
//# sourceMappingURL=shaderSource.d.ts.map