/**
 * std140 Layout Packing Utilities
 *
 * Handles conversion from tightly-packed user data to std140 layout
 * required by WebGL2 Uniform Buffer Objects.
 *
 * std140 array element rules:
 * - Every array element is rounded up to a vec4 (16 bytes) stride
 * - float[N]: 4 bytes data + 12 bytes padding per element
 * - vec2[N]:  8 bytes data + 8 bytes padding per element
 * - vec3[N]:  12 bytes data + 4 bytes padding per element
 * - vec4[N]:  16 bytes, no padding
 * - mat3[N]:  3 columns of vec4 (padded) = 48 bytes per element
 * - mat4[N]:  4 columns of vec4 = 64 bytes, no padding needed
 */
import { ArrayUniformType } from '../project/types';
/**
 * Number of tightly-packed floats for a given type and count.
 */
export declare function tightFloatCount(type: ArrayUniformType, count: number): number;
/**
 * Compute the total byte size of a std140 uniform block for an array.
 */
export declare function std140ByteSize(type: ArrayUniformType, count: number): number;
/**
 * Compute the total number of floats in std140 layout for a given type and count.
 */
export declare function std140FloatCount(type: ArrayUniformType, count: number): number;
/**
 * Pack tightly-packed user data into std140 layout.
 *
 * For mat4 and vec4, the tight layout is already std140-compatible,
 * so this returns the input directly (no copy).
 *
 * For other types, allocates a new Float32Array with proper padding.
 *
 * @param type - The GLSL type of each array element
 * @param count - Number of elements
 * @param tightData - User-provided tightly-packed data
 * @param out - Optional pre-allocated output buffer (reused across frames)
 */
export declare function packStd140(type: ArrayUniformType, count: number, tightData: Float32Array, out?: Float32Array): Float32Array;
/**
 * Get the GLSL type string for use in uniform block declarations.
 */
export declare function glslTypeName(type: ArrayUniformType): string;
/** Layout of a single field within a struct */
export interface StructFieldLayout {
    name: string;
    type: ArrayUniformType;
    /** Byte offset within one struct element */
    offsetBytes: number;
    /** Actual data size in bytes */
    sizeBytes: number;
    /** Number of user-facing floats for this field */
    tightFloats: number;
}
/** Computed layout for a struct array */
export interface StructLayout {
    fields: StructFieldLayout[];
    /** Total bytes per struct element (padded to base alignment) */
    strideBytes: number;
    /** strideBytes / 4 */
    strideFloats: number;
    /** Sum of all fields' tightFloats */
    tightFloatsPerElement: number;
}
/**
 * Compute the std140 layout for a struct with the given fields.
 * Fields are processed in insertion order (Object.keys preserves JSON key order).
 */
export declare function computeStructLayout(struct: Record<string, ArrayUniformType>): StructLayout;
/**
 * Total byte size of a struct array in std140 layout.
 */
export declare function std140StructByteSize(layout: StructLayout, count: number): number;
/**
 * Pack per-field data into std140 struct array layout.
 *
 * @param layout - Computed struct layout
 * @param count - Number of elements to pack
 * @param fieldData - Map of field name → tightly-packed Float32Array (count × tightFloats values)
 * @param out - Optional pre-allocated output buffer
 */
export declare function packStructStd140(layout: StructLayout, count: number, fieldData: Record<string, Float32Array>, out?: Float32Array): Float32Array;
/**
 * Pack a single struct element into an existing std140 buffer.
 *
 * @param layout - Computed struct layout
 * @param index - Element index
 * @param fieldValues - Map of field name → value array
 * @param out - Target buffer (modified in place)
 */
export declare function packStructElementStd140(layout: StructLayout, index: number, fieldValues: Record<string, number[]>, out: Float32Array): void;
//# sourceMappingURL=std140.d.ts.map