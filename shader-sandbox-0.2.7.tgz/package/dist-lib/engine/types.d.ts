/**
 * Engine Layer - Type Definitions
 *
 * Internal types used by ShaderEngine for managing WebGL resources.
 * Based on docs/engine-spec.md
 */
import type { ShaderProject, PassName, Channels, ChannelSource, CrossViewState } from '../project/types';
/**
 * Options for constructing a ShaderEngine.
 *
 * The App is responsible for creating the WebGL2RenderingContext
 * and passing it in.
 */
export interface EngineOptions {
    gl: WebGL2RenderingContext;
    project: ShaderProject;
    /** View names for multi-view projects (enables cross-view uniforms) */
    viewNames?: string[];
    /** Callback fired on asset load errors (texture, framebuffer) */
    onAssetError?: (error: {
        type: 'texture' | 'framebuffer';
        name: string;
        detail: string;
    }) => void;
}
/**
 * Per-pass uniform locations and metadata.
 *
 * NOTE: This is separate from RuntimePass so that we can keep
 * the GL program + locations together.
 */
export interface PassUniformLocations {
    program: WebGLProgram;
    iResolution: WebGLUniformLocation | null;
    iTime: WebGLUniformLocation | null;
    iTimeDelta: WebGLUniformLocation | null;
    iFrame: WebGLUniformLocation | null;
    iMouse: WebGLUniformLocation | null;
    iMousePressed: WebGLUniformLocation | null;
    iDate: WebGLUniformLocation | null;
    iFrameRate: WebGLUniformLocation | null;
    iChannel: (WebGLUniformLocation | null)[];
    iChannelResolution: (WebGLUniformLocation | null)[];
    iTouchCount: WebGLUniformLocation | null;
    iTouch: (WebGLUniformLocation | null)[];
    iPinch: WebGLUniformLocation | null;
    iPinchDelta: WebGLUniformLocation | null;
    iPinchCenter: WebGLUniformLocation | null;
    custom: Map<string, WebGLUniformLocation | null>;
    namedSamplers: Map<string, WebGLUniformLocation | null>;
    namedSamplerResolutions: Map<string, WebGLUniformLocation | null>;
    crossViewMouse: Map<string, WebGLUniformLocation | null>;
    crossViewResolution: Map<string, WebGLUniformLocation | null>;
    crossViewMousePressed: Map<string, WebGLUniformLocation | null>;
}
/**
 * A runtime representation of a pass:
 * - knows which project pass it corresponds to
 * - owns two textures (current + previous) for ping-pong
 * - owns a framebuffer and VAO for drawing
 */
export interface RuntimePass {
    name: PassName;
    projectChannels: Channels;
    vao: WebGLVertexArrayObject;
    uniforms: PassUniformLocations;
    framebuffer: WebGLFramebuffer;
    currentTexture: WebGLTexture;
    previousTexture: WebGLTexture;
    namedSamplers?: Map<string, ChannelSource>;
}
/**
 * Runtime representation of an external 2D texture.
 * This corresponds 1:1 to ShaderTexture2D from the project.
 */
export interface RuntimeTexture2D {
    name: string;
    texture: WebGLTexture;
    width: number;
    height: number;
}
/**
 * Keyboard texture representation.
 * For v1, you can leave this unimplemented or just stub it out.
 */
export interface RuntimeKeyboardTexture {
    texture: WebGLTexture;
    width: number;
    height: number;
}
/**
 * Runtime audio texture (microphone FFT + waveform).
 * 512x2, R8 format: row 0 = frequency, row 1 = waveform.
 */
export interface RuntimeAudioTexture {
    texture: WebGLTexture;
    audioContext: AudioContext | null;
    analyser: AnalyserNode | null;
    stream: MediaStream | null;
    frequencyData: Uint8Array<ArrayBuffer>;
    waveformData: Uint8Array<ArrayBuffer>;
    width: number;
    height: number;
    initialized: boolean;
}
/**
 * Runtime video texture (webcam or video file).
 */
export interface RuntimeVideoTexture {
    texture: WebGLTexture;
    video: HTMLVideoElement | null;
    stream: MediaStream | null;
    width: number;
    height: number;
    ready: boolean;
    kind: 'webcam' | 'video';
    src?: string;
}
/**
 * Runtime script-uploaded texture.
 */
export interface RuntimeScriptTexture {
    texture: WebGLTexture;
    width: number;
    height: number;
    isFloat: boolean;
}
/**
 * Values for all built-in uniforms, computed once per frame and passed to each pass.
 */
export interface BuiltinUniformValues {
    iResolution: readonly [number, number, number];
    iTime: number;
    iTimeDelta: number;
    iFrame: number;
    iMouse: [number, number, number, number];
    iMousePressed: boolean;
    iDate: readonly [number, number, number, number];
    iFrameRate: number;
    iTouchCount: number;
    iTouch: [[number, number, number, number], [number, number, number, number], [number, number, number, number]];
    iPinch: number;
    iPinchDelta: number;
    iPinchCenter: [number, number];
    /** Cross-view state for multi-view projects (viewName -> state) */
    crossViewStates?: Map<string, CrossViewState>;
}
/**
 * Engine stats (for optional overlay / debugging).
 */
export interface EngineStats {
    frame: number;
    time: number;
    deltaTime: number;
    width: number;
    height: number;
}
//# sourceMappingURL=types.d.ts.map