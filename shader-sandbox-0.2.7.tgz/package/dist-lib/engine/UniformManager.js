/**
 * UniformManager - Custom uniform state, validation, UBO packing, and GL binding
 *
 * Manages the lifecycle of user-defined uniforms: scalar uniforms with dirty tracking,
 * and array uniforms backed by std140-packed UBOs (plain arrays and struct arrays).
 */
import { isArrayUniform, isStructArrayUniform, isAnyUBOUniform, } from '../project/types';
import { UniformStore } from '../uniforms/UniformStore';
import { std140ByteSize, std140FloatCount, tightFloatCount, packStd140, computeStructLayout, std140StructByteSize, packStructStd140, packStructElementStd140, } from './std140';
// =============================================================================
// UniformManager
// =============================================================================
export class UniformManager {
    constructor(gl, uniforms, initialData) {
        this._ubos = [];
        this._uboMap = new Map();
        this._dirtyScalars = new Set();
        this._uniforms = uniforms;
        this._store = new UniformStore(uniforms);
        this.initUBOs(gl);
        if (initialData)
            this.applyInitialData(initialData);
        // Mark all scalar uniforms dirty so they bind on the first frame
        for (const [name, def] of Object.entries(uniforms)) {
            if (!isAnyUBOUniform(def)) {
                this._dirtyScalars.add(name);
            }
        }
    }
    // ===========================================================================
    // Accessors
    // ===========================================================================
    get ubos() { return this._ubos; }
    get store() { return this._store; }
    // ===========================================================================
    // Get / Set
    // ===========================================================================
    get(name) {
        return this._store.get(name);
    }
    getAll() {
        return this._store.getAll();
    }
    /**
     * Set the value of a custom uniform.
     * Dispatches to the appropriate handler based on uniform type.
     */
    set(name, value) {
        const def = this._uniforms[name];
        if (!def) {
            console.warn(`setUniformValue('${name}'): uniform not defined in config`);
            return;
        }
        if (isArrayUniform(def)) {
            this.setPlainArrayRaw(name, def, value);
        }
        else if (isStructArrayUniform(def)) {
            this.setStructArrayRaw(name, def, value);
        }
        else {
            this.setScalar(name, def, value);
        }
    }
    setScalar(name, def, value) {
        const t = def.type;
        if ((t === 'float' || t === 'int') && typeof value !== 'number') {
            console.warn(`setUniformValue('${name}'): expected number for ${t}, got ${typeof value}`);
            return;
        }
        if (t === 'bool' && typeof value !== 'boolean') {
            console.warn(`setUniformValue('${name}'): expected boolean, got ${typeof value}`);
            return;
        }
        if (t === 'vec2' || t === 'vec3' || t === 'vec4') {
            if (!Array.isArray(value)) {
                console.warn(`setUniformValue('${name}'): expected array for ${t}, got ${typeof value}`);
                return;
            }
            const expected = t === 'vec2' ? 2 : t === 'vec3' ? 3 : 4;
            if (value.length !== expected) {
                console.warn(`setUniformValue('${name}'): expected array of length ${expected} for ${t}, got ${value.length}`);
                return;
            }
        }
        this._store.set(name, value);
        this._dirtyScalars.add(name);
    }
    setPlainArrayRaw(name, def, data) {
        this._store.setRaw(name, data);
        const ubo = this._uboMap.get(name);
        if (!ubo)
            return;
        const maxLength = tightFloatCount(def.type, def.count);
        const cpe = tightFloatCount(def.type, 1);
        if (data.length > maxLength) {
            console.warn(`setUniformValue('${name}'): data length ${data.length} exceeds max ${maxLength}`);
            return;
        }
        if (data.length % cpe !== 0) {
            console.warn(`setUniformValue('${name}'): data length ${data.length} is not a multiple of ${cpe}`);
            return;
        }
        const actualCount = data.length / cpe;
        const packed = packStd140(def.type, actualCount, data, ubo.paddedData);
        if (packed !== ubo.paddedData) {
            ubo.paddedData.set(packed);
        }
        const activeFloats = std140FloatCount(def.type, actualCount);
        if (activeFloats < ubo.paddedData.length) {
            ubo.paddedData.fill(0, activeFloats);
        }
        ubo.activeCount = actualCount;
        ubo.dirty = true;
    }
    setStructArrayRaw(name, def, data) {
        this._store.setRaw(name, data);
        const ubo = this._uboMap.get(name);
        if (!ubo)
            return;
        const maxFloats = ubo.layout.strideFloats * def.count;
        if (data.length > maxFloats) {
            console.warn(`setUniformValue('${name}'): data length ${data.length} exceeds max ${maxFloats}`);
            return;
        }
        ubo.paddedData.set(data);
        if (data.length < ubo.paddedData.length) {
            ubo.paddedData.fill(0, data.length);
        }
        ubo.activeCount = Math.ceil(data.length / ubo.layout.strideFloats);
        ubo.dirty = true;
    }
    setMultiple(values) {
        for (const [name, value] of Object.entries(values)) {
            if (value !== undefined) {
                this.set(name, value);
            }
        }
    }
    // ===========================================================================
    // Plain Array Helpers
    // ===========================================================================
    /**
     * Set an array uniform from structured JS arrays.
     * Flattens and packs automatically based on the uniform's declared type.
     */
    setArrayUniform(name, data) {
        const def = this._uniforms[name];
        if (!def || !isArrayUniform(def)) {
            console.warn(`setArrayUniform('${name}'): not an array uniform`);
            return;
        }
        const cpe = tightFloatCount(def.type, 1);
        if (data.length === 0) {
            this.set(name, new Float32Array(0));
            return;
        }
        const ubo = this._uboMap.get(name);
        const scratch = ubo?.scratch;
        // Flat number[] (for float arrays or pre-flattened data)
        if (typeof data[0] === 'number') {
            const nums = data;
            if (scratch) {
                for (let i = 0; i < nums.length && i < scratch.length; i++)
                    scratch[i] = nums[i];
                this.set(name, scratch.subarray(0, nums.length));
            }
            else {
                this.set(name, new Float32Array(nums));
            }
            return;
        }
        // Structured number[][] — flatten into scratch buffer
        const elements = data;
        if (elements.length > def.count) {
            console.warn(`setArrayUniform('${name}'): ${elements.length} elements exceeds max ${def.count}`);
            return;
        }
        const totalFloats = elements.length * cpe;
        const buf = scratch ?? new Float32Array(totalFloats);
        for (let i = 0; i < elements.length; i++) {
            const el = elements[i];
            const base = i * cpe;
            for (let j = 0; j < cpe; j++) {
                buf[base + j] = el[j] ?? 0;
            }
        }
        this.set(name, buf.subarray(0, totalFloats));
    }
    /**
     * Set a single element of an array uniform by index.
     * Only repacks that element's std140 slot.
     */
    setArrayElement(name, index, value) {
        const def = this._uniforms[name];
        if (!def || !isArrayUniform(def)) {
            console.warn(`setArrayElement('${name}'): not an array uniform`);
            return;
        }
        const ubo = this._uboMap.get(name);
        if (!ubo)
            return;
        if (index < 0 || index >= def.count) {
            console.warn(`setArrayElement('${name}'): index ${index} out of range [0, ${def.count})`);
            return;
        }
        const cpe = tightFloatCount(def.type, 1);
        const vals = typeof value === 'number' ? [value] : value;
        // Update the tight data in the store
        const storeData = this._store.getRaw(name);
        const tightOffset = index * cpe;
        for (let j = 0; j < cpe; j++) {
            storeData[tightOffset + j] = vals[j] ?? 0;
        }
        // Re-pack just this one element into the std140 padded buffer
        const std140Stride = std140FloatCount(def.type, 1);
        const paddedOffset = index * std140Stride;
        const elementTight = new Float32Array(cpe);
        for (let j = 0; j < cpe; j++) {
            elementTight[j] = vals[j] ?? 0;
        }
        packStd140(def.type, 1, elementTight, ubo.paddedData.subarray(paddedOffset, paddedOffset + std140Stride));
        if (index >= ubo.activeCount) {
            ubo.activeCount = index + 1;
        }
        ubo.dirty = true;
    }
    // ===========================================================================
    // Struct Array Helpers
    // ===========================================================================
    /**
     * Set a struct array uniform from per-field data.
     * Omitted fields preserve their existing values in the buffer.
     */
    setStructArrayUniform(name, data) {
        const def = this._uniforms[name];
        if (!def || !isStructArrayUniform(def)) {
            console.warn(`setStructArrayUniform('${name}'): not a struct array uniform`);
            return;
        }
        const ubo = this._uboMap.get(name);
        if (!ubo)
            return;
        let elementCount = 0;
        const fieldData = {};
        for (const field of ubo.layout.fields) {
            const raw = data[field.name];
            if (!raw || raw.length === 0)
                continue; // Omitted → preserve existing
            const scratch = ubo.fieldScratch[field.name];
            if (typeof raw[0] === 'number') {
                const nums = raw;
                for (let i = 0; i < nums.length && i < scratch.length; i++)
                    scratch[i] = nums[i];
                fieldData[field.name] = scratch.subarray(0, nums.length);
                elementCount = Math.max(elementCount, Math.floor(nums.length / field.tightFloats));
            }
            else {
                const elements = raw;
                elementCount = Math.max(elementCount, elements.length);
                const totalFloats = elements.length * field.tightFloats;
                for (let i = 0; i < elements.length; i++) {
                    const el = elements[i];
                    const base = i * field.tightFloats;
                    for (let j = 0; j < field.tightFloats; j++) {
                        scratch[base + j] = el[j] ?? 0;
                    }
                }
                fieldData[field.name] = scratch.subarray(0, totalFloats);
            }
        }
        if (elementCount > def.count) {
            console.warn(`setStructArrayUniform('${name}'): ${elementCount} elements exceeds max ${def.count}`);
            return;
        }
        packStructStd140(ubo.layout, elementCount, fieldData, ubo.paddedData);
        const activeFloats = ubo.layout.strideFloats * elementCount;
        if (activeFloats < ubo.paddedData.length) {
            ubo.paddedData.fill(0, activeFloats);
        }
        ubo.activeCount = elementCount;
        ubo.dirty = true;
    }
    /**
     * Set a single element of a struct array uniform by index.
     * Omitted fields preserve their existing values.
     */
    setStructArrayElement(name, index, data) {
        const def = this._uniforms[name];
        if (!def || !isStructArrayUniform(def)) {
            console.warn(`setStructArrayElement('${name}'): not a struct array uniform`);
            return;
        }
        const ubo = this._uboMap.get(name);
        if (!ubo)
            return;
        if (index < 0 || index >= def.count) {
            console.warn(`setStructArrayElement('${name}'): index ${index} out of range [0, ${def.count})`);
            return;
        }
        const fieldValues = {};
        for (const field of ubo.layout.fields) {
            const val = data[field.name];
            if (val === undefined)
                continue;
            fieldValues[field.name] = typeof val === 'number' ? [val] : val;
        }
        packStructElementStd140(ubo.layout, index, fieldValues, ubo.paddedData);
        if (index >= ubo.activeCount) {
            ubo.activeCount = index + 1;
        }
        ubo.dirty = true;
    }
    // ===========================================================================
    // Shared Helpers
    // ===========================================================================
    /**
     * Set how many elements of a UBO uniform the shader should use.
     * Works for both plain array and struct array uniforms.
     */
    setActiveCount(name, count) {
        const ubo = this._uboMap.get(name);
        if (!ubo) {
            console.warn(`setActiveCount('${name}'): not a UBO uniform`);
            return;
        }
        if (count < 0 || count > ubo.def.count) {
            console.warn(`setActiveCount('${name}'): count ${count} out of range [0, ${ubo.def.count}]`);
            return;
        }
        ubo.activeCount = count;
    }
    // ===========================================================================
    // GL Binding
    // ===========================================================================
    /**
     * Bind custom uniform values to the current program.
     * Uploads dirty UBOs and re-binds changed scalar uniforms.
     */
    bindToProgram(gl, uniforms) {
        for (const ubo of this._ubos) {
            if (ubo.dirty) {
                gl.bindBuffer(gl.UNIFORM_BUFFER, ubo.buffer);
                gl.bufferSubData(gl.UNIFORM_BUFFER, 0, ubo.paddedData);
                ubo.dirty = false;
            }
            const loc = uniforms.custom.get(`${ubo.name}_count`);
            if (loc) {
                gl.uniform1i(loc, ubo.activeCount);
            }
        }
        for (const name of this._dirtyScalars) {
            const def = this._uniforms[name];
            if (!def || isAnyUBOUniform(def))
                continue;
            const value = this._store.get(name);
            if (value === undefined)
                continue;
            const location = uniforms.custom.get(name);
            if (!location)
                continue;
            switch (def.type) {
                case 'float':
                    gl.uniform1f(location, value);
                    break;
                case 'int':
                    gl.uniform1i(location, value);
                    break;
                case 'bool':
                    gl.uniform1i(location, value ? 1 : 0);
                    break;
                case 'vec2': {
                    const v = value;
                    gl.uniform2f(location, v[0], v[1]);
                    break;
                }
                case 'vec3': {
                    const v = value;
                    gl.uniform3f(location, v[0], v[1], v[2]);
                    break;
                }
                case 'vec4': {
                    const v = value;
                    gl.uniform4f(location, v[0], v[1], v[2], v[3]);
                    break;
                }
            }
        }
    }
    clearDirty() {
        this._dirtyScalars.clear();
    }
    markAllScalarsDirty() {
        for (const [name, def] of Object.entries(this._uniforms)) {
            if (!isAnyUBOUniform(def)) {
                this._dirtyScalars.add(name);
            }
        }
    }
    bindUBOsToProgram(gl, program, customLocations) {
        for (const ubo of this._ubos) {
            const blockIndex = gl.getUniformBlockIndex(program, `_ub_${ubo.name}`);
            if (blockIndex !== gl.INVALID_INDEX) {
                gl.uniformBlockBinding(program, blockIndex, ubo.bindingPoint);
            }
            customLocations.set(`${ubo.name}_count`, gl.getUniformLocation(program, `${ubo.name}_count`));
        }
    }
    // ===========================================================================
    // Cleanup
    // ===========================================================================
    dispose(gl) {
        for (const ubo of this._ubos) {
            gl.deleteBuffer(ubo.buffer);
        }
        this._ubos = [];
        this._uboMap.clear();
    }
    // ===========================================================================
    // Initial Data
    // ===========================================================================
    applyInitialData(data) {
        for (const [name, value] of Object.entries(data)) {
            const def = this._uniforms[name];
            if (!def)
                continue;
            if (isArrayUniform(def)) {
                this.setArrayUniform(name, value);
            }
            else if (isStructArrayUniform(def)) {
                this.setStructArrayUniform(name, value);
            }
        }
    }
    // ===========================================================================
    // Initialization
    // ===========================================================================
    initUBOs(gl) {
        const maxSize = gl.getParameter(gl.MAX_UNIFORM_BLOCK_SIZE);
        const maxBindings = gl.getParameter(gl.MAX_UNIFORM_BUFFER_BINDINGS);
        let bindingPoint = 0;
        for (const [name, def] of Object.entries(this._uniforms)) {
            if (isArrayUniform(def)) {
                const ubo = this.createPlainArrayUBO(gl, name, def, bindingPoint, maxSize, maxBindings);
                this._ubos.push(ubo);
                this._uboMap.set(name, ubo);
                bindingPoint++;
            }
            else if (isStructArrayUniform(def)) {
                const ubo = this.createStructArrayUBO(gl, name, def, bindingPoint, maxSize, maxBindings);
                this._ubos.push(ubo);
                this._uboMap.set(name, ubo);
                bindingPoint++;
            }
        }
    }
    createPlainArrayUBO(gl, name, def, bindingPoint, maxSize, maxBindings) {
        const byteSize = std140ByteSize(def.type, def.count);
        this.validateUBOSize(name, byteSize, bindingPoint, maxSize, maxBindings);
        const buffer = this.allocateBuffer(gl, name, byteSize, bindingPoint);
        return {
            kind: 'array',
            name, def, buffer, bindingPoint, byteSize,
            dirty: false,
            paddedData: new Float32Array(byteSize / 4),
            activeCount: 0,
            scratch: new Float32Array(tightFloatCount(def.type, def.count)),
        };
    }
    createStructArrayUBO(gl, name, def, bindingPoint, maxSize, maxBindings) {
        const layout = computeStructLayout(def.struct);
        const byteSize = std140StructByteSize(layout, def.count);
        this.validateUBOSize(name, byteSize, bindingPoint, maxSize, maxBindings);
        const buffer = this.allocateBuffer(gl, name, byteSize, bindingPoint);
        const fieldScratch = {};
        for (const field of layout.fields) {
            fieldScratch[field.name] = new Float32Array(field.tightFloats * def.count);
        }
        return {
            kind: 'struct',
            name, def, buffer, bindingPoint, byteSize,
            dirty: false,
            paddedData: new Float32Array(byteSize / 4),
            activeCount: 0,
            layout,
            fieldScratch,
        };
    }
    validateUBOSize(name, byteSize, bindingPoint, maxSize, maxBindings) {
        if (byteSize > maxSize) {
            throw new Error(`UBO '${name}' requires ${byteSize} bytes but GL MAX_UNIFORM_BLOCK_SIZE is ${maxSize}`);
        }
        if (bindingPoint >= maxBindings) {
            throw new Error(`Too many UBO uniforms: binding point ${bindingPoint} exceeds GL MAX_UNIFORM_BUFFER_BINDINGS (${maxBindings})`);
        }
    }
    allocateBuffer(gl, name, byteSize, bindingPoint) {
        const buffer = gl.createBuffer();
        if (!buffer)
            throw new Error(`Failed to create UBO buffer for '${name}'`);
        gl.bindBuffer(gl.UNIFORM_BUFFER, buffer);
        gl.bufferData(gl.UNIFORM_BUFFER, byteSize, gl.DYNAMIC_DRAW);
        gl.bindBuffer(gl.UNIFORM_BUFFER, null);
        gl.bindBufferBase(gl.UNIFORM_BUFFER, bindingPoint, buffer);
        return buffer;
    }
}
