/**
 * UniformManager - Custom uniform state, validation, UBO packing, and GL binding
 *
 * Manages the lifecycle of user-defined uniforms: scalar uniforms with dirty tracking,
 * and array uniforms backed by std140-packed UBOs (plain arrays and struct arrays).
 */
import { UniformValue, UniformValues, UniformDefinitions, ArrayUniformDefinition, StructArrayUniformDefinition } from '../project/types';
import { UniformStore } from '../uniforms/UniformStore';
import { StructLayout } from './std140';
import { PassUniformLocations } from './types';
/** Shared fields for all UBO-backed uniforms. */
interface UBOBase {
    name: string;
    buffer: WebGLBuffer;
    bindingPoint: number;
    byteSize: number;
    dirty: boolean;
    /** Pre-allocated std140-padded buffer, reused across frames */
    paddedData: Float32Array;
    /** Number of elements currently active (may be less than max count) */
    activeCount: number;
}
/** UBO for a plain typed array (e.g. vec3[100]) */
export interface PlainArrayUBO extends UBOBase {
    kind: 'array';
    def: ArrayUniformDefinition;
    /** Scratch buffer for flattening JS arrays, sized to tightFloatCount(type, count) */
    scratch: Float32Array;
}
/** UBO for a struct array (e.g. { pos: vec2, color: vec3 }[100]) */
export interface StructArrayUBO extends UBOBase {
    kind: 'struct';
    def: StructArrayUniformDefinition;
    layout: StructLayout;
    /** Per-field scratch buffers, each sized to field.tightFloats * count */
    fieldScratch: Record<string, Float32Array>;
}
export type UBOEntry = PlainArrayUBO | StructArrayUBO;
export declare class UniformManager {
    private _store;
    private _ubos;
    private _uboMap;
    private _dirtyScalars;
    private _uniforms;
    constructor(gl: WebGL2RenderingContext, uniforms: UniformDefinitions, initialData?: Record<string, unknown>);
    get ubos(): UBOEntry[];
    get store(): UniformStore;
    get(name: string): UniformValue | undefined;
    getAll(): UniformValues;
    /**
     * Set the value of a custom uniform.
     * Dispatches to the appropriate handler based on uniform type.
     */
    set(name: string, value: UniformValue): void;
    private setScalar;
    private setPlainArrayRaw;
    private setStructArrayRaw;
    setMultiple(values: Partial<UniformValues>): void;
    /**
     * Set an array uniform from structured JS arrays.
     * Flattens and packs automatically based on the uniform's declared type.
     */
    setArrayUniform(name: string, data: number[][] | number[]): void;
    /**
     * Set a single element of an array uniform by index.
     * Only repacks that element's std140 slot.
     */
    setArrayElement(name: string, index: number, value: number | number[]): void;
    /**
     * Set a struct array uniform from per-field data.
     * Omitted fields preserve their existing values in the buffer.
     */
    setStructArrayUniform(name: string, data: Record<string, number[][] | number[]>): void;
    /**
     * Set a single element of a struct array uniform by index.
     * Omitted fields preserve their existing values.
     */
    setStructArrayElement(name: string, index: number, data: Record<string, number | number[]>): void;
    /**
     * Set how many elements of a UBO uniform the shader should use.
     * Works for both plain array and struct array uniforms.
     */
    setActiveCount(name: string, count: number): void;
    /**
     * Bind custom uniform values to the current program.
     * Uploads dirty UBOs and re-binds changed scalar uniforms.
     */
    bindToProgram(gl: WebGL2RenderingContext, uniforms: PassUniformLocations): void;
    clearDirty(): void;
    markAllScalarsDirty(): void;
    bindUBOsToProgram(gl: WebGL2RenderingContext, program: WebGLProgram, customLocations: Map<string, WebGLUniformLocation | null>): void;
    dispose(gl: WebGL2RenderingContext): void;
    private applyInitialData;
    private initUBOs;
    private createPlainArrayUBO;
    private createStructArrayUBO;
    private validateUBOSize;
    private allocateBuffer;
}
export {};
//# sourceMappingURL=UniformManager.d.ts.map