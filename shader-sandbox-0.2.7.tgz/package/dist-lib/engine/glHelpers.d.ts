/**
 * Engine Layer - WebGL Helper Functions
 *
 * Low-level WebGL utilities for shader compilation, texture creation,
 * framebuffer management, and VAO setup.
 *
 * Based on docs/engine-spec.md
 */
/**
 * Compile a shader of given type from source. Throws on error.
 */
export declare function createShader(gl: WebGL2RenderingContext, type: GLenum, source: string): WebGLShader;
/**
 * Link a program from vertex + fragment source strings.
 * Throws with a descriptive error if link fails.
 */
export declare function createProgramFromSources(gl: WebGL2RenderingContext, vertexSource: string, fragmentSource: string): WebGLProgram;
/**
 * Create a full-screen triangle VAO.
 *
 * Attribute layout:
 *  - location 0: vec2 position in clip space.
 *
 * The triangle covers the entire screen using three vertices:
 * (-1, -1), (3, -1), (-1, 3)
 * This ensures all pixels are covered without needing two triangles.
 */
export declare function createFullscreenTriangleVAO(gl: WebGL2RenderingContext): WebGLVertexArrayObject;
/**
 * Create a float RGBA texture (no data) for use as a render target.
 * This MUST use an internal format compatible with EXT_color_buffer_float.
 *
 * Per spec: ALL render targets MUST be RGBA32F.
 */
export declare function createRenderTargetTexture(gl: WebGL2RenderingContext, width: number, height: number): WebGLTexture;
/**
 * Create a framebuffer with a single color attachment at COLOR_ATTACHMENT0.
 * Throws if framebuffer is not complete.
 */
export declare function createFramebufferWithColorAttachment(gl: WebGL2RenderingContext, texture: WebGLTexture): WebGLFramebuffer;
/**
 * Create a 1x1 black float texture for unused channels.
 *
 * Per spec: UNUSED CHANNELS MUST STILL BIND A 1×1 BLACK FLOAT TEXTURE.
 * This prevents NaN/undefined behavior when sampling unused channels.
 */
export declare function createBlackTexture(gl: WebGL2RenderingContext): WebGLTexture;
/**
 * Create a 256x3 keyboard state texture.
 *
 * Shadertoy keyboard texture format:
 * - Width: 256 (one column per ASCII keycode)
 * - Height: 3 (3 rows for different data)
 * - Row 0 (sample at y=0.25): Current key state (0.0 = up, 1.0 = down)
 * - Row 1: Unused
 * - Row 2 (sample at y=0.75): Toggle state (flips between 0.0 and 1.0 on each press)
 *
 * Returns the WebGLTexture. Data is initialized to all zeros.
 * Use updateKeyboardTexture() to update the state.
 */
export declare function createKeyboardTexture(gl: WebGL2RenderingContext): WebGLTexture;
/**
 * Update keyboard texture with current key states.
 *
 * @param gl WebGL context
 * @param texture The keyboard texture to update
 * @param keyStates Map of keycode -> current state (true = down, false = up)
 * @param toggleStates Map of keycode -> toggle state (0.0 or 1.0)
 */
export declare function updateKeyboardTexture(gl: WebGL2RenderingContext, texture: WebGLTexture, keyStates: Map<number, boolean>, toggleStates: Map<number, number>): void;
/**
 * Create a 2D texture from an HTMLImageElement (or ImageBitmap).
 * This is used for project textures (dog.png, noise.png, etc.)
 *
 * NOTE: actual image loading is done by the App; engine just gets an
 * already-loaded image object.
 */
export declare function createTextureFromImage(gl: WebGL2RenderingContext, image: HTMLImageElement | ImageBitmap, filter: 'nearest' | 'linear', wrap: 'clamp' | 'repeat'): WebGLTexture;
/**
 * Create a 512x2 audio texture (Shadertoy-compatible).
 * Row 0: frequency spectrum (FFT), Row 1: waveform.
 * Uses R8 format — data is in the red channel, sampled with texture().x
 */
export declare function createAudioTexture(gl: WebGL2RenderingContext): WebGLTexture;
/**
 * Update audio texture with frequency and waveform data.
 */
export declare function updateAudioTextureData(gl: WebGL2RenderingContext, texture: WebGLTexture, frequencyData: Uint8Array, waveformData: Uint8Array): void;
/**
 * Create a placeholder texture for video/webcam (1x1 black, RGBA).
 * Updated each frame with actual video data once ready.
 */
export declare function createVideoPlaceholderTexture(gl: WebGL2RenderingContext): WebGLTexture;
/**
 * Upload a video frame to a texture.
 */
export declare function updateVideoTexture(gl: WebGL2RenderingContext, texture: WebGLTexture, video: HTMLVideoElement): void;
/**
 * Create or update a script-uploaded texture.
 * Detects data type: Uint8Array → RGBA8, Float32Array → RGBA32F.
 */
export declare function createOrUpdateScriptTexture(gl: WebGL2RenderingContext, existing: WebGLTexture | null, width: number, height: number, data: Uint8Array | Float32Array): WebGLTexture;
//# sourceMappingURL=glHelpers.d.ts.map