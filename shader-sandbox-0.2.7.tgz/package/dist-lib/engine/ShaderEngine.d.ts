/**
 * Engine - Shadertoy Execution Engine
 *
 * Implements the execution model described in docs/engine-spec.md.
 *
 * Responsibilities:
 *  - Own WebGL resources for passes (programs, VAOs, textures, FBOs).
 *  - Execute passes each frame in Shadertoy order: BufferA→BufferB→BufferC→BufferD→Image.
 *  - Bind Shadertoy uniforms (iResolution, iTime, iTimeDelta, iFrame, iMouse).
 *  - Bind iChannel0..3 according to ChannelSource.
 */
import { ShaderProject, PassName, UniformValue, UniformValues } from '../project/types';
import { UniformStore } from '../uniforms/UniformStore';
import { EngineOptions, EngineStats, BuiltinUniformValues } from './types';
/** Line mapping for error reporting — maps compiled shader lines back to user source. */
export interface LineMapping {
    /** 1-indexed line where common.glsl starts in compiled source (0 if no common). */
    commonStartLine: number;
    /** Number of lines in common.glsl. */
    commonLines: number;
    /** 1-indexed line where user shader code starts in compiled source. */
    userCodeStartLine: number;
}
export declare class ShaderEngine {
    readonly project: ShaderProject;
    readonly gl: WebGL2RenderingContext;
    private _width;
    private _height;
    private _frame;
    private _time;
    private _lastStepTime;
    private _passes;
    private _textures;
    private _keyboardTexture;
    private _blackTexture;
    private _keyStates;
    private _toggleStates;
    private _compilationErrors;
    private _uniformMgr;
    private _media;
    private _scriptTextures;
    private _sharedVAO;
    private _disposed;
    private _viewNames;
    private _onAssetError?;
    constructor(opts: EngineOptions);
    initAudio(): Promise<void>;
    updateAudioTexture(): void;
    initWebcam(): Promise<void>;
    initVideo(src: string): Promise<void>;
    updateVideoTextures(): void;
    /** Whether this project uses audio channels. */
    get needsAudio(): boolean;
    /** Whether this project uses webcam channels. */
    get needsWebcam(): boolean;
    /** Get video sources that need initialization. */
    get videoSources(): string[];
    /**
     * Upload or update a named texture from JavaScript (for script channel).
     */
    updateTexture(name: string, width: number, height: number, data: Uint8Array | Float32Array): void;
    /**
     * Read pixels from a buffer pass (reads previous frame's data).
     */
    readPixels(passName: PassName, x: number, y: number, w: number, h: number): Uint8Array;
    get width(): number;
    get height(): number;
    get stats(): EngineStats;
    /**
     * Get shader compilation errors (if any occurred during initialization).
     * Returns empty array if all shaders compiled successfully.
     */
    getCompilationErrors(): Array<{
        passName: PassName;
        error: string;
        source: string;
        isFromCommon: boolean;
        originalLine: number | null;
        lineMapping: LineMapping;
    }>;
    /**
     * Check if there were any compilation errors.
     */
    hasErrors(): boolean;
    getUniformStore(): UniformStore;
    getUniformValue(name: string): UniformValue | undefined;
    getUniformValues(): UniformValues;
    setUniformValue(name: string, value: UniformValue): void;
    setUniformValues(values: Partial<UniformValues>): void;
    setArrayUniform(name: string, data: number[][] | number[]): void;
    setArrayElement(name: string, index: number, value: number | number[]): void;
    setActiveCount(name: string, count: number): void;
    setStructArrayUniform(name: string, data: Record<string, number[][] | number[]>): void;
    setStructArrayElement(name: string, index: number, data: Record<string, number | number[]>): void;
    /** Export UBO data for HTML export (copies current padded data). */
    getUBOExportData(): Array<{
        name: string;
        type: string;
        count: number;
        bindingPoint: number;
        paddedData: Float32Array;
        struct?: Record<string, string>;
    }>;
    /**
     * Get the framebuffer for the Image pass (for presenting to screen).
     */
    getImageFramebuffer(): WebGLFramebuffer | null;
    /**
     * Bind the Image pass output as the READ_FRAMEBUFFER for blitting to screen.
     *
     * After the ping-pong swap, the rendered output is in previousTexture,
     * but the framebuffer is attached to currentTexture. This method temporarily
     * attaches previousTexture so blitFramebuffer reads the correct data.
     */
    bindImageForRead(): boolean;
    /**
     * Restore the Image pass framebuffer to its normal state (attached to currentTexture).
     * Call after blitting to screen.
     */
    unbindImageForRead(): void;
    /**
     * Run one full frame of all passes.
     *
     * @param timeSeconds - global time in seconds (monotone, from App)
     * @param mouse - iMouse as [x, y, clickX, clickY]
     * @param touch - optional touch state for touch uniforms
     */
    step(timeSeconds: number, mouse: [number, number, number, number], mousePressed: boolean, touch?: {
        count: number;
        touches: BuiltinUniformValues['iTouch'];
        pinch: number;
        pinchDelta: number;
        pinchCenter: [number, number];
    }, crossViewStates?: Map<string, import('../project/types').CrossViewState>): void;
    /**
     * Resize all internal render targets to new width/height.
     * Does not reset time or frame count.
     */
    resize(width: number, height: number): void;
    /**
     * Reset frame counter and clear all render targets.
     * Used for playback controls to restart shader from frame 0.
     */
    reset(): void;
    /**
     * Update keyboard key state (called from App on keydown/keyup events).
     *
     * @param keycode ASCII keycode (e.g., 65 for 'A')
     * @param isDown true if key pressed, false if released
     */
    updateKeyState(keycode: number, isDown: boolean): void;
    /**
     * Update keyboard texture with current key states.
     * Should be called once per frame before rendering.
     */
    updateKeyboardTexture(): void;
    /**
     * Recompile a single pass with new GLSL source code.
     * Used for live editing - keeps the old shader running if compilation fails.
     *
     * @param passName - Name of the pass to recompile ('Image', 'BufferA', etc.)
     * @param newSource - New GLSL source code for the pass
     * @returns Object with success status and error message if failed
     */
    recompilePass(passName: PassName, newSource: string): {
        success: boolean;
        error?: string;
    };
    /**
     * Recompile common.glsl and all passes that use it.
     * Used for live editing of common code.
     *
     * @param newCommonSource - New GLSL source code for common.glsl
     * @returns Object with success status and errors for each failed pass
     */
    recompileCommon(newCommonSource: string): {
        success: boolean;
        errors: Array<{
            passName: PassName;
            error: string;
        }>;
    };
    /**
     * Delete all GL resources.
     */
    dispose(): void;
    private initExtensions;
    /**
     * Cache uniform locations for a compiled program.
     * Returns a PassUniformLocations object with all standard and custom uniform locations.
     */
    private cacheUniformLocations;
    /**
     * Initialize external textures based on project.textures.
     *
     * NOTE: This function as written assumes that actual image loading
     * is handled elsewhere. For now we just construct an empty array.
     * In a real implementation, you would load images here.
     */
    private initProjectTextures;
    /**
     * Compile shaders, create VAOs/FBOs/textures, and build RuntimePass array.
     */
    private initRuntimePasses;
    /**
     * Build complete fragment shader source with Shadertoy boilerplate.
     */
    private buildFragmentShader;
    /**
     * Set view names for multi-view projects.
     * This enables cross-view uniforms (iMouse_viewName, iResolution_viewName, etc.)
     * Must be called before shader compilation.
     */
    setViewNames(names: string[]): void;
    private executePass;
    private bindBuiltinUniforms;
    private bindChannelTextures;
    /**
     * Bind named samplers (standard mode).
     * Each named sampler gets its own texture unit.
     */
    private bindNamedSamplers;
    /**
     * Resolve a ChannelSource to an actual WebGLTexture to bind.
     */
    private resolveChannelTexture;
    /**
     * Resolve a ChannelSource to its resolution [width, height].
     * Returns [0, 0] for unused channels.
     */
    private resolveChannelResolution;
    /**
     * Swap current and previous textures for a pass (ping-pong).
     * Also reattach framebuffer to new current texture.
     */
    private swapPassTextures;
}
//# sourceMappingURL=ShaderEngine.d.ts.map