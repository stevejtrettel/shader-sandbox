/**
 * MediaManager - Audio, video, and webcam texture management
 *
 * Owns the lifecycle of media inputs (microphone, webcam, video files)
 * and their corresponding WebGL textures. The engine calls update methods
 * per-frame and resolves textures when binding channels.
 */
import { ShaderProject } from '../project/types';
import { RuntimeAudioTexture, RuntimeVideoTexture } from './types';
export declare class MediaManager {
    private _audioTexture;
    private _needsAudio;
    private _videoTextures;
    constructor(gl: WebGL2RenderingContext, project: ShaderProject);
    get needsAudio(): boolean;
    get needsWebcam(): boolean;
    get videoSources(): string[];
    get audioTexture(): RuntimeAudioTexture | null;
    get videoTextures(): RuntimeVideoTexture[];
    initAudio(): Promise<void>;
    initWebcam(): Promise<void>;
    initVideo(src: string): Promise<void>;
    updateAudioTexture(gl: WebGL2RenderingContext): void;
    updateVideoTextures(gl: WebGL2RenderingContext): void;
    dispose(gl: WebGL2RenderingContext): void;
    private getAllChannelSources;
}
//# sourceMappingURL=MediaManager.d.ts.map