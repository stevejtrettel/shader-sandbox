/**
 * Engine Layer - Type Definitions
 *
 * Internal types used by ShaderEngine for managing WebGL resources.
 * Based on docs/engine-spec.md
 */
export {};
