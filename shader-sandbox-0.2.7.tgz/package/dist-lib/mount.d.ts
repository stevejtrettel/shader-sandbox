/**
 * mount() — Core programmatic API for mounting a shader project into a DOM element.
 *
 * Consolidates all handler wiring (recompile + uniform callbacks)
 * previously split between main.ts and embed.ts.
 *
 * Does NOT import generatedLoader — the project is always passed in by the caller.
 * Does NOT import base.css — callers handle their own global resets.
 */
import './styles/theme.css';
import { ShaderProject, MultiViewProject, ThemeMode, UniformValue } from './project/types';
import { LayoutMode } from './layouts/types';
export interface MountOptions {
    /** The loaded project to render. */
    project: ShaderProject | MultiViewProject;
    /** Add pane decoration (border-radius, box-shadow). Default: true. */
    styled?: boolean;
    /** Canvas pixel ratio. Default: window.devicePixelRatio. */
    pixelRatio?: number;
    /** Override the layout mode from config. */
    layout?: LayoutMode;
    /** Override the optional master UI switch. */
    controls?: boolean;
    /** Override the FPS / resolution overlay. */
    stats?: boolean;
    /** Override the playback bar. */
    playback?: boolean;
    /** Override the uniforms UI presentation: 'panel' | 'inline' | 'off'. */
    uniformsUI?: 'panel' | 'inline' | 'off';
    /** Override the color theme. */
    theme?: ThemeMode;
    /** Override whether the shader starts paused. */
    startPaused?: boolean;
    /** Override whether iMouse.zw stays positive after release (sticky mouse). */
    stickyMouse?: boolean;
}
/** Consumer-facing options (everything except `project`, which is loaded by the caller). */
export type MountPresentationOptions = Omit<MountOptions, 'project'>;
export interface MountHandle {
    pause(): void;
    resume(): void;
    reset(): void;
    readonly isPaused: boolean;
    setUniform(name: string, value: UniformValue): void;
    getUniform(name: string): UniformValue | undefined;
    destroy(): void;
}
/**
 * Mount a shader project into a DOM element.
 *
 * @param el - Target DOM element (will be filled 100%)
 * @param options - Mount configuration
 * @returns Handle with playback controls, uniform access, and destroy() cleanup
 */
export declare function mount(el: HTMLElement, options: MountOptions): MountHandle;
//# sourceMappingURL=mount.d.ts.map